"""Adapt the audited packager's private-file policy to nested two-arm evidence.

Bootstrap filtering, archive construction and byte accounting use the unchanged
audited implementation. This adapter only excludes private payloads at any depth.
"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PRIVATE_DIRS = {"native-build-cache", "native-artifacts", "input", "source"}
PRIVATE_SUFFIXES = (
    ".safetensors", ".so", ".o", ".cubin", ".pack", ".ptx", ".ttir",
    ".ttgir", ".llir", ".source", ".tar.gz", ".tgz", ".zst",
)


def load_base():
    path = HERE / "package_base.py"
    expected = next(
        row["sha256"] for row in json.loads((HERE / "tooling-provenance.json").read_text())["copied_tools"]
        if row["name"] == path.name
    )
    assert hashlib.sha256(path.read_bytes()).hexdigest() == expected
    spec = importlib.util.spec_from_file_location("delay_public_base", path)
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    return base


def exclusion(relative):
    if any(part in PRIVATE_DIRS for part in relative.parts[:-1]):
        return "Private native/build/source material; exact identity is retained in the private archive and indexed by hash."
    if relative.name.endswith(PRIVATE_SUFFIXES):
        return "Private tensor/binary/archive payload; exact bytes remain in the preserved private archive."
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("raw-root", "private-archive", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--expected-private-sha", required=True)
    args = parser.parse_args()
    base = load_base()
    base.exclusion = exclusion
    report = base.package(args.raw_root, args.private_archive, args.output, args.expected_private_sha)
    policy = {
        "status": "passed",
        "adapter_sha256": base.file_sha(__file__),
        "audited_packager_sha256": base.file_sha(HERE / "package_base.py"),
        "public_archive_sha256": report["archive_sha256"],
        "private_archive_sha256": args.expected_private_sha,
        "policy": "Only nested private build/source/native payloads and tensor/binary archives are excluded. Every scientific record, log, trace and winner cache is byte-exact; only the documented bootstrap import-inventory entries may be derived.",
        "limitations": "Public scientific reanalysis does not replace the private source/native integrity audit. Original records and their original hash references are never rewritten.",
    }
    encoded = json.dumps(policy, indent=2).encode() + b"\n"
    base.scanned_payload("publication-policy.json", encoded)
    (args.output / "publication-policy.json").write_bytes(encoded)
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
