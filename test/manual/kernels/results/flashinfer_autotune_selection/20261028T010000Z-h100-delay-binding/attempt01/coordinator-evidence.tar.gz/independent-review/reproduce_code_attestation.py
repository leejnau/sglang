"""Native-free reproduction of code-object serialization false mismatch."""

import argparse
import hashlib
import importlib.util
import json
import marshal
import sys
import tempfile
from pathlib import Path
from types import CodeType, ModuleType, SimpleNamespace


def digest(value):
    return hashlib.sha256(value).hexdigest()


def run(helper_path):
    spec = importlib.util.spec_from_file_location('study_binding_fixture', helper_path)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    parent = ModuleType('attestation_fixture')
    parent.__path__ = []
    jit = ModuleType('attestation_fixture.jit.tllm_utils')
    jit.gen_trtllm_utils_module = lambda: SimpleNamespace(build_and_load=lambda: None)
    ffi = ModuleType('tvm_ffi')
    sys.modules.update({'attestation_fixture': parent, 'attestation_fixture.jit.tllm_utils': jit, 'tvm_ffi': ffi})
    rows = []
    with tempfile.TemporaryDirectory(prefix='source-identity-') as scratch:
        for arm in ('baseline', 'patched'):
            path = Path(scratch) / (arm + '.py')
            path.write_bytes(helper.wrapper_source(arm))
            name = 'attestation_fixture.' + arm
            spec = importlib.util.spec_from_file_location(name, path)
            module = importlib.util.module_from_spec(spec)
            sys.modules[name] = module
            spec.loader.exec_module(module)
            compiled = compile(path.read_bytes(), str(path), 'exec', dont_inherit=True)
            expected = next(c for c in compiled.co_consts if isinstance(c, CodeType) and c.co_name == 'delay_kernel')
            actual = module.delay_kernel.__code__
            expected_serial = marshal.dumps(expected)
            actual_serial = marshal.dumps(actual)
            fields = ('co_argcount', 'co_posonlyargcount', 'co_kwonlyargcount', 'co_nlocals', 'co_stacksize', 'co_flags', 'co_code', 'co_consts', 'co_names', 'co_varnames', 'co_filename', 'co_name', 'co_qualname', 'co_firstlineno', 'co_linetable', 'co_exceptiontable', 'co_freevars', 'co_cellvars')
            differences = [key for key in fields if getattr(expected, key) != getattr(actual, key)]
            altered = actual.replace(co_code=compile('def different():\n    return 99\n', str(path), 'exec', dont_inherit=True).co_consts[0].co_code)
            rows.append({'arm': arm, 'source_sha256': digest(path.read_bytes()), 'source_exact': path.read_bytes() == helper.wrapper_source(arm), 'code_objects_equal': expected == actual, 'semantic_field_differences': differences, 'marshal_bytes_equal': expected_serial == actual_serial, 'marshal_expected_sha256': digest(expected_serial), 'marshal_actual_sha256': digest(actual_serial), 'marshal_first_difference': next((i for i, (a,b) in enumerate(zip(expected_serial, actual_serial)) if a != b), None), 'modified_bytecode_rejected_by_equality': expected != altered})
    return {'python': sys.version, 'native_or_gpu_imports': False, 'study_helper_sha256': digest(helper_path.read_bytes()), 'rows': rows, 'interpretation': 'marshal is a transport encoding with reference/intern flags, not a canonical code-object semantic identity. Source bytes and structural code equality can agree while marshal bytes differ.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--helper', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = run(args.helper)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
