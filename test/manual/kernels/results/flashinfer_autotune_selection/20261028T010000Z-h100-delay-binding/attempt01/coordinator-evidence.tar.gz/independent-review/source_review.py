"""Record the independent manual integration review at frozen source."""

import hashlib
import json
from pathlib import Path

ROOT = Path('/private/tmp/sglang-delay-binding-study')
BATCH = ROOT / 'test/manual/kernels/results/flashinfer_autotune_selection/20261028T010000Z-h100-delay-binding'
DEST = Path(__file__).parent
files = [
    BATCH / name
    for name in ('plan.json', 'schedule.json', 'run_current.py', 'launch.py', 'stage.sh', 'analyze.py')
] + [
    ROOT / 'test/manual/kernels/flashinfer_autotune_delay_binding.py',
    BATCH.parent / '20261027T020000Z-h100-mlp-confirmation/analyzer.py',
    BATCH.parent / '20261026T230000Z-h100-finalist-confirmation/analyzer.py',
]
report = {
    'status': 'passed',
    'execution_commit': 'b687aecf9e1a4e1dd0e7ae407b239b60759dfd8c',
    'kind': 'independent manual source and interface review, no CUDA execution',
    'files_sha256': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
    'findings': [],
    'reviewed_contracts': [
        'Canonical source and native paths are identical in both container arms; source mount roots differ only outside containers.',
        'Full restored source inventories differ only in the exact pinned delay wrapper; native provider hashes and Ninja no-work checks are retained.',
        'Launcher passes one outer --output; adapter appends that same output once for the unchanged inherited MLP worker.',
        'New outer bootstrap binds the adapter hash; unchanged admission analyzer receives the same-process .binding.json that binds the historical MLP worker hash and result.',
        'Per-arm raw paths, trace paths, saved cache paths and inherited analysis inputs agree.',
        'Ordering and admission gates precede the fixed 16 timing launches; ledger requires sequential distinct container IDs rather than distinct namespace PIDs.',
        'Paired analysis scores original and hypothetical decisions on the same retained post-confirmation graph measurements, with block-level resampling and no historical pooling.',
    ],
    'limits': 'This review does not establish runtime ordering, model numerics, runtime source availability, native execution or performance. Raw evidence must be reviewed after qualification.',
}
(DEST / 'source-review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'files_reviewed': len(files), 'report': str(DEST / 'source-review.json')}))
