"""Describe the incomplete first attempt without treating it as a paired result."""

import argparse
import hashlib
import json
import statistics
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-root", type=Path, required=True)
    parser.add_argument("--publication", type=Path, required=True)
    parser.add_argument("--cpu-reproduction", type=Path, required=True)
    args = parser.parse_args()
    raw = args.raw_root
    baseline = json.loads((raw / "ordering/baseline.json").read_text())
    failed = json.loads((raw / "ordering/patched.bootstrap.json").read_text())
    ledger = json.loads((raw / "launch-ledger.json").read_text())
    reproduction = json.loads(args.cpu_reproduction.read_text())
    assert baseline["status"] == "passed" and baseline["arm"] == "baseline"
    assert failed["status"] == "failed" and failed["phase"] == "bootstrap"
    assert not (raw / "ordering/patched.json").exists()
    assert not (raw / "ordering-gate.json").exists()
    assert [(row["phase"], row["arm"], row["returncode"]) for row in ledger["entries"]] == [
        ("ordering", "baseline", 0), ("ordering", "patched", 1)
    ]
    assert len({row["container_id"] for row in ledger["entries"]}) == 2
    assert ledger["entries"][0]["result_sha256"] == digest(raw / "ordering/baseline.json")
    assert ledger["entries"][1]["result_sha256"] is None
    assert all(row["cleanup_error"] is None for row in ledger["entries"])
    observations = {}
    for section in ("controlled_streams", "natural_streams"):
        observations[section] = []
        for row in baseline[section]:
            assert len(row["samples"]) == 5
            computed = {
                key: statistics.median(sample[key] for sample in row["samples"])
                for key in ("event_ms", "host_ms", "residual_sync_ms")
            }
            assert row["medians"] == computed
            observations[section].append({
                "stream_kind": row["stream_kind"],
                "forced_conflict": row["forced_conflict"],
                "ordering_observed": row["ordering_observed"],
                "reference_ms": row["reference_ms"],
                "medians": computed,
            })
    profiler = baseline["actual_profiler"]
    observations["actual_profiler"] = {
        "settings": profiler["settings"],
        "forced_conflict": profiler["forced_conflict"],
        "samples": len(profiler["samples"]),
        "medians": {
            key: statistics.median(sample[key] for sample in profiler["samples"])
            for key in ("profiler_ms", "host_ms", "residual_sync_ms")
        },
        "all_numerics_passed": all(sample["numerics"] for sample in profiler["samples"]),
    }
    patched_cpu = next(row for row in reproduction["rows"] if row["arm"] == "patched")
    assert patched_cpu["source_exact"] and patched_cpu["code_objects_equal"]
    assert not patched_cpu["semantic_field_differences"]
    assert patched_cpu["marshal_bytes_equal"] is False
    assert patched_cpu["modified_bytecode_rejected_by_equality"]
    refs = [
        "ordering/baseline.json", "ordering/baseline.bootstrap.json",
        "ordering/patched.bootstrap.json", "ordering/patched.log",
        "launch-ledger.json", "manifest.json", "source-snapshot.json",
    ]
    report = {
        "schema_version": 1,
        "status": "incomplete",
        "attempt": "attempt01",
        "source_commit": json.loads((raw / "source-snapshot.json").read_text())["source_commit"],
        "scope": "Baseline-only H100 ordering observations; no patched diagnostic or MLP comparison was executed.",
        "completed_processes": {"baseline_ordering": 1, "patched_ordering": 0, "mlp_admission": 0, "mlp_timing": 0},
        "failure": {
            "phase": failed["phase"],
            "error": failed["error"],
            "classification": "Research-harness code-identity guard false positive, reproduced independently on CPU.",
            "cause": "Equal code objects compiled from exact source produced unequal marshal encodings. Marshal bytes are not a canonical semantic identity.",
            "patched_runtime_diagnostics_executed": False,
            "paired_ordering_gate_passed": False,
        },
        "baseline_observations": observations,
        "interpretation": [
            "The baseline observed the intended forced-conflict negative control on both streams.",
            "With natural ambient state, baseline default-stream ordering succeeded and nondefault-stream ordering failed in this process.",
            "The actual-profiler probe left about 5 ms of device-wide residual synchronization work while profiling on the natural nondefault Torch stream. This is diagnostic evidence about the delay ordering, not an MLP ranking or serving-performance measurement.",
        ],
        "limitations": [
            "No patched diagnostic result exists, so this attempt does not qualify the proposed fix.",
            "No admission, timing block, finalist confirmation, or MLP performance estimate exists.",
            "Baseline graph replay was deliberately excluded from the negative control; patched graph replay did not execute.",
            "The CPU reproduction used no GPU or native imports and cannot replace CUDA qualification.",
        ],
        "raw_private_sha256": {name: digest(raw / name) for name in refs},
        "cpu_reproduction_sha256": digest(args.cpu_reproduction),
        "summary_source_sha256": digest(Path(__file__)),
        "publication_difference_audit_sha256": digest(args.publication / "publication-difference-audit.json"),
    }
    encoded = json.dumps(report, indent=2, allow_nan=False).encode() + b"\n"
    forbidden = bytes.fromhex("766c6c6d")
    assert forbidden not in encoded.lower()
    assert forbidden not in args.cpu_reproduction.read_bytes().lower()
    output = args.publication / "failure-summary.json"
    cpu_copy = args.publication / "code-attestation-reproduction.json"
    assert not output.exists() and not cpu_copy.exists()
    output.write_bytes(encoded)
    cpu_copy.write_bytes(args.cpu_reproduction.read_bytes())
    assert digest(cpu_copy) == digest(args.cpu_reproduction)
    print(json.dumps({"status": "prepared", "summary": str(output), "summary_sha256": digest(output)}))


if __name__ == "__main__":
    main()
