"""Recompute completed baseline observations from an incomplete attempt."""

import argparse
import hashlib
import json
import statistics
from pathlib import Path


def audit(path):
    data = json.loads(path.read_text())
    bootstrap = json.loads(path.with_suffix('.bootstrap.json').read_text())
    assert data['status'] == bootstrap['status'] == 'passed'
    assert data['attestation_before'] == data['attestation_after'] == bootstrap['binding_before'] == bootstrap['binding_after']
    assert bootstrap['result_sha256'] == hashlib.sha256(path.read_bytes()).hexdigest()
    references = {r['stream_kind']: statistics.median(s['event_ms'] for s in r['samples']) for r in data['reference']}
    summary = {}
    for field in ('controlled_streams', 'natural_streams'):
        summary[field] = []
        for row in data[field]:
            medians = {key: statistics.median(s[key] for s in row['samples']) for key in ('event_ms', 'host_ms', 'residual_sync_ms')}
            if field == 'controlled_streams':
                assert row['restored'] and row['forced_conflict'] and row['torch_stream'] != row['ambient_ffi_stream']
                assert medians['event_ms'] < references[row['stream_kind']] / 2
            summary[field].append({'stream_kind': row['stream_kind'], 'torch_stream': row['torch_stream'], 'ambient_ffi_stream': row['ambient_ffi_stream'], **medians})
    profiler = data['actual_profiler']
    assert all(row['numerics'] for row in profiler['samples'])
    summary['profiler'] = {key: statistics.median(s[key] for s in profiler['samples']) for key in ('profiler_ms', 'host_ms', 'residual_sync_ms')}
    witness = data['attestation_before']
    return {'status': 'partial baseline evidence validated; overall attempt failed before patched diagnostics', 'source_sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'wrapper_sha256': witness['wrapper_sha256'], 'ffi_version': witness['tvm_ffi_version'], 'native_references_ms': references, 'summary': summary, 'limits': 'No patched ordering result or ranking cohort; baseline evidence alone does not qualify the correction.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--baseline-json', type=Path, required=True)
    parser.add_argument('--compare-report', type=Path, required=True)
    args = parser.parse_args()
    assert audit(args.baseline_json) == json.loads(args.compare_report.read_text())
    print('Partial baseline report reproduced exactly.')
