"""Independent exact-difference check; imports no publication implementation."""

import argparse
import copy
import hashlib
import gzip
import json
from pathlib import Path, PurePosixPath
import tarfile


TOKEN = bytes.fromhex("766c6c6d")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def read_archive(path, prefix):
    rows = {}
    with tarfile.open(path, "r:gz") as archive:
        for member in archive:
            name = PurePosixPath(member.name)
            assert not name.is_absolute() and ".." not in name.parts and name.parts[0] == prefix
            if member.isdir():
                continue
            assert member.isfile()
            rel = str(PurePosixPath(*name.parts[1:]))
            assert rel not in rows
            rows[rel] = archive.extractfile(member).read()
            assert len(rows[rel]) == member.size
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("private-archive", "public", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--expected-private-sha", required=True)
    parser.add_argument("--expected-public-sha", required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    assert sha(args.private_archive.read_bytes()) == args.expected_private_sha
    public_archive = args.public / "raw-public.tar.gz"
    assert sha(public_archive.read_bytes()) == args.expected_public_sha
    original = read_archive(args.private_archive, "attempt01")
    published = read_archive(public_archive, "raw")
    manifest = json.loads(published["public-manifest.json"])
    assert published["public-manifest.json"] == (args.public / "public-manifest.json").read_bytes()
    rows = {row["path"]: row for row in manifest["files"]}
    original_paths = {sha(name.encode()): name for name in original}
    assert len(original_paths) == len(original)
    excluded = {(row["path"] if "path" in row else original_paths[row["path_sha256"]]): row for row in manifest["excluded_private_files"]}
    assert len(excluded) == len(manifest["excluded_private_files"])
    assert set(rows).isdisjoint(excluded)
    assert set(rows) | set(excluded) == set(original)
    assert set(published) == set(rows) | {"public-manifest.json"}
    exact = derived = omitted = 0
    for name, row in rows.items():
        before, after = original[name], published[name]
        assert sha(before) == row["private_sha256"] and len(before) == row["private_size_bytes"]
        assert sha(after) == row["public_sha256"] and len(after) == row["public_size_bytes"]
        assert (args.public / "raw" / name).read_bytes() == after
        assert TOKEN not in name.encode().lower() and TOKEN not in after.lower()
        if row["mode"] == "byte_exact":
            assert before == after
            exact += 1
            continue
        assert row["mode"] == "derived_inventory_only" and name.endswith(".bootstrap.json")
        expected, actual = json.loads(before), json.loads(after)
        inventories = []
        modules = expected["import"].get("source_modules")
        if modules is not None:
            dropped = {key: value for key, value in modules.items() if TOKEN in canonical({key: value}).lower()}
            if dropped:
                expected["import"]["source_modules"] = {key: value for key, value in modules.items() if key not in dropped}
                inventories.append({"path": "import.source_modules", "original_count": len(modules), "omitted_count": len(dropped), "original_inventory_sha256": sha(canonical(modules)), "omitted_entry_sha256": [sha(canonical({key: value})) for key, value in sorted(dropped.items())]})
        for index, provider in enumerate(expected["import"].get("aot_providers", [])):
            modules = provider.get("modules")
            if modules is None:
                continue
            dropped = [name for name in modules if TOKEN in name.encode().lower()]
            if dropped:
                provider["modules"] = [name for name in modules if name not in dropped]
                inventories.append({"path": f"import.aot_providers[{index}].modules", "original_count": len(modules), "omitted_count": len(dropped), "original_inventory_sha256": sha(canonical(modules)), "omitted_entry_sha256": [sha(canonical(name)) for name in dropped]})
        metadata = actual["public_evidence_derivation"]
        assert metadata == row["derivation"] and metadata["inventories"] == inventories
        assert metadata["private_file_sha256"] == sha(before) and metadata["private_file_size_bytes"] == len(before)
        assert metadata["omitted_entries"] == sum(item["omitted_count"] for item in inventories)
        expected["public_evidence_derivation"] = copy.deepcopy(metadata)
        assert expected == actual
        assert json.dumps(expected, indent=2, allow_nan=False).encode() + b"\n" == after
        derived += 1
        omitted += metadata["omitted_entries"]
    for name, row in excluded.items():
        relative = PurePosixPath(name)
        assert any(part in {"native-build-cache", "native-artifacts", "input", "source"} for part in relative.parts[:-1]) or relative.name.endswith((".safetensors", ".so", ".o", ".cubin", ".pack", ".ptx", ".ttir", ".ttgir", ".llir", ".source", ".tar.gz", ".tgz", ".zst"))
        assert sha(original[name]) == row["sha256"] and len(original[name]) == row["size_bytes"]
    for name, payload in published.items():
        if name.endswith(".gz"):
            expanded = gzip.decompress(payload)
            assert len(expanded) <= 512 * 1024 * 1024 and TOKEN not in expanded.lower()
    result = {"status": "passed", "audit_source_sha256": sha(Path(__file__).read_bytes()), "private_archive_sha256": args.expected_private_sha, "public_archive_sha256": args.expected_public_sha, "original_files": len(original), "public_members": len(published), "byte_exact_files": exact, "derived_bootstraps": derived, "omitted_inventory_entries": omitted, "indexed_private_exclusions": len(excluded), "scientific_fields_modified": 0, "limitations": ["Publication accounting and exact-difference verification only; no scientific reinterpretation."]}
    assert TOKEN not in json.dumps(result).encode().lower()
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
