"""Independent arithmetic on all frozen MLP cells; no study analyzer imports."""

import argparse
import hashlib
import json
import math
import random
import statistics
from pathlib import Path

WORKER = "a8532276afc70ae1b70e12eaf9fc722fa7b29ed6102407360dd93708a7789157"
FIXTURE = "0e456c2d371906be235c5fb405fc20c0a969f672ee26722264ae6761b1838809"
checks = 0


def require(value, why):
    global checks
    checks += 1
    if not value:
        raise ValueError(why)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def finite_positive(x):
    return math.isfinite(x) and x > 0


def close(a, b):
    return math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-15)


def cell(path):
    d = read(path)
    require(d['status'] == 'success' and d['worker_sha256'] == WORKER, 'valid unchanged MLP worker')
    require(d['fixture']['tensor_file_sha256'] == FIXTURE and d['fixture']['shape'] == [144, 1024, 3072], 'frozen fixture')
    require(d['all_samples_retained'] and not d['protocol_errors'] and not d['forbidden_profile_attempts'], 'retention and protocol')
    require(all(r['passed'] for r in d['correctness'] + d['profile_correctness']), 'all numerical checks')
    profiles = d['startup']['profiles']
    require(len(profiles) == d['startup']['profile_attempts'] == 81, '81 actual startup profiles')
    runtime = [r for r in profiles if r['m'] == 144]
    require(len(runtime) == 9, 'nine runtime candidates')
    for r in profiles:
        require(r['error'] is None and finite_positive(r['elapsed_ms']), 'valid candidate profile')
        s = r['settings']
        require(s['warmup'] == 3 and s['repeat'] == 10 and s['stream_delay_micro_secs'] == 5000, 'frozen timing settings')
        require(s['measurement_policy'] is None and not s['config']['use_cuda_graph'] and not s['config']['use_cold_l2_cache'], 'unspecified policy and eager hot L2')
    default = [r for r in runtime if r['tactic'] == -1]
    require(len(default) == 1, 'single default candidate')
    default = default[0]
    explicit = min((r for r in runtime if r['tactic'] != -1), key=lambda r: r['elapsed_ms'])
    actual = min(runtime, key=lambda r: r['elapsed_ms'])
    require(d['natural']['tactic'] == actual['tactic'] and d['natural']['first_pass_profile_index'] == actual['index'], 'actual original winner matches first finite minimum')
    require(d['finalist']['tactic'] == explicit['tactic'] and d['finalist']['profile_index'] == explicit['index'], 'explicit finalist matches observed order')
    require(d['natural']['frozen_ns'] < d['confirmation']['started_ns'], 'original frozen before confirmation')

    confirmation = d['confirmation']
    require(len(confirmation['rounds']) == 12 and len(d['diagnostic_profile_attempts']) == 24, 'twelve balanced confirmation pairs')
    confirm_logs = []
    confirm_first = []
    for i, r in enumerate(confirmation['rounds']):
        by_role = {m['role']: m for m in r['measurements']}
        require(set(by_role) == {'winner', 'default'} and r['index'] == i, 'confirmation role pairing')
        require([m['role'] for m in r['measurements']] == r['order'], 'confirmation order')
        confirm_first.append(r['order'][0])
        for role, m in by_role.items():
            p = d['diagnostic_profile_attempts'][m['attempt_index']]
            require(p['error'] is None and finite_positive(m['elapsed_ms']) and p['elapsed_ms'] == m['elapsed_ms'], 'actual confirmation profile')
            require(m['tactic'] == (-1 if role == 'default' else explicit['tactic']), 'same confirmation finalist')
        confirm_logs.append(math.log(by_role['winner']['elapsed_ms'] / by_role['default']['elapsed_ms']))
    require(confirm_first.count('default') == confirm_first.count('winner') == 6, 'balanced confirmation orders')
    confirm_log = statistics.median(confirm_logs)
    shadow_explicit = confirm_log < 0
    require(close(confirm_log, confirmation['median_log_ratio']), 'confirmation arithmetic')
    require(confirmation['decision_role'] == ('winner' if shadow_explicit else 'default'), 'hypothetical confirmation decision')
    require(confirmation['decision_tactic'] == (explicit['tactic'] if shadow_explicit else -1), 'hypothetical tactic')
    require(all(g['capture_started_ns'] > confirmation['decided_ns'] for g in d['graphs']), 'graphs captured after confirmation')

    require(len(d['rounds']) == 24, 'all 24 graph windows')
    graph_logs, default_logs = [], []
    graph_first = []
    for i, r in enumerate(d['rounds']):
        by_role = {m['graph_id']: m for m in r['measurements']}
        require(set(by_role) == {'winner', 'default'} and r['index'] == i, 'graph role pairing')
        require([m['graph_id'] for m in r['measurements']] == r['order'], 'graph order')
        graph_first.append(r['order'][0])
        for m in by_role.values():
            require(m['replays'] == 16 and m['prequeue_cycles'] == 10000000, 'fixed graph queue recipe')
            require(m['start_query_error'] is None and m['start_event_complete_after_enqueue'] is False and m['queue_evidence'] == 'start_pending_after_enqueue', 'queued graph timing')
            require(m['profile_attempts_before'] == m['profile_attempts_after'] == 81, 'no graph profiling')
            require(finite_positive(m['gpu_event_per_replay_ms']) and close(m['gpu_event_batch_ms'] / 16, m['gpu_event_per_replay_ms']), 'event time per replay')
        graph_logs.append(math.log(by_role['winner']['gpu_event_per_replay_ms'] / by_role['default']['gpu_event_per_replay_ms']))
        default_logs.append(math.log(by_role['default']['gpu_event_per_replay_ms']))
    require(graph_first.count('default') == graph_first.count('winner') == 12, 'balanced graph orders')
    graph_log = statistics.median(graph_logs)
    original_explicit = actual['tactic'] != -1
    original_log = graph_log if original_explicit else 0.0
    shadow_log = graph_log if shadow_explicit else 0.0
    final = d['final']
    require(final['profile_attempts'] == 81 and not final['forbidden_profile_attempts'], 'no late profiling')
    require(final['cache_unchanged'] and final['operands_unchanged'] and d['natural']['cache_preserved_after_confirmation'], 'immutable original cache and operands')
    require(d['startup']['cache_sha256'] == d['natural']['cache_sha256'] == final['cache_sha256'], 'v1 persistence identity unchanged')
    require(d['startup']['cache_state_sha256'] == d['natural']['cache_state_sha256'] == final['cache_state_sha256'], 'in-memory cache identity unchanged')
    require(not final['active_v2'] and not final['is_tuning_mode'] and not final['managed_store'] and final['measurement_policy'] is None and final['tuning_contexts'] == 0, 'context exited with unchanged policy')
    original_slower = original_log > min(0.0, graph_log)
    shadow_slower = shadow_log > min(0.0, graph_log)
    return {
        'block': d['block'], 'capture_order': d['capture_order'],
        'raw_sha256': sha(path), 'original_tactic': actual['tactic'], 'finalist_tactic': explicit['tactic'],
        'shadow_tactic': confirmation['decision_tactic'], 'original_explicit': original_explicit, 'shadow_explicit': shadow_explicit,
        'first_pass_explicit_over_default': explicit['elapsed_ms'] / default['elapsed_ms'],
        'confirmation_explicit_over_default': math.exp(confirm_log), 'graph_explicit_over_default': math.exp(graph_log),
        'original_log': original_log, 'shadow_log': shadow_log, 'shadow_over_original_log': shadow_log - original_log,
        'default_graph_log_ms': statistics.median(default_logs),
        'startup_host_ms': (d['startup']['ended_ns'] - d['startup']['started_ns']) / 1e6,
        'confirmation_host_ms': (confirmation['ended_ns'] - confirmation['started_ns']) / 1e6,
        'confirmation_profiler_host_ms': sum(p['ended_ns'] - p['started_ns'] for p in d['diagnostic_profile_attempts']) / 1e6,
        'recorded_numerical_checks': {'execution': len(d['correctness']), 'profiling': len(d['profile_correctness'])},
        'reversal': original_explicit != shadow_explicit,
        'original_slower_point': original_slower, 'shadow_slower_point': shadow_slower,
        'corrected_slower_point': original_slower and not shadow_slower,
        'introduced_slower_point': shadow_slower and not original_slower,
        'remaining_slower_point': original_slower and shadow_slower,
    }


def percentile(ordered, q):
    position = (len(ordered) - 1) * q
    lo = math.floor(position)
    hi = math.ceil(position)
    return ordered[lo] + (ordered[hi] - ordered[lo]) * (position - lo)


def audit(root):
    rows = {arm: [cell(root / arm / f'block{i}-auto_synthetic-timing.json') for i in range(8)] for arm in ('baseline', 'patched')}
    for arm in rows:
        require([r['block'] for r in rows[arm]] == list(range(8)), 'complete assigned blocks')
    metrics = ('original_log', 'shadow_log', 'shadow_over_original_log', 'default_graph_log_ms')
    deltas = {name: [rows['patched'][i][name] - rows['baseline'][i][name] for i in range(8)] for name in metrics}
    series = {'paired.' + name: values for name, values in deltas.items()}
    series.update({arm + '.' + name: [row[name] for row in rows[arm]] for arm in rows for name in metrics})
    rng = random.Random(202610280100)
    draws = {name: [] for name in series}
    for _ in range(100000):
        indices = [rng.randrange(8) for _ in range(8)]
        for name, values in series.items():
            draws[name].append(math.exp(sum(values[i] for i in indices) / 8))
    estimates = {}
    for name, values in series.items():
        ordered = sorted(draws[name])
        estimates[name] = {'values_by_block': [math.exp(x) for x in values], 'geometric_mean': math.exp(statistics.mean(values)), 'percentile95': [percentile(ordered, 0.025), percentile(ordered, 0.975)]}
    counts = {}
    for arm in rows:
        counts[arm] = {key: sum(r[key] for r in rows[arm]) for key in ('original_explicit', 'shadow_explicit', 'reversal', 'original_slower_point', 'shadow_slower_point', 'corrected_slower_point', 'introduced_slower_point', 'remaining_slower_point')}
        counts[arm]['recorded_numerical_checks'] = {key: sum(r['recorded_numerical_checks'][key] for r in rows[arm]) for key in ('execution', 'profiling')}
    return {'rows': rows, 'counts': counts, 'estimates': estimates, 'checks': checks,
            'limits': 'Independent raw arithmetic; 8 complete paired blocks, no historical/admission pooling. Graph scores follow confirmation and do not measure untouched startup or full serving. Point slower-choice counts do not imply statistically certain per-cell differences.'}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--raw-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        result = audit(args.raw_root)
        result['status'] = 'passed'
    except Exception as exc:
        result = {'status': 'failed', 'checks': checks, 'error': repr(exc)}
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k != 'rows'}))
    raise SystemExit(0 if result['status'] == 'passed' else 1)
