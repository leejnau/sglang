"""Derive the bounded result summary from preserved experiment records."""

import hashlib
import json
import math
import statistics
from pathlib import Path

ROOT = Path('/private/tmp/fi-delay-binding-20261028')
COORD = Path('/private/tmp/fi-delay-binding-20261028-attempt02/coordinator')
RAW = COORD / 'raw-timing/attempt01'
REPO = Path('/private/tmp/sglang-delay-binding-study')
BATCH = REPO / 'test/manual/kernels/results/flashinfer_autotune_selection/20261028T010000Z-h100-delay-binding'


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


analysis = read(RAW / 'paired-analysis.json')
plan = read(BATCH / 'plan.json')
ordering = read(ROOT / 'independent-review/attempt02-ordering-review.json')
independent = read(ROOT / 'independent-review/attempt02-mlp-review.json')
released = read(COORD / 'release-confirmed/result.json')
assert analysis['status'] == ordering['status'] == independent['status'] == 'passed'
assert released['status'] == 'released' and released['queue_empty']
assert len(analysis['provenance']) == 20

per_arm = {}
numerics = {'timing': 0, 'admission': 0, 'ordering': 12}
for arm, rows in analysis['process_rows'].items():
    assert len(rows) == 8
    for stem in ['admission-auto_synthetic'] + [f'block{i}-auto_synthetic-timing' for i in range(8)]:
        data = read(RAW / arm / (stem + '.json'))
        checks = data['correctness'] + data['profile_correctness']
        assert all(row['passed'] for row in checks)
        numerics['admission' if stem.startswith('admission') else 'timing'] += len(checks)
    unique = {tuple(row['finalist']) for row in rows}
    assert len(unique) == 1
    per_arm[arm] = {
        'counts': analysis['counts'][arm],
        'explicit_finalist': list(next(iter(unique))),
        'first_pass_finalist_profile_indices': sorted({row['finalist_profile_index'] for row in rows}),
        'geometric_mean_finalist_over_default': {
            key: math.exp(statistics.mean(math.log(row[key]) for row in rows))
            for key in ['original_profiler_ratio', 'confirmation_ratio', 'graph_ratio']
        },
        'per_block': [{key: row[key] for key in [
            'block', 'capture_order', 'original_role', 'confirmed_role',
            'original_profiler_ratio', 'confirmation_ratio', 'graph_ratio',
            'original_selected_over_default', 'confirmed_selected_over_default',
        ]} for row in rows],
    }

summary = {
    'schema_version': 1,
    'status': 'completed',
    'batch_id': plan['batch_id'],
    'attempt': 'attempt02',
    'execution_commit': analysis['execution_commit'],
    'research_branch': 'leejnau/sglang:experiment/flashinfer-candidate-selection',
    'research_pr_opened': False,
    'question': 'Does the exact upstream delay wrapper correction restore stream ordering and change selection on the frozen MLP experiment?',
    'upstream': plan['upstream'],
    'intervention': plan['binding'],
    'scope': 'One H100 NVL, one M144/N1024/K3072 captured MLP fixture, eight paired blocks and sixteen fresh timing processes. Both arms use default-inclusive v2 selection with existing v1 persistence; this is not a v1-versus-v2 comparison.',
    'environment': plan['environment'],
    'fixture': plan['source_contract']['fixture'],
    'protocol': plan['protocol'],
    'completed_processes': {'ordering': 2, 'admission': 2, 'timing': 16},
    'ordering': ordering['arms'],
    'selection': per_arm,
    'primary_metric': analysis['primary_metric'],
    'metrics': analysis['metrics'],
    'host_costs': analysis['cold_startup_and_confirmation_host_costs'],
    'host_cost_interpretation': 'The isolated startup-tuning slice median increased from 545.489 to 610.291 ms, approximately 64.8 ms or 11.9 percent. This includes enforcing the requested delay; it is neither complete server startup nor recurring serving latency. Confirmation profiler-only intervals move synchronization inside the profiler, so they should not be read as added end-to-end cost. Total confirmation median changed from 178.453 to 182.348 ms.',
    'interpretation': [
        'The exact wrapper fix restores intended native delay/event ordering on the qualified stack, including natural nondefault-stream use, conflicting-stream controls, FFI context restoration, and numerical graph replay.',
        'The old wrapper selected default in all eight timing processes. The corrected wrapper selected an explicit candidate in all eight, with lower retained-layer graph time relative to its own default in every process.',
        'The paired normalized graph ratio is 0.98827206, about 1.17 percent lower, with an exploratory eight-block bootstrap interval of 0.98581895 to 0.99127979. This is bounded selection evidence for the wrapper intervention under this protocol, not a full-model serving-speedup claim.',
        'Shadow confirmation changed no choice in either arm and adds no measured selection benefit in this cohort. These results do not justify adding a production confirmation heuristic.',
        'Each arm has a different dynamic explicit finalist. Zero slower-choice counts compare only that finalist with default and do not establish graph optimality across the entire candidate pool.',
        'The shared timing helper affects both APIs. This evidence supports using the corrected helper for subsequent qualification; it does not establish a v2-versus-v1 speedup or prove the historical ranking reversal had this cause.',
    ],
    'validation': {
        'pre_execution_cpu_cases': 59,
        'frozen_ordering_gate': 'passed',
        'frozen_admission_analysis': 'passed',
        'frozen_timing_analysis': 'passed',
        'independent_ordering_checks': ordering['checks'],
        'independent_mlp_checks': independent['checks'],
        'recorded_numerical_checks': numerics,
        'all_numerical_checks_passed': True,
        'original_cache_choices_and_v1_files_unchanged': True,
        'additional_profiling_during_graph_execution': 0,
        'historical_or_admission_pooling': False,
    },
    'attempt_history': plan['attempt_history'],
    'preservation': read(COORD / '20261028T010000Z-h100-delay-binding-attempt02-timing-preservation.json'),
    'cleanup': {**released, 'elapsed_seconds': 705, 'containers_cleaned': 20, 'final_gpu_memory_mib': 0, 'final_gpu_processes': 0},
    'limits': analysis['limits'] + [
        'The source is the previously qualified frozen FlashInfer build with the same FP8 descriptor and benchmark-validation overlays, plus only the stated delay wrapper change. This is not validation of an unmodified stable release or all current upstream code.',
        'No production SGLang change, measurement policy change, managed-store migration, scoped-cache adoption, additional experiment, PR or CI trigger follows automatically.',
    ],
    'next_action': 'Retain the qualified delay correction as a prerequisite for future measurement work; share this bounded evidence with the owner when requested. Keep SGLang production policy and v1 persistence unchanged, and do not implement shadow confirmation on this result.',
    'input_sha256': {
        'plan.json': sha(BATCH / 'plan.json'),
        'paired-analysis.json': sha(RAW / 'paired-analysis.json'),
        'independent-ordering-review.json': sha(ROOT / 'independent-review/attempt02-ordering-review.json'),
        'independent-mlp-review.json': sha(ROOT / 'independent-review/attempt02-mlp-review.json'),
        'release-confirmed.json': sha(COORD / 'release-confirmed/result.json'),
    },
    'summary_source_sha256': sha(Path(__file__)),
}
target = ROOT / 'publication/attempt02-result.json'
target.write_text(json.dumps(summary, indent=2, allow_nan=False) + '\n')
print(json.dumps({'status': 'written', 'path': str(target), 'sha256': sha(target), 'numerics': numerics}))
