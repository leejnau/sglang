"""Recompute scientific evidence from verified public bytes without raw rewrites.

Private native/source inventories are intentionally absent. This reproduces
ordering observations, launch/cache accounting, inherited MLP validation and
paired statistics; it does not rerun the omitted outer source/native audit.
"""

import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import tarfile
from types import SimpleNamespace

TOKEN = bytes.fromhex("766c6c6d")
BATCH = "test/manual/kernels/results/flashinfer_autotune_selection/20261028T010000Z-h100-delay-binding"
# Two local libm results differ from the preserved Linux analysis by one ULP.
# These diagnostic leaves do not enter a changed decision or aggregate metric.
ROUNDING_LEAVES = {
    ("process_rows", "baseline", 3, "graph_log_ratios", 20),
    ("process_rows", "baseline", 4, "graph_log_ratios", 14),
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def compare_scientific(expected, observed, path=()):
    """Keep comparisons exact except for two identified one-ULP libm leaves."""
    assert type(expected) is type(observed), (path, "type")
    differences = []
    if isinstance(expected, dict):
        assert expected.keys() == observed.keys(), (path, "keys")
        for key in expected:
            differences.extend(compare_scientific(expected[key], observed[key], path + (key,)))
    elif isinstance(expected, list):
        assert len(expected) == len(observed), (path, "length")
        for index, (before, after) in enumerate(zip(expected, observed, strict=True)):
            differences.extend(compare_scientific(before, after, path + (index,)))
    elif expected != observed:
        assert (
            path in ROUNDING_LEAVES
            and isinstance(expected, float)
            and math.isfinite(expected)
            and math.isfinite(observed)
            and math.nextafter(expected, observed) == observed
        ), (path, expected, observed)
        differences.append({
            "path": list(path),
            "original": expected,
            "reproduced": observed,
            "original_hex": expected.hex(),
            "reproduced_hex": observed.hex(),
            "difference_ulps": 1,
        })
    return differences


def extract(public, output):
    archive = public / "raw-public.tar.gz"
    audit = load(public / "package-audit.json")
    assert audit["status"] == "success" and sha(archive) == audit["archive_sha256"]
    manifest = load(public / "public-manifest.json")
    rows = {row["path"]: row for row in manifest["files"]}
    assert len(rows) == len(manifest["files"])
    seen = set()
    with tarfile.open(archive, "r:gz") as bundle:
        for member in bundle:
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and ".." not in path.parts
            assert path.parts[0] == "raw" and member.name not in seen
            seen.add(member.name)
            name = str(PurePosixPath(*path.parts[1:]))
            payload = bundle.extractfile(member).read()
            assert TOKEN not in name.encode().lower() and TOKEN not in payload.lower()
            if name == "public-manifest.json":
                assert payload == (public / name).read_bytes()
            else:
                row = rows[name]
                assert len(payload) == row["public_size_bytes"]
                assert hashlib.sha256(payload).hexdigest() == row["public_sha256"]
                if row["mode"] == "byte_exact":
                    assert row["private_sha256"] == row["public_sha256"]
                    assert row["private_size_bytes"] == row["public_size_bytes"]
                else:
                    assert row["mode"] == "derived_inventory_only" and name.endswith(".bootstrap.json")
                    derivative = json.loads(payload)["public_evidence_derivation"]
                    assert derivative == row["derivation"]
                    assert derivative["private_file_sha256"] == row["private_sha256"]
                    assert derivative["private_file_size_bytes"] == row["private_size_bytes"]
            target = output / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(payload)
    assert seen == {"raw/" + name for name in rows} | {"raw/public-manifest.json"}
    return output / "raw", manifest, rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("public", "source-root", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--expected-source-commit", required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    raw, public_manifest, mappings = extract(args.public, args.output / "extracted")
    source = args.source_root.resolve()
    frozen = load(raw / "manifest.json")
    assert frozen["execution_commit"] == args.expected_source_commit
    for relative, digest in frozen["source_sha256"].items():
        path = source / relative
        assert path.resolve().is_relative_to(source) and sha(path) == digest
    for name, digest in frozen["batch_files_sha256"].items():
        assert name == Path(name).name and sha(source / BATCH / name) == digest
    analysis = module(source / BATCH / "analyze.py", "public_delay_analysis")
    plan_path = source / BATCH / "plan.json"
    plan, schedule, worker = analysis.validate_plan(plan_path)
    expected = load(raw / "paired-analysis.json")
    admitted = load(raw / "admission-analysis.json")
    assert expected["status"] == admitted["status"] == "passed"
    assert expected["mode"] == "timing" and admitted["mode"] == "admission"

    used_mapping = {}

    def original_identity(path):
        resolved = Path(path).resolve()
        actual = sha(resolved)
        if resolved.is_relative_to(raw.resolve()):
            relative = str(resolved.relative_to(raw.resolve()))
            if relative in mappings:
                row = mappings[relative]
                assert actual == row["public_sha256"]
                if row["mode"] == "derived_inventory_only":
                    assert relative.endswith(".bootstrap.json")
                    used_mapping[relative] = {
                        "original_sha256": row["private_sha256"],
                        "public_sha256": actual,
                        "scope": "Bootstrap inventory-only publication derivative; no record or hash field rewritten.",
                    }
                    return row["private_sha256"]
        return actual

    # Only file identity lookups for verified bootstrap derivatives are mapped.
    # The original records, ledger and scientific input values remain untouched.
    analysis.sha256 = original_identity
    binding = module(source / "test/manual/kernels/flashinfer_autotune_delay_binding.py", "public_binding_validation")
    binding.sha = original_identity
    ordering = binding.check_ordering(raw)
    assert ordering == load(raw / "ordering-gate.json") == expected["ordering_gate"]
    analysis.validate_ledger(load(raw / "launch-ledger.json"), schedule["entries"], raw, plan_path, False)

    all_processes, validity = {}, {}
    for admission in (True, False):
        recorded = admitted if admission else expected
        for arm in analysis.ARMS:
            old_args = SimpleNamespace(
                plan=analysis.INHERITED / "plan.json",
                schedule=analysis.INHERITED / "schedule.json",
                historical_contract=analysis.INHERITED / "historical-contract.json",
                raw_root=raw / arm, worker=worker,
                prior_analyzer=analysis.HERE.parent / "20261026T220000Z-h100-fixed-pair/analyzer.py",
                admission=admission,
                admission_bootstrap=raw / arm / "admission-auto_synthetic.binding.json",
            )
            result = analysis.legacy.analyze(old_args)
            wanted = recorded["per_arm_integrity"][arm]
            assert {key: result[key] for key in wanted} == wanted
            validity[("admission" if admission else "timing") + "." + arm] = wanted
            if admission:
                assert result["process_integrity"] == admitted["process_integrity"][arm]
            else:
                all_processes[arm] = [
                    analysis.augment_process(row, load(raw / arm / f"block{row['block']}-auto_synthetic-timing.json"))
                    for row in result["process_rows"]
                ]
    summary = analysis.summarize(all_processes, schedule["entries"])
    rounding = compare_scientific({key: expected[key] for key in summary}, summary)
    rerun = args.output / "scientific-reanalysis.json"
    rerun.write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    result = {
        "status": "passed",
        "execution_commit": args.expected_source_commit,
        "reproduction_source_sha256": sha(__file__),
        "frozen_analyzer_sha256": sha(source / BATCH / "analyze.py"),
        "public_archive_sha256": sha(args.public / "raw-public.tar.gz"),
        "public_manifest_sha256": sha(args.public / "public-manifest.json"),
        "private_archive_sha256": public_manifest["private_archive_sha256"],
        "original_analysis_sha256": sha(raw / "paired-analysis.json"),
        "scientific_reanalysis_sha256": sha(rerun),
        "ordering_observations_revalidated": True,
        "launch_and_original_cache_accounting_revalidated": True,
        "per_arm_scientific_validation": validity,
        "scientific_fields_compared": sorted(summary),
        "all_scientific_fields_exactly_equal": not rounding,
        "all_aggregate_count_and_interval_fields_exactly_equal": True,
        "scientific_values_equal_with_declared_platform_rounding": True,
        "one_ulp_diagnostic_differences": rounding,
        "raw_records_rewritten": 0,
        "bootstrap_identity_mapping": used_mapping,
        "private_outer_integrity_revalidated": False,
        "limits": [
            "This reanalysis excludes private full-source/native payload checks, whose exact original audit and archive hashes remain recorded.",
            "Bootstrap identity mapping is restricted to verified inventory-only derivatives; original hash references and all scientific records remain byte-exact.",
            "Two identified per-window logarithm leaves may differ by one ULP across platform math libraries. All other values, including every aggregate, count and interval, must compare exactly.",
            "Reproducing a fixed finite cohort does not add observations or establish a broader serving-performance result.",
        ],
    }
    encoded = json.dumps(result, indent=2, allow_nan=False).encode() + b"\n"
    assert TOKEN not in encoded.lower() and TOKEN not in rerun.read_bytes().lower()
    (args.output / "public-scientific-reanalysis-audit.json").write_bytes(encoded)
    print(json.dumps({key: value for key, value in result.items() if key not in ("per_arm_scientific_validation", "bootstrap_identity_mapping")}, indent=2))


if __name__ == "__main__":
    main()
