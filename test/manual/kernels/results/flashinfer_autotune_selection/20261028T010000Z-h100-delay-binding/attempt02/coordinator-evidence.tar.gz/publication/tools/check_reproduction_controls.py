"""Verify that public reanalysis keeps its platform-rounding exception narrow."""

import argparse
import hashlib
import importlib.util
import json
import math
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reproducer", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    spec = importlib.util.spec_from_file_location("public_reanalysis", args.reproducer)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    compare = module.compare_scientific
    path = ("process_rows", "baseline", 3, "graph_log_ratios", 20)
    original = 0.06682511111349981
    adjacent = math.nextafter(original, math.inf)
    two_steps = math.nextafter(adjacent, math.inf)
    assert compare({"aggregate": 1.0}, {"aggregate": 1.0}) == []
    assert len(compare(original, adjacent, path)) == 1
    checks = ["exact_comparison", "identified_one_ulp_diagnostic_allowed"]
    cases = [
        ("two_ulp_diagnostic_rejected", two_steps, path),
        ("changed_aggregate_rejected", adjacent, ("metrics", "geometric_mean")),
        ("unlisted_diagnostic_rejected", adjacent, ("process_rows", "baseline", 2, "graph_log_ratios", 20)),
    ]
    for label, value, location in cases:
        try:
            compare(original, value, location)
        except AssertionError:
            checks.append(label)
        else:
            raise AssertionError(label)
    result = {
        "status": "passed",
        "source_sha256": hashlib.sha256(args.reproducer.read_bytes()).hexdigest(),
        "control_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "checks": checks,
        "controls_only": True,
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    main()
