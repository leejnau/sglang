"""Compare independent arithmetic and independently inspect pools/traces."""

import hashlib
import json
import math
import statistics
from pathlib import Path

ROOT = Path('/private/tmp/fi-delay-binding-20261028-attempt02/coordinator/raw-timing/attempt01')
DEST = Path(__file__).parent


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def equal(a, b):
    if isinstance(a, list):
        assert len(a) == len(b)
        for x, y in zip(a, b):
            equal(x, y)
    else:
        assert math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-15), (a, b)


independent = load(DEST / 'attempt02-mlp-review.json')
analysis = load(ROOT / 'paired-analysis.json')
assert independent['status'] == analysis['status'] == 'passed'
names = {'original_log': 'original_selected_over_default', 'shadow_log': 'confirmed_selected_over_default', 'shadow_over_original_log': 'confirmation_over_original', 'default_graph_log_ms': 'default_graph_absolute_ms'}
for name, value in independent['estimates'].items():
    arm, metric = name.split('.')
    published = analysis['metrics'][('patched_over_baseline' if arm == 'paired' else arm) + '.' + names[metric]]
    equal(value['values_by_block'], published['values_by_block'])
    equal(value['geometric_mean'], published['geometric_mean'])
    equal(value['percentile95'], published['exploratory_paired_block_bootstrap_95pct'])

ledger = load(ROOT / 'launch-ledger.json')['entries']
assert len(ledger) == len({row['container_id'] for row in ledger}) == 20
assert [row['phase'] for row in ledger] == ['ordering'] * 2 + ['admission'] * 2 + ['timing'] * 16
assert all(ledger[i]['ended_ns'] < ledger[i+1]['started_ns'] for i in range(19))
for entry in ledger:
    result = ROOT / entry['result_relative_path']
    bootstrap = result.with_suffix('.bootstrap.json')
    assert entry['returncode'] == 0 and entry['result_sha256'] == sha(result) and entry['bootstrap_sha256'] == sha(bootstrap)
    boot = load(bootstrap)
    assert boot['status'] == 'passed' and boot['binding_arm'] == entry['arm']
    assert boot['binding_before'] == boot['binding_after']
    assert all(boot['binding_before']['callable_comparison'].values())
    assert result.with_suffix('.container-id').read_text().strip() == entry['container_id']

reference_pool = None
trace_signatures = {'baseline': {}, 'patched': {}}
counts = {'timing': {'execution': 0, 'profiling': 0}, 'admission': {'execution': 0, 'profiling': 0}, 'ordering': {'profiler': 10, 'graph': 2}}
host_medians = {}
for arm in ('baseline', 'patched'):
    for mode, paths in (('admission', [ROOT / arm / 'admission-auto_synthetic.json']), ('timing', [ROOT / arm / f'block{i}-auto_synthetic-timing.json' for i in range(8)])):
        for path in paths:
            raw = load(path)
            assert all(row['passed'] for row in raw['correctness'] + raw['profile_correctness'])
            counts[mode]['execution'] += len(raw['correctness'])
            counts[mode]['profiling'] += len(raw['profile_correctness'])
            if mode == 'admission':
                continue
            pool = [(r['index'], r['tactic']) for r in raw['startup']['profiles'] if r['m'] == 144]
            assert len(pool) == 9 and len({json.dumps(tactic) for _, tactic in pool}) == 9
            if reference_pool is None:
                reference_pool = pool
            assert pool == reference_pool
            assert raw['finalist']['profile_index'] == (75 if arm == 'baseline' else 80)
            trace_path = path.with_suffix('.trace.json')
            assert sha(trace_path) == raw['trace']['sha256']
            events = load(trace_path)['traceEvents']
            annotations = {e['name']: e for e in events if e.get('cat') == 'user_annotation'}
            for role in ('winner', 'default'):
                annotation = annotations['retained_' + role]
                launches = [e for e in events if e.get('cat') == 'cuda_runtime' and e.get('name') == 'cudaGraphLaunch' and annotation['ts'] <= e['ts'] < annotation['ts'] + annotation['dur']]
                assert len(launches) == 3
                signature = None
                graph_ids = set()
                for launch in launches:
                    kernels = sorted((e for e in events if e.get('cat') == 'kernel' and e['args']['correlation'] == launch['args']['correlation']), key=lambda e: e['ts'])
                    assert len(kernels) == 2
                    signatures = [{'name': e['name'], **{k: e['args'][k] for k in ('device', 'grid', 'block', 'registers per thread', 'shared memory')}} for e in kernels]
                    graph_ids.update(e['args']['graph id'] for e in kernels)
                    if signature is None:
                        signature = signatures
                    assert signatures == signature
                assert len(graph_ids) == 1
                expected = next(g for g in raw['trace']['graphs'] if g['graph_id'] == role)
                assert expected['signatures'] == signature and expected['kernel_sequence'] == [0, 1] * 3
                if role not in trace_signatures[arm]:
                    trace_signatures[arm][role] = signature
                assert trace_signatures[arm][role] == signature
    rows = independent['rows'][arm]
    host_medians[arm] = {key: statistics.median(r[key] for r in rows) for key in ('startup_host_ms', 'confirmation_host_ms', 'confirmation_profiler_host_ms')}
    for own, frozen in zip(rows, analysis['process_rows'][arm]):
        assert own['finalist_tactic'] == frozen['finalist']
        equal(own['first_pass_explicit_over_default'], frozen['original_profiler_ratio'])
        equal(own['confirmation_explicit_over_default'], frozen['confirmation_ratio'])
        equal(own['graph_explicit_over_default'], frozen['graph_ratio'])
        for key in host_medians[arm]:
            equal(own[key], frozen[key])
assert trace_signatures['baseline']['default'] == trace_signatures['patched']['default']
report = {
    'status': 'passed', 'execution_commit': analysis['execution_commit'],
    'independent_metrics_compared': 12, 'complete_fresh_processes': 20,
    'identical_nine_candidate_order_all_sixteen_timing_processes': True,
    'candidate_pool': reference_pool, 'native_graph_signatures': trace_signatures,
    'recorded_numerical_checks': counts, 'recorded_numerical_checks_total': sum(sum(v.values()) for v in counts.values()),
    'host_medians_ms': host_medians,
    'inputs_sha256': {'independent_mlp_review': sha(DEST / 'attempt02-mlp-review.json'), 'frozen_paired_analysis': sha(ROOT / 'paired-analysis.json'), 'launch_ledger': sha(ROOT / 'launch-ledger.json')},
    'interpretation': [
        'Both arms retain v2 candidate selection and v1 persistence. The intervention changes the shared delay helper, not v1 versus v2.',
        'Baseline chooses default and its explicit finalist is profile75 (40x64); patched chooses profile80 (64x40). Default remains the same64x32 graph signature in both arms.',
        'Zero slower-choice counts concern each process finalist/default pair. Held-out graph timing did not evaluate every enumerated candidate, so global optimality over all nine is unproven.',
        'Ordering qualification is independently established. Selection quality here is a bounded paired comparison on one fixture/GPU, scored after confirmation work.',
        'Confirmation reverses no decisions and adds no measured selection benefit in this cohort. Historical observations are not pooled and their prior ranking reversals are not retroactively attributed.'
    ]}
(DEST / 'attempt02-final-review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k:v for k,v in report.items() if k not in ('candidate_pool','native_graph_signatures')}, indent=2))
