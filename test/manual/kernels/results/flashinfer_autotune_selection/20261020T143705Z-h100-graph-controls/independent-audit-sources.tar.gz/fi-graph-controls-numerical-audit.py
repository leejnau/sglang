"""Independent focused audit of graph-control raw evidence; stdlib only.

No worker or analyzer is imported. Nonzero numerical output tensors were not
retained, so this validates recorded numerical assertions and frozen source;
it does not claim to recompute those GPU tensors.
"""
import argparse
import ast
import collections
import functools
import hashlib
import itertools
import json
import math
import random
import statistics
import struct
import subprocess
from pathlib import Path

BATCH = "test/manual/kernels/results/flashinfer_autotune_selection/20261020T143705Z-h100-graph-controls"
WORKER = "test/manual/kernels/flashinfer_autotune_graph_controls.py"
IDS = ("pre_default", "post_hit", "post_miss")
checks = 0


def need(value, label):
    global checks
    if not value:
        raise AssertionError(label)
    checks += 1


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(value)
    return result


def loads(text):
    def invalid(value):
        raise ValueError(value)
    return json.loads(text, parse_float=finite_float, parse_constant=invalid)


def load(path):
    return loads(path.read_text())


def artifact(root, stored):
    matches = list(root.rglob(Path(stored).name))
    need(len(matches) == 1, "unique preserved artifact: " + stored)
    return matches[0]


def acceptance(row, label):
    need(row["accepted"] and row["used_descriptor"] == ([] if row["tactic"] == -1 else [1]), label + ": real native acceptance")


def measured(row, label):
    count = row["effective_iterations"]
    need(row["requested_iterations"] == 5120 and row["iterations_per_sample"] == count and 5120 <= count <= 65536, label + ": calibrated common lower bound")
    need(row["warmup_actual_ms"] >= 500 and row["warmup_calls"] >= 5120, label + ": real untimed warmup")
    need(row["calibration_batches"][-1]["iterations"] == count and row["calibration_batches"][-1]["wall_ms"] >= 20, label + ": minimum calibration span")
    for sample, batches in (("samples_ms", "wall_batch_ms"), ("gpu_event_samples_ms", "gpu_event_batch_ms")):
        need(len(row[sample]) == len(row[batches]) == 15, label + ": sample count")
        need(all(math.isfinite(x) and x > 0 for x in row[sample] + row[batches]), label + ": valid raw timings")
        need(all(math.isclose(x * count, y, rel_tol=1e-12) for x, y in zip(row[sample], row[batches])), label + ": per-call normalization")
    need(statistics.median(row["samples_ms"]) == row["median_ms"], label + ": raw wall median")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--trials", type=int, nargs="+", required=True)
    parser.add_argument("--include-observe", action="store_true")
    parser.add_argument("--expected-source-commit", required=True)
    parser.add_argument("--source-root", type=Path, default=Path("/private/tmp/sglang-autotune-selection-study"))
    args = parser.parse_args()
    need(len(set(args.trials)) == len(args.trials) and all(t in range(6) for t in args.trials), "valid trial subset")

    @functools.lru_cache(None)
    def blob(path):
        return subprocess.check_output(["git", "show", args.expected_source_commit + ":" + path], cwd=args.source_root)

    def source_sha(path):
        return hashlib.sha256(blob(path)).hexdigest()

    plan = loads(blob(BATCH + "/plan.json"))
    fixture = loads(blob(BATCH + "/fixture-manifest.json"))
    need(source_sha(BATCH + "/fixture-manifest.json") == plan["fixture"]["manifest_sha256"], "exact original fixture manifest")
    fixture_shas = {name: row["sha256"] for name, row in fixture["tensors"].items()}
    source_manifest = loads(blob(plan["flashinfer_source"]["input_batch"] + "/source-manifest.json"))
    native_sources = {entry["installed_package_path"]: entry["candidate_sha256"] for entry in source_manifest["files"] if entry["runtime_overlay"]}
    need(fixture["shape"] == [144, 4096, 1024], "actual layer fixture shape")
    for source, expected_sha in fixture["source"]["sglang_source_sha256"].items():
        need(source_sha(source) == expected_sha, "actual captured layer source: " + source)
    zero_sha = hashlib.sha256(bytes(144 * 4096 * 2)).hexdigest()
    text = blob(WORKER).decode()
    cls = next(n for n in ast.parse(text).body if isinstance(n, ast.ClassDef) and n.name == "GraphControlExperiment")
    methods = {n.name: n for n in cls.body if isinstance(n, ast.FunctionDef)}
    need("operation" not in methods, "actual linear facade inherited without replacement")
    for name in ("graph_window", "interleave"):
        need("graph.graph.replay" in ast.get_source_segment(text, methods[name]), "unhooked raw replay in " + name)
    need("graph.inputs = inputs" in ast.get_source_segment(text, methods["retain_capture"]), "graph operand views retained strongly")
    need("copy.deepcopy" in ast.get_source_segment(text, methods["miss_scope"]) and "self.restore_state(all_state)" in ast.get_source_segment(text, methods["miss_scope"]), "entire miss cache state restored in finally")
    need("data_ptr()" in ast.get_source_segment(text, methods["check_retained_output"]), "explicit graph output identity gate")
    helper_names = ("flashinfer_autotune_linear_layer.py", "flashinfer_autotune_descriptor_selection.py", "flashinfer_autotune_descriptor_qualification.py", "flashinfer_autotune_eager_setup.py")
    helpers = {name: source_sha("test/manual/kernels/" + name) for name in helper_names}
    expected = [(trial, arm, "timing") for trial in args.trials for arm in ("v1", "v2")]
    if args.include_observe:
        expected += [(0, arm, "observe") for arm in ("v1", "v2")]
    counters = collections.Counter()
    winners = collections.defaultdict(list)
    observer_algorithms, rows = {}, []
    for trial, arm, mode in expected:
        name = f"trial{trial}-{arm}-{mode}"
        row = load(args.root / (name + ".json"))
        rows.append(row)
        need(row["status"] == "success" and (args.root / (name + ".exit-code")).read_text().strip() == "0", name + ": actual successful worker")
        need((row["trial"], row["arm"], row["mode"], row["seed"], row["shape"]) == (trial, arm, mode, 19, [144, 4096, 1024]), name + ": protocol identity")
        env, control = row["environment"], row["graph_controls"]
        need(row["worker_sha256"] == source_sha(WORKER) and env["sglang_commit"] == args.expected_source_commit and env["helper_sha256"] == helpers, name + ": actual frozen source provenance")
        need(env["operand_sha256"] == fixture_shas and row["fixture"]["tensors"] == fixture["tensors"] and row["fixture"]["tensor_file_sha256"] == plan["fixture"]["tensor_file_sha256"], name + ": original fixture operands")
        need(env["measurement_policy"] == "unspecified" and not env["managed_store"] and env["backend"] == "cublas", name + ": original tuning policy/store scope")
        need(env["native_artifact"]["source_sha256"] == native_sources and env["native_artifact"]["cuda_arch_list"] == "9.0", name + ": exact qualified source and native architecture")
        library = args.root / "native-builds/candidate/gemm.so"
        ninja = args.root / "native-builds/candidate/build.ninja"
        need(sha(library) == env["native_artifact"]["library_sha256"] and sha(ninja) == env["native_artifact"]["ninja_sha256"], name + ": exact preserved native binary/build bytes")
        need(env["physical_gpu_uuid"] == plan["environment"]["physical_gpu_uuid"] and env["gpu"] == plan["environment"]["gpu"], name + ": exact physical device")
        qr = row["actual_layer"]["quantization_reference"]
        need(qr["byte_match"] and qr["actual_input_fp8_sha256"] == qr["independent_input_fp8_sha256"] == fixture["quantization"]["independent_input_fp8_sha256"], name + ": real quantizer hard byte gate")
        need(row["actual_layer"]["source_sha256"] == fixture["source"]["sglang_source_sha256"], name + ": actual runtime layer source provenance")
        actual_settings = row["autotuner_settings"]["after"]
        need(actual_settings["effective_measure_policy"] is None and actual_settings["effective_policy_timer"] is None and actual_settings["config"] == {"use_cuda_graph": False, "use_cold_l2_cache": False, "cuda_graph_profile_replays": 1, "profiling_repeat": None, "effective_profiling_repeat": 10}, name + ": actual unspecified timer policy and config")
        need(row["profile_attempts"] == len(row["profiles"]) and not row["forbidden_profile_attempts"], name + ": every profiling attempt confined to startup")
        counters["profiles"] += len(row["profiles"])
        for p in row["profiles"]:
            need(p["stage"] == "startup" and not p["use_cuda_graph"] and not p["use_cold_l2_cache"], name + ": unchanged startup profiling flags")
            need(p["autotuner_settings"] == actual_settings, name + ": per-profile observed settings preserved")
            need(p.get("profiler_ms") is not None and p["profiler_ms"] > 0, name + ": finite actual profile")
            counters["finite_profiles"] += 1
        summary = row["runtime_profile_summary"]
        runtime = [p for p in row["profiles"] if p["normalized_profile"] == summary["normalized_profile"]]
        minimum = min(p["profiler_ms"] for p in runtime)
        need(summary["minimum_ms"] == minimum and row["natural"]["tactic"] in [p["tactic"] for p in runtime if p["profiler_ms"] == minimum], name + ": actual finite runtime argmin")
        need(any(p["tactic"] == -1 for p in runtime) if arm == "v2" else not any(p["tactic"] == -1 for p in row["profiles"]), name + ": v2-only default profiling")
        winners[arm + "/" + mode].append(row["natural"]["tactic"])
        need(control["capture_order"] == ["pre_default", * (["post_hit", "post_miss"] if trial % 2 == 0 else ["post_miss", "post_hit"])], name + ": parity-balanced postcapture order")
        graphs = {g["id"]: g for g in control["graphs"]}
        need(set(graphs) == set(IDS) and len({g["output"]["data_ptr"] for g in graphs.values()}) == 3, name + ": retained independent output allocations")
        for graph_id, g in graphs.items():
            wanted_tier, wanted_tactic = ("memory", row["natural"]["tactic"]) if graph_id == "post_hit" else ("miss", -1)
            need(g["lookup_tier"] == wanted_tier and g["tactic"] == wanted_tactic and g["selection"]["lookup_tier"] == wanted_tier and g["selection"]["cache_hit"] == (wanted_tier != "miss") and g["selection"]["capturing"], name + ": real capture source " + graph_id)
            need(g["started_ns"] < g["ended_ns"], name + ": capture chronology")
            need(g["output"]["shape"] == [144, 4096] and g["output"]["dtype"] == "torch.bfloat16", name + ": actual graph output metadata")
            need(g["linear_input"]["shape"] == [144, 1024] and g["linear_input"]["dtype"] == "torch.bfloat16", name + ": actual BF16 input")
            need(g["quantized_input_sha256"] == fixture["quantization"]["independent_input_fp8_sha256"] and g["weight_rowmajor_sha256"] == fixture_shas["weight_fp8_rowmajor"] and g["input_scale_sha256"] == fixture_shas["input_scale"] and g["weight_scale_sha256"] == fixture_shas["weight_scale"], name + ": captured operand bytes " + graph_id)
            for meta in [g["linear_input"], g["output"], *g["inputs"]]:
                need(meta["data_ptr"] % 256 == meta["alignment_mod256"] and meta["data_ptr"] % 4096 == meta["alignment_mod4096"], name + ": actual alignment metadata")
            counters["retained_graphs"] += 1
        need(graphs["pre_default"]["ended_ns"] < control["startup_started_ns"] < control["startup_ended_ns"] < min(graphs[g]["started_ns"] for g in ("post_hit", "post_miss")), name + ": actual pre/startup/postcapture chronology")
        scopes = control["miss_scope"]
        need(len(scopes) == 1 and scopes[0]["winner_entries_before"] > 0, name + ": actual winner state existed before miss control")
        miss = scopes[0]
        need(miss["winner_entries_after_removal"] == miss["file_entries_after_removal"] == 0 and miss["restored"] and miss["all_cache_state_restored"], name + ": effective maps removed and whole state restored")
        for key in ("winner_contents", "file_contents", "cache"):
            need(miss[key + "_sha256_before"] == miss[key + "_sha256_after"], name + ": original miss scope contents restored")
        need(row["cache"]["miss_scopes_restored"] and row["cache"]["before_sha256"] is None and row["cache"]["after_startup_sha256"] == row["cache"]["after_controls_sha256"], name + ": original persisted file unchanged")
        cache_parts = Path(row["cache"]["path"]).parts
        cache = args.root.joinpath(*cache_parts[cache_parts.index("caches"):])
        payload = load(cache)
        need(sha(cache) == row["cache"]["after_controls_sha256"], name + ": actual original cache SHA")
        need(hashlib.sha256(canonical({k: v for k, v in payload.items() if k != "_generation"}).encode()).hexdigest() == payload["_generation"], name + ": real saved generation")
        entries = {k: v for k, v in payload.items() if not k.startswith("_")}
        need(entries[row["cache"]["runtime_file_key"]][1] == row["natural"]["tactic"] and len(entries) == len({canonical(p["normalized_profile"]) for p in row["profiles"]}), name + ": actual natural winner and every profiled bucket persisted")
        counters["cache_generation_checks"] += 1
        for b in row["binding_acceptance_checks"]:
            acceptance(b, name)
            counters["native_acceptance_checks"] += 1
        for public in row["actual_layer"]["observed_public_inputs"]:
            if not public["capturing"] and "quantized_input_sha256" in public:
                need(public["quantized_input_sha256"] == fixture["quantization"]["independent_input_fp8_sha256"] and public["weight_rowmajor_sha256"] == fixture_shas["weight_fp8_rowmajor"] and public["input_scale_sha256"] == fixture_shas["input_scale"] and public["weight_scale_sha256"] == fixture_shas["weight_scale"], name + ": actual public byte guard")
                counters["public_operand_byte_guards"] += 1
        checks_by_label = {c["check"]: c for c in row["correctness"]["checks"]}
        need(len(checks_by_label) == len(row["correctness"]["checks"]), name + ": unambiguous numerical labels")
        for c in row["correctness"]["checks"]:
            q, dense = c["quantized_reference"], c["bf16_reference"]
            need(q["passed"] and dense["diagnostic_only"] and q["max_normalized_error"] <= 1.000001, name + ": quantitative gate versus BF16 diagnostic")
            need(all(math.isfinite(ref[k]) and ref[k] >= 0 for ref in (q, dense) for k in ("max_abs_error", "max_normalized_error", "rmse", "relative_l2")), name + ": finite numerical metrics")
            if c["graph_id"] is not None:
                need(c["output_data_ptr"] == graphs[c["graph_id"]]["output"]["data_ptr"], name + ": numerical guard checks actual graph-owned output")
                counters["graph_owned_numerical_guards"] += 1
            if c["exact_zero_required"]:
                need(c["output_sha256"] == zero_sha and q["max_abs_error"] == dense["max_abs_error"] == 0, name + ": changed BF16 input yields exact zero output bytes")
                counters["exact_zero_byte_checks"] += 1
            counters["numerical_checks"] += 1
        for graph_id in IDS:
            for suffix in ("changed_input", "restored_input"):
                c = checks_by_label[graph_id + "_" + suffix]
                need(c["graph_id"] == graph_id and c["output_data_ptr"] == graphs[graph_id]["output"]["data_ptr"], name + ": changed/restored graph ownership")
        if mode == "timing":
            need(not env["LD_PRELOAD"] and not row["observer"]["enabled"] and row["observer"]["trace"] is None, name + ": timing has no preload/trace")
            for key in ("history_before_startup", "history_after_startup_pre_capture"):
                window = control[key]
                need(window["graph_id"] == "pre_default" and checks_by_label[window["correctness_check"]]["graph_id"] == "pre_default", name + ": history uses exact original graph")
                measured(window["measurement"], name + "/" + key)
            before, after = control["history_before_startup"], control["history_after_startup_pre_capture"]
            need(before["ended_ns"] < control["startup_started_ns"] < control["startup_ended_ns"] < after["started_ns"] < after["ended_ns"] < min(graphs[g]["started_ns"] for g in ("post_hit", "post_miss")), name + ": retained pregraph history before later allocation")
            need([w["graph_id"] for w in control["sequential"]] == list(IDS), name + ": all sequential graphs")
            for window in control["sequential"]:
                measured(window["measurement"], name + "/sequential/" + window["graph_id"])
            expected_schedule = [list(p) for _ in range(4) for p in itertools.permutations(IDS)]
            random.Random(4000 + trial).shuffle(expected_schedule)
            need(control["schedule"] == expected_schedule and len(control["blocks"]) == 24 and control["common_iterations"] == 5120, name + ": complete balanced common-count protocol")
            for group in control["blocks"]:
                need(group["order"] == expected_schedule[group["index"]] == [b["graph_id"] for b in group["measurements"]], name + ": actual recorded replay order")
                for b in group["measurements"]:
                    need(b["iterations"] == 5120 and b["started_ns"] < b["ended_ns"] and b["rewarm_actual_ms"] >= 20 and b["rewarm_calls"] >= 5120 and b["rewarm_calls"] % 5120 == 0, name + ": common count and untimed rewarm")
                    for total, per in (("wall_batch_ms", "wall_per_call_ms"), ("gpu_event_batch_ms", "gpu_event_per_call_ms")):
                        need(b[total] > 0 and math.isclose(b[total], b[per] * 5120, rel_tol=1e-12), name + ": raw replay batch normalization")
                    need(checks_by_label[b["correctness_check"]]["graph_id"] == b["graph_id"], name + ": timed replay output belongs to that retained graph")
                    counters["balanced_replay_batches"] += 1
        else:
            need(env["LD_PRELOAD"] and row["observer"]["enabled"] and row["observer"]["constructor_guard_suspended"] and row["observer"]["real_interposition_remained_loaded"], name + ": explicit instrumented process")
            need(control["history_before_startup"] is None and control["history_after_startup_pre_capture"] is None and not control["sequential"] and not control["blocks"] and not control["schedule"], name + ": observer contributes no latency windows")
            trace_info = row["observer"]["trace"]
            trace_path = artifact(args.root, trace_info["path"])
            trace = load(trace_path)
            events = trace["traceEvents"]
            need(sha(trace_path) == trace_info["sha256"] and sum(e.get("cat") == "kernel" for e in events) == trace_info["kernel_events"] > 0, name + ": actual CUDA kernel trace")
            need(sum("cudaGraphLaunch" in str(e.get("name", "")) for e in events) == trace_info["graph_launch_events"] > 0, name + ": actual graph launches")
            native_path = artifact(args.root, row["observer"]["native_output_path"])
            native = [loads(line) for line in native_path.read_text().splitlines() if line]
            observer_algorithms[arm] = {}
            for graph_id in IDS:
                mats = [n for n in native if n.get("event") == "matmul" and n["phase"] == graph_id + "_capture"]
                need(len(mats) == 1 and mats[0]["status"] == 0 and mats[0]["algo"]["raw_bytes"] == 64, name + ": actual native capture submission " + graph_id)
                if graphs[graph_id]["tactic"] != -1:
                    need(mats[0]["algo"]["raw_hex"] == struct.pack("<8Q", *graphs[graph_id]["tactic"]).hex(), name + ": exact native submitted descriptor")
                observer_algorithms[arm][graph_id] = mats[0]["algo"]
                counters["observed_native_captures"] += 1
            replay_phases = ["history_before_startup", "history_after_startup_pre_capture", *("sequential_" + g for g in IDS), *("trace_" + g for g in IDS)]
            for label in replay_phases:
                summaries = [n for n in native if n.get("event") == "phase_summary" and n["phase"] == label]
                need(summaries and all(api["calls"] == 0 for n in summaries for api in n["apis"].values()), name + ": replay invokes no new native CUBLAS submission")
    report = {
        "status": "passed", "immutable_raw": True, "complete_batch": len(args.trials) == 6 and args.include_observe,
        "source_commit": args.expected_source_commit, "trials": args.trials, "workers": len(rows),
        "worker_sha256": source_sha(WORKER), "plan_sha256": source_sha(BATCH + "/plan.json"),
        "fixture_manifest_sha256": source_sha(BATCH + "/fixture-manifest.json"),
        "assertions": checks, "error_count": 0, "errors": [], "counts": dict(counters),
        "forbidden_profile_attempts": 0, "winner_tactics": dict(winners),
        "observer_native_algorithms": observer_algorithms,
        "scope": "Independent stdlib raw/source numerical-evidence, graph-ownership, cache and replay-protocol audit; no analyzer/worker import and no GPU recomputation. Original nonzero output tensors were not retained.",
    }
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps({key: report[key] for key in ("status", "workers", "assertions", "counts")}))


if __name__ == "__main__":
    main()
