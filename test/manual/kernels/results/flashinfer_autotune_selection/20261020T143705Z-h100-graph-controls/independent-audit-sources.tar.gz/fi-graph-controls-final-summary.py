#!/usr/bin/env python3
"""Derive a compact graph-control summary independently from raw timing rows."""
import argparse
import collections
import functools
import hashlib
import itertools
import json
import math
from pathlib import Path
import statistics

IDS = ("pre_default", "post_hit", "post_miss")
PAIRS = (("post_miss", "pre_default"), ("post_hit", "post_miss"), ("post_hit", "pre_default"))
ARMS = ("v1", "v2")


def load(path):
    def bad(value):
        raise ValueError("Non-finite JSON: " + value)
    return json.loads(Path(path).read_text(), parse_constant=bad)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def med(values):
    return statistics.median(values)


@functools.lru_cache(None)
def bootstrap_index_rows(n):
    return tuple(itertools.product(range(n), repeat=n))


def interval(values):
    if len(values) < 2:
        return None
    distribution = sorted(med(values[i] for i in indices) for indices in bootstrap_index_rows(len(values)))
    def quantile(p):
        position = p * (len(distribution) - 1)
        lo, hi = math.floor(position), math.ceil(position)
        return distribution[lo] + (distribution[hi] - distribution[lo]) * (position - lo)
    return {"lower": quantile(.025), "upper": quantile(.975), "resamples": len(distribution),
            "independent_trial_units": len(values), "exploratory_unadjusted": True}


def stats(rows):
    values = [r["ratio"] for r in rows]
    assert rows and len({r["trial"] for r in rows}) == len(rows)
    return {"n": len(rows), "trial_estimates": rows, "median_ratio": med(values),
            "min_ratio": min(values), "max_ratio": max(values),
            "below_one": sum(v < 1 for v in values), "above_one": sum(v > 1 for v in values),
            "exploratory_bootstrap_95_percent": interval(values)}


def compute_effects(worker):
    arm, trial = worker["arm"], worker["trial"]
    controls = worker["graph_controls"]
    effects = []
    for channel, key, samples_key in (
        ("gpu_event", "gpu_event_per_call_ms", "gpu_event_samples_ms"),
        ("wall", "wall_per_call_ms", "samples_ms"),
    ):
        block_maps = [{r["graph_id"]: r[key] for r in b["measurements"]} for b in controls["blocks"]]
        for numerator, denominator in PAIRS:
            ratios = [r[numerator] / r[denominator] for r in block_maps]
            effects.append({"arm": arm, "trial": trial, "channel": channel,
                            "kind": "interleaved_paired_blocks",
                            "comparison": numerator + "_over_" + denominator,
                            "ratio": med(ratios), "same_public_tactic": numerator != "post_hit" or worker["natural"]["tactic"] == -1})
        before = med(controls["history_before_startup"]["measurement"][samples_key])
        after = med(controls["history_after_startup_pre_capture"]["measurement"][samples_key])
        seq = {r["graph_id"]: med(r["measurement"][samples_key]) for r in controls["sequential"]}
        for comparison, ratio in (
            ("after_startup_before_new_captures_over_before_startup", after / before),
            ("after_new_captures_over_after_startup_before_new_captures", seq["pre_default"] / after),
        ):
            effects.append({"arm": arm, "trial": trial, "channel": channel,
                            "kind": "chronological_retained_graph", "comparison": comparison, "ratio": ratio})
        for numerator, denominator in PAIRS:
            effects.append({"arm": arm, "trial": trial, "channel": channel,
                            "kind": "separate_sequential_windows", "comparison": numerator + "_over_" + denominator,
                            "ratio": seq[numerator] / seq[denominator],
                            "same_public_tactic": numerator != "post_hit" or worker["natural"]["tactic"] == -1})
    return effects


def summary(args):
    analysis = load(args.analysis)
    assert analysis["status"] == "success"
    trials = analysis["trials"]
    workers = [load(args.raw_root / f"trial{trial}-{arm}-timing.json") for trial in trials for arm in ARMS]
    assert all(w["status"] == "success" and w["mode"] == "timing" for w in workers)
    effects = [e for w in workers for e in compute_effects(w)]
    indexed = {(e["arm"], e["trial"], e["channel"], e["kind"], e["comparison"]): e for e in effects}
    for original in analysis["analysis"]["worker_effects"]:
        key = tuple(original[k] for k in ("arm", "trial", "channel", "kind", "comparison"))
        assert math.isclose(indexed[key]["ratio"], original["ratio"], rel_tol=1e-14, abs_tol=1e-15), key
    groups = collections.defaultdict(list)
    subgroups = collections.defaultdict(list)
    for e in effects:
        group = (e["arm"], e["channel"], e["kind"], e["comparison"])
        groups[group].append({"trial": e["trial"], "ratio": e["ratio"]})
        if e.get("same_public_tactic") and e["comparison"].startswith("post_hit"):
            subgroups[group].append({"trial": e["trial"], "ratio": e["ratio"]})
    contrasts = [{"arm": arm, "channel": channel, "primary": channel == "gpu_event",
                  "kind": kind, "comparison": comparison, **stats(rows)}
                 for (arm, channel, kind, comparison), rows in sorted(groups.items())]
    derived_groups = {(r["arm"], r["channel"], r["kind"], r["comparison"]): r for r in contrasts}
    for original in analysis["analysis"]["trial_summaries"]:
        key = tuple(original[k] for k in ("arm", "channel", "kind", "comparison"))
        derived = derived_groups[key]
        for metric in ("median_ratio", "min_ratio", "max_ratio"):
            assert math.isclose(derived[metric], original[metric], rel_tol=1e-14, abs_tol=1e-15), (key, metric)
        expected_ci = original["exploratory_cluster_bootstrap_95_percent"]
        actual_ci = derived["exploratory_bootstrap_95_percent"]
        assert (expected_ci is None) == (actual_ci is None), key
        if actual_ci is not None:
            for metric in ("lower", "upper"):
                assert math.isclose(actual_ci[metric], expected_ci[metric], rel_tol=1e-14, abs_tol=1e-15), (key, metric)
        assert derived["below_one"] == original["ratios_below_one"]
        assert derived["above_one"] == original["ratios_above_one"]
    same_default = [{"arm": arm, "channel": channel, "primary": channel == "gpu_event",
                     "kind": kind, "comparison": comparison, "selection_condition": "natural winner was public default -1",
                     **stats(rows)} for (arm, channel, kind, comparison), rows in sorted(subgroups.items())]
    cross_arm = []
    for channel, key in (("gpu_event", "gpu_event_per_call_ms"), ("wall", "wall_per_call_ms")):
        by_worker = {}
        for w in workers:
            by_worker[w["trial"], w["arm"]] = {
                graph: med(next(r[key] for r in b["measurements"] if r["graph_id"] == graph)
                           for b in w["graph_controls"]["blocks"]) for graph in IDS
            }
        for graph in IDS:
            rows = [{"trial": t, "ratio": by_worker[t, "v2"][graph] / by_worker[t, "v1"][graph]} for t in trials]
            cross_arm.append({"channel": channel, "primary": channel == "gpu_event",
                              "comparison": "v2_over_v1_" + graph,
                              "estimand": "Ratio of each fresh worker's median interleaved absolute latency; cross-process contextual comparison.",
                              **stats(rows)})
        rows = [{"trial": t, "ratio": indexed["v2", t, channel, "interleaved_paired_blocks", "post_hit_over_post_miss"]["ratio"] /
                 indexed["v1", t, channel, "interleaved_paired_blocks", "post_hit_over_post_miss"]["ratio"]} for t in trials]
        cross_arm.append({"channel": channel, "primary": channel == "gpu_event",
                          "comparison": "v2_over_v1_default_normalized_winner",
                          "estimand": "Ratio of within-worker winner/default median paired-block scores; different natural tactics remain explicit.",
                          **stats(rows)})
    observations = []
    for o in analysis.get("diagnostic_observers", []):
        evidence = o["evidence"]
        graphs = evidence["graphs"]
        comparisons = []
        for a, b in itertools.combinations(IDS, 2):
            aa, bb = graphs[a], graphs[b]
            comparisons.append({
                "graphs": [a, b],
                "algorithm_raw64_equal": aa["native"]["algorithm"]["raw_hex"] == bb["native"]["algorithm"]["raw_hex"],
                "algorithm_public_attributes_equal": aa["native"]["algorithm"]["config"] == bb["native"]["algorithm"]["config"],
                "ordered_cuda_launch_signatures_equal": aa["trace"]["ordered_launch_signature"] == bb["trace"]["ordered_launch_signature"],
            })
        observations.append({"arm": o["arm"], "winner": o["winner"], "graph_comparisons": comparisons,
                             "graphs": graphs, "scope": evidence["scope"]})
    winner_counts = []
    for arm in ARMS:
        selected = [w for w in workers if w["arm"] == arm]
        counts = collections.Counter(json.dumps(w["natural"]["tactic"], separators=(",", ":")) for w in selected)
        winner_counts.append({"arm": arm, "n": len(selected),
                              "default_selected": sum(w["natural"]["tactic"] == -1 for w in selected),
                              "tactic_counts": [{"tactic": json.loads(k), "count": n} for k, n in counts.items()]})
    minimum_profiles = []
    for w in workers:
        runtime = w["runtime_profile_summary"]["normalized_profile"]
        rows = sorted((r for r in w["profiles"] if r["normalized_profile"] == runtime and r.get("profiler_ms") is not None), key=lambda r: r["profiler_ms"])
        assert rows and rows[0]["tactic"] == w["natural"]["tactic"]
        minimum_profiles.append({"trial": w["trial"], "arm": w["arm"], "winner": w["natural"]["tactic"],
                                 "minimum_profiler_ms": rows[0]["profiler_ms"],
                                 "runner_up_fractional_margin": None if len(rows) < 2 else rows[1]["profiler_ms"] / rows[0]["profiler_ms"] - 1,
                                 "failed_profiles": sum(r.get("profiler_ms") is None for r in w["profiles"])})
    first = workers[0]
    explicit_v2 = []
    for w in workers:
        if w["arm"] == "v2" and w["natural"]["tactic"] != -1:
            explicit_v2.append({"trial": w["trial"], "tactic": w["natural"]["tactic"],
                                "winner_over_default_graph_ratio": indexed["v2", w["trial"], "gpu_event", "interleaved_paired_blocks", "post_hit_over_post_miss"]["ratio"]})
    errors = []
    for path in args.raw_root.rglob("*.json"):
        try:
            payload = load(path)
        except (ValueError, UnicodeDecodeError):
            continue
        if isinstance(payload, dict) and payload.get("status") == "error":
            errors.append({"path": str(path.relative_to(args.raw_root)), "sha256": sha(path), "error": payload.get("error"),
                           "worker_cohort": bool(payload.get("mode") in ("timing", "observe"))})
    return {
        "status": "success", "derived_from_validated_frozen_analysis": str(args.analysis), "analysis_sha256": sha(args.analysis),
        "raw_root": str(args.raw_root), "summary_script_sha256": sha(__file__), "source_commit": analysis["source_commit"],
        "scope": {"layer": first["actual_layer"]["function"], "shape": first["shape"], "seed": 19,
                  "gpu": analysis["outer_provenance"]["gpu"], "trials": trials, "fresh_timing_workers": len(workers),
                  "observation_workers": len(observations), "fixture_sha256": first["fixture"]["tensor_file_sha256"],
                  "policy": "unspecified; existing v1 persistence; managed store disabled",
                  "independent_unit": "Fresh fixed-input process trial; 24 blocks and15 sequential samples are dependent subsamples.",
                  "graph_primary": "GPU-event replay span including any host-submission gaps; wall secondary."},
        "state": "FINAL_IMMUTABLE" if trials == list(range(6)) and len(observations) == 2 else "CHECKPOINT",
        "winner_frequencies": winner_counts, "contrasts": contrasts, "same_default_winner_subgroups": same_default,
        "v2_explicit_winner_graph_comparators": explicit_v2,
        "cross_arm_context": cross_arm, "runtime_profile_minima": minimum_profiles,
        "diagnostic_observers": observations, "preserved_error_records": errors,
        "validation_counts": {"timing_numerical_checks": sum(len(w["correctness"]["checks"]) for w in workers),
                              "profile_attempts": sum(w["profile_attempts"] for w in workers),
                              "forbidden_profile_attempts": [w["forbidden_profile_attempts"] for w in workers if w["forbidden_profile_attempts"]],
                              "finite_profile_rows": sum(r.get("profiler_ms") is not None for w in workers for r in w["profiles"]),
                              "failed_profile_rows": sum(r.get("profiler_ms") is None for w in workers for r in w["profiles"])},
        "limits": analysis["limitations"] + [
            "A public-default subgroup is conditional on observed natural selection, with its actual n reported; no all-six default assumption.",
            "Cross-arm contextual ratios compare fresh processes and different natural winners. They do not isolate cache lookup during graph replay.",
            "Preserved coordinator staging errors are outside the timing-worker cohort only when they are not actual timing/observe worker results.",
            "An absent current stable gap would not prove the earlier separate-process4% runtime regression was noise.",
        ],
        "interpretation": [
            "The same retained pre-tuning graph slows after startup in both arms. This is a measured chronological process/window change; no matched untuned process establishes tuning as its unique cause.",
            "Interleaved independent-capture default/default comparisons do not reproduce a stable4% slowdown. The changed protocol cannot retrospectively explain the earlier separate-process result.",
            "V2 selects default in4/6 timing trials. Its conditional default winner/miss subgroup is near neutral with an exploratory interval crossing1; the other two explicit winners remain22%+ slower than default during graph replay.",
            "The v2/v1 aggregate winner comparison includes a lower median and a regression, with exploratory cross-process uncertainty crossing1. No universal v2 superiority or serving speedup follows.",
            "The existing profiler uses eager timing and synthesized dynamic activations, while this study measures captured serving graphs using actual activations. Finite profiler minima do not establish graph-optimal candidate choice.",
            "Both separate observers chose explicit winners; matched default/default native64-byte descriptors, seven attributes and launch signatures corroborate those diagnostic processes only."
        ],
        "next_decision": "Design one bounded measurement-objective qualification on this same actual layer: current unspecified-policy control versus explicit graph policy, with matching tuning/capture lookup identity and unchanged v1 persistence/numerical guards. Review protocol before launch; no production policy change or broader performance claim is justified yet.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis", type=Path, required=True)
    parser.add_argument("--raw-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    payload = summary(args)
    args.output.write_text(json.dumps(payload, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"status": payload["status"], "output": str(args.output), "sha256": sha(args.output)}))


if __name__ == "__main__":
    main()
