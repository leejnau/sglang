"""Preserve final audited graph-control results without private tensor/binary bytes."""

import hashlib
import json
import shutil
import tarfile
from pathlib import Path

ROOT = Path('/private/tmp/sglang-graph-controls-20261020T143705Z')
RAW = ROOT / 'raw/attempt01'
BATCH = Path('/private/tmp/sglang-autotune-selection-study/test/manual/kernels/results/flashinfer_autotune_selection/20261020T143705Z-h100-graph-controls')
COMMIT = 'e7abea4796b7f5314905888e20728f5e5c59138d'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def record(path):
    return {'sha256': digest(path), 'size_bytes': path.stat().st_size}


def read(path):
    return json.loads(path.read_text())


def write(name, data):
    (BATCH / name).write_text(json.dumps(data, indent=2) + '\n')


reports = {
    'source_build': ROOT / 'independent-source-build-audit.json',
    'numerical_cache': Path('/private/tmp/fi-graph-controls-final-numerical-audit.json'),
    'analysis': Path('/private/tmp/fi-graph-controls-final-analysis-audit.json'),
}
for p in reports.values():
    assert read(p)['status'] in ('passed', 'success')
shutil.copyfile(RAW / 'final-analysis.json', BATCH / 'analysis.json')
shutil.copyfile('/private/tmp/fi-graph-controls-final-summary.json', BATCH / 'summary.json')
assert read(BATCH / 'summary.json')['analysis_sha256'] == digest(BATCH / 'analysis.json')

sources = [
    Path('/private/tmp/sglang-graph-controls-source-audit.py'),
    Path('/private/tmp/fi-graph-controls-numerical-audit.py'),
    Path('/private/tmp/fi-graph-controls-independent-audit.py'),
    Path('/private/tmp/fi-graph-controls-final-summary.py'),
    Path('/private/tmp/fi-graph-controls-preserve.py'),
    ROOT / 'package_public.py',
    Path(__file__),
]
source_index = []
with tarfile.open(BATCH / 'independent-audit-sources.tar.gz', 'w:gz') as archive:
    for p in sources:
        assert bytes([118, 108, 108, 109]) not in p.read_bytes().lower(), p
        archive.add(p, arcname=p.name, recursive=False)
        source_index.append({'path': p.name, **record(p)})

release = (ROOT / 'release-state.txt').read_text()
lines = release.splitlines()
header_pos = next(i for i, row in enumerate(lines) if row.startswith('JobID|'))
header = lines[header_pos].split('|')
accounting = [dict(zip(header, row.split('|'))) for row in lines[header_pos + 1:] if row]
confirmed = (ROOT / 'release-confirmed.txt').read_text()
assert confirmed.splitlines()[1].startswith('JobID|'), 'queue was not empty'
own_containers = list(RAW.rglob('*containers-after*'))
assert len(own_containers) == 1 and not own_containers[0].read_text().strip()
write('scheduler.json', {
    'schema_version': 1,
    'allocation': '2690410',
    'exclusive_node': '1u1g-gen-0100',
    'execution_commit': COMMIT,
    'release_utc': lines[0],
    'empty_queue_confirmed_utc': confirmed.splitlines()[0],
    'queue_empty': True,
    'own_containers_remaining_before_release': 0,
    'accounting': accounting,
    'release_accounting_raw': release,
    'release_confirmation_raw': confirmed,
    'preparation': read(ROOT / 'preparation-files.json'),
    'classification': {
        'allocation_cancelled': 'Intentional resource release after successful experiment and preservation; not a worker failure.',
        '2690410.0_and_2690410.2': 'Cancelled slow source staging; no timing workers had run.',
        '2690410.5': 'First coordinator provenance gate failed after two successful timing workers because historical fixture-capture Git object was absent.',
        '2690410.8_and_2690410.9': 'Historical Git metadata import attempts; fixed by client-resolved self-contained object pack. No runtime source or worker rerun.',
        '2690410.11': 'Unchanged first-pair gate passed; resume ran only missing ten timing workers and two observers; final frozen analyzer passed.',
        '2690410.15': 'Full raw/private fixture/native preservation completed successfully.',
    },
    'actual_timing_worker_retries': 0,
    'actual_worker_exclusions': 0,
})

private = ROOT / '20261020T143705Z-h100-graph-controls-attempt01-full-raw.tgz'
assert digest(private) == '6aa2b4e6db0f2d88bf2c65e087998d4d0adc54d98076501b2bd7291f15467365'
write('validation.json', {
    'schema_version': 1,
    'status': 'success',
    'execution_commit': COMMIT,
    'timing_workers': 12,
    'separate_observers': 2,
    'all_actual_worker_exit_codes': 0,
    'source_changes_during_run': False,
    'source_build_audit': {'report': read(reports['source_build']), **record(reports['source_build'])},
    'numerical_cache_audit': {'report': read(reports['numerical_cache']), **record(reports['numerical_cache'])},
    'analysis_audit': {'report': read(reports['analysis']), **record(reports['analysis'])},
    'root_frozen_analyzer_rerun': record(ROOT / 'root-analysis.json'),
    'independent_frozen_rerun': record(Path('/private/tmp/fi-graph-controls-final-frozen-analysis.json')),
    'path_relocation_difference': 'Only 14 validated_workers.file paths differ after download; all other analysis values match.',
    'analysis': record(BATCH / 'analysis.json'),
    'summary': record(BATCH / 'summary.json'),
    'raw_public_archive': record(BATCH / 'attempt01-raw.tar.gz'),
    'raw_public_index': record(BATCH / 'raw-member-index.json'),
    'audit_source_archive': {'members': source_index, **record(BATCH / 'independent-audit-sources.tar.gz')},
    'full_private_archive': {
        'retained_path': '/home/lnau/flashinfer-autotune-study/' + private.name,
        **record(private),
        'node_durable_client_sha256_match': True,
        'indexed_original_members_verified': 136,
        'private_tensors_and_shared_objects_excluded_from_git': True,
    },
    'scope': 'One real static-FP8 QKV linear layer on H100 NVL; unchanged v1 persistence and unspecified policy; separate observers excluded from timing.',
    'limits': read(BATCH / 'summary.json')['limits'],
    'next_checkpoint_readiness': {
        'production_policy_pr_ready': False,
        'action': 'First recheck exact policy/cache APIs and prove tune-to-capture/eager-to-save-to-fresh-load winner identity with deterministic controls. Then review one bounded objective qualification before launch.',
        'constraint': 'A nonempty policy partitions winners. Bare post-context lookup and current v1 serialization may use the legacy partition, so retaining existing v1 persistence is an unproven requirement of the proposed policy experiment, not an achieved capability.',
        'inference': 'Eager profiling objective and synthesized dynamic inputs are separate mismatch hypotheses; neither is an isolated root cause.',
    },
})
with tarfile.open(BATCH / 'independent-audit-sources.tar.gz') as archive:
    for member in archive.getmembers():
        content = archive.extractfile(member).read()
        expected = next(item for item in source_index if item['path'] == member.name)
        assert hashlib.sha256(content).hexdigest() == expected['sha256']
        assert len(content) == expected['size_bytes']
print(json.dumps({'packaged': str(BATCH), 'audit_sources': len(source_index), 'scheduler_released': True}))
