#!/usr/bin/env python3
"""Independent stdlib actual-data audit: no frozen analyzer/worker imports."""
import collections
import copy
import hashlib
import importlib.util
import itertools
import json
import math
from pathlib import Path
import random
import statistics
import struct

RAW=Path('/private/tmp/sglang-graph-controls-20261020T143705Z/raw/attempt01')
ROOT=Path('/private/tmp/sglang-autotune-selection-study')
OUT=Path('/private/tmp/fi-graph-controls-final-analysis-audit.json')
SOURCE='e7abea4796b7f5314905888e20728f5e5c59138d'
IDS=('pre_default','post_hit','post_miss')
checks=collections.Counter()
def check(ok,group):
    checks[group]+=1
    if not ok:raise AssertionError(group)
def load(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def close(a,b):return math.isclose(a,b,rel_tol=1e-13,abs_tol=1e-15)
def locate(p):
    if '/caches/' in p:
        candidate=RAW/'caches'/p.split('/caches/',1)[1]
        check(candidate.is_file(),'actual retained cache path')
        return candidate
    found=list(RAW.rglob(Path(p).name))
    check(len(found)==1,'unique retained path')
    return found[0]
def signature(e):
    a=e['args']
    return {'name':e['name'],**{k:a[k] for k in ('grid','block','registers per thread','shared memory')}}
original=load(RAW/'final-analysis.json')
rerun=load('/private/tmp/fi-graph-controls-final-frozen-analysis.json')
normalized=copy.deepcopy(original)
for w in normalized['validated_workers']:
    w['file']=str(RAW/Path(w['file']).name)
check(normalized==rerun,'frozen rerun equality after14 path relocations')
check(original['source_commit']==SOURCE,'frozen original source')
check(sha(ROOT/'test/manual/kernels/results/flashinfer_autotune_selection/20261020T143705Z-h100-graph-controls/analyze.py')==original['analyzer_sha256'],'frozen analyzer SHA')
spec=importlib.util.spec_from_file_location('independent_summary','/private/tmp/fi-graph-controls-final-summary.py')
summary_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(summary_module)
derived=load('/private/tmp/fi-graph-controls-final-summary.json')
all_workers=[]
for trial in range(6):
 for arm in ('v1','v2'):
    path=RAW/f'trial{trial}-{arm}-timing.json';w=load(path);all_workers.append(w)
for arm in ('v1','v2'):
 all_workers.append(load(RAW/f'trial0-{arm}-observe.json'))
native_reports=[]
trace_reports=[]
cids=[]
finite_profile_count=0
numerics=0
block_observations=0
sequential_samples=0
for w in all_workers:
    label=f"trial{w['trial']}-{w['arm']}-{w['mode']}"
    p=RAW/(label+'.json')
    check(w['status']=='success' and w['environment']['sglang_commit']==SOURCE,'worker source/status')
    check((RAW/(label+'.exit-code')).read_text().strip()=='0','worker actual exit')
    cids.append((RAW/(label+'.container-id')).read_text().strip())
    check(w['shape']==[144,4096,1024] and w['seed']==19,'actual shape/input seed')
    check(w['profile_attempts']==len(w['profiles']) and not w['forbidden_profile_attempts'],'profiles startup-only attempt count')
    runtime=w['runtime_profile_summary']['normalized_profile']
    finite=[r for r in w['profiles'] if r['normalized_profile']==runtime and r.get('profiler_ms') is not None]
    check(min(finite,key=lambda r:r['profiler_ms'])['tactic']==w['natural']['tactic'],'source-order finite runtime minimum')
    check(any(r['tactic']==-1 for r in finite)==(w['arm']=='v2'),'v2 default participates finite')
    for r in w['profiles']:
        check(r['stage']=='startup' and not r['use_cuda_graph'] and not r['use_cold_l2_cache'],'actual default profiling objective')
        check(r.get('profiler_ms') is not None and math.isfinite(r['profiler_ms']) and r['profiler_ms']>0,'finite profiler row')
        finite_profile_count+=1
    cache=w['cache'];cp=locate(cache['path']);payload=load(cp)
    check(sha(cp)==cache['after_startup_sha256']==cache['after_controls_sha256'],'natural JSON bytes restored')
    check(payload[cache['runtime_file_key']][1]==w['natural']['tactic'],'real JSON winner persisted')
    g=w['graph_controls'];graphs={x['id']:x for x in g['graphs']}
    check(set(graphs)==set(IDS) and len({x['output']['data_ptr'] for x in graphs.values()})==3,'three distinct retained actual outputs')
    check(graphs['pre_default']['tactic']==graphs['post_miss']['tactic']==-1,'actual miss default choices')
    check(graphs['pre_default']['lookup_tier']==graphs['post_miss']['lookup_tier']=='miss','actual miss tiers')
    check(graphs['post_hit']['tactic']==w['natural']['tactic'] and graphs['post_hit']['lookup_tier']=='memory','actual natural memory winner')
    for m in g['miss_scope']:
        check(m['winner_entries_after_removal']==m['file_entries_after_removal']==0 and m['restored'] and m['all_cache_state_restored'],'effective maps removed and entire state restored')
        for prefix in ('cache_sha256','winner_contents_sha256','file_contents_sha256'):
            check(m[prefix+'_before']==m[prefix+'_after'],'all state and unrelated winners preserved')
    check(w['correctness']['passed'],'worker numerical acceptance')
    for r in w['correctness']['checks']:
        numerics+=1
        check(r['quantized_reference']['passed'] and r['quantized_reference']['max_normalized_error']<=1,'quantized FP32 reference')
        check(r['bf16_reference']['diagnostic_only'],'BF16 approximation is diagnostic')
        if r['graph_id'] is not None:check(r['output_data_ptr']==graphs[r['graph_id']]['output']['data_ptr'],'exact retained graph output ownership')
        if r['exact_zero_required']:check(r['max_abs_error']==0 and r['quantized_reference']['rmse']==0,'changed input exact zero')
    for r in w['binding_acceptance_checks']:
        check(r['accepted'] and r['used_descriptor']==([] if r['tactic']==-1 else [1]),'actual native acceptance no descriptor fallback')
    if w['mode']=='timing':
        check(not w['environment']['LD_PRELOAD'] and not w['observer']['enabled'],'uninstrumented timing cohort')
        expected=list(itertools.permutations(IDS))*4
        random.Random(4000+w['trial']).shuffle(expected)
        check(g['schedule']==[list(x) for x in expected],'exact balanced seeded schedule')
        check(len(g['blocks'])==24,'24 paired dependent block groups')
        for b in g['blocks']:
            check(b['order']==list(expected[b['index']]),'actual block order')
            for r in b['measurements']:
                block_observations+=1
                check(r['iterations']==5120 and r['rewarm_actual_ms']>=20,'common replay count and rewarm')
                check(close(r['wall_per_call_ms'],r['wall_batch_ms']/5120) and close(r['gpu_event_per_call_ms'],r['gpu_event_batch_ms']/5120),'block raw per-call normalization')
                check(close(r['wall_batch_ms'],(r['ended_ns']-r['started_ns'])/1e6),'block wall clock raw span')
        for window in [g['history_before_startup'],g['history_after_startup_pre_capture']]+g['sequential']:
            m=window['measurement'];n=m['effective_iterations']
            check(n==m['iterations_per_sample'] and m['warmup_actual_ms']>=500,'sequential calibration/warmup')
            for per,batch in (('samples_ms','wall_batch_ms'),('gpu_event_samples_ms','gpu_event_batch_ms')):
                check(len(m[per])==len(m[batch])==15,'15 dependent sequential samples')
                for v,total in zip(m[per],m[batch]):check(close(v,total/n) and math.isfinite(v) and v>0,'sequential raw normalization')
            sequential_samples+=15
    else:
        check(g['history_before_startup'] is None and not g['blocks'] and not g['sequential'],'observers excluded from latency inference')
        records=[json.loads(x) for x in locate(w['observer']['native_output_path']).read_text().splitlines()]
        phase_summaries={r['phase']:r for r in records if r['event']=='phase_summary'}
        captures={}
        for gid in IDS:
            phase=gid+'_capture'
            submitted=[r for r in records if r['event']=='matmul' and r['phase']==phase]
            hs=[r for r in records if r['event']=='heuristic' and r['phase']==phase]
            check(len(submitted)==1 and submitted[0]['status']==0,'native one accepted capture matmul')
            algo=submitted[0]['algo'];check(algo['raw_bytes']==64 and len(bytes.fromhex(algo['raw_hex']))==64,'actual64-byte algorithm')
            check(len(algo['config'])==7 and all(a['status']==0 and a['bytes']==4 for a in algo['config'].values()),'all7 native public attributes')
            if graphs[gid]['tactic']==-1:
                check(len(hs)==1 and hs[0]['requested']==hs[0]['returned']==1 and hs[0]['status']==0,'actual one-result default heuristic')
                check(hs[0]['algorithms'][0]['algo']==algo,'default heuristic submitted identity')
            else:
                check(not hs and struct.pack('<8Q',*graphs[gid]['tactic']).hex()==algo['raw_hex'],'actual descriptor submitted exact identity')
            captures[gid]=algo
        replay_phases=[x+'_numerics' for x in IDS]+['history_before_startup','history_after_startup_pre_capture']+['sequential_'+x for x in IDS]+['trace_'+x for x in IDS]
        for phase in replay_phases:
            apis=phase_summaries[phase]['apis']
            check(apis['matmul']['calls']==apis['heuristic']['calls']==0,'actual graph replay no CPU native selection')
        check(captures['pre_default']==captures['post_miss'],'observer same defaults raw64 and7 attrs')
        trace_path=locate(w['observer']['trace']['path'])
        check(sha(trace_path)==w['observer']['trace']['sha256'],'original trace hash')
        events=load(trace_path)['traceEvents'];traces={}
        for gid in IDS:
            scopes=[e for e in events if e.get('cat')=='user_annotation' and e.get('name')=='retained_'+gid and e.get('ph')=='X']
            check(len(scopes)==1,'actual retained replay scope')
            scope=scopes[0];start,end=scope['ts'],scope['ts']+scope['dur']
            launches=sorted([e for e in events if e.get('cat')=='cuda_runtime' and 'cudaGraphLaunch' in e.get('name','') and start<=e['ts']<=end],key=lambda e:e['ts'])
            check(len(launches)==3,'actual3 replay launches per retained scope')
            cycles=[];graph_ids=set()
            for launch in launches:
                kernels=sorted([e for e in events if e.get('cat')=='kernel' and e.get('args',{}).get('correlation')==launch['args']['correlation']],key=lambda e:e['ts'])
                check(len(kernels)==2 and any(e['name']=='_static_quant_fp8' for e in kernels),'actual quantizer plus matrix CUDA launches')
                check(all(start<=e['ts'] and e['ts']+e['dur']<=end+1 for e in kernels),'actual launch scoped lifetime')
                cycles.append([signature(e) for e in kernels])
                graph_ids.update(e['args']['graph id'] for e in kernels)
            check(cycles[0]==cycles[1]==cycles[2] and len(graph_ids)==1,'three repeated full ordered launch signatures')
            traces[gid]={'signature':cycles[0],'graph_ids':list(graph_ids)}
        check(len({x['graph_ids'][0] for x in traces.values()})==3,'three distinct retained native graph identities')
        check(traces['pre_default']['signature']==traces['post_miss']['signature'],'observer matching default full launch signatures')
        native_reports.append({'arm':w['arm'],'winner':w['natural']['tactic'],'captures':captures})
        trace_reports.append({'arm':w['arm'],'graphs':traces})
check(len(set(cids))==14,'14 fresh distinct containers')
fixture=load(RAW/'fixture/manifest.json')
check(sha(RAW/'fixture/fixture.safetensors')==fixture['tensor_file']['sha256'],'private actual fixture raw hash')
for n in ('library','ninja'):
    expected=all_workers[0]['environment']['native_artifact'][n+'_sha256']
    path=locate(all_workers[0]['environment']['native_artifact'][n+'_path'])
    check(sha(path)==expected,'retained actual native artifact')
# The separate summary independently compares all192 raw worker effects and
# all whole-trial aggregate medians/ranges/counts/exact6^6 bootstrap endpoints.
effects=[r for w in all_workers[:12] for r in summary_module.compute_effects(w)]
index={(r['trial'],r['arm'],r['channel'],r['kind'],r['comparison']):r for r in effects}
for r in original['analysis']['worker_effects']:
    key=tuple(r[k] for k in ('trial','arm','channel','kind','comparison'))
    check(close(index[key]['ratio'],r['ratio']),'independent actual paired/history/sequential effect')
for r in derived['contrasts']:
    check(r['n']==6 and r['exploratory_bootstrap_95_percent']['resamples']==46656,'six whole-trial bootstrap units')
# Preserve source-stage metadata failure as coordinator evidence only.
initial=load(RAW/'initial-missing-history-trial0-analysis.json')
check(initial['status']=='error' and not initial.get('mode'),'coordinator error preserved outside actual worker cohort')
check(all((RAW/f'trial{t}.launcher.exit-code').read_text().strip()=='0' for t in range(6)),'all final trial gates0')
payload={'status':'success','state':'FINAL_IMMUTABLE','source_commit':SOURCE,
 'audit_script_sha256':sha(__file__),'summary_script_sha256':sha('/private/tmp/fi-graph-controls-final-summary.py'),
 'raw_root':str(RAW),'original_analysis_sha256':sha(RAW/'final-analysis.json'),
 'local_frozen_rerun_sha256':sha('/private/tmp/fi-graph-controls-final-frozen-analysis.json'),
 'frozen_rerun_byte_identical':False,'frozen_rerun_identical_after_only14_raw_path_relocations':True,
 'assertions_passed':sum(checks.values()),'assertion_groups':dict(checks),
 'cohort':{'timing_workers':12,'separate_observers':2,'fresh_containers':14,
           'numeric_checks':numerics,'finite_profiles_including_observers':finite_profile_count,
           'interleaved_observations':block_observations,'sequential_dependent_samples':sequential_samples},
 'native':native_reports,'trace':trace_reports,
 'limits':['No AlgoCheck interception in actual reused probe.','Native/trace identity is observed only in separate diagnostic processes, never identifies timing-worker physical launches.',
           'Before/after chronology cannot uniquely attribute effects to tuning.','Different retained/interleaved protocol cannot retrospectively identify the earlier4% gap as noise.',
           'Conditional same-default winner subgroup has n4, not all6.','Exact exploratory bootstrap resamples six trial units, not replay blocks.']}
OUT.write_text(json.dumps(payload,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':'success','audit':str(OUT),'sha256':sha(OUT),'assertions':sum(checks.values()),'cohort':payload['cohort']}))
