"""Package byte-identical nonbinary raw members after independent verification."""
import argparse,hashlib,json,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--raw',type=Path,required=True);p.add_argument('--batch',type=Path,required=True);a=p.parse_args()
sha=lambda data:hashlib.sha256(data).hexdigest()
members=[];excluded=[];archive=a.batch/'attempt01-raw.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for f in sorted(a.raw.rglob('*')):
  if f.is_symlink():raise RuntimeError('raw symlink not permitted: '+str(f))
  if not f.is_file():continue
  data=f.read_bytes();name=str(f.relative_to(a.raw));meta={'path':name,'sha256':sha(data),'size_bytes':len(data)}
  if f.suffix in ('.so','.safetensors'):
   excluded.append(meta);continue
  assert bytes([118,108,108,109]) not in data.lower(),name
  t.add(f,arcname=name,recursive=False);members.append(meta)
with tarfile.open(archive) as t:
 actual={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
assert set(actual)=={r['path'] for r in members}
for r in members:assert sha(actual[r['path']])==r['sha256'] and len(actual[r['path']])==r['size_bytes']
(a.batch/'raw-member-index.json').write_text(json.dumps({'schema_version':1,'archive_sha256':sha(archive.read_bytes()),'archive_size_bytes':archive.stat().st_size,'members':members,'private_binary_members_excluded':excluded,'byte_comparison_passed':True},indent=2)+'\n')
print(json.dumps({'public_members':len(members),'excluded_private_binaries':len(excluded),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes())}))
