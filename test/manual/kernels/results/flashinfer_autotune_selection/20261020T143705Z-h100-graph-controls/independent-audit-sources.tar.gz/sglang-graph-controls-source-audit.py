#!/usr/bin/env python3
"""Independent source/build audit; no imports from experiment code."""
import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-root", type=Path, required=True)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--trials", nargs="+", type=int, default=list(range(6)))
    parser.add_argument("--observations", action="store_true")
    parser.add_argument("--require-binaries", action="store_true")
    args = parser.parse_args()
    raw, source = args.raw_root, args.source_root
    count = 0

    def check(condition, label):
        nonlocal count
        if not condition:
            raise AssertionError(label)
        count += 1

    def read(path):
        return json.loads(path.read_text())

    execution = (raw / "execution-commit.txt").read_text().strip()
    check(re.fullmatch(r"[0-9a-f]{40}", execution), "execution commit shape")

    def frozen(path):
        return subprocess.check_output(
            ["git", "show", execution + ":" + path], cwd=source
        )

    def frozen_sha(path):
        return hashlib.sha256(frozen(path)).hexdigest()

    batch = "test/manual/kernels/results/flashinfer_autotune_selection/20261020T143705Z-h100-graph-controls"
    plan = json.loads(frozen(batch + "/plan.json"))
    manifest = read(raw / "manifest.json")
    check(manifest["plan_sha256"] == frozen_sha(batch + "/plan.json"), "frozen plan hash")
    for path, recorded_sha in manifest["source_sha256"].items():
        check(recorded_sha == frozen_sha(path), "frozen source bytes: " + path)
    original = "test/manual/kernels/results/flashinfer_autotune_selection/20261019T232945Z-h100-descriptor-qualification"
    check(manifest["source_manifest_sha256"] == frozen_sha(original + "/source-manifest.json"), "source manifest provenance")
    fi_manifest = json.loads(frozen(original + "/source-manifest.json"))
    runtime_hashes = {
        row["installed_package_path"]: row["candidate_sha256"]
        for row in fi_manifest["files"] if row["runtime_overlay"]
    }
    wrapper = "python/sglang/srt/model_executor/runner/flashinfer_autotune.py"
    check(frozen_sha(wrapper) == plan["environment"]["sglang_wrapper_sha256"], "landed wrapper hash")
    check(sha(raw / "fixture/manifest.json") == plan["fixture"]["manifest_sha256"], "fixture manifest bytes")
    if args.require_binaries:
        check(sha(raw / "fixture/fixture.safetensors") == plan["fixture"]["tensor_file_sha256"], "private fixture bytes")

    names = [f"trial{trial}-{arm}-timing" for trial in args.trials for arm in ("v1", "v2")]
    if args.observations:
        names += [f"trial0-{arm}-observe" for arm in ("v1", "v2")]
    library_hashes, ninja_hashes = set(), set()
    for name in names:
        row = read(raw / (name + ".json"))
        check(row["status"] == "success", name + ": result")
        check((raw / (name + ".exit-code")).read_text().strip() == "0", name + ": exit")
        env = row["environment"]
        check(env["sglang_commit"] == execution, name + ": source commit")
        check(env["sglang_wrapper_sha256"] == frozen_sha(wrapper), name + ": wrapper")
        check(row["worker_sha256"] == frozen_sha("test/manual/kernels/flashinfer_autotune_graph_controls.py"), name + ": worker")
        for helper, recorded_sha in env["helper_sha256"].items():
            check(recorded_sha == frozen_sha("test/manual/kernels/" + helper), name + ": helper " + helper)
        check(env["torch"] == "2.14.1+cu130" and env["torch_cuda"] == "13.0" and env["flashinfer"] == "0.7.2", name + ": dependencies")
        check(env["measurement_policy"] == "unspecified" and env["managed_store"] is False, name + ": policy/store")
        check(env["physical_gpu_uuid"].removeprefix("GPU-") == plan["environment"]["physical_gpu_uuid"], name + ": physical GPU")
        native = env["native_artifact"]
        check(native["source_sha256"] == runtime_hashes, name + ": runtime sources")
        check(native["cuda_arch_list"] == "9.0", name + ": CUDA architecture")
        check("bmm_fp8_run_with_descriptor" in native["required_native_exports"], name + ": native descriptor interface")
        library_hashes.add(native["library_sha256"])
        ninja_hashes.add(native["ninja_sha256"])
        check(row["fixture"]["manifest_sha256"] == plan["fixture"]["manifest_sha256"] and row["fixture"]["tensor_file_sha256"] == plan["fixture"]["tensor_file_sha256"], name + ": fixture inputs")
        if row["mode"] == "timing":
            check(not env["LD_PRELOAD"] and not row["observer"]["enabled"], name + ": observer isolation")
        else:
            check(row["observer"]["enabled"] and row["observer"]["constructor_guard_suspended"] and row["observer"]["real_interposition_remained_loaded"], name + ": observer adapter disclosure")
            for preload in row["observer"]["preload_files"]:
                check(preload["sha256"] == sha(raw / Path(preload["path"]).name), name + ": actual preload binary")

    check(len(library_hashes) == len(ninja_hashes) == 1, "same actual JIT build across workers")
    ninja = raw / "native-builds/candidate/build.ninja"
    check(sha(ninja) in ninja_hashes, "retained ninja bytes")
    text = ninja.read_text()
    check("-gencode=arch=compute_90a,code=sm_90a" in text, "SM90a native target")
    units = re.findall(r"^build .+: (?:cuda_compile|compile) (.+)$", text, re.M)
    check(len(units) == 3 and {Path(p).name for p in units} == {"bmm_fp8.cu", "group_gemm.cu", "flashinfer_gemm_binding.cu"}, "all actual native translation units")
    check(all("/packages/candidate/flashinfer/data/csrc/" in p for p in units), "isolated native source paths")
    if args.require_binaries:
        check(sha(raw / "native-builds/candidate/gemm.so") in library_hashes, "retained actual native ELF")
    provenance = read(raw / ("native-build-provenance.json" if args.observations else "native-build-provenance-trial0.json" if args.trials == [0] else "native-build-provenance-timing.json"))
    check(provenance["status"] == "success", "collector status")
    native = provenance["arms"]["candidate"]
    check(native["library"]["sha256"] in library_hashes and native["ninja"]["sha256"] in ninja_hashes, "collector/worker agreement")
    check(native["all_runtime_source_sha256"] == runtime_hashes, "collector runtime inputs")
    expected_tus = {
        Path(path).name: recorded for path, recorded in runtime_hashes.items()
        if path.endswith(("bmm_fp8.cu", "flashinfer_gemm_binding.cu"))
    }
    expected_tus["group_gemm.cu"] = "727c326e0f2270748f2c9036dba98fc1b64a6c70e2f8891d23633567cc808ecc"
    for unit in native["translation_units"]:
        check(unit["sha256"] == expected_tus[Path(unit["repository_path"]).name], "collector actual translation unit: " + unit["repository_path"])
    check(len(native["validated_worker_results"]) == len(names), "all expected worker build records")
    image = read(raw / "image.json")
    check(plan["container_image"] in image["RepoDigests"] and image["Architecture"] == "amd64", "immutable image identity")
    output = {"status": "success", "checks": count, "execution_commit": execution, "workers": len(names), "library_sha256": sorted(library_hashes), "ninja_sha256": sorted(ninja_hashes), "private_binaries_verified": args.require_binaries, "scope": "Independent stdlib source/build/fixture provenance audit; no numerical/performance conclusion."}
    args.output.write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output))


if __name__ == "__main__":
    main()
