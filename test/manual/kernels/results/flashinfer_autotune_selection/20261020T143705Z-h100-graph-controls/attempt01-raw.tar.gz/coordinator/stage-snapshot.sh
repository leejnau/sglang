#!/usr/bin/env bash
set -euo pipefail
srun --jobid 2690410 --nodes=1 --ntasks=1 bash -s <<'NODE'
set -euo pipefail
source_commit=e7abea4796b7f5314905888e20728f5e5c59138d
batch=20261020T143705Z-h100-graph-controls
study_dir=/tmp/fi-graph-2690410
durable=/home/lnau/flashinfer-autotune-study
[[ -d "$study_dir/source" && ! -e "$study_dir/source-shared-copy" ]]
mv "$study_dir/source" "$study_dir/source-shared-copy"
git init -q "$study_dir/source"
pack_hash=$(git -C "$study_dir/source" index-pack --stdin < "$durable/$batch-snapshot.pack" | awk '{print $2}')
[[ "$pack_hash" =~ ^[0-9a-f]{40}$ ]]
touch "$study_dir/source/.git/objects/pack/pack-$pack_hash.promisor"
git -C "$study_dir/source" config remote.origin.url https://github.com/leejnau/sglang.git
git -C "$study_dir/source" config remote.origin.promisor true
git -C "$study_dir/source" config core.repositoryformatVersion 1
git -C "$study_dir/source" config extensions.partialClone origin
git -C "$study_dir/source" config core.sparseCheckout true
git -C "$study_dir/source" config core.sparseCheckoutCone false
printf '%s\n' "$source_commit" > "$study_dir/source/.git/shallow"
printf '%s\n' /python/ /test/manual/kernels/ /.gitignore /pyproject.toml > "$study_dir/source/.git/info/sparse-checkout"
git -C "$study_dir/source" update-ref refs/heads/frozen "$source_commit"
git -C "$study_dir/source" symbolic-ref HEAD refs/heads/frozen
git -C "$study_dir/source" read-tree -mu HEAD
[[ "$(git -C "$study_dir/source" rev-parse HEAD)" == "$source_commit" ]]
[[ -z "$(git -C "$study_dir/source" status --porcelain)" ]]
sha256sum "$durable/$batch-snapshot.pack"
tar -xzf "$durable/20261020T034000Z-h100-fp8-linear-attempt01-full-raw.tgz" -C "$study_dir" --strip-components=1 attempt01/fixture
cp "$durable/$batch-preserve.py" "$study_dir/preserve.py"
sha256sum "$study_dir/fixture/fixture.safetensors" "$study_dir/fixture/manifest.json"
nvidia-smi --query-gpu=index,name,uuid,driver_version,pstate,clocks.sm,clocks.mem,power.limit,power.draw,temperature.gpu,memory.total,memory.used --format=csv > "$study_dir/hardware-preflight.csv"
cat "$study_dir/hardware-preflight.csv"
docker image inspect lmsysorg/sglang@sha256:c1f4d9fc6fcf50c2269adbc757ce7b1778883af04155edb888fa9eea3b6648c0 --format '{{.Id}}'
printf '%s\n' "$study_dir"
NODE
