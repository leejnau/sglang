#!/usr/bin/env bash
set -euo pipefail
job_id=${1:?allocation}
source_commit=${2:?frozen source}
batch=20261020T143705Z-h100-graph-controls
srun --jobid "$job_id" --nodes=1 --ntasks=1 bash -s -- "$job_id" "$source_commit" "$batch" <<'NODE'
set -euo pipefail
job_id=$1
source_commit=$2
batch=$3
study_dir="/tmp/fi-graph-$job_id"
durable=/home/lnau/flashinfer-autotune-study
[[ -d "$study_dir/source" && ! -e "$study_dir/source-initial-clone" ]]
mv "$study_dir/source" "$study_dir/source-initial-clone"
cp -a "$durable/source" "$study_dir/source"
git -C "$study_dir/source" fetch "$durable/$batch-source.bundle" HEAD
git -C "$study_dir/source" checkout --detach "$source_commit"
[[ "$(git -C "$study_dir/source" rev-parse HEAD)" == "$source_commit" ]]
[[ -z "$(git -C "$study_dir/source" status --porcelain)" ]]
tar -xzf "$durable/20261020T034000Z-h100-fp8-linear-attempt01-full-raw.tgz" -C "$study_dir" --strip-components=1 attempt01/fixture
cp "$durable/$batch-preserve.py" "$study_dir/preserve.py"
sha256sum "$study_dir/fixture/fixture.safetensors" "$study_dir/fixture/manifest.json"
nvidia-smi --query-gpu=index,name,uuid,driver_version,pstate,clocks.sm,clocks.mem,power.limit,power.draw,temperature.gpu,memory.total,memory.used --format=csv > "$study_dir/hardware-preflight.csv"
cat "$study_dir/hardware-preflight.csv"
docker image inspect lmsysorg/sglang@sha256:c1f4d9fc6fcf50c2269adbc757ce7b1778883af04155edb888fa9eea3b6648c0 --format '{{.Id}}'
printf '%s\n' "$study_dir"
NODE
