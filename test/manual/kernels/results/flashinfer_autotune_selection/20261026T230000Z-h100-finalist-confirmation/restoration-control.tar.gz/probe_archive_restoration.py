"""CPU-only restoration probe against retained private native artifacts."""
import argparse
import hashlib
import importlib.util
import json
import shutil
import tempfile
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--helper', type=Path, required=True)
p.add_argument('--prior-raw', type=Path, required=True)
p.add_argument('--qualified-source', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
assert not a.output.exists()
spec = importlib.util.spec_from_file_location('restoration_under_test', a.helper)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
with tempfile.TemporaryDirectory(prefix='native-restoration-control-') as temporary:
    s = Path(temporary)
    (s / 'runtime-attempt01').mkdir()
    shutil.copytree(a.prior_raw / 'native-build-cache/timing', s / 'runtime-attempt01/cache')
    (s / 'input/current').mkdir(parents=True)
    (s / 'input/current/source').symlink_to(a.qualified_source, target_is_directory=True)
    shutil.copy2(a.prior_raw / 'preservation-manifest-timing.json', s / 'native-preservation.json')
    result = m.restore(s)
    assert result['status'] == 'passed' and result['files_verified'] == 28 and len(result['changes']) == 10
    target = s / 'runtime-attempt01/cache' / m.NATIVE_PREFIX / 'gemm/gemm.so'
    original = target.read_bytes()
    target.write_bytes(original + b'changed')
    try:
        m.restore(s)
    except AssertionError:
        rejected = True
    else:
        raise AssertionError('changed ELF was accepted')
    target.write_bytes(original)
report = dict(status='passed', helper_sha256=hashlib.sha256(a.helper.read_bytes()).hexdigest(), control_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), checks={'actual_cache_restored': 'passed', 'changed_elf_rejected': 'passed'}, positive_result=result, scope='CPU filesystem/content probe only; pinned-container actual Ninja no-work remains a mandatory admission gate.')
a.output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'output': str(a.output), 'files_verified': result['files_verified'], 'timestamps': len(result['changes'])}))
