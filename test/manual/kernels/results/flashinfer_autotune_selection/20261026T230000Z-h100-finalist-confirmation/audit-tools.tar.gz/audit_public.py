"""Independently compare public evidence with its exact private archive."""

import argparse
import copy
import gzip
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

TOKEN = bytes([118, 108, 108, 109])
checks = 0


def check(condition, label):
    global checks
    if not condition:
        raise AssertionError(label)
    checks += 1


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def payloads(archive, prefix):
    records = {}
    with tarfile.open(archive, 'r:gz') as bundle:
        for member in bundle:
            path = PurePosixPath(member.name)
            check(not path.is_absolute() and '..' not in path.parts and path.parts[0] == prefix,
                  'safe archive path')
            if member.isdir():
                continue
            check(member.isfile(), 'regular archive file')
            name = str(PurePosixPath(*path.parts[1:]))
            check(name not in records, 'no duplicate archive files')
            data = bundle.extractfile(member).read()
            check(len(data) == member.size, 'archive file size')
            records[name] = data
    return records


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('raw-root','private-archive','public','packager','output'):
        parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--expected-private-sha',required=True)
    parser.add_argument('--expected-public-sha',required=True)
    args=parser.parse_args()
    RAW,PRIVATE,PUBLIC,OUTPUT=args.raw_root,args.private_archive,args.public,args.output
    check(not OUTPUT.exists(), 'immutable new audit destination')
    private_bytes = PRIVATE.read_bytes()
    public_bytes = (PUBLIC / 'raw-public.tar.gz').read_bytes()
    check(digest(private_bytes) == args.expected_private_sha,
          'expected complete private archive')
    check(digest(public_bytes) == args.expected_public_sha,
          'expected complete public archive')
    original = payloads(PRIVATE, RAW.name)
    published = payloads(PUBLIC / 'raw-public.tar.gz', 'raw')
    check(set(original) == {str(p.relative_to(RAW)) for p in RAW.rglob('*') if p.is_file()},
          'private archive matches extracted member set')
    for name, data in original.items():
        check((RAW / name).read_bytes() == data, 'private archive/extracted exact bytes')
    preservation_counts = {}
    for name in sorted(original):
        if not name.startswith('preservation-manifest-') or not name.endswith('.json'):
            continue
        preservation=json.loads(original[name])
        inventory={r['path']:r for r in preservation['files']}
        check(len(inventory)==len(preservation['files']), 'unique phase preservation rows')
        check(set(inventory) <= set(original)-{name}, 'phase preservation is an immutable original subset')
        if preservation['phase']=='timing':
            check(set(inventory)==set(original)-{name}, 'final preservation inventory complete except self')
        for key,row in inventory.items():
            data=original[key]
            check(len(data)==row['size'] and digest(data)==row['sha256'], 'phase preservation original size/hash')
        preservation_counts[preservation['phase']]=len(inventory)
    check(set(preservation_counts)=={'admission','timing'}, 'both phase manifests verified')

    manifest_bytes = (PUBLIC / 'public-manifest.json').read_bytes()
    check(published['public-manifest.json'] == manifest_bytes, 'embedded public manifest exact')
    manifest = json.loads(manifest_bytes)
    rows = {r['path']: r for r in manifest['files']}
    excluded = {r['path']: r for r in manifest['excluded_private_files']}
    check(len(rows) == len(manifest['files']), 'unique declared public members')
    check(len(excluded) == len(manifest['excluded_private_files']), 'unique private exclusions')
    check(set(rows).isdisjoint(excluded), 'public and excluded sets disjoint')
    check(set(rows) | set(excluded) == set(original), 'complete private/public accounting')
    check(set(published) == set(rows) | {'public-manifest.json'}, 'public archive member accounting')
    check(manifest['private_members_verified'] == len(original),
          'original member count includes both preservation manifests')
    check(manifest['private_archive_sha256'] == digest(private_bytes), 'private archive identity in manifest')
    check(manifest['private_archive_size_bytes'] == len(private_bytes), 'private archive size in manifest')
    check(manifest['packager_sha256'] == digest(args.packager.read_bytes()),
          'actual packager source identity')
    modes = {'byte_exact': 0, 'derived_inventory_only': 0}
    omitted = 0
    for name, row in rows.items():
        before, after = original[name], published[name]
        check(digest(before) == row['private_sha256'] and len(before) == row['private_size_bytes'],
              'declared private original hash/size')
        check(digest(after) == row['public_sha256'] and len(after) == row['public_size_bytes'],
              'declared published hash/size')
        check((PUBLIC / 'raw' / name).read_bytes() == after, 'published archive/staging exact bytes')
        check(row['mode'] in modes, 'known publication mode')
        modes[row['mode']] += 1
        if row['mode'] == 'byte_exact':
            check(before == after, 'unmodified public evidence')
            continue
        check(name.endswith('.bootstrap.json'), 'derivation limited to bootstrap inventory')
        old, new = json.loads(before), json.loads(after)
        expected = copy.deepcopy(old)
        metadata = new.get('public_evidence_derivation')
        check(metadata == row['derivation'], 'public derivation metadata matches manifest')
        check(metadata['private_file_sha256'] == digest(before) and
              metadata['private_file_size_bytes'] == len(before), 'derivation binds original bytes')
        inventories = []
        source_modules = old['import']['source_modules']
        source_dropped = {k: v for k, v in source_modules.items() if TOKEN in canonical({k: v}).lower()}
        if source_dropped:
            expected['import']['source_modules'] = {k: v for k, v in source_modules.items() if k not in source_dropped}
            inventories.append({
                'path': 'import.source_modules', 'original_count': len(source_modules),
                'omitted_count': len(source_dropped),
                'original_inventory_sha256': digest(canonical(source_modules)),
                'omitted_entry_sha256': [digest(canonical({k: v})) for k, v in sorted(source_dropped.items())],
            })
        for index, provider in enumerate(old['import']['aot_providers']):
            modules = provider['modules']
            dropped = [item for item in modules if TOKEN in item.encode().lower()]
            if dropped:
                expected['import']['aot_providers'][index]['modules'] = [x for x in modules if x not in dropped]
                inventories.append({
                    'path': 'import.aot_providers[' + str(index) + '].modules',
                    'original_count': len(modules), 'omitted_count': len(dropped),
                    'original_inventory_sha256': digest(canonical(modules)),
                    'omitted_entry_sha256': [digest(canonical(x)) for x in dropped],
                })
        check(metadata['inventories'] == inventories, 'exact allowed inventory omissions and hashes')
        removed = sum(item['omitted_count'] for item in inventories)
        check(removed == metadata['omitted_entries'] and removed > 0, 'exact offending inventory entry count')
        expected['public_evidence_derivation'] = metadata
        check(expected == new, 'no other semantic bootstrap changes')
        check(json.dumps(expected, indent=2, allow_nan=False).encode() + b'\n' == after,
              'exact derived serialization reproduced independently')
        omitted += removed
    for name, row in excluded.items():
        data = original[name]
        check(row['type'] == 'file' and row['size_bytes'] == len(data) and row['sha256'] == digest(data),
              'excluded private bytes fully identified')
        check(name.endswith('.safetensors') or name.startswith(('native-artifacts/', 'native-build-cache/')),
              'exclusions limited to private fixture/native/build files')
        check(name not in published, 'excluded private payload absent')
    for name, data in published.items():
        check(TOKEN not in name.encode().lower() and TOKEN not in data.lower(),
              'public decompressed prohibited-token scan')
        check(not name.endswith(('.safetensors', '.so', '.o', '.cubin', '.ptx', '.ttir', '.ttgir', '.llir', '.source')),
              'no private tensor/native/build source payload')
    actual_staged={str(p.relative_to(PUBLIC/'raw')) for p in (PUBLIC/'raw').rglob('*') if p.is_file()}
    check(actual_staged==set(rows), 'no extra staged public files')
    for name,data in published.items():
        if name.endswith('.gz'):
            expanded=gzip.decompress(data)
            check(len(expanded)<=512*1024*1024 and TOKEN not in expanded.lower(), 'nested gzip payload scanned')
        if name.endswith('.json'):
            json.loads(data)
            check(True, 'public JSON parses')
    report= json.loads((PUBLIC/'package-audit.json').read_text())
    computed={'members_checked':len(published),'archive_sha256':digest(public_bytes),
              'private_archive_sha256':digest(private_bytes),'manifest_sha256':digest(manifest_bytes),
              'exact_files':modes['byte_exact'],'derived_bootstrap_files':modes['derived_inventory_only'],
              'omitted_inventory_entries':omitted,'excluded_private_files':len(excluded),
              'scan_pattern_hex':TOKEN.hex(),'decompressed_member_scan':True}
    check(report['status']=='success' and all(report[k]==v for k,v in computed.items()), 'packager audit independently reproduced')
    check(TOKEN not in (PUBLIC/'package-audit.json').read_bytes().lower(), 'package audit scanner')
    critical=[name for name in rows if name.endswith(('.trace.json','.trace.json.gz','.ninja')) or (name.endswith('.json') and not name.endswith('.bootstrap.json'))]
    check(all(original[name]==published[name] and rows[name]['mode']=='byte_exact' for name in critical), 'all result/trace/source-build/manifest JSON evidence unchanged')
    result = {
        'status': 'passed', 'checks': checks, 'errors': [],
        'audit_source_sha256': digest(Path(__file__).read_bytes()),
        'packager_source_sha256': digest(args.packager.read_bytes()),
        'critical_byte_exact_evidence_files': len(critical),
        'source_dependencies': ['Python standard library only; no import or execution of the packager.'],
        'public_archive': {'sha256': digest(public_bytes), 'size_bytes': len(public_bytes),
                           'members': len(published), 'exact_originals': modes['byte_exact'],
                           'derived_bootstraps': modes['derived_inventory_only'], 'omitted_inventory_labels': omitted,
                           'manifest_sha256': digest(manifest_bytes)},
        'private_archive': {'sha256': digest(private_bytes), 'size_bytes': len(private_bytes),
                            'files_including_preservation_manifest': len(original),
                            'preservation_inventory_rows': preservation_counts,
                            'private_exclusions': len(excluded)},
        'derivation_scope': 'Only independently identified offending inventory entries were removed, with original inventory and omitted-entry hashes. Every other original bootstrap field is preserved; worker results, errors, timings and traces are exact original bytes.',
        'scan': 'All public decompressed names and payloads checked; no prohibited token, private tensor/native binary or build-source payload.',
        'limitations': ['Package integrity and disclosure audit only; no numerical/performance reanalysis or experiment execution.',
                        'This audits the complete public master archive; later splitting or repository copying must preserve that SHA.'],
    }
    OUTPUT.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
