"""Independent raw arithmetic and interpretation data for shadow confirmation.

No benchmark/analyzer imports. Eight fresh processes are the inference units;
paired windows and admission never become additional independent observations.
"""
from __future__ import annotations
import argparse
import collections
import hashlib
import json
import math
import random
import statistics
from pathlib import Path

SOURCE_COMMIT='77ea4b9a6de1f03fdf8666cead7b27f4fbed4908'
GEMM_SHA='72690cacca4ce1d69ccaa6b9190475483d984bd58de0962d06c874c801c678d6'
TIMING_SHA='e442a689064fe3af4ab46510b2d5aaf3597b072949b84f13d14e9e53352109e4'
SEED=202610262300

def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def encoded(x):return json.dumps(x,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def require(value,label):
    if not value:raise AssertionError(label)
def q7(values,q):
    values=sorted(values);p=(len(values)-1)*q;lo=math.floor(p);hi=math.ceil(p)
    return values[lo]+(values[hi]-values[lo])*(p-lo)
def median_logs(pairs,role_key,value_key):
    logs=[]
    for pair in pairs:
        rows=pair['measurements'];values={r[role_key]:r[value_key] for r in rows}
        require(len(rows)==2 and set(values)=={'winner','default'},'one result per role')
        require(all(type(v) in (float,int) and math.isfinite(v) and v>0 for v in values.values()),'finite positive pair durations')
        logs.append(math.log(values['winner']/values['default']))
    return logs,statistics.median(logs)
def finalist(rows):
    candidates=[r for r in rows if r['m']==144 and r['tactic']!=-1 and r.get('error') is None and type(r['elapsed_ms']) in (float,int) and math.isfinite(r['elapsed_ms']) and r['elapsed_ms']>0]
    require(candidates,'finite explicit candidates')
    return min(candidates,key=lambda r:r['elapsed_ms'])
def effect(old,new,layer_log):
    old_cost=layer_log if old=='winner' else 0.
    new_cost=layer_log if new=='winner' else 0.
    optimum=min(layer_log,0.)
    delta=new_cost-old_cost
    outcome='unchanged_choice' if old==new else 'measured_better' if delta<0 else 'measured_worse' if delta>0 else 'changed_choice_measured_tie'
    return {'effect_log':delta,'effect_ratio':math.exp(delta),'original_regret_log':old_cost-optimum,'confirmed_regret_log':new_cost-optimum,'outcome':outcome}
def trace_graph(path,graph):
    events=read(path)['traceEvents']
    marks=[e for e in events if e.get('cat')=='user_annotation' and e.get('name')=='retained_'+graph]
    require(len(marks)==1,'single retained CPU marker')
    mark=marks[0];contained=[e for e in events if mark['ts']<=e.get('ts',-1)<=mark['ts']+mark['dur']]
    require(sum('cudaGraphLaunch' in e.get('name','') for e in contained)==3,'three real graph launches')
    kernels=sorted((e for e in contained if e.get('cat')=='kernel'),key=lambda e:e['ts'])
    fields=('device','grid','block','registers per thread','shared memory')
    sig=[{'name':e['name'],**{k:e.get('args',{}).get(k) for k in fields}} for e in kernels]
    require(len(sig)>=6 and len(sig)%3==0,'three complete quantizer/GEMM cycles')
    size=len(sig)//3
    require(sig[:size]==sig[size:2*size]==sig[2*size:],'same original graph repeated signature')
    return sig[:size]

def analyze(raw,official=None):
    manifest=read(raw/'manifest-timing.json')
    require(manifest['execution_commit']==SOURCE_COMMIT,'actual frozen execution source')
    expected_worker=manifest['source_sha256']['test/manual/kernels/bench_flashinfer_finalist_confirmation.py']
    processes=[];containers=[];traces=[];query_counts=collections.Counter();retained_hashes=collections.Counter()
    for block in range(8):
        path=raw/f'block{block}-auto_synthetic-timing.json';x=read(path)
        require(x['status']=='success' and x['mode']=='timing' and x['block']==block,'complete planned worker')
        require(path.with_suffix('.exit-code').read_text().strip()=='0','successful process exit')
        containers.append(path.with_suffix('.container-id').read_text().strip())
        bootstrap=read(path.with_name(path.stem+'.bootstrap.json'))
        require(bootstrap['status']=='passed' and bootstrap['result_sha256']==sha(path) and bootstrap['worker_sha256']==x['worker_sha256']==expected_worker,'bootstrap binds actual result and frozen source')
        require(bootstrap['native_identity_passthrough'] is True,'real native provider object')
        for name,expected in (('gemm',GEMM_SHA),('trtllm_utils',TIMING_SHA)):
            require(bootstrap['native']['providers'][name]['library_sha256']==expected,'exact reused native ELF')
        rows=x['startup']['profiles'];require(len(rows)==81,'all original measurements')
        require(all(type(r['elapsed_ms']) in (float,int) and math.isfinite(r['elapsed_ms']) and r['elapsed_ms']>0 and r['error'] is None for r in rows),'all81 original finite')
        best=finalist(rows);require(best['tactic']==x['finalist']['tactic'] and best['index']==x['finalist']['profile_index'],'dynamic finalist independently recomputed')
        old=min(rows[72:81],key=lambda r:r['elapsed_ms'])
        old_role='default' if old['tactic']==-1 else 'winner'
        require(old['tactic']==x['natural']['tactic']==x['startup_choices'][0]['tactic'],'actual original choice unchanged')
        require(old['tactic'] in (-1,best['tactic']),'natural choice within held-out pair')
        conf=x['confirmation'];logs,confirm_log=median_logs(conf['rounds'],'role','elapsed_ms')
        require(len(logs)==12,'all12 confirmation pairs')
        new_role='winner' if confirm_log<0 else 'default'
        require(conf['decision_role']==new_role and conf['median_log_ratio']==confirm_log,'median-log shadow choice')
        payload={'explicit_tactic':best['tactic'],'default_tactic':-1,'pair_orders':[p['order'] for p in conf['rounds']],'log_ratios':logs,'median_log_ratio':confirm_log,'decision_role':new_role,'decision_tactic':best['tactic'] if new_role=='winner' else -1,'decided_ns':conf['decided_ns']}
        digest=hashlib.sha256(encoded(payload)).hexdigest()
        require(payload==conf['decision_payload'] and digest==conf['decision_sha256']==conf['initial_decision_sha256']==x['final']['decision_sha256'],'immutable decision payload reconstructed')
        graph_rows={g['id']:g for g in x['graphs']}
        require(set(graph_rows)=={'winner','default'} and all(g['confirmation_decision_sha256']==digest and g['capture_started_ns']>conf['decided_ns'] for g in graph_rows.values()),'decision precedes both exact retained graphs')
        glogs,layer_log=median_logs(x['rounds'],'graph_id','gpu_event_per_replay_ms')
        require(len(glogs)==24,'all24 held-out graph pairs')
        all_checks=x['correctness']+x['profile_correctness'];require(all(r['passed'] for r in all_checks),'all output checks pass')
        require(len(x['diagnostic_profile_attempts'])==24 and x['total_actual_profiler_calls']==105 and not x['forbidden_profile_attempts'],'bounded81+24 profiling')
        require(x['post_timing_acceptance']['used_descriptor']==1 and x['synthetic_acceptance'][0]['used_descriptor']==1,'explicit accepted at serving/synthetic inputs')
        require(x['final']['cache_unchanged'] and x['final']['operands_unchanged'] and x['natural']['cache_preserved_after_confirmation'],'cache and read operands preserved')
        trace=path.with_suffix('.trace.json');require(sha(trace)==x['trace']['sha256'],'actual original graph trace identity')
        signatures={role:trace_graph(trace,role) for role in ('winner','default')}
        traces.append({'block':block,'finalist':best['tactic'],'signatures':signatures})
        for pair in x['rounds']:
            for sample in pair['measurements']:
                query_counts[sample['queue_evidence']]+=1
                require(sample['profile_attempts_before']==sample['profile_attempts_after']==81,'no profiler in graph timing windows')
        for r in x['diagnostic_profile_attempts']:
            require(r['tensor_object_ids']==x['retained_profile']['tensor_object_ids'],'same exact profiling objects')
        retained_hashes[tuple(x['retained_profile']['read_operand_hashes'])]+=1
        scored=effect(old_role,new_role,layer_log)
        processes.append({'block':block,'raw_sha256':sha(path),'capture_order':x['capture_order'],'finalist':best['tactic'],'finalist_profile_index':best['index'],'natural_role':old_role,'confirmed_role':new_role,'transition':old_role+'->'+new_role,'original_profile_log_ratio':math.log(best['elapsed_ms']/rows[72]['elapsed_ms']),'confirmation_log_ratio':confirm_log,'layer_log_ratio':layer_log,**scored,'confirmation_order_strata':{role:statistics.median(v for v,p in zip(logs,conf['rounds']) if p['order'][0]==role) for role in ('winner','default')},'graph_order_strata':{role:statistics.median(v for v,p in zip(glogs,x['rounds']) if p['order'][0]==role) for role in ('winner','default')},'numerical_checks':{'serving':len(x['correctness']),'synthetic':len(x['profile_correctness'])}})
    require(len(set(containers))==8,'eight fresh containers')
    metric_source={'hypothetical_over_original':'effect_log','finalist_graph_over_default':'layer_log_ratio','confirmation_finalist_over_default':'confirmation_log_ratio','original_profile_finalist_over_default':'original_profile_log_ratio','original_regret_two_candidate_only':'original_regret_log','confirmed_regret_two_candidate_only':'confirmed_regret_log'}
    values={key:[p[field] for p in processes] for key,field in metric_source.items()}
    rng=random.Random(SEED);draws={key:[] for key in values}
    for _ in range(100000):
        chosen=[rng.randrange(8) for _ in range(8)]
        for key,xs in values.items():draws[key].append(math.exp(sum(xs[i] for i in chosen)/8))
    metrics={key:{'geometric_mean_ratio':math.exp(statistics.mean(xs)),'min_ratio':math.exp(min(xs)),'max_ratio':math.exp(max(xs)),'below_one':sum(x<0 for x in xs),'above_one':sum(x>0 for x in xs),'equal_one':sum(x==0 for x in xs),'exploratory_whole_process_bootstrap_95pct':[q7(draws[key],.025),q7(draws[key],.975)]} for key,xs in values.items()}
    comparison=None
    if official:
        theirs=read(official);require(theirs['status']=='passed','official analyzer complete')
        for key,row in metrics.items():
            actual=theirs['metrics'][key]
            for field in ('geometric_mean_ratio','min_ratio','max_ratio'):
                require(math.isclose(row[field],actual[field],rel_tol=1e-12,abs_tol=1e-15),'independent metric matches '+key+field)
            for p,q in zip(row['exploratory_whole_process_bootstrap_95pct'],actual['exploratory_process_bootstrap_95pct']):
                require(math.isclose(p,q,rel_tol=1e-12,abs_tol=1e-15),'independent whole-process bootstrap matches')
        comparison={'all_six_metrics_and_bootstrap_intervals_match':True,'analysis_sha256':sha(official)}
    capture={order:{'blocks':[p['block'] for p in processes if p['capture_order']==order],'hypothetical_over_original':math.exp(statistics.mean(p['effect_log'] for p in processes if p['capture_order']==order)),'finalist_graph_over_default':math.exp(statistics.mean(p['layer_log_ratio'] for p in processes if p['capture_order']==order)),'transitions':dict(collections.Counter(p['transition'] for p in processes if p['capture_order']==order))} for order in ('winner-first','default-first')}
    descriptors=[]
    for identity in dict.fromkeys(tuple(p['finalist']) for p in processes):
        group=[p for p in processes if tuple(p['finalist'])==identity]
        descriptors.append({'tactic':list(identity),'blocks':[p['block'] for p in group],'n':len(group),'transitions':dict(collections.Counter(p['transition'] for p in group)),'graph_geometric_mean':math.exp(statistics.mean(p['layer_log_ratio'] for p in group))})
    return {'status':'success','final':True,'execution_commit':SOURCE_COMMIT,'scope':'Independent raw arithmetic; eight current fresh-process units only; no admission or historical pooling.','metrics':metrics,'process_rows':processes,'transitions':dict(collections.Counter(p['transition'] for p in processes)),'outcomes':dict(collections.Counter(p['outcome'] for p in processes)),'capture_order_strata':capture,'per_descriptor':descriptors,'queue_outcomes_all_retained':dict(query_counts),'retained_profile_read_hash_groups':[{'hashes':list(k),'processes':v} for k,v in retained_hashes.items()],'serving_trace_signatures':traces,'official_comparison':comparison,'bootstrap':{'replicates':100000,'seed':SEED,'unit':'fresh process','quantile':'type7'},'reproducibility':{'script_sha256':sha(__file__),'benchmark_or_analyzer_imports':False},'interpretation_limits':['The shadow decision was fixed before graph capture; both choices use the same post-confirmation graphs. This is not an implemented-policy throughput comparison.','Finalist identity is selected by the first pass and may vary across processes; two-candidate regret is not a full oracle.','Confirmation uses synthetic inputs; the serving graph uses captured activations and quantization.','First-position and capture-order strata are descriptive small-n evidence; capture/allocation/history remain bundled.','Fixed fixture and one device/time window; no general safety, rare-error-rate or equivalence inference.']}

def self_test():
    controls=[]
    for old,new,L,expected in (('default','default',math.log(1.2),1.),('winner','winner',math.log(.8),1.),('winner','default',math.log(1.2),1/1.2),('default','winner',math.log(1.2),1.2),('default','winner',math.log(.8),.8),('winner','default',math.log(.8),1/.8)):
        x=effect(old,new,L);require(math.isclose(x['effect_ratio'],expected),'known counterfactual effect');require(x['original_regret_log']>=0 and x['confirmed_regret_log']>=0,'nonnegative two-candidate regret');controls.append({'control':old+'->'+new+':'+str(L),'passed':True})
    rows=[{'m':144,'tactic':-1,'elapsed_ms':.1,'error':None},{'m':144,'tactic':[2]*8,'elapsed_ms':.4,'error':None},{'m':144,'tactic':[3]*8,'elapsed_ms':.3,'error':None},{'m':144,'tactic':[4]*8,'elapsed_ms':.3,'error':None}]
    require(finalist(rows)['tactic']==[3]*8,'dynamic finalist tie order');controls.append({'control':'dynamic finalist first exact tie','passed':True})
    pairs=[{'measurements':[{'role':'winner','elapsed_ms':ratio},{'role':'default','elapsed_ms':1.}]} for ratio in [.5]*6+[1.8]*6]
    require(median_logs(pairs,'role','elapsed_ms')[1]<0 and statistics.median([.5]*6+[1.8]*6)>1,'actual even median-log boundary');controls.append({'control':'median log differs arithmetic median ratio','passed':True})
    require(q7([0,10],.25)==2.5,'type7 interpolation');controls.append({'control':'type7 quantile','passed':True})
    return {'status':'success','count':len(controls),'controls':controls,'script_sha256':sha(__file__)}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw',type=Path)
    parser.add_argument('--official',type=Path)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--self-test',action='store_true')
    a=parser.parse_args()
    result=self_test() if a.self_test else analyze(a.raw,a.official)
    text=json.dumps(result,indent=2,allow_nan=False)+'\n'
    require(bytes([118,108,108,109]) not in text.lower().encode(),'public result byte scan')
    a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(text)
    print(json.dumps({'status':result['status'],'path':str(a.output),'sha256':sha(a.output)}))

if __name__=='__main__':main()
