#!/usr/bin/env python3
"""Derive a concise summary from an independently audited fixed calibration."""
import hashlib
import json
import statistics
from pathlib import Path

BASE = Path(__file__).parent
RAW = Path('/private/tmp/fi-next-steps-20261024/coordinator/calibration-raw/attempt01')
AUDIT = BASE / 'final-audit.json'
d = json.loads(AUDIT.read_text())
manifest = json.loads((RAW / 'manifest.json').read_text())
processes = d['processes']
absolute = []
for method in ('plain5120', 'queued16_10m', 'queued16_40m'):
    for graph in ('graph_a', 'graph_b'):
        values = [next(row['median'] for row in p['absolute_event_us']
                       if row['method'] == method and row['graph'] == graph)
                  for p in processes]
        absolute.append({'method': method, 'graph': graph,
                         'median_of_six_process_medians_us': statistics.median(values),
                         'range_of_process_medians_us': [min(values), max(values)]})
queries = []
for method in ('plain5120', 'queued16_10m', 'queued16_40m'):
    rows = [r for p in processes for r in p['query_outcomes'] if r['method'] == method]
    queries.append({'method': method, 'batches': sum(r['pending'] + r['complete_inconclusive'] for r in rows),
                    'pending_start_after_enqueue': sum(r['pending'] for r in rows),
                    'completed_start_inconclusive': sum(r['complete_inconclusive'] for r in rows),
                    'excluded': sum(r['excluded'] for r in rows)})
recorded = json.loads((RAW / 'final-analysis.json').read_text())
rerun = json.loads((BASE / 'frozen-analyzer-rerun.json').read_text())
path_differences = []
def normalize(a, b, path=''):
    if isinstance(a, dict) and isinstance(b, dict):
        if set(a) != set(b): raise AssertionError('summary keys differ')
        return {key: normalize(a[key], b[key], path + '/' + key) for key in a}
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b): raise AssertionError('summary lengths differ')
        return [normalize(x, y, path + '/' + str(i)) for i, (x, y) in enumerate(zip(a,b))]
    if a != b:
        if not path.endswith('/file'): raise AssertionError('non-path frozen rerun discrepancy: ' + path)
        path_differences.append(path)
    return a
normalize(recorded, rerun)
summary = {
    'status': 'FINAL_immutable',
    'batch': '20261024T090000Z-h100-replay-calibration',
    'source_commit': d['source_commit'],
    'audit_sha256': hashlib.sha256(AUDIT.read_bytes()).hexdigest(),
    'summary_generator_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'scope': {
        'independent_units': 'Six fresh processes, fixed fixture/input seed19; dependent paired rounds are not additional independent trials.',
        'hardware': {key: manifest['gpu'][key] for key in ('name','uuid','driver_version','power.limit [W]')},
        'fixture_sha256': manifest['fixture_tensor_file_sha256'],
        'shape_m_n_k': [144,4096,1024],
        'software': 'Torch2.14.1+cu130; FlashInfer0.7.2 plus exact reviewed descriptor overlay; unchanged v2 auto policy.',
        'measured': 'Two retained genuine-default CUDA Graphs of actual SGLang static FP8 quantization plus BMM; startup winner deliberately not consumed.',
        'recipe': '24 complete paired rounds; all six method orders repeated four times, graph order balanced; fixed six processes, capture3/3.',
        'primary': 'External GPU-event batch span divided by replay count, then same-round ratios and six process medians.',
    },
    'validation': {**d['totals'], 'independent_math_comparisons': d['official_comparison']['numeric_comparisons'],
                   'actual_default_graph_signatures_identical_in_all_processes': all(p['trace']['both_default_graphs_same_launch_signature'] for p in processes),
                   'frozen_analyzer_rerun': {'status': 'pass', 'byte_identical': False,
                       'only_differences': '13 location fields (/file): downloaded raw root versus container root, including canonical/final build-provenance filename. All values, source/native/worker/trace hashes and analysis statistics identical.',
                       'location_fields': len(path_differences),
                       'sha256': hashlib.sha256((BASE/'frozen-analyzer-rerun.json').read_bytes()).hexdigest()}},
    'same_graph_method_and_capture_order_ratios': d['summaries'],
    'absolute_event_microseconds': absolute,
    'queue_evidence': queries,
    'interpretation': [
        'Queued16/10m event time is 1.30% to1.51% above plain5120/noqueue at the process-median level for both graphs, in all six processes. This is a complete-recipe difference, not a pure host-cost estimate.',
        'At fixed16-replay windows, increasing prequeue10m to40m changes median event ratios by about -0.112% for graph_a and -0.035% for graph_b. The graph_a exploratory interval excludes1; graph_b crosses1. Delay sensitivity is smaller than the contextual0.65% scale here, without an equivalence claim.',
        'All queued starts were pending after all timed commands were issued, providing queue-ahead evidence. Completed starts in plain5120 are inconclusive about submission gaps and were retained.',
        'Both retained graphs launch the same quantizer and GEMM signatures, yet first/second capture uncertainty remains about0.73% to1.18% across exploratory interval widths. Sub0.65% capture/selection resolution is unresolved.',
        'The study does not invalidate the observed18.9% to22.0% explicit-winner regressions in the prior fixed study. Those are much larger than this calibration scale and had different actual GEMM signatures.',
        'No serving-throughput or universal tuning-quality claim follows from this single static FP8 fixture/H100.'
    ],
    'decision': {
        'subpercent_resolution': 'unresolved',
        'do_not_expand_based_on_this_alone': 'Do not promote tiny selection/capture differences to performance claims or assume all timing recipes equivalent.',
        'next_bounded_step_if_authorized': 'Qualify the reviewed current-source native provider and fixture ownership/numerics, resolving stale-output refresh coverage before an input/objective matrix. Retain same-object graph controls and report recipe/capture uncertainty; no automatic new experiment.',
    },
    'limits': d['limits'],
}
output = BASE / 'final-summary.json'
if output.exists(): raise FileExistsError('refusing to overwrite final summary')
output.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':'success','output':str(output),'sha256':hashlib.sha256(output.read_bytes()).hexdigest()}))
