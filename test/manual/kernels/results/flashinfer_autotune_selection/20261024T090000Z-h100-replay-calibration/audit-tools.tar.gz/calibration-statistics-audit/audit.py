#!/usr/bin/env python3
"""Independent six-process replay-calibration audit; imports no study analyzer."""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
import math
import re
import types
from pathlib import Path

HELPER = Path("/private/tmp/fi-next-steps-20261024/history-statistics-audit/audit.py")
source = HELPER.read_bytes()
independent = types.ModuleType("independent_occupancy_bootstrap")
independent.__file__ = str(HELPER)
exec(compile(source, str(HELPER), "exec"), independent.__dict__)
check, close, median = independent.check, independent.close, independent.median
bootstrap, describe = independent.bootstrap_distribution, independent.describe_trials
METHODS = {
    "plain5120": (5120, 0),
    "queued16_10m": (16, 10_000_000),
    "queued16_40m": (16, 40_000_000),
}
GRAPHS = ("graph_a", "graph_b")
PLAN_SHA = "1f263135413a4c331f0408961da46fa11718ae2f19332c8cc2edacc71e4424a6"
SOURCE = Path("/private/tmp/sglang-autotune-selection-study")
BATCH = "test/manual/kernels/results/flashinfer_autotune_selection/20261024T090000Z-h100-replay-calibration"


def load(path):
    return json.loads(Path(path).read_text())


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ratios_within_process(rounds, capture_order):
    tables = []
    for group in rounds:
        table = {}
        for sample in group["measurements"]:
            key = sample["method"], sample["graph_id"]
            check(key not in table, "duplicate method/graph in complete round")
            table[key] = sample["gpu_event_batch_ms"] / sample["replays"]
        check(set(table) == {(method, graph) for method in METHODS for graph in GRAPHS},
              "round excluded a graph/method")
        tables.append(table)
    rows = []
    for graph in GRAPHS:
        for upper, lower in (
            ("queued16_10m", "plain5120"),
            ("queued16_40m", "queued16_10m"),
            ("queued16_40m", "plain5120"),
        ):
            values = [table[upper, graph] / table[lower, graph] for table in tables]
            rows.append({"kind": "same_graph_method_ratio", "graph": graph,
                         "numerator": upper, "denominator": lower,
                         "estimate": median(values), "paired_round_values": values})
    first, second = capture_order
    for method in METHODS:
        values = [table[method, first] / table[method, second] for table in tables]
        rows.append({"kind": "capture_order_ratio", "method": method,
                     "first_graph": first, "second_graph": second,
                     "estimate": median(values), "paired_round_values": values})
    return rows


def trace_identity(data, raw_root):
    cal = data["calibration"]
    trace = cal["post_timing_trace"]
    last = max(sample["ended_ns"] for group in cal["rounds"] for sample in group["measurements"])
    check(last < cal["pre_trace_checks"]["ended_ns"] < trace["started_ns"] <
          trace["ended_ns"] < cal["post_trace_checks"]["ended_ns"], "trace entered primary timing")
    path = raw_root / Path(trace["path"]).name
    check(sha(path) == trace["sha256"], "trace bytes changed")
    events = load(path)["traceEvents"]
    captures = {graph["id"]: graph for graph in data["graph_controls"]["graphs"]}
    observed = {graph["graph_id"]: graph for graph in trace["graphs"]}
    identities, correlations = {}, set()
    for name in GRAPHS:
        original, recorded = captures[name], observed[name]
        check(original["graph_object_id"] == recorded["graph_object_id"] and
              original["output"]["data_ptr"] == recorded["output_data_ptr"],
              "trace replaced the measured graph")
        scopes = [event for event in events if event.get("cat") == "user_annotation"
                  and event.get("name") == "retained_" + name]
        check(len(scopes) == 1, "ambiguous CPU trace annotation")
        start, end = scopes[0]["ts"], scopes[0]["ts"] + scopes[0]["dur"]
        launches = sorted([event for event in events if event.get("cat") == "cuda_runtime"
                           and "cudaGraphLaunch" in event.get("name", "")
                           and start <= event["ts"] <= end], key=lambda event: event["ts"])
        check(len(launches) == 3, "three original-graph replays required")
        sequences, graph_ids = [], set()
        for launch in launches:
            correlation = launch["args"]["correlation"]
            check(correlation not in correlations, "trace correlation reused")
            correlations.add(correlation)
            kernels = sorted([event for event in events if event.get("cat") == "kernel"
                              and event.get("args", {}).get("correlation") == correlation],
                             key=lambda event: event["ts"])
            check(len(kernels) == 2, "expected actual quantizer/GEMM pair")
            check(all(start <= event["ts"] < event["ts"] + event["dur"] <= end + 1
                      for event in kernels), "GPU work escapes CPU graph range")
            graph_ids.update(event["args"]["graph id"] for event in kernels)
            sequences.append([
                [event["name"], *(event["args"][field] for field in
                  ("device", "grid", "block", "registers per thread", "shared memory"))]
                for event in kernels
            ])
        check(sequences[0] == sequences[1] == sequences[2] and
              "static_quant_fp8" in sequences[0][0][0], "retained launch signatures changed")
        check(len(graph_ids) == 1 and next(iter(graph_ids)) > 0, "actual CUDA graph identity changed")
        identities[name] = {"cuda_graph_id": next(iter(graph_ids)),
                            "ordered_signature": sequences[0],
                            "python_graph_object_id": original["graph_object_id"],
                            "output_data_ptr": original["output"]["data_ptr"]}
    check(identities["graph_a"]["cuda_graph_id"] != identities["graph_b"]["cuda_graph_id"],
          "same CUDA graph presented under both labels")
    check(len([event for event in events if event.get("cat") == "kernel"]) == 12,
          "undeclared kernels in trace")
    return {"path": str(path), "sha256": sha(path), "identities": identities,
            "both_default_graphs_same_launch_signature":
                identities["graph_a"]["ordered_signature"] == identities["graph_b"]["ordered_signature"]}


def audit_process(path, scheduled, round_plan, args):
    data = load(path)
    check(data["status"] == "success" and path.with_suffix(".exit-code").read_text().strip() == "0",
          "incomplete/failed process")
    check(data["trial"] == scheduled["trial"] and data["arm"] == "auto", "wrong process/objective")
    check(data["environment"]["sglang_commit"] == args.source_commit, "wrong frozen source")
    cal = data["calibration"]
    check(cal["all_samples_retained"] is True and
          cal["queue_query_is_exclusion_criterion"] is False and cal["pending_sample"] is None,
          "sample filtering or incomplete sample")
    check(cal["methods"] == {method: {"replays": values[0], "prequeue_cycles": values[1]}
                             for method, values in METHODS.items()}, "different timing contract")
    capture = ["graph_a", "graph_b"] if scheduled["capture_order"] == "a-first" else ["graph_b", "graph_a"]
    check(cal["capture_order"] == data["graph_controls"]["capture_order"] == capture,
          "unbalanced actual capture order")
    graphs = {graph["id"]: graph for graph in data["graph_controls"]["graphs"]}
    check(set(graphs) == set(GRAPHS), "missing original graph")
    check(len({graph["output"]["data_ptr"] for graph in graphs.values()}) == 2,
          "primary output allocation shared")
    for graph in graphs.values():
        selection = graph["selection"]
        check(graph["tactic"] == -1 and selection["tactic"] == -1 and
              selection["cache_hit"] is False and selection["lookup_tier"] == "miss",
              "actual tuned winner consumed instead of default miss")
    check(data["profile_attempts"] == len(data["profiles"]) and not data["forbidden_profile_attempts"],
          "profile attempt mismatch")
    for state in ("file_sha256", "winner_sha256", "loaded_file_sha256"):
        check(cal["pre_trace_checks"][state] == cal["post_trace_checks"][state],
              "trace changed tuned caches")
    check(cal["pre_trace_checks"]["profile_attempts"] == cal["post_trace_checks"]["profile_attempts"] ==
          data["profile_attempts"], "trace changed profiling attempts")
    check(data["cache"]["after_startup_sha256"] == data["cache"]["after_controls_sha256"],
          "startup cache changed")
    check(len(cal["rounds"]) == len(round_plan) == 24, "round count changed")
    expected_schedule = [{key: row[key] for key in ("methods", "graph_order")} for row in round_plan]
    check(cal["schedule"] == expected_schedule, "round schedule changed")
    counts = collections.Counter((tuple(row["methods"]), tuple(row["graph_order"])) for row in expected_schedule)
    check(len(counts) == 12 and set(counts.values()) == {2}, "method/graph counterbalance lost")
    latest = cal["captures_finished_ns"]
    absolute = collections.defaultdict(list)
    query = collections.Counter()
    diagnostics = collections.defaultdict(list)
    correct = {row["check"]: row for row in data["correctness"]["checks"]}
    check(data["correctness"]["passed"] and len(correct) == len(data["correctness"]["checks"]),
          "numerical evidence incomplete")
    for group, requested in zip(cal["rounds"], round_plan):
        check(group["index"] == requested["index"] and
              group["methods"] == requested["methods"] and group["graph_order"] == requested["graph_order"],
              "wrong complete-round order")
        expected = [(method, graph) for method in requested["methods"] for graph in requested["graph_order"]]
        check([(sample["method"], sample["graph_id"]) for sample in group["measurements"]] == expected,
              "sample excluded/reordered")
        for sample in group["measurements"]:
            method, graph = sample["method"], sample["graph_id"]
            repeats, delay = METHODS[method]
            check(sample["replays"] == repeats and sample["prequeue_cycles"] == delay,
                  "wrong replay normalization/queue")
            check(independent.positive(sample["gpu_event_batch_ms"]), "invalid event span")
            event = sample["gpu_event_batch_ms"] / repeats
            close(event, sample["gpu_event_per_replay_ms"], "event per replay normalization")
            check(sample["graph_object_id"] == graphs[graph]["graph_object_id"] and
                  sample["output_data_ptr"] == graphs[graph]["output"]["data_ptr"],
                  "method changed graph object/allocation")
            check(sample["profile_attempts_before"] == sample["profile_attempts_after"] == data["profile_attempts"] and
                  sample["policy_scope_active"] is False and sample["tuning_mode"] is False,
                  "profiling/context during timing")
            completed = sample["start_event_complete_after_enqueue"]
            check(type(completed) is bool and sample["start_query_error"] is None,
                  "query error silently accepted")
            expected_evidence = ("start_complete_inconclusive" if completed else "start_pending_after_enqueue") if delay else "not_prequeued"
            check(sample["queue_evidence"] == expected_evidence, "query outcome mislabeled")
            query[method, graph, completed] += 1
            begin, enqueue, issued, end = [sample[field] for field in
                ("wall_started_ns", "enqueue_started_ns", "enqueue_ended_ns", "ended_ns")]
            check(latest < begin <= enqueue < issued <= end, "timing chronology")
            close((issued - enqueue) / 1e6, sample["enqueue_cpu_ms"], "CPU enqueue normalization")
            close((end - begin) / 1e6, sample["wall_including_prequeue_ms"], "diagnostic wall normalization")
            check(sample["wall_diagnostic_only"] and sample["enqueue_span_includes_start_query"],
                  "wall/CPU scope misrepresented")
            stage = sample["correctness_check"]
            numeric = correct[stage]
            check(numeric["graph_id"] == graph and numeric["output_data_ptr"] == graphs[graph]["output"]["data_ptr"] and
                  numeric["quantized_reference"]["passed"] and numeric["quantized_reference"]["max_normalized_error"] <= 1,
                  "timed numerical check inspected wrong output")
            absolute[method, graph].append(event * 1000)
            diagnostics[method, "wall_ms_including_intentional_wait"].append(sample["wall_including_prequeue_ms"])
            diagnostics[method, "enqueue_ms_including_query"].append(sample["enqueue_cpu_ms"])
            latest = end
    estimates = ratios_within_process(cal["rounds"], capture)
    for row in estimates:
        row["trial"] = data["trial"]
    return {
        "trial": data["trial"], "file": str(path), "sha256": sha(path),
        "container_id": path.with_suffix(".container-id").read_text().strip(),
        "capture_order": capture, "estimates": estimates,
        "absolute_event_us": [{"method": method, "graph": graph, "samples": len(values),
                               "median": median(values), "range": [min(values), max(values)]}
                              for (method, graph), values in absolute.items()],
        "query_outcomes": [{"method": method, "graph": graph,
                             "pending": query[method, graph, False],
                             "complete_inconclusive": query[method, graph, True], "excluded": 0}
                            for method in METHODS for graph in GRAPHS],
        "wall_and_enqueue_diagnostic_only": [
            {"method": method, "scope": scope, "median_ms": median(values), "n": len(values)}
            for (method, scope), values in diagnostics.items()],
        "native_library_sha": data["environment"]["native_artifact"]["library_sha256"],
        "fixture_sha": data["fixture"]["tensor_file_sha256"],
        "trace": trace_identity(data, args.raw_root),
        "numeric_checks": len(correct), "profiles": len(data["profiles"]),
    }


def key_for(row):
    return (row["kind"], row.get("graph"), row.get("numerator"), row.get("denominator"), row.get("method"))


def summarize(processes):
    grouped = collections.defaultdict(list)
    for process in processes:
        for estimate in process["estimates"]:
            grouped[key_for(estimate)].append((process["trial"], estimate["estimate"]))
    results = []
    for key, values in grouped.items():
        results.append({"kind": key[0], "graph": key[1], "numerator": key[2],
                        "denominator": key[3], "method": key[4], **describe(values)})
    return results


def compare_official(ours, official):
    check(official["status"] == "success" and official["trials"] == ours["trials"],
          "official process cohort differs")
    by_key = {key_for(row): row for row in official["analysis"]["summaries"]}
    comparisons = 0
    for own in ours["summaries"]:
        other = by_key[key_for(own)]
        check(other["independent_trials"] == own["n_complete_repetitions"], "official independent units differ")
        trials = dict(own["trial_values"])
        for row in other["trial_estimates"]:
            close(row["ratio"], trials[row["trial"]], "official per-process pair statistic")
            comparisons += 1
        for name, value in (("median_ratio", own["median"]),
                            ("min_ratio", own["range"][0]), ("max_ratio", own["range"][1])):
            close(other[name], value, "official process summary statistic")
            comparisons += 1
        expected = own["exploratory_block_bootstrap95"]
        recorded = other["exploratory_cluster_bootstrap_95_percent"]
        if expected is None:
            check(recorded is None, "official checkpoint invented CI")
        else:
            close(recorded["lower"], expected[0], "official exact bootstrap lower")
            close(recorded["upper"], expected[1], "official exact bootstrap upper")
            comparisons += 2
    query = {(row["trial"], row["method"]): row for row in official["analysis"]["query_outcomes_all_retained"]}
    for process in ours["processes"]:
        for method in METHODS:
            selected = [row for row in process["query_outcomes"] if row["method"] == method]
            other = query[process["trial"], method]
            check(other["samples"] == 48 and other["excluded_samples"] == 0 and
                  other["start_pending_after_enqueue"] == sum(row["pending"] for row in selected) and
                  other["start_complete_inconclusive"] == sum(row["complete_inconclusive"] for row in selected),
                  "official query counts dropped outcomes")
            comparisons += 1
    return {"status": "pass", "numeric_comparisons": comparisons,
            "arithmetic_source": "Raw event/count arithmetic and independent occupancy bootstrap; no official analyzer import."}


def audit(args):
    check(sha(args.plan) == PLAN_SHA, "preregistered plan changed")
    check(args.trials and sorted(set(args.trials)) == args.trials and
          all(trial in range(6) for trial in args.trials), "invalid process subset")
    plan = load(args.plan)
    processes = [
        audit_process(args.raw_root / scheduled["raw_name"], scheduled,
                      next(row["rounds"] for row in plan["protocol"]["round_schedules"]
                           if row["trial"] == scheduled["trial"]), args)
        for scheduled in plan["protocol"]["worker_schedule"] if scheduled["trial"] in args.trials
    ]
    check(len({row["container_id"] for row in processes}) == len(processes) and
          all(re.fullmatch("[0-9a-f]{64}", row["container_id"]) for row in processes), "process reused")
    for field in ("native_library_sha", "fixture_sha"):
        check(len({row[field] for row in processes}) == 1, "provenance changed: " + field)
    result = {
        "status": "success", "source_commit": args.source_commit, "trials": args.trials,
        "script_sha256": sha(__file__), "independent_bootstrap_source_sha256": sha(HELPER),
        "plan_sha256": sha(args.plan), "processes": processes, "summaries": summarize(processes),
        "totals": {"processes": len(processes), "complete_rounds": len(processes) * 24,
                   "timed_batches": len(processes) * 144, "trace_launches": len(processes) * 6,
                   "numerical_checks": sum(row["numeric_checks"] for row in processes)},
        "contextual_ratio_scale": 0.0065,
        "limits": [
            "Six fresh processes are independent; rounds, graphs and trace calls are paired dependent observations.",
            "All completed-start query outcomes remain in primary statistics; query completion is inconclusive.",
            "Absolute GPU-event microseconds describe these replay recipes, not model/serving performance.",
            "Wall spans include deliberate prequeue and are diagnostic only, never a10m/40m latency claim.",
            "Batch length and prequeue differ together for5120/noqueue versus16/queued. No pure host-cost subtraction.",
            "CI crossing1 does not establish equivalence; compare width/sensitivity to contextual0.65percent without a validity gate.",
        ],
    }
    if args.official_analysis:
        result["official_comparison"] = compare_official(result, load(args.official_analysis))
    return result


def self_test():
    tests = []
    mass = bootstrap([1] * 3 + [2] * 3)
    expected = {
        1: sum(math.comb(6, n) for n in range(3)) * 3**6,
        1.5: math.comb(6, 3) * 3**6,
        2: sum(math.comb(6, n) for n in range(4, 7)) * 3**6,
    }
    check(mass == expected and sum(mass.values()) == 6**6, "six-process closed-form bootstrap disagrees")
    tests.append("six_process_exact_bootstrap_matches_binomial_formula")
    rounds = []
    for index in range(24):
        records = []
        for method, (count, delay) in METHODS.items():
            value = {"plain5120": 4, "queued16_10m": 3.2, "queued16_40m": 3.216}[method]
            for graph in GRAPHS:
                sample = value * (1 if graph == "graph_a" else 1.0065)
                records.append({"method": method, "graph_id": graph,
                                "gpu_event_batch_ms": sample * count / 1000, "replays": count})
        rounds.append({"measurements": records})
    estimates = ratios_within_process(rounds, ["graph_a", "graph_b"])
    for row in estimates:
        if row["kind"] == "same_graph_method_ratio":
            expected = {("queued16_10m", "plain5120"): 0.8,
                        ("queued16_40m", "queued16_10m"): 1.005,
                        ("queued16_40m", "plain5120"): 0.804}[row["numerator"], row["denominator"]]
        else:
            expected = 1 / 1.0065
        close(row["estimate"], expected, "known paired recipe/capture effect")
    tests.append("known_all_graph_method_and_capture_paired_round_ratios")
    check(describe([(0, 1)])["exploratory_block_bootstrap95"] is None, "n1 invented CI")
    tests.append("one_process_checkpoint_no_interval")
    check(len(independent.resampling_occupancies(6)) == 462, "six-process occupancy coverage")
    tests.append("462_multinomial_occupancies_represent_46656_process_resamples")
    return {"status": "success", "scope": "independent CPU arithmetic only", "tests": tests,
            "script_sha256": sha(__file__), "independent_bootstrap_source_sha256": sha(HELPER)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-root", type=Path)
    parser.add_argument("--source-commit")
    parser.add_argument("--plan", type=Path, default=SOURCE / BATCH / "plan.json")
    parser.add_argument("--trials", nargs="+", type=int, default=list(range(6)))
    parser.add_argument("--official-analysis", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if not args.self_test and (args.raw_root is None or args.source_commit is None):
        parser.error("--raw-root and --source-commit are required")
    try:
        result = self_test() if args.self_test else audit(args)
        code = 0
    except Exception as error:
        result, code = {"status": "error", "error": f"{type(error).__name__}: {error}"}, 1
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"status": result["status"], "output": str(args.output), "sha256": sha(args.output)}))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
