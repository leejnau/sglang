"""CPU controls for replay calibration orchestration and retained native provenance."""
import copy,hashlib,json,os,shutil,subprocess,tempfile
from pathlib import Path
ROOT=Path('/private/tmp/sglang-autotune-selection-study')
BATCH='20261024T090000Z-h100-replay-calibration'
REL=Path('test/manual/kernels/results/flashinfer_autotune_selection')/BATCH
COLLECTOR=ROOT/REL/'collect_build_provenance.py'
LAUNCHER=ROOT/REL/'launch.sh'
OLD=Path('/private/tmp/sglang-graph-controls-20261020T143705Z/raw/attempt01')
FI=Path('/private/tmp/fi-next-steps-20261024/coordinator/qualified-fi-source')
MANIFEST=ROOT/'test/manual/kernels/results/flashinfer_autotune_selection/20261019T232945Z-h100-descriptor-qualification/source-manifest.json'
records=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def control(name,ok,detail=None):
    if not ok:raise AssertionError(name)
    records.append({'control':name,'passed':True,'detail':detail})
with tempfile.TemporaryDirectory(prefix='fi-objective-collector-') as directory:
    study=Path(directory);runtime=study/'runtime-attempt01';raw=study/'results'/BATCH/'attempt01'
    raw.mkdir(parents=True);(study/'fixture').mkdir()
    shutil.copyfile(OLD/'fixture/manifest.json',study/'fixture/manifest.json')
    (runtime/'source-overlay').mkdir(parents=True);shutil.copyfile(MANIFEST,runtime/'source-overlay/source-manifest.json')
    manifest=json.loads(MANIFEST.read_text())
    package=runtime/'packages/candidate'
    for row in manifest['files']:
        if row['runtime_overlay']:
            src=FI/row['repository_path'];dst=package/row['installed_package_path']
            assert sha(src)==row['candidate_sha256'],src
            dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
    dst=package/'flashinfer/data/csrc/group_gemm.cu';shutil.copyfile(FI/'csrc/group_gemm.cu',dst)
    native=json.loads((OLD/'trial0-v1-timing.json').read_text())['environment']['native_artifact']
    def native_path(key):return study/Path(native[key]).relative_to('/study')
    native_path('library_path').parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(OLD/'native-builds/candidate/gemm.so',native_path('library_path'))
    shutil.copyfile(OLD/'native-builds/candidate/build.ninja',native_path('ninja_path'))
    originals={}
    for trial in range(6):
        row=json.loads((OLD/f'trial{trial}-v1-timing.json').read_text())
        p=raw/f'trial{trial}-calibration.json'
        p.write_text(json.dumps(row));originals[p]=p.read_bytes()
    def run(label,trials=(0,),expected=0):
        out=raw/(label+'.json')
        result=subprocess.run(['python3',str(COLLECTOR),'--study',str(study),'--batch',BATCH,'--trials',*map(str,trials),'--copy-ninja','--output',str(out)],capture_output=True,text=True)
        data=json.loads(out.read_text())
        control(label,result.returncode==expected,(data['status'],data['errors']))
        return data
    d=run('positive-first-block');control('first-block-record-count',d['validated_native_records']==1 and d['expected_native_records']==1)
    d=run('positive-full-cohort',range(6));control('full-cohort-record-count',d['validated_native_records']==6 and d['expected_native_records']==6)
    p=raw/'trial0-calibration.json'
    p.unlink();run('reject-missing-record',expected=1);p.write_bytes(originals[p])
    row=json.loads(p.read_text());row['status']='error';p.write_text(json.dumps(row));run('reject-worker-failure',expected=1);p.write_bytes(originals[p])
    row=json.loads(p.read_text());row['environment']['native_artifact']['library_sha256']='0'*64;p.write_text(json.dumps(row));run('reject-native-hash-drift',expected=1);p.write_bytes(originals[p])
    row=json.loads(p.read_text());row['environment']['native_artifact']['library_path']='/study/source/unrelated.so';p.write_text(json.dumps(row));run('reject-library-outside-runtime',expected=1);p.write_bytes(originals[p])
    header=package/'flashinfer/data/include/flashinfer/gemm/bmm_fp8.cuh';before=header.read_bytes();header.write_bytes(before+b'\n');run('reject-runtime-source-drift',expected=1);header.write_bytes(before)
    ninja=native_path('ninja_path');before=ninja.read_bytes();ninja.write_bytes(before.replace(b'compute_90a,code=sm_90a',b'compute_80a,code=sm_80a'))
    run('reject-wrong-architecture',expected=1);ninja.write_bytes(before)
    d=run('positive-after-fault-restoration');control('restored-first-block',d['validated_native_records']==1)
# These controls never invoke Docker/GPU: only CPU stubs check early ownership.
with tempfile.TemporaryDirectory(prefix='fi-objective-shell-') as directory:
    base=Path(directory);study=base/'study';(study/'source').mkdir(parents=True)
    bin_dir=base/'bin';bin_dir.mkdir();log=base/'unexpected-command.log'
    commit='a'*40
    (bin_dir/'git').write_text('#!/bin/sh\ncase "$*" in *"rev-parse HEAD"*) printf "%s\\n" "'+commit+'";; *"status --porcelain"*) exit 0;; *) exit 99;; esac\n')
    for cmd in ('docker','nvidia-smi'):
        (bin_dir/cmd).write_text('#!/bin/sh\nprintf "%s\\n" "'+cmd+' $*" >> "'+str(log)+'"\nexit 0\n')
    for p in bin_dir.iterdir():p.chmod(0o755)
    env=dict(os.environ,PATH=str(bin_dir)+os.pathsep+os.environ['PATH'])
    raw=study/'results'/BATCH/'existing';raw.mkdir(parents=True)
    marker=raw/'launcher.exit-code';marker.write_text('PRESERVE\n')
    result=subprocess.run(['bash',str(LAUNCHER),str(study),commit,'existing'],env=env,capture_output=True)
    control('reject-existing-attempt-without-overwrite',result.returncode!=0 and marker.read_text()=='PRESERVE\n')
    control('existing-attempt-no-container-or-GPU-touch',not log.exists())
    result=subprocess.run(['bash',str(LAUNCHER),str(study),commit,'../escape'],env=env,capture_output=True)
    control('reject-attempt-path-traversal',result.returncode!=0 and not log.exists())
    result=subprocess.run(['bash',str(LAUNCHER),str(study),'invalid','new'],env=env,capture_output=True)
    control('reject-non-SHA-before-side-effects',result.returncode!=0 and not (study/'results'/BATCH/'new').exists())
    text=LAUNCHER.read_text();function=text[text.index('cleanup() {'):text.index('\ntrap cleanup EXIT')]
    cid='c'*64;cidfile=base/'owned.container-id';cidfile.write_text(cid+'\n')
    own=study/'results'/BATCH/'owned';own.mkdir();runtime=study/'runtime-owned';(runtime/'caches').mkdir(parents=True);(runtime/'caches/cache.json').write_text('{}\n')
    script='active_cid_file="'+str(cidfile)+'"\nresults_created=1\nresults_dir="'+str(own)+'"\nruntime_dir="'+str(runtime)+'"\n'+function+'\nfalse\ncleanup\n'
    result=subprocess.run(['bash','-c',script],env=env,capture_output=True)
    commands=log.read_text().splitlines()
    control('cleanup-only-recorded-owned-CID',commands[0]=='docker rm -f '+cid and sum(x.startswith('docker') for x in commands)==1)
    control('cleanup-preserves-failing-exit-and-cache', (own/'launcher.exit-code').read_text()=='1\n' and (own/'caches/cache.json').read_text()=='{}\n')
    log.unlink();cidfile.write_text('not-a-container-id\n')
    result=subprocess.run(['bash','-c',script],env=env,capture_output=True)
    control('cleanup-invalid-CID-never-removes-container',all(not x.startswith('docker') for x in log.read_text().splitlines()))
report={'status':'success','scope':'CPU-only launcher ownership and retained real native/source provenance controls; no Docker/GPU execution or experiment simulation.',
        'launcher_sha256':sha(LAUNCHER),'collector_sha256':sha(COLLECTOR),'controls_passed':len(records),'controls':records,'script_sha256':sha(Path(__file__))}
out=Path('/private/tmp/fi-next-steps-20261024/coordinator/calibration-launcher-controls.json');out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'success','controls':len(records),'output':str(out),'sha256':sha(out)}))
