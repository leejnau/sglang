"""Package the fixed replay calibration; never rewrite protocol or original raw bytes."""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import shutil
import subprocess
import tarfile

BATCH = "test/manual/kernels/results/flashinfer_autotune_selection/20261024T090000Z-h100-replay-calibration"
COMMIT = "e38fd25173543600dab03d3a757e27e45e0a3caf"
PRIVATE_SHA = "c91907fede6170aaeda2974ca516fcda5f53b92e81dbd9cb222c203a31edfab2"
PROTOCOL = (
    "plan.json",
    "analyze.py",
    "launch.sh",
    "collect_build_provenance.py",
    "fixture-manifest.json",
    "cpu-validation.json",
)
FORBIDDEN = bytes([118, 108, 108, 109])
COUNTS = collections.Counter()


def require(condition, category):
    COUNTS[category] += 1
    if not condition:
        raise AssertionError(category)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def check_tar(path, expected):
    with tarfile.open(path) as archive:
        members = archive.getmembers()
        require(all(item.isfile() for item in members), "archive_regular_members")
        require(
            len(members) == len(expected)
            and {item.name for item in members} == set(expected),
            "archive_member_set",
        )
        for item in members:
            data = archive.extractfile(item).read()
            reference = expected[item.name]
            require(data == reference.read_bytes(), "archive_original_byte_identity")
            require(FORBIDDEN not in data.lower(), "archive_prohibited_token_scan")


def write_tar(path, files):
    require(not path.exists(), "new_artifact_no_overwrite")
    with tarfile.open(path, "w:gz") as archive:
        for name, source in sorted(files.items()):
            require(
                FORBIDDEN not in source.read_bytes().lower(),
                "audit_source_prohibited_token_scan",
            )
            archive.add(source, arcname=name, recursive=False)
    check_tar(path, files)


def exact_rerun(recorded, repeated):
    changes = []

    def walk(a, b, path=""):
        require(type(a) is type(b), "rerun_same_types")
        if isinstance(a, dict):
            require(a.keys() == b.keys(), "rerun_same_keys")
            for key in a:
                walk(a[key], b[key], path + "/" + key)
        elif isinstance(a, list):
            require(len(a) == len(b), "rerun_same_lengths")
            for index, (left, right) in enumerate(zip(a, b)):
                walk(left, right, path + "/" + str(index))
        elif a != b:
            require(
                path.endswith("/file") and isinstance(a, str),
                "rerun_only_location_fields",
            )
            changes.append({"field": path, "cluster": a, "local": b})

    walk(recorded, repeated)
    expected = (
        {"/actual_native_build/file"}
        | {f"/validated_workers/{i}/file" for i in range(6)}
        | {f"/validated_workers/{i}/actual_trace/file" for i in range(6)}
    )
    require(
        {row["field"] for row in changes} == expected and len(changes) == 13,
        "rerun_exact_thirteen_location_fields",
    )
    for row in changes:
        if row["field"] != "/actual_native_build/file":
            require(
                Path(row["cluster"]).name == Path(row["local"]).name,
                "rerun_same_relocated_filename",
            )
    return changes


def controls(raw, source, recorded, statistics_audit):
    workers = [load(raw / f"trial{i}-calibration.json") for i in range(6)]
    totals = collections.Counter()
    zeros = digest(bytes(144 * 4096 * 2))
    natural = []
    queries = {
        name: collections.Counter()
        for name in ("plain5120", "queued16_10m", "queued16_40m")
    }
    native = raw / "native-builds/candidate/gemm.so"
    require(native.read_bytes().startswith(b"\x7fELF"), "private_native_actual_ELF")
    require(
        len(
            {
                (raw / f"trial{i}-calibration.container-id").read_text().strip()
                for i in range(6)
            }
        )
        == 6,
        "six_fresh_containers",
    )
    for i, data in enumerate(workers):
        require(
            data["status"] == "success"
            and data["trial"] == i
            and (raw / f"trial{i}-calibration.exit-code").read_text().strip() == "0",
            "successful_worker",
        )
        require(
            data["environment"]["sglang_commit"] == COMMIT, "frozen_execution_source"
        )
        require(
            data["profile_attempts"] == len(data["profiles"]) == 81
            and not data["forbidden_profile_attempts"],
            "all_profiles_startup_only",
        )
        require(
            data["environment"]["native_artifact"]["library_sha256"] == sha(native),
            "private_ELF_matches_every_worker",
        )
        groups = collections.defaultdict(list)
        for row in data["profiles"]:
            require(
                row["stage"] == "startup"
                and row.get("error") is None
                and math.isfinite(row["profiler_ms"])
                and row["profiler_ms"] > 0,
                "finite_actual_profile",
            )
            require(
                row["fingerprinted"] is False
                and not row["use_cuda_graph"]
                and not row["use_cold_l2_cache"],
                "fixed_H0F0_auto_hot_config",
            )
            groups[json.dumps(row["normalized_profile"])].append(row)
        require(
            len(groups) == 9
            and all(
                len(rows) == 9 and rows[0]["tactic"] == -1 for rows in groups.values()
            ),
            "default_in_nine_complete_candidate_races",
        )
        runtime = [
            row
            for row in data["profiles"]
            if row["normalized_profile"]
            == data["runtime_profile_summary"]["normalized_profile"]
        ]
        minimum = min(row["profiler_ms"] for row in runtime)
        require(
            any(
                row["tactic"] == data["natural"]["tactic"]
                and row["profiler_ms"] == minimum
                for row in runtime
            ),
            "startup_winner_actual_finite_minimum",
        )
        require(
            data["natural"]["consumed_by_calibration_graphs"] is False,
            "natural_winner_not_measured",
        )
        natural.append({"trial": i, "tactic": data["natural"]["tactic"]})
        cache = raw / "caches" / Path(data["cache"]["path"]).name
        require(
            sha(cache)
            == data["cache"]["after_startup_sha256"]
            == data["cache"]["after_controls_sha256"],
            "original_v1_cache_bytes_unchanged",
        )
        saved = load(cache)
        generation = saved.pop("_generation")
        require(
            digest(json.dumps(saved, sort_keys=True, separators=(",", ":")).encode())
            == generation,
            "actual_v1_cache_generation",
        )
        require(
            sum(key.startswith("(") for key in saved) == 9,
            "nine_incidental_saved_entries",
        )
        graphs = {row["id"]: row for row in data["graph_controls"]["graphs"]}
        require(
            set(graphs) == {"graph_a", "graph_b"}
            and len({row["output"]["data_ptr"] for row in graphs.values()}) == 2,
            "two_distinct_owned_default_graphs",
        )
        for graph in graphs.values():
            require(
                graph["tactic"] == -1
                and graph["lookup_tier"] == "miss"
                and graph["selection"]["cache_hit"] is False
                and graph["selection"]["is_tuning_mode"] is False,
                "genuine_default_capture",
            )
        require(
            len(data["graph_controls"]["miss_scope"]) == 2
            and all(
                row["restored"] and row["all_cache_state_restored"]
                for row in data["graph_controls"]["miss_scope"]
            ),
            "all_removed_cache_maps_restored",
        )
        checks = data["correctness"]["checks"]
        require(
            len(checks) == len({row["check"] for row in checks}) == 158,
            "complete_unique_numerical_guards",
        )
        for row in checks:
            metric = row["quantized_reference"]
            require(
                metric["passed"]
                and metric["max_normalized_error"] <= 1
                and all(
                    math.isfinite(value)
                    for key, value in metric.items()
                    if key != "passed"
                ),
                "actual_quantized_reference_guard",
            )
            if row["graph_id"] is not None:
                require(
                    row["output_data_ptr"]
                    == graphs[row["graph_id"]]["output"]["data_ptr"],
                    "correct_graph_output_allocation",
                )
            if row["exact_zero_required"]:
                require(
                    row["output_sha256"] == zeros
                    and all(
                        metric[key] == 0
                        for key in (
                            "max_abs_error",
                            "max_normalized_error",
                            "rmse",
                            "relative_l2",
                        )
                    ),
                    "recomputed_positive_zero_hash",
                )
                totals["exact_zero_guards"] += 1
        for row in data["binding_acceptance_checks"]:
            require(
                row["accepted"]
                and row["used_descriptor"] == ([] if row["tactic"] == -1 else [1]),
                "explicit_acceptance_never_fallback",
            )
        cal = data["calibration"]
        require(
            cal["pending_sample"] is None
            and cal["all_samples_retained"]
            and not cal["queue_query_is_exclusion_criterion"],
            "all_completed_samples_retained",
        )
        for block in cal["rounds"]:
            require(len(block["measurements"]) == 6, "complete_paired_round")
            for row in block["measurements"]:
                require(
                    row["profile_attempts_before"]
                    == row["profile_attempts_after"]
                    == 81
                    and not row["policy_scope_active"]
                    and not row["tuning_mode"],
                    "no_timing_profile_or_policy_scope",
                )
                require(
                    row["graph_object_id"] == graphs[row["graph_id"]]["graph_object_id"]
                    and row["output_data_ptr"]
                    == graphs[row["graph_id"]]["output"]["data_ptr"],
                    "same_original_measured_graph",
                )
                require(
                    row["gpu_event_batch_ms"] / row["replays"]
                    == row["gpu_event_per_replay_ms"],
                    "exact_raw_event_normalization",
                )
                require(
                    type(row["start_event_complete_after_enqueue"]) is bool
                    and row["start_query_error"] is None,
                    "query_outcome_preserved",
                )
                queries[row["method"]][
                    "complete_inconclusive"
                    if row["start_event_complete_after_enqueue"]
                    else "pending"
                ] += 1
                totals["timed_batches"] += 1
        trace = cal["post_timing_trace"]
        require(
            sha(raw / Path(trace["path"]).name) == trace["sha256"]
            and trace["kernel_events"] == 12,
            "actual_original_trace_bytes",
        )
        require(
            cal["pre_trace_checks"]["profile_attempts"]
            == cal["post_trace_checks"]["profile_attempts"]
            == 81,
            "no_trace_profiling",
        )
        require(
            all(
                cal["pre_trace_checks"][key] == cal["post_trace_checks"][key]
                for key in ("file_sha256", "winner_sha256", "loaded_file_sha256")
            ),
            "trace_cache_state_unchanged",
        )
        totals.update(
            workers=1,
            startup_profiles=81,
            default_profiles=9,
            numerical_guards=len(checks),
            complete_rounds=len(cal["rounds"]),
            graph_captures=2,
            trace_kernels=trace["kernel_events"],
            trace_launches=sum(row["graph_launch_events"] for row in trace["graphs"]),
        )
    require(
        totals
        == {
            "workers": 6,
            "startup_profiles": 486,
            "default_profiles": 54,
            "numerical_guards": 948,
            "exact_zero_guards": 12,
            "complete_rounds": 144,
            "timed_batches": 864,
            "graph_captures": 12,
            "trace_kernels": 72,
            "trace_launches": 36,
        },
        "independently_counted_complete_totals",
    )
    require(
        statistics_audit["totals"]["numerical_checks"] == totals["numerical_guards"]
        and statistics_audit["official_comparison"]["numeric_comparisons"] == 117,
        "independent_statistics_agreement",
    )
    return (
        dict(totals),
        {name: dict(counts) for name, counts in queries.items()},
        natural,
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--research-root",
        type=Path,
        default=Path("/private/tmp/fi-next-steps-20261024"),
    )
    parser.add_argument(
        "--source-root",
        type=Path,
        default=Path("/private/tmp/sglang-autotune-selection-study"),
    )
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    research, source = args.research_root, args.source_root
    raw, batch = research / "coordinator/calibration-raw/attempt01", source / BATCH
    private_archive = (
        research
        / "coordinator/20261024T090000Z-h100-replay-calibration-attempt01-full-raw.tgz"
    )
    require(sha(private_archive) == PRIVATE_SHA, "private_full_archive_SHA")
    frozen = {}
    for name in PROTOCOL:
        original = subprocess.check_output(
            ["git", "-C", str(source), "show", COMMIT + ":" + BATCH + "/" + name]
        )
        require((batch / name).read_bytes() == original, "committed_protocol_unchanged")
        frozen[name] = digest(original)
    manifest = load(raw / "preservation-manifest.json")["files"]
    original_files = {
        str(path.relative_to(raw)): path for path in raw.rglob("*") if path.is_file()
    }
    require(
        set(original_files) == set(manifest) | {"preservation-manifest.json"},
        "complete_private_member_manifest",
    )
    require(not any(path.is_symlink() for path in raw.rglob("*")), "no_raw_symlinks")
    for name, metadata in manifest.items():
        require(
            sha(raw / name) == metadata["sha256"]
            and (raw / name).stat().st_size == metadata["size_bytes"],
            "original_preservation_member",
        )
    with tarfile.open(private_archive) as archive:
        full = {
            row.name.removeprefix("attempt01/"): row
            for row in archive.getmembers()
            if row.isfile()
        }
        require(set(full) == set(original_files), "full_archive_exact_file_set")
        for name, row in full.items():
            require(
                archive.extractfile(row).read() == original_files[name].read_bytes(),
                "full_archive_downloaded_byte_identity",
            )
    recorded = load(raw / "final-analysis.json")
    repeated_path = research / "calibration-statistics-audit/frozen-analyzer-rerun.json"
    repeated = load(repeated_path)
    require(
        recorded["status"] == "success"
        and recorded["source_commit"] == COMMIT
        and recorded["analyzer_sha256"] == frozen["analyze.py"],
        "frozen_successful_analysis",
    )
    changes = exact_rerun(recorded, repeated)
    require(
        (raw / "native-build-provenance.json").read_bytes()
        == (raw / "native-build-provenance-final.json").read_bytes(),
        "canonical_final_build_file_same_bytes",
    )
    stats_path = research / "calibration-statistics-audit/final-audit.json"
    stats = load(stats_path)
    require(
        stats["status"] == "success"
        and stats["script_sha256"]
        == sha(research / "calibration-statistics-audit/audit.py")
        and stats["independent_bootstrap_source_sha256"]
        == sha(research / "history-statistics-audit/audit.py"),
        "retained_exact_independent_audit_sources",
    )
    totals, queries, natural = controls(raw, source, recorded, stats)
    public = {
        name: path
        for name, path in original_files.items()
        if path.suffix not in (".so", ".safetensors")
    }
    excluded = {
        name: path for name, path in original_files.items() if name not in public
    }
    require(
        set(excluded)
        == {"fixture/fixture.safetensors", "native-builds/candidate/gemm.so"},
        "only_private_fixture_and_ELF_excluded",
    )
    require(
        all(
            not name.startswith(("flashinfer/", "csrc/"))
            and (not name.endswith(".py") or name == "coordinator/preserve.py")
            for name in public
        ),
        "no_raw_upstream_source_members",
    )
    if args.verify_only:
        check_tar(batch / "attempt01-raw.tar.gz", public)
        index = load(batch / "artifact-index.json")
        for row in index["files"]:
            require(
                sha(batch / row["path"]) == row["sha256"]
                and (batch / row["path"]).stat().st_size == row["size_bytes"],
                "published_artifact_index",
            )
        print(
            json.dumps(
                {
                    "status": "verified",
                    "raw_members": len(public),
                    "checks": sum(COUNTS.values()),
                }
            )
        )
        return
    products = (
        "analysis.json",
        "local-analyzer-rerun.json",
        "independent-statistics-audit.json",
        "attempt01-raw.tar.gz",
        "attempt01-raw-member-index.json",
        "audit-tools.tar.gz",
        "summary.json",
        "validation.json",
        "artifact-index.json",
    )
    require(
        not any((batch / name).exists() for name in products), "all_result_products_new"
    )
    shutil.copyfile(raw / "final-analysis.json", batch / "analysis.json")
    shutil.copyfile(repeated_path, batch / "local-analyzer-rerun.json")
    shutil.copyfile(stats_path, batch / "independent-statistics-audit.json")
    write_tar(batch / "attempt01-raw.tar.gz", public)
    member_index = {
        "schema_version": 1,
        "archive_sha256": sha(batch / "attempt01-raw.tar.gz"),
        "archive_size_bytes": (batch / "attempt01-raw.tar.gz").stat().st_size,
        "members": [
            {"path": name, "sha256": sha(path), "size_bytes": path.stat().st_size}
            for name, path in sorted(public.items())
        ],
        "private_binary_members_excluded": [
            {"path": name, "sha256": sha(path), "size_bytes": path.stat().st_size}
            for name, path in sorted(excluded.items())
        ],
        "byte_comparison_passed": True,
    }
    dump(batch / "attempt01-raw-member-index.json", member_index)
    tools_names = (
        "calibration-statistics-audit/audit.py",
        "calibration-statistics-audit/summarize.py",
        "calibration-statistics-audit/cpu-controls.json",
        "history-statistics-audit/audit.py",
        "selection-audit/check_oracle_calibration_worker.py",
        "selection-audit/oracle-calibration-worker-cpu-controls.json",
        "coordinator/check_calibration_launcher.py",
        "coordinator/calibration-launcher-controls.json",
        "coordinator/preserve.py",
        "coordinator/package_public.py",
        "coordinator/package_calibration_results.py",
        "coordinator/scheduler-after-release.log",
        "coordinator/scheduler-final.log",
    )
    tools = {name: research / name for name in tools_names}
    write_tar(batch / "audit-tools.tar.gz", tools)
    concise = []
    for row in recorded["analysis"]["summaries"]:
        concise.append(
            {
                key: row[key]
                for key in (
                    "kind",
                    "graph",
                    "numerator",
                    "denominator",
                    "method",
                    "independent_trials",
                    "median_ratio",
                    "min_ratio",
                    "max_ratio",
                    "exploratory_cluster_bootstrap_95_percent",
                    "interval_width_ratio_units",
                )
            }
        )
    summary = {
        "status": "complete",
        "batch_id": Path(BATCH).name,
        "execution_source_commit": COMMIT,
        "conclusion": "Replay recipes differ on the same retained graphs; subpercent capture and selection resolution remains unresolved.",
        "scope": "Six fresh processes on one H100 NVL and one fixed captured static FP8 SGLang layer. Both measured graphs use genuine default misses; the startup winner is deliberately unused.",
        "actual_counts": totals,
        "actual_signature_result": all(
            row["trace"]["both_default_graphs_same_launch_signature"]
            for row in stats["processes"]
        ),
        "ratios": concise,
        "queue_outcomes_all_retained": queries,
        "interpretation": [
            "The 16-replay/10-million-cycle recipe reports about 1.30% to 1.51% higher GPU-event time than the 5120-replay/no-delay recipe on the same graphs. Batch length and delay change together; this is not a pure host-cost estimate.",
            "At fixed 16 replays, increasing delay from 10 to 40 million cycles changes median event ratios by about -0.112% and -0.035% for the two graphs. No equivalence claim follows.",
            "All 576 queued samples had pending start events after enqueue. All 288 plain samples had completed starts, which is inconclusive. No sample was excluded by query outcome.",
            "First/second-capture exploratory interval widths are about 0.73% to 1.18%. The contextual 0.65% scale remains unresolved rather than an acceptance threshold.",
            "This calibration does not negate the much larger 18.9% to 22.0% explicit-winner regressions with different BMM kernels in the prior fixed study.",
        ],
        "limits": recorded["limits"],
        "next_step": "Qualify the current-source native provider and fixture output ownership/numerics before an activation/objective matrix. This package authorizes no new experiment.",
        "allocation": {
            "job_id": 2792066,
            "deliberately_released_utc": "2026-10-24 08:36:29 UTC",
            "remaining_workers": 0,
        },
    }
    dump(batch / "summary.json", summary)
    validation = {
        "status": "passed",
        "execution_source_commit": COMMIT,
        "protocol_sha256_unchanged": frozen,
        "all_six_worker_exits": [
            int((raw / f"trial{i}-calibration.exit-code").read_text()) for i in range(6)
        ],
        "final_integrity_gate_exit": int(
            (raw / "final-analysis.exit-code").read_text()
        ),
        "independently_derived_counts": totals,
        "independent_statistics": {
            "source_sha256": sha(research / "calibration-statistics-audit/audit.py"),
            "report_sha256": sha(stats_path),
            "comparisons": stats["official_comparison"]["numeric_comparisons"],
        },
        "strict_local_frozen_analyzer_comparison": {
            "passed": True,
            "location_only_fields": changes,
            "all_other_values_exact": True,
            "canonical_final_build_file_byte_identical": True,
            "local_rerun_sha256": sha(repeated_path),
        },
        "successful_full_private_raw": {
            "archive_sha256": PRIVATE_SHA,
            "archive_size_bytes": private_archive.stat().st_size,
            "preservation_manifest_members_verified": len(manifest),
            "archive_files_verified": len(original_files),
            "durable_path": "/home/lnau/flashinfer-autotune-study/20261024T090000Z-h100-replay-calibration-attempt01-full-raw.tgz",
        },
        "public_raw": {
            "members": len(public),
            "excluded_private_binary_members": len(excluded),
            "archive_sha256": member_index["archive_sha256"],
            "byte_identical_members": True,
        },
        "audit_tools": [
            {"path": name, "sha256": sha(path), "size_bytes": path.stat().st_size}
            for name, path in sorted(tools.items())
        ],
        "package_checks_by_category": dict(COUNTS),
        "startup_winners_recorded_not_consumed": natural,
        "allocation": {
            "job_id": 2792066,
            "state": "Deliberately released after both full experiment archives were verified.",
            "accounting_end_utc": "2026-10-24 08:36:29 UTC",
            "extern_cleanup_end_utc": "2026-10-24 08:36:31 UTC",
            "remaining_workers": 0,
            "scheduler_final_sha256": sha(research / "coordinator/scheduler-final.log"),
        },
        "limitations": [
            *recorded["limits"],
            "General numerical metrics are preserved guard results; output arrays were not retained for independent recomputation. Exact-zero output digests were recomputed.",
            "The public archive excludes the private captured fixture and actual native ELF. Full raw retains both, with indexed hashes.",
            "The six-process analysis is exact apart from the 13 verified location-only fields; no floating-point tolerance was used for this comparison.",
            "Audit sources retain their original path constants. Extract tools under the original research root, restore private members when needed, and use the frozen source checkout to reproduce full provider/fixture gates.",
        ],
        "reproduction": {
            "frozen_analyzer": f"python3 {BATCH}/analyze.py --raw-root RAW --source-root SOURCE --expected-source-commit {COMMIT} --source-manifest SOURCE/test/manual/kernels/results/flashinfer_autotune_selection/20261019T232945Z-h100-descriptor-qualification/source-manifest.json --fixture-manifest SOURCE/{BATCH}/fixture-manifest.json --build-provenance RAW/native-build-provenance-final.json --output rerun.json",
            "independent_math": f"python3 calibration-statistics-audit/audit.py --raw-root RAW --source-commit {COMMIT} --plan SOURCE/{BATCH}/plan.json --official-analysis RAW/final-analysis.json --output independent.json",
            "package_verification": "python3 coordinator/package_calibration_results.py --research-root RESEARCH --source-root SOURCE --verify-only",
        },
    }
    dump(batch / "validation.json", validation)
    for name, expected in frozen.items():
        require(sha(batch / name) == expected, "committed_protocol_still_unchanged")
    published = [
        path
        for path in batch.iterdir()
        if path.is_file() and path.name != "artifact-index.json"
    ]
    for path in published:
        if path.suffix != ".gz":
            require(
                FORBIDDEN not in path.read_bytes().lower(),
                "published_file_prohibited_token_scan",
            )
    dump(
        batch / "artifact-index.json",
        {
            "schema_version": 1,
            "files": [
                {
                    "path": path.name,
                    "sha256": sha(path),
                    "size_bytes": path.stat().st_size,
                }
                for path in sorted(published)
            ],
        },
    )
    require(
        FORBIDDEN not in (batch / "artifact-index.json").read_bytes().lower(),
        "artifact_index_prohibited_token_scan",
    )
    print(
        json.dumps(
            {
                "status": "packaged",
                "public_raw_members": len(public),
                "private_excluded": len(excluded),
                "audit_tool_members": len(tools),
                "checks": sum(COUNTS.values()),
                "public_archive_sha256": sha(batch / "attempt01-raw.tar.gz"),
            }
        )
    )


if __name__ == "__main__":
    main()
