"""CPU protocol controls executing the new worker's actual schedule and sampler."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import importlib
import itertools
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from unittest.mock import patch

WORKERS = Path('/private/tmp/sglang-autotune-selection-study/test/manual/kernels')
sys.path.insert(0, str(WORKERS))
m = importlib.import_module('bench_flashinfer_oracle_calibration')
checks = []


def check(ok, label):
    if not ok:
        raise AssertionError(label)
    checks.append(label)


for trial in range(6):
    rows = m.schedule(trial)
    check(len(rows) == 24, f'trial{trial} has 24 rounds')
    count = Counter(tuple(x['methods']) for x in rows)
    check(count == Counter({x: 4 for x in itertools.permutations(m.METHODS)}), f'trial{trial} method permutations balanced')
    positions = defaultdict(Counter)
    graph_orders = defaultdict(Counter)
    for row in rows:
        graph_orders[tuple(row['methods'])][tuple(row['graph_order'])] += 1
        for pos, method in enumerate(row['methods']):
            positions[method][pos] += 1
    check(all(v == Counter({0: 8, 1: 8, 2: 8}) for v in positions.values()), f'trial{trial} method positions balanced')
    check(all(v == Counter({('graph_a', 'graph_b'): 2, ('graph_b', 'graph_a'): 2}) for v in graph_orders.values()), f'trial{trial} graph order balanced within each permutation')
    check(rows == m.schedule(trial), f'trial{trial} schedule deterministic')

argv = ['--trial', '0', '--capture-order', 'a-first']
for flag in ('cache', 'output', 'manifest', 'fixture', 'fixture-manifest', 'trace'):
    argv += ['--' + flag, '/tmp/unused-' + flag]
args = m.parse_args(argv)
check((args.arm, args.history, args.fingerprint, args.seed) == ('auto', 0, 0, 19), 'actual H0/F0 auto startup is fixed')
for extra in (['--blocks', '23'], ['--rewarm-ms', '19'], ['--trial', '6'], ['--capture-order', 'other']):
    with patch('sys.stderr'):
        try:
            m.parse_args(argv + extra)
        except SystemExit as exc:
            check(exc.code == 2, 'parser rejects ' + ' '.join(extra))
        else:
            raise AssertionError('invalid parser input accepted')


class Output:
    def __init__(self, log):
        self.log, self.value = log, 1

    def data_ptr(self):
        return 10101

    def fill_(self, value):
        self.log.append('poison')
        self.value = value


class Graph:
    def __init__(self, log, output, no_write):
        self.log, self.output, self.no_write = log, output, no_write

    def replay(self):
        self.log.append('replay')
        if not self.no_write:
            self.output.value = 1


class Event:
    def __init__(self, log, index, query):
        self.log, self.index, self.result = log, index, query

    def record(self):
        self.log.append(f'record{self.index}')

    def synchronize(self):
        self.log.append(f'sync{self.index}')

    def query(self):
        if self.log[-1] != 'record1':
            raise AssertionError('query was not immediate after end record')
        self.log.append(f'query{self.index}')
        if isinstance(self.result, Exception):
            raise self.result
        return self.result

    def elapsed_time(self, other):
        self.log.append('elapsed')
        return 3.2


def sampler(method, query, no_write=False):
    log = []
    output = Output(log)
    graph = Graph(log, output, no_write)
    event_count = iter(range(2))
    cuda = SimpleNamespace(
        Event=lambda **kw: Event(log, next(event_count), query),
        _sleep=lambda cycles: log.append(('sleep', cycles)),
    )
    ex = m.CalibrationExperiment.__new__(m.CalibrationExperiment)
    ex.args = SimpleNamespace(rewarm_ms=20)
    ex.torch = SimpleNamespace(cuda=cuda)
    ex.tuner = SimpleNamespace(_in_v2_context=0, is_tuning_mode=False)
    ex.graphs = {'graph_a': SimpleNamespace(graph=graph, output=output)}
    ex.profile_attempts, ex.calibration = 81, {}
    ex.assert_bare_replay_state = lambda: log.append('bare')
    def warm(graph_id, ms):
        log.append('rewarm')
        return {'actual_ms': ms, 'calls': 5120}
    ex.warm_graph = warm
    def numeric(graph_id, stage):
        log.append('numeric')
        if ex.out is not output or ex.out.value != 1:
            raise AssertionError('wrong or unwritten graph-owned output')
    ex.check_retained_output = numeric
    with patch.object(m, 'device_status', lambda: {}):
        try:
            row = ex.sample('graph_a', method, 0)
        except Exception as error:
            return ex, log, None, error
    return ex, log, row, None


for method, config in m.METHODS.items():
    for query in (True, False):
        ex, log, row, error = sampler(method, query)
        tag = f'{method} query={query}'
        check(error is None, tag + ' returns a retained sample')
        check(log.count('replay') == config['replays'], tag + ' exact actual replay count')
        check(row['start_event_complete_after_enqueue'] is query, tag + ' query outcome preserved')
        check(row['gpu_event_per_replay_ms'] == 3.2 / config['replays'], tag + ' event normalization')
        check(row['wall_diagnostic_only'] and row['enqueue_span_includes_start_query'], tag + ' diagnostic wall and honest enqueue span')
        check(row['profile_attempts_before'] == row['profile_attempts_after'] == 81, tag + ' no additional profiling')
        check(log.index('poison') < log.index('sync1') < log.index('replay'), tag + ' output poison drained before measured replay')
        check(log[-3:] == ['elapsed', 'numeric', 'bare'], tag + ' exact timed output checked before another operation')
        check(row['graph_object_id'] == id(ex.graphs['graph_a'].graph) and row['output_data_ptr'] == 10101, tag + ' original graph and owned allocation bound')
        sleeps = [x for x in log if isinstance(x, tuple)]
        expected_sleep = [('sleep', config['prequeue_cycles'])] if config['prequeue_cycles'] else []
        check(sleeps == expected_sleep, tag + ' exact delay method')
        if sleeps:
            check(log.index('sync1') < log.index(expected_sleep[0]) < log.index('replay'), tag + ' prequeue follows poison drain and precedes replay')
        check(ex.calibration['pending_sample'] is None, tag + ' completed sample clears pending evidence')

ex, log, row, error = sampler('queued16_10m', RuntimeError('query fault'))
check(isinstance(error, RuntimeError), 'query exception propagates without exclusion or retry')
pending = ex.calibration['pending_sample']
check(pending['start_query_error'] == 'RuntimeError: query fault', 'query error retained with original text')
check(pending['wall_started_ns'] <= pending['enqueue_started_ns'] <= pending['query_error_observed_ns'], 'partial query failure retains boundary timestamps')
check(log.count('query0') == 1 and log.count('replay') == 16, 'query failure does not rerun measured work')
ex, log, row, error = sampler('queued16_40m', False, no_write=True)
check(isinstance(error, AssertionError) and 'unwritten' in str(error), 'destructive no-write replay is rejected after poison')
check(ex.calibration['pending_sample']['start_event_complete_after_enqueue'] is False, 'failed numeric sample retains queue/timing evidence')

path = Path(m.__file__)
report = {
    'status': 'success', 'worker': str(path),
    'worker_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
    'controls': len(checks), 'checks': checks,
    'scope': 'CPU execution of the actual worker schedule/parser/sampler with fake GPU boundaries. No CUDA measurement, sleep behavior, kernel or numerical accuracy claim.',
}
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
ns = parser.parse_args()
ns.output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ('status', 'worker_sha256', 'controls')}))
