"""Synthetic CPU controls only; never read or package actual experiment data."""

import hashlib
import json
from pathlib import Path
import tarfile
import tempfile

from prepare_public import prepare


def sha(data):
    return hashlib.sha256(data).hexdigest()


def fixture(root, forbidden_target=None):
    raw = root / "attempt01"
    raw.mkdir()
    token = bytes.fromhex("766c6c6d").decode()
    (raw / "cold.log").write_text("retained diagnostic\n")
    (raw / "cold.exit-code").write_text("1\n")
    (raw / "cold.json").write_text(json.dumps({"status": "error", "scientific_finding": "retained"}))
    (raw / "cold.bootstrap.json").write_text(json.dumps({
        "status": "error",
        "import": {"source_modules": {"unrelated." + token: {"sha256": "a" * 64}, "wanted": {"sha256": "b" * 64}}, "aot_providers": []},
        "native_identity": "preserved",
    }))
    (raw / "model").mkdir()
    (raw / "model/weights.safetensors").write_bytes(b"private checkpoint bytes")
    private_plan = b'{"private_piece_paths":["retained privately"]}'
    (raw / "model-stream-plan.json").write_bytes(private_plan)
    (raw / "provenance.json").write_text(json.dumps({"model_stream_plan_sha256": sha(private_plan)}))
    if forbidden_target:
        (raw / forbidden_target).write_text(token)
    rows = [
        {"path": str(p.relative_to(raw)), "size": p.stat().st_size, "sha256": sha(p.read_bytes())}
        for p in sorted(raw.rglob("*")) if p.is_file()
    ]
    (raw / "preservation-manifest-cold.json").write_text(json.dumps({"phase": "cold", "files": rows}))
    archive = root / "private.tgz"
    with tarfile.open(archive, "w:gz") as bundle:
        bundle.add(raw, arcname=raw.name)
    return raw, archive


def main():
    checks = []
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        raw, archive = fixture(root)
        before = archive.read_bytes()
        output = root / "public"
        report = prepare(raw, archive, output, sha(before), ["cold"])
        assert report["status"] == "passed" and archive.read_bytes() == before
        assert (output / "raw/cold.json").read_bytes() == (raw / "cold.json").read_bytes()
        assert (output / "raw/cold.log").read_bytes() == (raw / "cold.log").read_bytes()
        assert not (output / "raw/model").exists()
        derived = json.loads((output / "raw/cold.bootstrap.json").read_text())
        assert derived["native_identity"] == "preserved"
        assert derived["public_evidence_derivation"]["omitted_entries"] == 1
        checks.extend(["failure records and logs preserved exactly", "private archive immutable", "model bytes excluded with accounting", "only unrelated bootstrap label omitted with original hash"])
        assert (raw / "model-stream-plan.json").is_file()
        assert not (output / "raw/model-stream-plan.json").exists()
        manifest = json.loads((output / "public-manifest.json").read_text())
        excluded = next(row for row in manifest["excluded_private_files"] if row.get("path") == "model-stream-plan.json")
        original_sha = sha((raw / "model-stream-plan.json").read_bytes())
        assert excluded["sha256"] == original_sha
        provenance = json.loads((output / "raw/provenance.json").read_text())
        assert provenance["model_stream_plan_sha256"] == original_sha
        assert (output / "raw/provenance.json").read_bytes() == (raw / "provenance.json").read_bytes()
        checks.append("private stream plan absent public; original SHA indexed and public provenance unchanged")
    for target in ("cold.json", "cold.log"):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            raw, archive = fixture(root, target)
            try:
                prepare(raw, archive, root / "public", sha(archive.read_bytes()), ["cold"])
            except RuntimeError:
                checks.append("reject prohibited bytes in " + target)
            else:
                raise AssertionError("Scientific evidence was silently modified")
    with tempfile.TemporaryDirectory() as directory:
        root = Path(directory)
        raw, archive = fixture(root)
        try:
            prepare(raw, archive, root / "public", "0" * 64, ["cold"])
        except ValueError:
            checks.append("reject wrong complete private archive SHA")
        else:
            raise AssertionError("Wrong private archive identity accepted")
    print(json.dumps({"status": "passed", "synthetic_only": True, "checks": len(checks), "cases": checks}, indent=2))


if __name__ == "__main__":
    main()
