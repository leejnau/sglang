"""Verify retained provider bytes, cache identities and frozen analyzer output."""
import argparse
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--raw-root', type=Path, required=True)
p.add_argument('--rerun', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
r = a.raw_root
load = lambda name: json.loads((r/name).read_text())
cold, warm = load('cold.json'), load('warm.json')
choices = {x['key']: [x['runner'], x['tactic']] for x in cold['startup']['cache']['memory']}
assert choices == warm['startup']['cache']['loaded'] and len(choices) == 4
assert cold['startup']['files'] == warm['cache_before_startup'] == warm['startup']['files'] == warm['cache_after_numerics']
assert cold['sources'] == warm['sources']
assert a.rerun.read_bytes() == (r/'combined-analysis.json').read_bytes()
reuse = load('native-build-cache/reuse-manifest.json')
observed_native = {}
for relative, expected in reuse['native_files'].items():
    path = r/'native-build-cache/qualified-providers'/relative
    actual = sha(path)
    assert actual == expected
    observed_native[relative] = actual
model = load('model-manifest.json')
for phase in ('preflight', 'cold', 'warm'):
    snapshot = load(f'runtime-snapshot-{phase}.json')
    assert snapshot['model_files'] == {x['path']: x['sha256'] for x in model['files']}
    assert snapshot['native_files'] == reuse['native_files']
report = dict(status='passed', cache_keys_reused_exactly=len(choices), saved_file_bytes_unchanged=True,
              native_files_verified=len(observed_native), native_file_sha256=observed_native,
              model_files_verified_at_each_node_snapshot=len(model['files']),
              frozen_analyzer_byte_equal=True, analyzer_sha256=sha(a.rerun),
              analysis_result_sha256=sha(r/'combined-analysis.json'),
              cold_cache_sha256={key: value['sha256'] for key,value in cold['startup']['files'].items()})
with a.output.open('x') as handle:
    json.dump(report,handle,indent=2,sort_keys=True);handle.write('\n')
