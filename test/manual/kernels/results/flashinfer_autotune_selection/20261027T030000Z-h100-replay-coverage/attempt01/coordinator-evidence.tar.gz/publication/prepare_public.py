"""Package actual preserved coverage evidence; never edit original raw files.

The adjacent generic packager is reused byte-for-byte. Only unrelated offending
bootstrap import labels may be removed, with explicit original hashes. Worker
records, logs and errors are retained verbatim or publication fails closed.
"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path


BASE_SHA = "7324863cb8598251d977dfdb71102621562ee828deb0ab50fdc1ad1cd97bd33c"
ASSEMBLY_SHA = "c96c507702ab345cc4ac7bad36aef857788acda9982b54d3dae2faa01ab028a0"


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for data in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(data)
    return h.hexdigest()


def load_base():
    path = Path(__file__).with_name("package_base.py")
    if digest(path) != BASE_SHA:
        raise ValueError("Generic packager source identity changed")
    spec = importlib.util.spec_from_file_location("coverage_package_base", path)
    base = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(base)
    base.PRIVATE_DIRS |= {"model", "checkpoint", "model-cache"}
    base.PRIVATE_SUFFIXES += (
        ".bin", ".pt", ".ptx", ".ttir", ".ttgir", ".llir", ".source"
    )
    original_exclusion = base.exclusion

    def exclusion(relative):
        if relative.name == "model-stream-plan.json":
            return "Private checkpoint transfer plan; original bytes and SHA remain in the private archive, with its digest in public provenance."
        return original_exclusion(relative)

    base.exclusion = exclusion
    return base


def verify_preservation(raw, phases):
    counts = {}
    for phase in phases:
        for suffix in ("log", "exit-code"):
            if not (raw / f"{phase}.{suffix}").is_file():
                raise ValueError("Missing declared phase evidence: " + phase + "." + suffix)
        path = raw / f"preservation-manifest-{phase}.json"
        record = json.loads(path.read_text())
        if record["phase"] != phase:
            raise ValueError("Preservation phase differs")
        seen = set()
        for row in record["files"]:
            rel = Path(row["path"])
            if rel.is_absolute() or ".." in rel.parts or str(rel) in seen:
                raise ValueError("Unsafe or repeated preservation path")
            seen.add(str(rel))
            original = raw / rel
            if original.stat().st_size != row["size"] or digest(original) != row["sha256"]:
                raise ValueError("Original preservation evidence differs: " + str(rel))
        counts[phase] = len(seen)
    return counts


def prepare(raw, archive, output, expected_sha, phases):
    base = load_base()
    if digest(archive) != expected_sha:
        raise ValueError("Private archive differs from the preservation receipt")
    counts = verify_preservation(raw, phases)
    report = base.package(raw, archive, output, expected_sha)
    scan_path = Path(__file__).with_name("assemble_public.py")
    if digest(scan_path) != ASSEMBLY_SHA:
        raise ValueError("Recursive scanner source identity changed")
    spec = importlib.util.spec_from_file_location("coverage_archive_scan", scan_path)
    scanner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(scanner)
    scanner.scan("raw-public.tar.gz", (output / "raw-public.tar.gz").read_bytes())
    manifest = json.loads((output / "public-manifest.json").read_text())
    by_path = {row["path"]: row for row in manifest["files"]}
    critical = []
    for path in raw.rglob("*"):
        if not path.is_file() or base.exclusion(path.relative_to(raw)):
            continue
        rel = str(path.relative_to(raw))
        if rel.endswith(".bootstrap.json"):
            continue
        row = by_path[rel]
        if row["mode"] != "byte_exact" or (output / "raw" / rel).read_bytes() != path.read_bytes():
            raise ValueError("Scientific or diagnostic evidence changed: " + rel)
        critical.append(rel)
    # Include the wrapper's stricter exclusion policy in the reproducibility record.
    result = {
        "status": "passed",
        "phases": list(phases),
        "preservation_rows": counts,
        "private_archive_sha256": expected_sha,
        "public_archive_sha256": report["archive_sha256"],
        "public_manifest_sha256": report["manifest_sha256"],
        "critical_byte_exact_files": critical,
        "base_packager_sha256": BASE_SHA,
        "wrapper_sha256": digest(Path(__file__)),
        "recursive_scanner_sha256": ASSEMBLY_SHA,
        "private_directories": sorted(base.PRIVATE_DIRS),
        "private_suffixes": list(base.PRIVATE_SUFFIXES),
        "private_exact_filenames": ["model-stream-plan.json"],
        "limits": [
            "Publication integrity only; no scientific interpretation or phase filtering.",
            "Unexpected prohibited bytes in worker records or logs stop publication.",
            "The complete original private archive remains unchanged.",
        ],
    }
    encoded = json.dumps(result, indent=2).encode() + b"\n"
    base.scanned_payload("coverage-publication-audit.json", encoded)
    (output / "coverage-publication-audit.json").write_bytes(encoded)
    if digest(archive) != expected_sha:
        raise ValueError("Private archive changed during publication")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ("raw-root", "private-archive", "output"):
        parser.add_argument("--" + flag, type=Path, required=True)
    parser.add_argument("--expected-private-sha", required=True)
    parser.add_argument("--phases", nargs="+", choices=("preflight", "cold", "warm"), required=True)
    args = parser.parse_args()
    result = prepare(args.raw_root.resolve(), args.private_archive.resolve(), args.output.resolve(), args.expected_private_sha, args.phases)
    print(json.dumps({key: value for key, value in result.items() if key != "critical_byte_exact_files"}, indent=2))


if __name__ == "__main__":
    main()
