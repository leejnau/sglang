"""Independent read-only replay coverage audit; no producer/analyzer imports."""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import subprocess

EXECUTION = 'b2b52b4b6b109941e8df34df59f19b6f437445fa'
BATCH = 'test/manual/kernels/results/flashinfer_autotune_selection/20261027T030000Z-h100-replay-coverage'
FI = {
    'flashinfer.autotuner.autotuner': '0db42ad90d1a3fec6f81509a2c520c1892cea0a433f5dbd7f43468a2a10243ca',
    'flashinfer.autotune_cache': '1ab2ed7208ed1bf1007b1f74de29fc818c93a5ab091beea0833474177fbb29ad',
}
NATIVE = {'gemm': '72690cacca4ce1d69ccaa6b9190475483d984bd58de0962d06c874c801c678d6',
          'trtllm_utils': 'e442a689064fe3af4ab46510b2d5aaf3597b072949b84f13d14e9e53352109e4'}

def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--raw-root', type=Path, required=True)
    p.add_argument('--source-root', type=Path, default=Path('/private/tmp/sglang-replay-coverage-study'))
    p.add_argument('--phases', nargs='+', choices=('cold', 'warm'), default=['cold', 'warm'])
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    checks = 0
    def check(value, reason):
        nonlocal checks
        checks += 1
        if not value:
            raise AssertionError(reason)
    root = a.raw_root
    provenance = read(root/'provenance.json')
    check(provenance['execution_commit'] == EXECUTION, 'execution commit changed')
    frozen = subprocess.check_output(['git', 'show', f'{EXECUTION}:{BATCH}/model-manifest.json'], cwd=a.source_root)
    check(hashlib.sha256(frozen).hexdigest() == provenance['model_manifest_sha256'] == sha(root/'model-manifest.json'), 'frozen checkpoint manifest changed')
    check(read(root/'model-manifest.json') == provenance['model'], 'actual checkpoint manifest changed')
    check(provenance['model']['revision'] == '42d9515ebd69eea3a87351d079c671c3c5ff0a31', 'checkpoint revision changed')
    for name, value in FI.items():
        check(provenance['source_sha256'][name] == value, 'qualified tuner/cache source changed')
    results = []
    payloads = []
    ids = []
    for phase in a.phases:
        raw = root/f'{phase}.json'
        w = read(raw)
        payloads.append(w)
        check(w['status'] == 'completed' and w['phase'] == phase, 'incomplete worker')
        check(w['provenance'] == provenance and w['provenance_sha256'] == sha(root/'provenance.json'), 'worker provenance mismatch')
        check((root/f'{phase}.exit-code').read_text().strip() == '0', 'worker failure')
        check((root/f'launcher-{phase}.exit-code').read_text().strip() == '0', 'launcher failure')
        cid = (root/f'{phase}.container-id').read_text().strip()
        check(len(cid) == 64 and cid not in ids, 'container reused')
        ids.append(cid)
        boot = read(root/f'{phase}.bootstrap.json')
        check(boot['status'] == 'passed' and boot['result_sha256'] == sha(raw), 'bootstrap failure or wrong result')
        check(boot['worker_sha256'] == w['worker_sha256'] == provenance['worker_sha256'], 'worker source binding')
        for name, value in NATIVE.items():
            check(boot['native']['providers'][name]['library_sha256'] == value, 'native provider changed')
        check(boot['native_identity_passthrough'], 'provider forwarding changed')
        check({k:v['sha256'] for k,v in w['sources'].items()} == provenance['source_sha256'], 'imported source mismatch')
        for name, item in w['sources'].items():
            if name.startswith('sglang.'):
                file = 'python/' + name.replace('.', '/') + '.py'
                data = subprocess.check_output(['git','show',f'{EXECUTION}:{file}'], cwd=a.source_root)
                check(hashlib.sha256(data).hexdigest() == item['sha256'], 'wrong actual framework source')
        control = w['isolated_control']
        for field in ('exception_restored','state_restored','singleton_restored','model_cache_unchanged'):
            check(control[field] is True, 'control state leak')
        check(control['profile_count'] == 0, 'lookup control profiled')
        check(control['miss']['misses'] == 1 and control['miss']['records'][0]['status'] == 'miss' and control['miss']['records'][0]['selected_tactic'] == '-1', 'negative control lost miss')
        check(control['cached_default']['hits'] == 1 and control['cached_default']['records'][0]['status'] == 'hit' and control['cached_default']['records'][0]['selected_tactic'] == '-1', 'cached default confused with fallback')
        records = w['capture_records']
        check(len(records) == 3, 'extra/missing actual forward')
        check([r['capturing'] for r in records] == [False,False,True], 'warmup/capture conflation')
        check([r['ordinal'] for r in records] == [0,1,2], 'missing capture ordinal')
        check(not any(row['observed'] for row in w['protocol_calls']), 'protocol neutrality unqualified')
        summary = []
        for row in records:
            check(row['state_before'] == row['state_inside'] == row['state_after'] == w['startup']['state'] == w['final_state'], 'effective control mutation')
            state = row['state_before']
            check(not state['is_tuning'] and state['active_tuning_contexts'] == 0 and not state['managed_store'] and not state['ambient_store'] and state['winner_identity'] is None and state['measurement_policy'] == 'None', 'wrong legacy replay state')
            check(row['cache_before'] == row['cache_after'] == w['startup']['cache'] == w['inventory_after_numerics'], 'winner or file-cache mutation')
            check(row['profile_count_before'] == row['profile_count_after'] and row['context_restored'], 'reporting profile or scope leak')
            report = row['coverage']
            total = report['hits'] + report['misses'] + report['skipped']
            check(total == len(report['records']) + report['dropped_records'] and total > 0, 'empty/incomplete report')
            counts = collections.Counter(x['status'] for x in report['records'])
            if report['dropped_records'] == 0:
                check([counts['hit'],counts['miss'],counts['skipped']] == [report['hits'],report['misses'],report['skipped']], 'detail/status count mismatch')
            op = collections.Counter(x['op'] for x in report['records'])
            check(op['fp8_gemm'] > 0, 'intended operator absent')
            summary.append(dict(stage=row['stage'], totals={k:report[k] for k in ('hits','misses','skipped','dropped_records')}, operators=dict(op), sources=dict(collections.Counter(x['source'] for x in report['records'])), cached_default_hits=sum(x['status']=='hit' and x['selected_tactic']=='-1' for x in report['records']), fallback_default_misses=sum(x['status']=='miss' and x['selected_tactic']=='-1' for x in report['records'])))
        check(w['startup']['files'] == w['cache_after_numerics'], 'serving changed persisted files')
        numeric = w['numerics']['checks']
        check([r['case'] for r in numeric] == ['original','changed','restored'], 'numerical coverage incomplete')
        check(numeric[0]['decode_token'] == numeric[2]['decode_token'] != numeric[1]['decode_token'], 'vacuous changed token')
        for row in numeric:
            for arm in ('eager','graph'):
                item = row['arms'][arm]
                check(item['finite'] and item['original_graph_unchanged'] and item['graph_output_owner_unchanged'], 'numerical output or graph ownership failed')
                check(item['prompt_input_ids'] == row['prompt_input_ids'] and item['decode_token'] == row['decode_token'], 'prefix/token mismatch')
                check(item['prefix_seq_lens'] == [len(row['prompt_input_ids'])], 'incorrect KV prefix')
                check(item['replay_delta'] == int(arm=='graph') and item['profile_delta'] >= 0, 'wrong execution route')
                check(item['poisoned_graph_output'] == (arm=='graph'), 'missing output freshness challenge')
                if arm == 'graph':
                    check(item['graph_input_ids'] == [row['decode_token']], 'graph failed dynamic token copy')
        results.append(dict(phase=phase, result_sha256=sha(raw), startup_profiles=w['startup']['profile_count'], post_startup_profiles=len(w['profile_calls'])-w['startup']['profile_count'], eligible_linears=w['startup']['eligible_linear_layers'], observed=summary, numerical_consistent=all(x['allclose'] and x['argmax_equal'] for x in numeric), changed_output=w['numerics']['changed_output'], restored_output=w['numerics']['restored_output_allclose'], numerical_max_abs_errors={x['case']:x['max_abs_error'] for x in numeric}, numerical_profile_deltas={x['case']:{arm:item['profile_delta'] for arm,item in x['arms'].items()} for x in numeric}))
    if a.phases == ['cold','warm']:
        cold,warm=payloads
        check(cold['startup']['files'] == warm['cache_before_startup'], 'cold/warm bytes chain mismatch')
        check(cold['finished_ns'] < warm['started_ns'], 'not sequential fresh processes')
        check(cold['server_args'] == warm['server_args'] and cold['sources'] == warm['sources'], 'configuration/source drift')
    report = dict(status='passed', scope='independent_raw_scientific_audit', execution_commit=EXECUTION, checks=checks, workers=results, coverage_gaps_preserved=True, limits=['One cold/warm pair on one dense FP8 model and one decode shape.', 'Coverage describes tuner choices; no performance or every-backend kernel-identity claim.', 'Numerics compare eager and retained graph execution, not an independent model-quality oracle.'])
    a.output.parent.mkdir(parents=True,exist_ok=True)
    with a.output.open('x') as handle:
        json.dump(report,handle,indent=2,sort_keys=True,allow_nan=False);handle.write('\n')

if __name__ == '__main__':
    main()
