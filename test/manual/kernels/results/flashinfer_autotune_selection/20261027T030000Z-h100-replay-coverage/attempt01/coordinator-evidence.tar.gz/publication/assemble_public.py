"""Assemble exact audited reports and losslessly split the public master archive."""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import tarfile
import tempfile

TOKEN = bytes.fromhex('766c6c6d')
LIMIT = 1_400_000


def require(value, label):
    if not value:
        raise ValueError(label)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def scan(name, data):
    require(TOKEN not in name.encode().lower() and TOKEN not in data.lower(), 'prohibited bytes: '+name)
    if name.endswith(('.tar.gz', '.tgz')):
        names = set()
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as bundle:
            for member in bundle:
                path = PurePosixPath(member.name)
                require(not path.is_absolute() and '..' not in path.parts, 'safe nested path')
                if member.isdir():
                    continue
                require(member.isfile() and member.name not in names, 'regular unique nested member')
                names.add(member.name)
                require(not member.name.endswith(('.safetensors','.so','.o','.cubin','.ptx','.ttir','.ttgir','.llir','.source')), 'no private tensor/native payload')
                scan(name+'!'+member.name, bundle.extractfile(member).read())
    elif name.endswith('.gz'):
        scan(name[:-3], gzip.decompress(data))


def bundle(files):
    data = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', mtime=0, compresslevel=9, fileobj=data) as zipped:
        with tarfile.open(fileobj=zipped, mode='w', format=tarfile.GNU_FORMAT) as archive:
            for name, payload in sorted(files.items()):
                info=tarfile.TarInfo(name)
                info.size,info.mode,info.mtime=len(payload),0o644,0
                archive.addfile(info,io.BytesIO(payload))
    return data.getvalue()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('public','reports','evidence','destination','output'):
        parser.add_argument('--'+name,type=Path,required=True)
    args=parser.parse_args()
    require(not args.destination.exists() and not args.output.exists(), 'immutable new destinations')
    master=(args.public/'raw-public.tar.gz').read_bytes()
    audit=json.loads((args.public/'package-audit.json').read_bytes())
    require(audit['status']=='success' and sha(master)==audit['archive_sha256'], 'audited master archive identity')
    scan('raw-public.tar.gz',master)
    reports=json.loads(args.reports.read_bytes())
    evidence=json.loads(args.evidence.read_bytes())
    args.destination.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='mlp-public-',dir=args.destination.parent) as temporary:
        out=Path(temporary)/'attempt01';out.mkdir()
        parts=[]
        for index,start in enumerate(range(0,len(master),LIMIT)):
            payload=master[start:start+LIMIT]
            name='raw-public.tar.gz' if len(master)<=LIMIT else f'raw-public.tar.gz.part-{index:02d}'
            (out/name).write_bytes(payload)
            parts.append({'path':name,'size_bytes':len(payload),'sha256':sha(payload)})
        require(b''.join((out/r['path']).read_bytes() for r in parts)==master,'lossless ordered reconstruction')
        part_index={'format':'Concatenate parts in listed order to reconstruct the audited gzip tar archive.','reconstructed_name':'raw-public.tar.gz','sha256':sha(master),'size_bytes':len(master),'parts':parts}
        if len(parts)>1:
            (out/'raw-public-parts.json').write_text(json.dumps(part_index,indent=2)+'\n')
        copied=[]
        for name,source in sorted(reports.items()):
            require(Path(name).name==name and not (out/name).exists(),'unique simple report name')
            payload=Path(source).read_bytes();scan(name,payload)
            if len(payload)>LIMIT:
                compressed=gzip.compress(payload,compresslevel=9,mtime=0)
                require(len(compressed)<=LIMIT,'report compression exceeds repository limit')
                require(gzip.decompress(compressed)==payload,'lossless report compression')
                (out/(name+'.gz')).write_bytes(compressed)
                index={'compressed_path':name+'.gz','compressed_sha256':sha(compressed),'uncompressed_sha256':sha(payload),'uncompressed_size_bytes':len(payload)}
                (out/(name.removesuffix('.json')+'-index.json')).write_text(json.dumps(index,indent=2)+'\n')
            else:
                (out/name).write_bytes(payload)
            copied.append({'path':name,'source_sha256':sha(payload),'source_size_bytes':len(payload)})
        members={}
        for name,source in sorted(evidence.items()):
            path=PurePosixPath(name)
            require(not path.is_absolute() and '..' not in path.parts,'safe evidence name')
            payload=Path(source).read_bytes();scan(name,payload)
            members[name]=payload
        archive=bundle(members);scan('coordinator-evidence.tar.gz',archive)
        require(len(archive)<=LIMIT,'coordinator evidence exceeds repository limit')
        (out/'coordinator-evidence.tar.gz').write_bytes(archive)
        index={'archive':'coordinator-evidence.tar.gz','sha256':sha(archive),'files':[{'path':n,'size_bytes':len(b),'sha256':sha(b)} for n,b in sorted(members.items())]}
        (out/'coordinator-evidence.json').write_text(json.dumps(index,indent=2)+'\n')
        inventory=[]
        for path in sorted(out.iterdir()):
            payload=path.read_bytes();require(len(payload)<=LIMIT,'repository file limit')
            if '.part-' not in path.name:scan(path.name,payload)
            inventory.append({'path':path.name,'size_bytes':len(payload),'sha256':sha(payload)})
        os.replace(out,args.destination)
    result={'status':'passed','assembly_source_sha256':sha(Path(__file__).read_bytes()),'master_archive_sha256':sha(master),'master_archive_size_bytes':len(master),'lossless_parts':len(parts),'maximum_repository_file_bytes':max(r['size_bytes'] for r in inventory),'copied_reports':copied,'coordinator_members':len(members),'files':inventory,'limits':['Artifact assembly only; no scientific inference or timing selection. Final result summary and repository hooks are separate root-owned steps.']}
    args.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('copied_reports','files')}))


if __name__=='__main__':
    main()
