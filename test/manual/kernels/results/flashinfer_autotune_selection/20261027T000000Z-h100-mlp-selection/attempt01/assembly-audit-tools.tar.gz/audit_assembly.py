"""Read-only final publication assembly verification; output stays in scratch."""
import gzip,hashlib,io,json,math,statistics,tarfile
from pathlib import Path,PurePosixPath
B=Path('/private/tmp/sglang-mlp-selection-study/test/manual/kernels/results/flashinfer_autotune_selection/20261027T000000Z-h100-mlp-selection')
S=Path('/private/tmp/fi-mlp-selection-20261026')
C=S/'coordinator'; A=B/'attempt01'; RAW=C/'raw-timing/attempt01'
I=Path('/private/tmp/fi-mlp-selection-20261027/independent-audit')
TOKEN=bytes.fromhex('766c6c6d'); checks=0; nested=[]
def check(c,label):
 global checks
 if not c: raise AssertionError(label)
 checks+=1
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def scan(name,data):
 check(TOKEN not in name.encode().lower() and TOKEN not in data.lower(), 'prohibited bytes: '+name)
 if name.endswith(('.tar.gz','.tgz')):
  records=members(data,name)
  nested.append({'name':name,'members':len(records),'sha256':sha(data)})
  for n,b in records.items():scan(name+'!'+n,b)
 elif name.endswith('.gz'):scan(name[:-3],gzip.decompress(data))
def members(data,label):
 out={}
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
  for m in t:
   p=PurePosixPath(m.name)
   check(not p.is_absolute() and '..' not in p.parts,'safe member '+label)
   if m.isdir():continue
   check(m.isfile(),'regular file '+label)
   check(m.name not in out,'unique member '+label)
   check(not m.name.endswith(('.safetensors','.so','.o','.cubin','.ptx','.ttir','.ttgir','.llir','.source')),'private payload exclusion '+label)
   out[m.name]=t.extractfile(m).read()
   check(len(out[m.name])==m.size,'member bytes '+label)
 return out
# All repository assembly files remain small; expanded containers are scanned separately.
files=[]
for sub in ['attempt01','preflight01']:
 for p in sorted((B/sub).rglob('*')):
  if p.is_file():
   b=p.read_bytes();check(len(b)<=1500000,'repository file size '+p.name)
   files.append({'path':str(p.relative_to(B)),'size_bytes':len(b),'sha256':sha(b)})
   if '.part-' not in p.name:scan(str(p.relative_to(B)),b)
parts=read(A/'raw-public-parts.json'); master=b''
for row in parts['parts']:
 b=(A/row['path']).read_bytes()
 check(len(b)==row['size_bytes'] and sha(b)==row['sha256'],'part '+row['path']);master+=b
check(len(master)==parts['size_bytes']==3527470,'reconstructed size')
check(sha(master)==parts['sha256']=='31d4bb491b6818c8b4c9da1efb16565b49f4c2f495ed764aa2ab992b272d65df','reconstructed hash')
check(master==(S/'public-attempt01/raw-public.tar.gz').read_bytes(),'master equals independently audited original')
scan('attempt01/raw-public.tar.gz',master)
public=members(master,'master')
manifest=read(A/'public-manifest.json')
check(public['raw/public-manifest.json']==(A/'public-manifest.json').read_bytes(),'embedded manifest')
for row in manifest['files']:
 p='raw/'+row['path']; b=public[p]
 check(sha(b)==row['public_sha256'] and len(b)==row['public_size_bytes'],'public row '+p)
 if row['mode']=='byte_exact':check(b==(RAW/row['path']).read_bytes(),'raw bytes '+p)
 else:check(row['mode']=='derived_inventory_only' and p.endswith('.bootstrap.json'),'limited derivative')
check(len(public)==344,'public members')
for row in manifest['excluded_private_files']:
 check('raw/'+row['path'] not in public,'private exclusion '+row['path'])
# Published reports are the exact successful scratch reports, not regenerated summaries.
mapping={
 'admission-analysis.json':C/'admission-analysis.json',
 'admission-outer-audit.json':C/'admission-outer-audit.json',
 'timing-analysis.json':C/'timing-analysis.json',
 'timing-artifact-validation.json':C/'timing-artifact-validation.json',
 'independent-fixture-audit.json':C/'independent-fixture-audit.json',
 'independent-admission-audit.json':I/'admission-audit.json',
 'independent-timing-audit.json':I/'timing-audit.json',
 'independent-arithmetic.json':S/'analysis/independent-arithmetic-verified.json',
 'timing-identity-summary.json':I/'timing-identity-summary.json',
 'default-hit-miss-interpretation.json':I/'default-hit-miss-interpretation.json',
 'publication-audit.json':C/'timing-publication-audit.json',
 'package-audit.json':S/'public-attempt01/package-audit.json',
 'public-manifest.json':S/'public-attempt01/public-manifest.json',
}
for n,p in mapping.items():check((A/n).read_bytes()==p.read_bytes(),'exact report '+n)
check((B/'preflight01/publication-audit.json').read_bytes()==(C/'preflight01-publication-audit.json').read_bytes(),'preflight audit')
outer_bytes=gzip.decompress((A/'timing-outer-audit.json.gz').read_bytes());idx=read(A/'timing-outer-audit-index.json')
check(outer_bytes==(C/'timing-outer-audit.json').read_bytes(),'outer gzip exact')
check(sha(outer_bytes)==idx['uncompressed_sha256']=='99ba0c15fc53551d1c62afffc0cc5f4a39128d3531cfa7368cf8fac9a0788d0c','outer original hash')
check(len(outer_bytes)==idx['uncompressed_size_bytes'],'outer original size')
check(sha((A/idx['compressed_path']).read_bytes())==idx['compressed_sha256'],'outer compressed hash')
outer=json.loads(outer_bytes);check(outer['status']=='passed' and outer['checks']==25664 and len(outer['workers'])==42,'outer status')
coord=read(A/'coordinator-evidence.json'); cb=(A/coord['archive']).read_bytes();cm=members(cb,'coordinator')
check(sha(cb)==coord['sha256'],'coordinator archive hash')
check(set(cm)=={r['path'] for r in coord['files']},'coordinator complete inventory')
for r in coord['files']:
 b=cm[r['path']];check(len(b)==r['size_bytes'] and sha(b)==r['sha256'],'coordinator manifest '+r['path'])
 check(b==(S/r['path']).read_bytes(),'coordinator scratch '+r['path'])
trace=members((A/'independent-trace-tools.tar.gz').read_bytes(),'trace-tools');ti=read(A/'independent-trace-tools-index.json')
for n,h in ti['members'].items():check(sha(trace[n])==h and trace[n]==(I/n).read_bytes(),'trace tool '+n)
check(trace['audit-tools-index.json']==(A/'independent-trace-tools-index.json').read_bytes(),'trace embedded index')
pubtools=members((A/'publication-tools.tar.gz').read_bytes(),'publication-tools')
check(pubtools['audit_public.py']==(C/'audit_public.py').read_bytes(),'publication auditor source')
check(pubtools['package_results.py']==Path('/private/tmp/fi-objective-values-20261024/public-packaging/package_results.py').read_bytes(),'unchanged packager source')
controls=read(A/'source-validation-summary.json')
for n,r in controls['cpu_controls'].items():check(sha((B/n).read_bytes())==r['sha256'],'control source '+n)
check(sum(r['count'] for r in controls['cpu_controls'].values())==159,'control count')
# Spot-check reported statistics/winners against both audited analyses and every original worker.
result=read(A/'result.json');official=read(A/'timing-analysis.json');ind=read(A/'independent-arithmetic.json');identity=read(A/'timing-identity-summary.json')
check(result['validation']['result_artifact_hooks']=='passed','final artifact hooks status')
check((A/'precommit-results.txt').read_bytes()==(C/'precommit-results.txt').read_bytes(),'exact final hook evidence')
check(result['execution_commit']=='a028b55b9c359568aa959e23e00b99a1824e89aa','execution source')
check(result['capture_commit']=='fb57a74b14b03ec5a35cfc4b43828e46e11261e3','capture source')
check(result['warm_estimates']==official['estimates']['warm']==ind['estimates']['warm'],'complete warm estimates')
check(result['cold_estimates_secondary']==official['estimates']['cold']==ind['estimates']['cold'],'complete cold estimates')
check(result['winners']==ind['winners'],'independent winners')
for arm,phases in ind['startup_ms'].items():
 for phase,values in phases.items():
  expected={'median_ms':statistics.median(values),'range_ms':[min(values),max(values)],'values_ms':values}
  check(result['startup_ms_secondary'][arm][phase]==expected,'startup secondary '+arm+' '+phase)
check(len(official['results'])==36 and ind['processes']==36,'36 timing only')
for r in official['results']:
 p=RAW/(r['name']+'.json');raw=read(p)
 check(sha(p.read_bytes())==r['result_sha256'],'original result binding '+r['name'])
 check(raw['status']=='success' and raw['natural']['tactic']==r['natural_tactic'],'original success/winner '+r['name'])
 check(result['winners'][raw['arm']][raw['phase']][raw['trial']]==raw['natural']['tactic'],'published winner '+r['name'])
 check(raw['startup']['startup_ms']==r['startup_ms'],'original startup '+r['name'])
 if raw['phase']=='warm':check(raw['startup']['profile_attempts']==0,'warm no profiling '+r['name'])
check(result['winners']['v2']['warm'].count(-1)==3,'default wins three')
for mode in ['eager','cuda_graph']:
 ratios=result['warm_estimates'][mode]['v2_over_v1_normalized_to_own_default']['per_block_ratios']
 check(sum(x>1 for x in ratios)==2,'both adverse blocks retained '+mode)
checks_expected={'timing_numerical_checks':official['correctness_checks'],'independent_timing_integrity_checks':identity['checks'],'independent_arithmetic_checks':ind['checks'],'outer_checks_all42workers':outer['checks'],'publication_checks':read(A/'publication-audit.json')['checks'],'failed_setup_publication_checks':read(B/'preflight01/publication-audit.json')['checks'],'queue_queries_pending':identity['queue_query_pending'],'queue_queries_completed':identity['queue_query_complete'],'warm_profile_attempts':identity['warm_profile_attempts']}
for k,v in checks_expected.items():check(result['validation'][k]==v,'reported validation '+k)
release=cm['coordinator/allocation-release-final.txt'].decode()
check('2863544|fi-mlp-selection|CANCELLED by 150381|00:46:40|' in release and '|0:0' in release,'released allocation')
check(release.splitlines()[1].startswith('JobID|'),'no queued jobs between header and accounting')
check(result['resources']=={'allocation':'2863544','elapsed':'00:46:40','released':True,'queue_empty':True,'experiments_running':False},'resource report')
report={'status':'passed','checks':checks,'audit_source_sha256':sha(Path(__file__).read_bytes()),'execution_commit':result['execution_commit'],'publication_master_sha256':sha(master),'public_members':len(public),'assembled_file_count':len(files),'largest_repository_file_bytes':max(r['size_bytes'] for r in files),'copied_reports_exact':len(mapping),'outer_uncompressed_sha256':sha(outer_bytes),'coordinator_members':len(cm),'nested_archives_checked':nested,'result_checks':'Complete published estimate tables match official and independent analyses; all 36 winners/result hashes/startup values match raw workers; audit counts and released allocation verified.','limits':['Read-only publication assembly check; no GPU execution or new performance study.','Result artifact hooks remain a separate root-owned check.'],'file_inventory':files}
out=C/'assembly-audit.json';check(not out.exists(),'new report destination');out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['nested_archives_checked','file_inventory']}))
