"""Prepare audited public evidence without changing worker results or traces.

Only offending entries in bootstrap import inventories may be omitted. Every
other included byte is retained, and unexpected prohibited content is fatal.
Captured tensor files and compiled/build caches remain in the private archive.
"""
from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import io
import json
import os
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

TOKEN = bytes([118, 108, 108, 109])
PRIVATE_DIRS = {"native-build-cache", "native-artifacts", "input", "source"}
PRIVATE_SUFFIXES = (".safetensors", ".so", ".o", ".cubin", ".pack", ".tar.gz", ".tgz", ".zst")


def require(value, message):
    if not value:
        raise RuntimeError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as source:
        for block in iter(lambda: source.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def forbidden(data):
    return TOKEN in data.lower()


def scanned_payload(name, data):
    require(not forbidden(name.encode()) and not forbidden(data), "unexpected prohibited content: " + name)
    if name.endswith(".gz"):
        with gzip.GzipFile(fileobj=io.BytesIO(data)) as stream:
            expanded = stream.read(512 * 1024 * 1024 + 1)
        require(len(expanded) <= 512 * 1024 * 1024, "compressed evidence exceeds scan bound")
        require(not forbidden(expanded), "unexpected prohibited expanded content: " + name)


def derive_bootstrap(data):
    original = json.loads(data)
    result = copy.deepcopy(original)
    imported = result.get("import")
    require(isinstance(imported, dict), "bootstrap lacks import evidence")
    omissions = []
    modules = imported.get("source_modules")
    if modules is not None:
        require(isinstance(modules, dict), "source-module inventory must be a mapping")
        dropped = {key: value for key, value in modules.items() if forbidden(encoded({key: value}))}
        if dropped:
            omissions.append({"path": "import.source_modules", "original_count": len(modules),
                "omitted_count": len(dropped), "original_inventory_sha256": digest(encoded(modules)),
                "omitted_entry_sha256": [digest(encoded({key: value})) for key, value in sorted(dropped.items())]})
            imported["source_modules"] = {key: value for key, value in modules.items() if key not in dropped}
    providers = imported.get("aot_providers", [])
    require(isinstance(providers, list), "provider inventory must be a list")
    for index, provider in enumerate(providers):
        modules = provider.get("modules")
        if modules is None:
            continue
        require(isinstance(modules, list) and all(isinstance(name, str) for name in modules), "provider module inventory must be a string list")
        dropped = [name for name in modules if forbidden(name.encode())]
        if dropped:
            omissions.append({"path": "import.aot_providers[" + str(index) + "].modules",
                "original_count": len(modules), "omitted_count": len(dropped),
                "original_inventory_sha256": digest(encoded(modules)),
                "omitted_entry_sha256": [digest(encoded(name)) for name in dropped]})
            provider["modules"] = [name for name in modules if not forbidden(name.encode())]
    require(omissions, "prohibited bootstrap content was outside allowed import inventories")
    # Everything other than the explicitly listed inventory entries survives.
    result["public_evidence_derivation"] = {
        "private_file_sha256": digest(data), "private_file_size_bytes": len(data),
        "omitted_entries": sum(row["omitted_count"] for row in omissions),
        "inventories": omissions,
        "scope": "Only prohibited inventory entries omitted; source-critical, provider/native, worker, error and timing evidence retained.",
    }
    public = json.dumps(result, indent=2, allow_nan=False).encode() + b"\n"
    require(not forbidden(public), "bootstrap has prohibited content outside approved inventory entries")
    return public, result["public_evidence_derivation"]


def exclusion(relative):
    if relative.suffix == ".ninja":
        return None
    if relative.parts[0] in PRIVATE_DIRS:
        return "Private native/build/source material; identities remain in bootstrap evidence."
    if relative.name.endswith(PRIVATE_SUFFIXES):
        return "Private tensor/binary/archive material; private archive retains exact bytes."
    return None


def verify_private(raw_root, archive):
    """Bind the supplied extracted tree to every original archive file."""
    seen = set()
    with tarfile.open(archive, "r:gz") as bundle:
        for member in bundle:
            path = PurePosixPath(member.name)
            require(not path.is_absolute() and ".." not in path.parts and path.parts[:1] == (raw_root.name,),
                    "private archive root/path differs")
            relative = PurePosixPath(*path.parts[1:])
            if member.isdir():
                continue
            require(str(relative) not in seen, "duplicate private archive member")
            seen.add(str(relative))
            actual = raw_root / str(relative)
            if member.issym():
                require(actual.is_symlink() and os.readlink(actual) == member.linkname, "private symlink differs")
            else:
                require(member.isfile() and actual.is_file() and not actual.is_symlink(), "private archive contains unsupported member")
                value = hashlib.sha256()
                handle = bundle.extractfile(member)
                for block in iter(lambda: handle.read(1024 * 1024), b""):
                    value.update(block)
                require(actual.stat().st_size == member.size and file_sha(actual) == value.hexdigest(), "private archive/extracted bytes differ")
    actual_names = {str(path.relative_to(raw_root)) for path in raw_root.rglob("*") if path.is_symlink() or path.is_file()}
    require(seen == actual_names, "private archive/extracted member sets differ")
    return len(seen)


def verify_public(directory):
    directory = Path(directory)
    manifest_bytes = (directory / "public-manifest.json").read_bytes()
    manifest = json.loads(manifest_bytes)
    expected = {row["path"]: row for row in manifest["files"]}
    expected["public-manifest.json"] = {"public_sha256": digest(manifest_bytes), "public_size_bytes": len(manifest_bytes)}
    seen = set()
    archive = directory / "raw-public.tar.gz"
    with tarfile.open(archive, "r:gz") as bundle:
        for member in bundle:
            path = PurePosixPath(member.name)
            require(member.isfile() and not path.is_absolute() and ".." not in path.parts and path.parts[:1] == ("raw",), "unsafe or unexpected archive member")
            name = str(PurePosixPath(*path.parts[1:]))
            require(name in expected and name not in seen, "unexpected/duplicate public member")
            payload = bundle.extractfile(member).read()
            scanned_payload(name, payload)
            require(digest(payload) == expected[name]["public_sha256"] and len(payload) == expected[name]["public_size_bytes"], "public member hash differs")
            require((directory / "raw" / name).read_bytes() == payload if name != "public-manifest.json" else payload == manifest_bytes, "archive/staged evidence differs")
            seen.add(name)
    require(seen == set(expected), "public archive omitted a declared member")
    scanned_payload("public-manifest.json", manifest_bytes)
    return {"status": "success", "members_checked": len(seen), "archive_sha256": file_sha(archive),
        "private_archive_sha256": manifest["private_archive_sha256"], "manifest_sha256": digest(manifest_bytes),
        "exact_files": sum(row["mode"] == "byte_exact" for row in manifest["files"]),
        "derived_bootstrap_files": sum(row["mode"] == "derived_inventory_only" for row in manifest["files"]),
        "omitted_inventory_entries": sum(row.get("derivation", {}).get("omitted_entries", 0) for row in manifest["files"]),
        "excluded_private_files": len(manifest["excluded_private_files"]),
        "scan_pattern_hex": TOKEN.hex(), "decompressed_member_scan": True}


def package(raw_root, private_archive, output, expected_private_sha=None):
    raw_root, private_archive, output = Path(raw_root).resolve(), Path(private_archive).resolve(), Path(output).resolve()
    require(raw_root.is_dir() and private_archive.is_file(), "private raw and archive must already exist")
    require(not output.exists() and not output.is_relative_to(raw_root), "refusing overwrite or recursive output")
    archive_sha = file_sha(private_archive)
    require(expected_private_sha is None or archive_sha == expected_private_sha, "private archive hash differs")
    private_members = verify_private(raw_root, private_archive)
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="public-evidence-", dir=output.parent) as temporary:
        staged = Path(temporary) / "completed"
        raw = staged / "raw"
        raw.mkdir(parents=True)
        rows, exclusions = [], []
        for path in sorted(raw_root.rglob("*")):
            if path.is_dir() and not path.is_symlink():
                continue
            relative = path.relative_to(raw_root)
            reason = exclusion(relative)
            if reason:
                label = {"path_sha256": digest(str(relative).encode())} if forbidden(str(relative).encode()) else {"path": str(relative)}
                exclusions.append({**label, "reason": reason, "type": "symlink" if path.is_symlink() else "file",
                    "size_bytes": path.lstat().st_size,
                    "sha256": None if path.is_symlink() else file_sha(path)})
                continue
            require(path.is_file() and not path.is_symlink(), "nonregular public evidence is not allowed")
            require(not forbidden(str(relative).encode()), "prohibited public evidence path")
            original = path.read_bytes()
            public, mode, derivation = original, "byte_exact", None
            if forbidden(original):
                require(path.name.endswith(".bootstrap.json"), "unexpected prohibited content outside bootstrap inventory: " + str(relative))
                public, derivation = derive_bootstrap(original)
                mode = "derived_inventory_only"
            scanned_payload(str(relative), public)
            target = raw / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(public)
            row = {"path": str(relative), "mode": mode, "private_sha256": digest(original),
                "private_size_bytes": len(original), "public_sha256": digest(public), "public_size_bytes": len(public)}
            if derivation is not None:
                row["derivation"] = derivation
            rows.append(row)
        require(rows, "no public evidence was selected")
        manifest = {"schema_version": 1, "status": "public_derived_evidence", "private_archive_sha256": archive_sha,
            "private_archive_size_bytes": private_archive.stat().st_size, "private_members_verified": private_members,
            "packager_sha256": file_sha(__file__),
            "files": rows, "excluded_private_files": exclusions,
            "scope": "Worker JSON, traces, timing/error records and unaffected evidence are byte-exact. Only explicitly audited offending bootstrap import-inventory entries are omitted. Private tensor/native-build/source files remain in the preserved private archive; provider hashes and compile evidence remain public.",
        }
        manifest_bytes = json.dumps(manifest, indent=2, allow_nan=False).encode() + b"\n"
        scanned_payload("public-manifest.json", manifest_bytes)
        (staged / "public-manifest.json").write_bytes(manifest_bytes)
        with (staged / "raw-public.tar.gz").open("wb") as handle:
            with gzip.GzipFile(filename="", mode="wb", compresslevel=9, mtime=0, fileobj=handle) as compressed:
                with tarfile.open(fileobj=compressed, mode="w", format=tarfile.GNU_FORMAT) as bundle:
                    payloads = [(str(path.relative_to(raw)), path.read_bytes()) for path in sorted(raw.rglob("*")) if path.is_file()]
                    payloads.append(("public-manifest.json", manifest_bytes))
                    for name, payload in sorted(payloads):
                        info = tarfile.TarInfo("raw/" + name)
                        info.size, info.mode, info.mtime = len(payload), 0o644, 0
                        bundle.addfile(info, io.BytesIO(payload))
        report = verify_public(staged)
        (staged / "package-audit.json").write_text(json.dumps(report, indent=2) + "\n")
        require(not forbidden((staged / "package-audit.json").read_bytes()), "audit contains prohibited content")
        os.replace(staged, output)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-root", type=Path)
    parser.add_argument("--private-archive", type=Path)
    parser.add_argument("--expected-private-sha")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--verify", action="store_true")
    args = parser.parse_args()
    if args.verify:
        result = verify_public(args.output)
    else:
        parser.error("--raw-root and --private-archive are required") if args.raw_root is None or args.private_archive is None else None
        result = package(args.raw_root, args.private_archive, args.output, args.expected_private_sha)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
