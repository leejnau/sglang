"""Recompute the complete MLP cohort from raw measurements, independently."""
import argparse,collections,hashlib,json,math,random,statistics
from pathlib import Path
import numpy as np
ARMS=('default','v1','v2');MODES=('eager','cuda_graph');PHASES=('warm','cold')
CHECKS=0
def require(condition,label):
    global CHECKS
    if not condition:raise AssertionError(label)
    CHECKS+=1
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def positive(x):
    require(type(x) in (int,float) and math.isfinite(x) and x>0,'positive finite duration')
    return x
def summarize_logs(logs,indices):
    array=np.asarray(logs,dtype=np.float64)
    distribution=np.exp(array[indices].mean(axis=1))
    return {'n_blocks':len(logs),'geometric_mean_ratio':math.exp(statistics.mean(logs)),'per_block_ratios':[math.exp(x) for x in logs],'range':[math.exp(min(logs)),math.exp(max(logs))],'exploratory_block_bootstrap_95':np.quantile(distribution,[.025,.975],method='linear').tolist()}
def equal_numeric(a,b):
    if isinstance(a,dict):return set(a)<=set(b) and all(equal_numeric(v,b[k]) for k,v in a.items())
    if isinstance(a,list):return len(a)==len(b) and all(equal_numeric(x,y) for x,y in zip(a,b))
    return math.isclose(a,b,rel_tol=2e-12,abs_tol=2e-12) if type(a) in (int,float) else a==b

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ('raw-root','plan','schedule','output'):p.add_argument('--'+key,type=Path,required=True)
    p.add_argument('--official-analysis',type=Path)
    args=p.parse_args();require(not args.output.exists(),'do not overwrite audit')
    plan=json.loads(args.plan.read_text());schedule=json.loads(args.schedule.read_text());entries=schedule['entries']
    require(plan['schedule_sha256']==sha(args.schedule) and plan['fixture_contract']['shape_m_n_k']==[144,1024,3072],'frozen geometry and schedule')
    require(len(entries)==36 and len({e['id'] for e in entries})==36,'complete prescribed assignments')
    rng=random.Random(202610270000)
    indices=np.asarray([[rng.randrange(6) for _ in range(6)] for _ in range(100000)],dtype=np.int16)
    known=summarize_logs([math.log(2),math.log(8)],np.asarray([[0,0],[1,1]],dtype=np.int16))
    require(equal_numeric(known,{'n_blocks':2,'geometric_mean_ratio':4.,'per_block_ratios':[2.,8.],'range':[2.,8.],'exploratory_block_bootstrap_95':[2.15,7.85]}),'independent bootstrap arithmetic control')
    observed={};workers=[];checks=1;total_numerical=0;queue=collections.Counter();startup=collections.defaultdict(list)
    for e in entries:
        path=args.raw_root/(e['id']+'.json');d=json.loads(path.read_text())
        require(d['status']=='success' and d['mode']=='timing' and d['assignment']==e,'actual timing worker identity')
        require(d['plan_sha256']==sha(args.plan) and d['schedule_sha256']==sha(args.schedule),'frozen plan and schedule identity')
        require(d['fixture']['manifest_sha256']==plan['fixture_manifest_sha256'] and d['fixture']['tensor_file_sha256']==plan['fixture_sha256'],'frozen fixture identity')
        require(d['source']['critical_sha256']==plan['source_contract']['runtime_sha256'] and d['source']['flashinfer_commit']==plan['source_contract']['flashinfer_commit'],'qualified source identity')
        require(not d['forbidden_profile_attempts'] and not d['profile_protocol_errors'],'no hidden profiling error')
        require(d['cache']['after_startup_sha256']==d['cache']['final_sha256'],'cache unchanged during measurements')
        require(d['final']['profile_attempts']==d['startup']['profile_attempts']==len(d['startup']['profiles']),'profiling count consistency')
        if e['phase']=='warm':require(d['cache']['before_sha256']==d['cache']['final_sha256'] and not d['startup']['profiles'],'warm cache reuse has no profiling')
        require(d['natural']['lookup_tier']==('miss' if e['arm']=='default' else 'memory' if e['phase']=='cold' else 'file'),'actual cache tier')
        checks+=6
        record={'name':e['id'],'result_sha256':sha(path),'trial':e['trial'],'arm':e['arm'],'phase':e['phase'],'capture_order':e['capture_order'],'mode_order':e['mode_order'],'natural_tactic':d['natural']['tactic'],'lookup_tier':d['natural']['lookup_tier'],'natural_key':d['natural']['key'],'cache_sha256':d['cache']['final_sha256'],'profile_attempts':len(d['startup']['profiles']),'numerical_checks':len(d['correctness']),'modes':{}}
        total_numerical+=record['numerical_checks'];startup[e['arm'],e['phase']].append(d['startup']['startup_ms'])
        for mode in MODES:
            metric='wall_per_call_ms' if mode=='eager' else 'gpu_event_per_call_ms'
            orders=schedule['round_schedules'][str(e['trial'])][mode]
            pairs=d['measurements'][mode]['pairs'];require(len(pairs)==len(orders)==12,'all paired windows retained')
            logs=[];latencies={'natural':[],'default':[]};previous_end=0
            for i,(pair,order) in enumerate(zip(pairs,orders)):
                require(pair['index']==i and pair['order']==order and [r['role'] for r in pair['measurements']]==order,'actual pair order')
                rows={r['role']:r for r in pair['measurements']};require(set(rows)=={'natural','default'},'two distinct paired roles')
                require(rows['natural']['iterations']==rows['default']['iterations'],'same replay/batch length')
                for r in pair['measurements']:
                    n=r['iterations'];require(type(n) is int and n>0,'positive integral batch')
                    require(r['started_ns']>=previous_end and r['ended_ns']>r['started_ns'],'nonoverlapping measurement windows');previous_end=r['ended_ns']
                    for clock in ('wall','gpu_event'):
                        require(math.isclose(positive(r[clock+'_batch_ms'])/n,positive(r[clock+'_per_call_ms']),rel_tol=1e-12,abs_tol=1e-15),'per-call normalization from raw batch')
                    if mode=='cuda_graph':
                        require(n==16 and r['prequeue_cycles']==10000000 and type(r['start_event_complete_after_enqueue']) is bool and r['queue_query_is_exclusion_criterion'] is False,'all fixed queued graph outcomes retained')
                        queue['complete_inconclusive' if r['start_event_complete_after_enqueue'] else 'pending']+=1
                    latencies[r['role']].append(r[metric]);checks+=6
                logs.append(math.log(rows['natural'][metric]/rows['default'][metric]));checks+=3
            median=statistics.median(logs)
            record['modes'][mode]={'median_log_ratio':median,'natural_over_default':math.exp(median),'paired_log_ratios':logs,'median_absolute_ms':{role:statistics.median(values) for role,values in latencies.items()},'first_position_strata':{role:math.exp(statistics.median(x for x,o in zip(logs,orders) if o[0]==role)) for role in ('natural','default')}}
        workers.append(record);observed[e['trial'],e['arm'],e['phase']]=record
    require(len(observed)==36,'36 complete fresh process assignments')
    for trial in range(6):
        for arm in ARMS:
            cold,warm=(observed[trial,arm,phase] for phase in ('cold','warm'))
            require(all(cold[k]==warm[k] for k in ('natural_tactic','natural_key','cache_sha256')) and warm['profile_attempts']==0,'persisted winner survives fresh warm process');checks+=1
    estimates={};strata={}
    for phase in PHASES:
        estimates[phase]={};strata[phase]={}
        for mode in MODES:
            logs={arm:[observed[t,arm,phase]['modes'][mode]['median_log_ratio'] for t in range(6)] for arm in ARMS}
            normalized=[logs['v2'][t]-logs['v1'][t] for t in range(6)]
            absolute=[math.log(observed[t,'v2',phase]['modes'][mode]['median_absolute_ms']['natural']/observed[t,'v1',phase]['modes'][mode]['median_absolute_ms']['natural']) for t in range(6)]
            estimates[phase][mode]={'natural_over_own_default':{arm:summarize_logs(values,indices) for arm,values in logs.items()},'v2_over_v1_normalized_to_own_default':summarize_logs(normalized,indices),'v2_over_v1_absolute_natural_latency_secondary':summarize_logs(absolute,indices)}
            strata[phase][mode]={}
            for arm in ARMS:
                strata[phase][mode][arm]={}
                for field in ('capture_order','mode_order'):
                    values=collections.defaultdict(list)
                    for t in range(6):
                        r=observed[t,arm,phase];values[r[field]].append(r['modes'][mode]['median_log_ratio'])
                    require(sorted(map(len,values.values()))==[3,3],'balanced strata');checks+=1
                    strata[phase][mode][arm][field]={name:{'blocks':len(xs),'geometric_mean_ratio':math.exp(statistics.mean(xs))} for name,xs in values.items()}
    comparison=None
    if args.official_analysis:
        official=json.loads(args.official_analysis.read_text())
        require(official['status']=='passed' and equal_numeric(estimates,official['estimates']),'independent estimates and bootstrap intervals match official analysis')
        require(official['correctness_checks']==total_numerical,'numerical count agreement')
        for r in official['results']:
            independent=observed[r['trial'],r['arm'],r['phase']]
            for mode in MODES:require(equal_numeric(independent['modes'][mode],r['modes'][mode]),'all raw paired estimates independently agree')
        checks+=74;comparison={'status':'passed','analysis_sha256':sha(args.official_analysis),'absolute_tolerance':2e-12,'relative_tolerance':2e-12}
    winners={arm:{phase:[observed[t,arm,phase]['natural_tactic'] for t in range(6)] for phase in PHASES} for arm in ARMS}
    profiles={arm:{phase:[observed[t,arm,phase]['profile_attempts'] for t in range(6)] for phase in PHASES} for arm in ARMS}
    result={'status':'passed','checks':CHECKS,'audit_source_sha256':sha(Path(__file__)),'plan_sha256':sha(args.plan),'schedule_sha256':sha(args.schedule),'primary_phase':'warm','processes':36,'blocks':6,'numerical_checks':total_numerical,'estimates':estimates,'winners':winners,'profile_attempts':profiles,'queue_evidence':dict(queue),'capture_and_mode_strata':strata,'startup_ms':{arm:{phase:startup[arm,phase] for phase in PHASES} for arm in ARMS},'workers':workers,'official_comparison':comparison,'bootstrap':{'resamples':100000,'seed':202610270000,'unit':'complete trial blocks containing all three arms and both phases; same indices across every metric','interval':'type7 percentile 95%','numpy_version':np.__version__},'limits':['Admission and historical cohorts excluded.','Graph capture, allocation and execution history remain bundled; normalization does not isolate tactic identity causally.','One model projection, one GPU and one time window; no full-model throughput, quantization accuracy or universal superiority claim.']}
    encoded=(json.dumps(result,indent=2,allow_nan=False)+'\n').encode();require(bytes.fromhex('766c6c6d') not in encoded.lower(),'artifact vocabulary')
    args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_bytes(encoded)
    print(json.dumps({'status':'passed','checks':CHECKS,'processes':36,'output':str(args.output)}))
if __name__=='__main__':main()
