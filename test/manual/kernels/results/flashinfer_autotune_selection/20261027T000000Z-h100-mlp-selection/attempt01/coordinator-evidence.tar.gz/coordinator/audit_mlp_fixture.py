"""Independent NumPy/byte audit of the captured fixture; no Torch or GPU."""
import hashlib,json,math,struct,subprocess
from pathlib import Path
import numpy as np
ROOT=Path('/private/tmp/sglang-mlp-selection-study')
COORD=Path('/private/tmp/fi-mlp-selection-20261026/coordinator')
RAW=COORD/'raw-capture/attempt01/fixture'
BATCH=ROOT/'test/manual/kernels/results/flashinfer_autotune_selection/20261027T000000Z-h100-mlp-selection'
COMMIT='a028b55b9c359568aa959e23e00b99a1824e89aa'
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def check(label,condition):
    if not condition:raise AssertionError(label)
    checks.append(label)
def git_bytes(commit,path):
    return subprocess.check_output(['git','-C',str(ROOT),'show',commit+':'+path])
plan=json.loads((BATCH/'plan.json').read_text())
manifest_bytes=(RAW/'manifest.json').read_bytes(); manifest=json.loads(manifest_bytes)
fixture_bytes=(RAW/'fixture.safetensors').read_bytes()
prior_path=ROOT/manifest['previous_fixture']['manifest_path']
prior=json.loads(prior_path.read_text())
checkpoint=json.loads((COORD/'independent-checkpoint-slice.json').read_text())
check('final plan is frozen commit content',git_bytes(COMMIT,str((BATCH/'plan.json').relative_to(ROOT)))==(BATCH/'plan.json').read_bytes())
check('manifest bound by frozen plan',sha(manifest_bytes)==plan['fixture_manifest_sha256'])
check('fixture bound by frozen plan',sha(fixture_bytes)==plan['fixture_sha256']==manifest['tensor_file']['sha256'])
check('fixture exact size',len(fixture_bytes)==manifest['tensor_file']['size_bytes'])
check('prior manifest bytes',sha(prior_path.read_bytes())==manifest['previous_fixture']['manifest_sha256']=='e13a86fab5db5796b22d8dab0f84080b8057b036ca7aef2c7be8832e76505bf1')
check('geometry is prespecified MLP',manifest['shape']==plan['fixture_contract']['shape_m_n_k']==[144,1024,3072])
check('schema and fixture kind',manifest['schema_version']==2 and manifest['fixture_kind']=='qwen3_mlp_down_proj')
check('same immutable checkpoint',manifest['model']['repo_id']==prior['model']['repo_id']==plan['fixture_contract']['model'] and manifest['model']['revision']==prior['model']['revision']==manifest['model']['resolved_snapshot_revision']==plan['fixture_contract']['revision'])
check('all checkpoint file identities preserved',manifest['checkpoint_files']==prior['checkpoint_files'])
check('actual checkpoint independently rehashed',checkpoint['checkpoint_sha256']==manifest['checkpoint_files']['model.safetensors']['sha256'] and checkpoint['checkpoint_size_bytes']==manifest['checkpoint_files']['model.safetensors']['size_bytes'])
check('checkpoint actual config',checkpoint['config_dimensions']==[1024,3072] and checkpoint['config_activation']=='silu')
capture=manifest['capture']
check('prespecified exact layer hook',capture['layer']=='model.layers.0.mlp' and capture['hook']=='model.layers.0.mlp.down_proj:forward_pre_hook' and capture['checkpoint_tensor']==checkpoint['tensor_key']=='model.layers.0.mlp.down_proj.weight')
check('single TP1 unbiased down weight',capture['weight_order']==['down_proj'] and capture['projection_shapes']==[[1024,3072]] and capture['tensor_parallel_size']==1 and capture['bias'] is None)
check('complete actual BF16 capture',capture['device']=='cuda' and capture['seed']==19 and capture['attention_implementation']=='eager' and capture['model_training'] is False and capture['full_bf16_forward_completed'] is True and capture['logits_shape']==[1,144,151936])
check('activation and checkpoint capture assertions',capture['activation_byte_match'] is True and capture['checkpoint_tensor_byte_match'] is True and capture['activation']=='silu(gate_proj(x)) * up_proj(x)')
check('same tokenizer and prompt settings',manifest['tokenization']==prior['tokenization'])
check('same reference model software',manifest['software']==prior['software'] and manifest['source']['upstream_source_sha256']==prior['source']['upstream_source_sha256'])
header_size=struct.unpack('<Q',fixture_bytes[:8])[0]
header=json.loads(fixture_bytes[8:8+header_size]); payload=fixture_bytes[8+header_size:]
expected={'input_bf16':('BF16',[144,3072],2),'weight_bf16_rowmajor':('BF16',[1024,3072],2),'weight_fp8_rowmajor':('F8_E4M3',[1024,3072],1),'input_scale':('F32',[1],4),'weight_scale':('F32',[1],4),'input_ids':('I64',[1,144],8)}
check('exact six tensor inventory',set(header)-{'__metadata__'}==set(expected)==set(manifest['tensors']))
tensor_bytes={};ranges=[]
for name,(dtype,shape,width) in expected.items():
    h=header[name]; begin,end=h['data_offsets']; raw=payload[begin:end];tensor_bytes[name]=raw;ranges.append((begin,end))
    check(name+' safetensors dtype/shape',h['dtype']==dtype and h['shape']==shape)
    check(name+' exact byte extent',0<=begin<end<=len(payload) and end-begin==math.prod(shape)*width==manifest['tensors'][name]['nbytes'])
    check(name+' payload digest',sha(raw)==manifest['tensors'][name]['sha256'])
check('no missing overlapping or trailing payload',sorted(ranges)[0][0]==0 and sorted(ranges)[-1][1]==len(payload) and all(a[1]==b[0] for a,b in zip(sorted(ranges),sorted(ranges)[1:])))
check('actual raw checkpoint tensor equals fixture weight',sha(tensor_bytes['weight_bf16_rowmajor'])==checkpoint['tensor_sha256'] and checkpoint['tensor_dtype']=='BF16' and checkpoint['tensor_shape']==[1024,3072] and checkpoint['tensor_nbytes']==len(tensor_bytes['weight_bf16_rowmajor']))
check('actual hook input bytes retained',manifest['tensors']['input_bf16']['sha256']==capture['hook_values']['input']['sha256'] and capture['hook_values']['input']['shape']==[1,144,3072] and capture['saved_shape']==[144,3072])
ids=np.frombuffer(tensor_bytes['input_ids'],dtype='<i8').reshape(1,144)
check('actual token IDs equal original prompt',ids.tolist()==prior['tokenization']['input_ids'] and sha(tensor_bytes['input_ids'])==prior['tensors']['input_ids']['sha256'])
def bf16(raw):return (np.frombuffer(raw,dtype='<u2').astype(np.uint32)<<16).view(np.float32)
input_values=bf16(tensor_bytes['input_bf16']);weight_values=bf16(tensor_bytes['weight_bf16_rowmajor'])
scales={name:np.frombuffer(tensor_bytes[name],dtype='<f4')[0] for name in ('input_scale','weight_scale')}
for name,values in [('input_scale',input_values),('weight_scale',weight_values)]:
    check(name+' finite data',np.isfinite(values).all() and np.isfinite(scales[name]) and scales[name]>0)
    reference=np.max(np.abs(values))/np.float32(448)
    check(name+' independently computed absmax calibration',reference.tobytes()==tensor_bytes[name])
# Decode all finite nonnegative E4M3FN codes, then independently round to the
# closest representable value with an even least-significant bit on ties.
codes=np.arange(127,dtype=np.uint8)
exp=(codes>>3).astype(np.int32);mant=(codes&7).astype(np.int32)
table=np.where(exp==0,mant*np.float64(2**-9),(1+mant/8)*np.exp2(exp-7)).astype(np.float32)
def fp8(values):
    values=np.clip(values,np.float32(-448),np.float32(448))
    absolute=np.abs(values)
    hi=np.minimum(np.searchsorted(table,absolute,side='left'),126)
    lo=np.maximum(hi-1,0)
    low_distance=absolute-table[lo]; high_distance=table[hi]-absolute
    nearest=np.where(low_distance<high_distance,lo,np.where(high_distance<low_distance,hi,np.where((lo&1)==0,lo,hi))).astype(np.uint8)
    return nearest | (np.signbit(values).astype(np.uint8)<<7)
check('independent FP8 conversion roundtrip controls',np.array_equal(fp8(table),codes) and fp8(np.array([-0.0],dtype=np.float32))[0]==128)
midpoints=(table[:-1]+table[1:])/np.float32(2)
check('independent FP8 ties choose even codes',np.array_equal(fp8(midpoints),np.where((codes[:-1]&1)==0,codes[:-1],codes[1:])))
quant_weight=fp8(weight_values/scales['weight_scale']).tobytes()
check('independent FP8 weight matches every byte',quant_weight==tensor_bytes['weight_fp8_rowmajor'])
quant_input=fp8(input_values*(np.float32(1)/scales['input_scale'])).tobytes()
check('independent FP8 input reference matches',sha(quant_input)==manifest['quantization']['independent_input_fp8_sha256'])
for relative,value in manifest['source']['sglang_source_sha256'].items():
    check('runtime/capture source '+relative,sha(git_bytes(COMMIT,relative))==value==sha(git_bytes(manifest['source']['sglang_commit'],relative)))
relative='test/manual/kernels/capture_flashinfer_mlp_fixture.py'
check('capture script same in execution freeze',sha(git_bytes(COMMIT,relative))==manifest['source']['capture_script_sha256']==sha(git_bytes(manifest['source']['sglang_commit'],relative)))
result={'status':'passed','checks':len(checks),'passed':checks,'execution_commit':COMMIT,'capture_commit':manifest['source']['sglang_commit'],'manifest_sha256':sha(manifest_bytes),'fixture_sha256':sha(fixture_bytes),'checkpoint_slice_audit_sha256':sha((COORD/'independent-checkpoint-slice.json').read_bytes()),'audit_source_sha256':sha(Path(__file__).read_bytes()),'shape':[144,1024,3072],'independent_quantization':{'numpy_version':np.__version__,'method':'independent BF16 decoder and nearest-even E4M3FN table encoder; FP32 calibration and arithmetic','weight_bytes_equal':True,'input_reference_sha256':sha(quant_input),'input_scale':float(scales['input_scale']),'weight_scale':float(scales['weight_scale'])},'limits':['Gate/up intermediates and full logits were not retained as raw tensors; their recorded identities and the capture-source assertions were audited, not independently rerun.','Actual SGLang quantizer/native correctness requires the separate CUDA admission. This audit used no GPU.']}
encoded=(json.dumps(result,indent=2,allow_nan=False)+'\n').encode()
assert bytes.fromhex('766c6c6d') not in encoded.lower()
(COORD/'independent-fixture-audit.json').write_bytes(encoded)
print(json.dumps({'status':'passed','checks':len(checks),'output':str(COORD/'independent-fixture-audit.json')}))
