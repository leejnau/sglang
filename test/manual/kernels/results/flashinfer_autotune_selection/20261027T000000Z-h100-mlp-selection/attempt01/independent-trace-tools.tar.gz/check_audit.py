#!/usr/bin/env python3
"""Small positive and corrupt-trace controls for the independent reader."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("audit", HERE / "audit_results.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def trace():
    events = []
    for r, role in enumerate(module.ROLES):
        begin = r * 1000
        events.append({"cat": "user_annotation", "ph": "X", "name": "retained_" + role,
                       "ts": begin, "dur": 500})
        # GPU annotations with the same labels must never substitute for CPU scopes.
        events.append({"cat": "gpu_user_annotation", "ph": "X", "name": "retained_" + role,
                       "ts": begin, "dur": 500})
        for launch in range(3):
            correlation = 1 + r * 3 + launch
            now = begin + 10 + launch * 100
            events.append({"cat": "cuda_runtime", "name": "cudaGraphLaunch_v2",
                           "ts": now, "dur": 1, "args": {"correlation": correlation}})
            for i, name in enumerate(("static_quant_fp8_kernel", "matrix_kernel")):
                events.append({"cat": "kernel", "name": name, "ts": now + 2 + i * 10,
                               "dur": 4, "args": {"correlation": correlation, "graph id": r + 1,
                               "device": 0, "grid": [1, 2, 3], "block": [32, 1, 1],
                               "registers per thread": 32, "shared memory": 0}})
    return {"traceEvents": events}


def main():
    cases = []
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "trace.json"
        base = trace()
        path.write_text(json.dumps(base))
        result = module.replay_trace(path)
        assert result["same_signatures"]
        cases.append("positive correlated two-graph trace including duplicate GPU annotations")
        mutations = {
            "missing CPU range": lambda d: d["traceEvents"].__setitem__(0, {**d["traceEvents"][0], "cat": "gpu_user_annotation"}),
            "missing actual runtime launch": lambda d: d["traceEvents"].pop(2),
            "wrong per-replay kernel": lambda d: d["traceEvents"][6].__setitem__("name", "changed_kernel"),
            "wrong correlation": lambda d: d["traceEvents"][3]["args"].__setitem__("correlation", 999),
            "shared actual native graph": lambda d: [e["args"].__setitem__("graph id", 1) for e in d["traceEvents"] if e["cat"] == "kernel"],
        }
        for label, mutate in mutations.items():
            data = copy.deepcopy(base)
            mutate(data)
            path.write_text(json.dumps(data))
            try:
                module.replay_trace(path)
            except AssertionError:
                cases.append(label)
            else:
                raise AssertionError("fault was accepted: " + label)
    output = {"status": "passed", "controls": len(cases), "cases": cases}
    (HERE / "audit-cpu-controls.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps(output))


if __name__ == "__main__":
    main()
