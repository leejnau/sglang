#!/usr/bin/env python3
"""Independent raw cache, native, replay and timing audit for the MLP cohort."""

import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import statistics

CHECKS = 0
ROLES = ("natural", "default")
MODES = ("eager", "cuda_graph")


def require(ok, message):
    global CHECKS
    CHECKS += 1
    if not ok:
        raise AssertionError(message)


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def finite(value):
    return isinstance(value, (float, int)) and math.isfinite(value) and value > 0


def launch_signature(event):
    args = event["args"]
    return {"name": event["name"], **{k: args[k] for k in (
        "grid", "block", "registers per thread", "shared memory", "device"
    )}}


def replay_trace(path):
    """Follow actual runtime correlations, independent of result summaries."""
    events = read(path)["traceEvents"]
    output, covered, correlations, graph_ids = {}, [], [], []
    for role in ROLES:
        markers = [e for e in events if e.get("cat") == "user_annotation"
                   and e.get("ph") == "X" and e.get("name") == "retained_" + role]
        require(len(markers) == 1, "one CPU range per original retained graph")
        marker = markers[0]
        lo, hi = marker["ts"], marker["ts"] + marker["dur"]
        launches = sorted((e for e in events if e.get("cat") == "cuda_runtime"
                           and "cudaGraphLaunch" in e.get("name", "")
                           and lo <= e["ts"] <= hi), key=lambda e: e["ts"])
        require(len(launches) == 3, "three actual launches of each retained graph")
        cycles, ids = [], set()
        for launch in launches:
            correlation = launch["args"]["correlation"]
            correlations.append(correlation)
            kernels = sorted((e for e in events if e.get("cat") == "kernel"
                              and e.get("args", {}).get("correlation") == correlation),
                             key=lambda e: e["ts"])
            require(len(kernels) >= 2, "full layer has quantizer and GEMM launches")
            require("static_quant_fp8" in kernels[0]["name"], "quantizer precedes GEMM")
            require(any("static_quant_fp8" not in e["name"] for e in kernels[1:]),
                    "matrix kernel is present")
            require(all(lo <= e["ts"] and e["ts"] + e["dur"] <= hi + 1 for e in kernels),
                    "all correlated GPU work completes inside its CPU range")
            covered.extend(id(e) for e in kernels)
            ids.update(e["args"]["graph id"] for e in kernels)
            cycles.append([launch_signature(e) for e in kernels])
        require(cycles[0] == cycles[1] == cycles[2], "ordered launch signature repeats")
        require(len(ids) == 1 and next(iter(ids)) > 0, "one positive CUDA graph identity")
        graph_ids.extend(ids)
        output[role] = {"cuda_graph_id": next(iter(ids)), "launches": 3,
                        "signature": cycles[0]}
    require(len(set(correlations)) == 6, "independent launch correlations")
    require(len(set(graph_ids)) == 2, "two independent native CUDA graph identities")
    actual = [id(e) for e in events if e.get("cat") == "kernel"]
    require(len(set(covered)) == len(actual) and set(covered) == set(actual),
            "all traced kernels accounted for exactly once")
    output["same_signatures"] = output["natural"]["signature"] == output["default"]["signature"]
    return output


def locate_cache(raw, mode, trial, arm):
    matches = [p for p in (raw / "tuner-cache" / mode).rglob("cache.json")
               if p.parent.name == f"trial{trial}-{arm}"]
    require(len(matches) == 1, "one actual persisted cache for each cold/warm pair")
    return matches[0]


def worker(raw, entry, admission, plan, schedule):
    name = ("admission-" if admission else "") + entry["id"]
    path = raw / (name + ".json")
    row = read(path)
    require(row["status"] == "success", "worker success")
    require(row["assignment"] == entry, "declared assignment matches frozen schedule")
    require(row["mode"] == ("admission" if admission else "timing"), "separate admission cohort")
    require(row["source"]["critical_sha256"] == plan["source_contract"]["runtime_sha256"],
            "frozen current source hashes")
    require(row["fixture"]["tensor_file_sha256"] == plan["fixture_sha256"], "fixture bytes bound")
    require(row["fixture"]["manifest_sha256"] == plan["fixture_manifest_sha256"], "fixture capture bound")
    bootstrap = read(path.with_suffix(".bootstrap.json"))
    require(bootstrap["status"] == "passed" and bootstrap["result_sha256"] == digest(path),
            "actual bootstrap/result binding")
    native = bootstrap["native"]["providers"]
    require({k: v["library_sha256"] for k, v in native.items()}
            == plan["native_reuse"]["required_library_sha256"], "exact qualified native ELF bytes")
    arm, phase = entry["arm"], entry["phase"]
    natural, cache, startup = (row[k] for k in ("natural", "cache", "startup"))
    tier = "miss" if arm == "default" else "memory" if phase == "cold" else "file"
    require(natural["lookup_tier"] == tier and natural["cache_hit"] == (tier != "miss"),
            "actual natural memory/file/miss branch")
    profiles = startup["profiles"]
    require(startup["profile_attempts"] == len(profiles) == row["final"]["profile_attempts"],
            "no hidden profiling after startup")
    require(not row["forbidden_profile_attempts"] and not row["profile_protocol_errors"],
            "no swallowed profile guard failure")
    if phase == "warm" or arm == "default":
        require(not profiles, "warm or untuned path profiles zero candidates")
    if phase == "warm":
        require(cache["memory_entries"] == 0, "fresh warm cache stays file-backed")
    mode = "admission" if admission else "timing"
    cachepath = locate_cache(raw, mode, entry["trial"], arm)
    persisted = read(cachepath)
    require(digest(cachepath) == cache["final_sha256"] == cache["after_startup_sha256"],
            "original saved bytes survive measurement and fresh warm save")
    if phase == "warm":
        require(cache["before_sha256"] == digest(cachepath), "fresh warm loaded unchanged cold artifact")
    require(cache["canonical_state_after_startup"] == cache["canonical_state_final"],
            "semantic live winner state preserved")
    records = {k: v for k, v in persisted.items() if not k.startswith("_")}
    if arm == "default":
        require(not records and natural["tactic"] == -1, "untuned serving is actual fallback")
    else:
        require(natural["key"] in records, "actual serialized runtime key exists")
        require(records[natural["key"]][0] == "CublasFp8GemmRunner"
                and records[natural["key"]][1] == natural["tactic"],
                "saved runtime winner is exact native descriptor/default")
    margins = []
    if profiles:
        groups = collections.defaultdict(list)
        for profile in profiles:
            groups[profile["key"]].append(profile)
        require(len(groups) == 9, "nine original dynamic profile keys")
        require(set(groups) == set(records), "entire actual profile inventory persists")
        for key, values in groups.items():
            finite_rows = [p for p in values if p["profiler_ms"] is not None]
            require(finite_rows and all(finite(p["profiler_ms"]) for p in finite_rows),
                    "finite successful profile times")
            require(sum(p["tactic"] == -1 for p in values) == (arm == "v2"),
                    "default races exactly once only in v2")
            winner = min(finite_rows, key=lambda p: p["profiler_ms"])
            require(records[key][1] == winner["tactic"], "every saved profile winner is first finite minimum")
        runtime = groups[natural["key"]]
        default = [p for p in runtime if p["tactic"] == -1 and p["profiler_ms"] is not None]
        explicit = [p for p in runtime if p["tactic"] != -1 and p["profiler_ms"] is not None]
        if default and explicit:
            margins = min(p["profiler_ms"] for p in explicit) / default[0]["profiler_ms"]
    checks = {c["check"]: c for c in row["correctness"]}
    require(len(checks) == len(row["correctness"]), "unique actual numerical checks")
    require(all(c["quantized_reference"]["passed"] and
                math.isfinite(c["quantized_reference"]["max_normalized_error"]) and
                c["quantized_reference"]["max_normalized_error"] <= 1 for c in checks.values()),
            "all outputs pass quantized-input FP32 reference")
    bindings = row["binding_acceptance_checks"]
    require(bindings and all(b["accepted"] and b["used_descriptor"] ==
                            ([] if b["tactic"] == -1 else [1]) for b in bindings),
            "real descriptor accepted; default avoids descriptor binding")
    graphs = {g["id"]: g for g in row["graphs"]}
    require(set(graphs) == set(ROLES) and len({g["output"]["data_ptr"] for g in graphs.values()}) == 2,
            "two independent retained output allocations")
    for role, graph in graphs.items():
        expected = natural["tactic"] if role == "natural" else -1
        require(graph["tactic"] == expected and graph["output"]["data_ptr"] == graph["inputs"][4]["data_ptr"],
                "capture uses actual selected tactic and native output allocation")
        for suffix in ("changed_input", "restored_input"):
            check = checks[f"{role}_{suffix}"]
            require(check["output_data_ptr"] == graph["output"]["data_ptr"] and
                    check["exact_zero_required"] == (suffix == "changed_input"),
                    "original graph changed/restored-input guard")
    require(all(m["restored"] and m["cache_sha256_before"] == m["cache_sha256_after"]
                and m["winner_entries_after_removal"] == m["file_entries_after_removal"] == 0
                for m in row["miss_scopes"]), "genuine miss scopes preserve original cache")
    summaries, outcomes = {}, collections.Counter()
    for mode in MODES:
        group = row["measurements"][mode]
        pairs = group["pairs"]
        orders = schedule["round_schedules"][str(entry["trial"])][mode]
        require(len(pairs) == len(orders) == 12, "all twelve prespecified pairs retained")
        logs = []
        for i, pair in enumerate(pairs):
            require(pair["index"] == i and pair["order"] == orders[i] and
                    [m["role"] for m in pair["measurements"]] == orders[i], "exact balanced temporal order")
            values = {}
            for sample in pair["measurements"]:
                role = sample["role"]
                require(sample["iterations"] == group["common_iterations"] and
                        sample["rewarm"]["actual_ms"] >= 20, "common iterations and outside-window rewarm")
                require(sample["profile_attempts_before"] == sample["profile_attempts_after"] == len(profiles),
                        "zero measured-path profiling")
                require(finite(sample["wall_batch_ms"]) and finite(sample["gpu_event_batch_ms"]), "finite event/wall batches")
                for base, per in (("wall_batch_ms", "wall_per_call_ms"),
                                  ("gpu_event_batch_ms", "gpu_event_per_call_ms")):
                    require(math.isclose(sample[base] / sample["iterations"], sample[per], rel_tol=1e-12),
                            "actual sample normalized exactly once")
                for when in ("lookup_before", "lookup_after"):
                    look = sample[when]
                    expected_tier = tier if role == "natural" else "miss"
                    require(look["tactic"] == (natural["tactic"] if role == "natural" else -1)
                            and look["lookup_tier"] == expected_tier and
                            look["cache_hit"] == (expected_tier != "miss"), "actual public lookup around timed batch")
                checked = checks[sample["correctness_check"]]
                require(checked["checked_ns"] >= sample["ended_ns"], "timed output checked after this batch")
                if mode == "cuda_graph":
                    require(sample["iterations"] == 16 and sample["prequeue_cycles"] == 10_000_000 and
                            sample["queue_query_is_exclusion_criterion"] is False and
                            type(sample["start_event_complete_after_enqueue"]) is bool and
                            sample["wall_diagnostic_only"] and sample["wall_includes_prequeue"], "queued graph primary and diagnostic wall semantics")
                    outcomes[str(sample["start_event_complete_after_enqueue"])] += 1
                    require(checked["output_data_ptr"] == graphs[role]["output"]["data_ptr"], "timed original graph allocation")
                values[role] = sample["wall_per_call_ms" if mode == "eager" else "gpu_event_per_call_ms"]
            logs.append(math.log(values["natural"] / values["default"]))
        summaries[mode] = {"median_log_natural_over_default": statistics.median(logs),
                           "ratio": math.exp(statistics.median(logs)), "pair_logs": logs}
    tracepath = raw / (name + ".trace.json")
    require(digest(tracepath) == row["trace"]["sha256"], "original trace bytes")
    require(row["trace"]["started_ns"] > max(g["ended_ns"] for g in row["measurements"].values()),
            "instrumented observation strictly after all timing")
    require({g["id"]: (g["graph_object_id"], g["output_data_ptr"]) for g in row["trace"]["graphs"]} ==
            {role: (g["graph_object_id"], g["output"]["data_ptr"]) for role, g in graphs.items()},
            "trace replays same original graph objects and output pointers")
    traces = replay_trace(tracepath)
    return {"name": name, "trial": entry["trial"], "arm": arm, "phase": phase,
            "key": natural["key"], "tactic": natural["tactic"], "tier": tier,
            "cache_sha256": digest(cachepath), "profiles": len(profiles),
            "runtime_best_explicit_over_default_profile": margins,
            "correctness_checks": len(checks), "native_acceptance_checks": len(bindings),
            "queue_start_outcomes": dict(outcomes), "modes": summaries, "trace": traces}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for option in ("raw-root", "plan", "schedule", "output"):
        parser.add_argument("--" + option, type=Path, required=True)
    parser.add_argument("--admission", action="store_true")
    args = parser.parse_args()
    require(not args.output.exists(), "immutable report path")
    plan, schedule = read(args.plan), read(args.schedule)
    entries = [e for e in schedule["entries"] if not args.admission or e["trial"] == 0]
    rows = [worker(args.raw_root, e, args.admission, plan, schedule) for e in entries]
    index = {(r["trial"], r["arm"], r["phase"]): r for r in rows}
    for trial in range(1 if args.admission else 6):
        for arm in ("default", "v1", "v2"):
            cold, warm = (index[trial, arm, phase] for phase in ("cold", "warm"))
            require((cold["key"], cold["tactic"], cold["cache_sha256"]) ==
                    (warm["key"], warm["tactic"], warm["cache_sha256"]),
                    "exact actual cold winner survives fresh-process legacy reload")
            require(not warm["profiles"], "fresh warm profiling count zero")
    result = {"status": "passed", "scope": "independent raw cache/native/trace/timing audit",
              "mode": "admission" if args.admission else "timing", "checks": CHECKS,
              "processes": len(rows), "source_sha256": digest(__file__), "workers": rows,
              "limits": ["Per-worker trace launch signatures do not prove universal physical identity.",
                         "Event graph replay span excludes prequeue delay; diagnostic wall includes it.",
                         "Eager wall includes recurring public-facade host/setup work.",
                         "One fixed fixture and research source overlay; no full-model serving claim."]}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({k: result[k] for k in ("status", "mode", "checks", "processes")}))


if __name__ == "__main__":
    main()
