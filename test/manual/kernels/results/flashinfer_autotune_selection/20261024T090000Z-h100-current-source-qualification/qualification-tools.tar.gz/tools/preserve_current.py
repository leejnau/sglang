"""Preserve every attempted result and reported native artifact before release."""

import argparse
import hashlib
import json
import shutil
import tarfile
from pathlib import Path


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--study", type=Path, required=True)
    parser.add_argument("--results", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    study, results = args.study.resolve(), args.results.resolve()
    if args.output.exists() or not results.is_relative_to(study):
        raise ValueError("new archive and owned results root required")
    native_dir = results / "native-artifacts"
    native_dir.mkdir(exist_ok=True)
    copied = {}
    for report in sorted(results.glob("*.json")):
        data = json.loads(report.read_text())
        providers = data.get("native", {}).get("providers", {})
        for name, item in providers.items():
            for key in ("library", "ninja"):
                container_path = Path(item[key + "_path"])
                if not container_path.is_relative_to("/study"):
                    raise ValueError("native artifact outside owned mount")
                actual = study / container_path.relative_to("/study")
                if not actual.resolve().is_relative_to(study):
                    raise ValueError("native artifact escaped owned study")
                digest = sha(actual)
                if digest != item[key + "_sha256"]:
                    raise ValueError("native artifact changed after execution")
                destination = native_dir / (name + "-" + digest[:16] + actual.suffix)
                if destination.exists():
                    if sha(destination) != digest:
                        raise ValueError("native archive collision")
                else:
                    shutil.copy2(actual, destination)
                copied[str(destination.relative_to(results))] = {
                    "sha256": digest,
                    "source_path": str(container_path),
                }
    rows = []
    for p in sorted(results.rglob("*")):
        if p.is_file() and p.name != "preservation-manifest.json":
            rows.append(
                {
                    "path": str(p.relative_to(results)),
                    "size_bytes": p.stat().st_size,
                    "sha256": sha(p),
                }
            )
    (results / "preservation-manifest.json").write_text(
        json.dumps({"files": rows, "native_artifacts": copied}, indent=2) + "\n"
    )
    with tarfile.open(args.output, "w:gz") as archive:
        archive.add(results, arcname=results.name)
    print(
        json.dumps(
            {
                "archive": str(args.output),
                "sha256": sha(args.output),
                "size_bytes": args.output.stat().st_size,
                "manifest_members": len(rows),
                "native_artifacts": len(copied),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
