#!/usr/bin/env python3
"""Bounded current-source FP8 provider/facade correctness qualification.

No startup search or performance measurement is performed. Explicit choices are
real-cache functionality controls. The actual decorated public APIs are retained.
"""
from __future__ import annotations

import argparse
import contextlib
import copy
import hashlib
import importlib.util
import inspect
import json
import math
import os
import sys
import traceback
from pathlib import Path
from unittest.mock import patch

PIN = '27c62fdf0ab1cd4014df8a15b66a975541fda83c'
PREFLIGHT_SHA = 'b8d0f6bbc85eaca0e3ef1419ab99a97d5340c96b3da382cba81d7896768287ba'
MANIFEST_SHA = '7c68529cfcb89ab47f1cae5f08ee3187626c0a6f2dadac3e6c4f862f42ded974'
PORT_SHA = '1ac5a30bb27519322e067b17f796a243bcec76814925a40c703797cfdfe31f14'
FIXTURE_SHA = 'c30aa761eba827bb0b4eb6de0e99d9b8dda8243dd16d00146f9718d2abb05e8b'
FIXTURE_MANIFEST_SHA = 'e13a86fab5db5796b22d8dab0f84080b8057b036ca7aef2c7be8832e76505bf1'
FOUR_FILES = {'csrc/bmm_fp8.cu', 'csrc/flashinfer_gemm_binding.cu',
              'include/flashinfer/gemm/bmm_fp8.cuh', 'flashinfer/gemm/gemm_base.py'}


def sha(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda: handle.read(1024*1024), b''):
            value.update(block)
    return value.hexdigest()


def require(value, message):
    if not value:
        raise RuntimeError(message)


def descriptor_json(value):
    if value == -1:
        return -1
    require(isinstance(value, tuple) and len(value) == 8 and
            all(type(word) is int and 0 <= word < 2**64 for word in value),
            'malformed descriptor')
    return list(value)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--candidate-manifest', type=Path, required=True)
    parser.add_argument('--port-manifest', type=Path, required=True)
    parser.add_argument('--preflight-helper', type=Path, required=True)
    parser.add_argument('--variant', choices=('fp8-runtime', 'fp8-runtime-callback'), default='fp8-runtime')
    parser.add_argument('--sglang-root', type=Path, required=True)
    parser.add_argument('--fixture', type=Path, required=True)
    parser.add_argument('--fixture-manifest', type=Path, required=True)
    parser.add_argument('--expected-gpu-uuid', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--prepare-data-links', action='store_true')
    return parser.parse_args()


class NativeObserver:
    """Forward every native call; retain returned acceptance, never replace it."""
    def __init__(self, owner, native):
        self.owner, self.native = owner, native

    def bmm_fp8_run_with_descriptor(self, *args):
        used = int(self.native.bmm_fp8_run_with_descriptor(*args))
        self.owner.result['native_calls'].append({
            'stage': self.owner.stage, 'api': 'bmm_fp8_run_with_descriptor',
            'm': int(args[0].shape[-2]), 'used_descriptor': used,
            'descriptor_raw_hex': bytes(args[-1].contiguous().view(self.owner.torch.uint8).tolist()).hex(),
            'capturing': bool(self.owner.torch.cuda.is_current_stream_capturing()),
        })
        return used

    def bmm_fp8_get_algos(self, *args):
        count = int(self.native.bmm_fp8_get_algos(*args))
        self.owner.result['native_calls'].append({
            'stage': self.owner.stage, 'api': 'bmm_fp8_get_algos',
            'actual_m': int(args[0].shape[-2]), 'enumeration_m': int(args[-1]),
            'count': count,
        })
        return count

    def bmm_fp8(self, *args):
        value = self.native.bmm_fp8(*args)
        self.owner.result['native_calls'].append({
            'stage': self.owner.stage, 'api': 'bmm_fp8',
            'm': int(args[0].shape[-2]),
            'capturing': bool(self.owner.torch.cuda.is_current_stream_capturing()),
        })
        return value

    def __getattr__(self, name):
        return getattr(self.native, name)


class Qualification:
    def __init__(self, args, result):
        self.args, self.result, self.stage = args, result, 'source_preflight'
        self.expected_tactic = -1
        self.torch = None
        self.first_inputs = None
        self.profile_attempts = 0

    def tensor_sha(self, tensor):
        raw = tensor.detach().contiguous().view(self.torch.uint8).cpu()
        return hashlib.sha256(raw.numpy().tobytes()).hexdigest()

    def metadata(self, tensor):
        return {'shape': list(tensor.shape), 'stride': list(tensor.stride()),
                'dtype': str(tensor.dtype), 'device': str(tensor.device),
                'data_ptr': tensor.data_ptr()}

    def setup(self):
        a = self.args
        require(sha(a.preflight_helper) == PREFLIGHT_SHA, 'preflight helper hash mismatch')
        require(sha(a.candidate_manifest) == MANIFEST_SHA, 'candidate manifest hash mismatch')
        require(sha(a.port_manifest) == PORT_SHA, 'port manifest hash mismatch')
        require(sha(a.fixture) == FIXTURE_SHA and sha(a.fixture_manifest) == FIXTURE_MANIFEST_SHA,
                'immutable fixture hash mismatch')
        port = json.loads(a.port_manifest.read_text())
        changed = {row['path']: row for row in port['files'] if row['changed']}
        require(port['base_commit'] == PIN and set(changed) == FOUR_FILES, 'port scope differs')
        for name, row in changed.items():
            require(sha(a.source/name) == row['candidate_sha256'], 'ported source mismatch: ' + name)
        spec = importlib.util.spec_from_file_location('qualified_current_preflight', a.preflight_helper)
        self.preflight = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.preflight)
        if a.prepare_data_links:
            self.result['packaging_preparation'] = self.preflight.prepare_data_links(a.source)
        self.result['source'] = self.preflight.check_source(a.source, a.candidate_manifest, a.variant)
        self.result['inventory'] = self.preflight.inventory(a.source)
        import torch
        self.torch = torch
        require(torch.cuda.is_available() and torch.cuda.get_device_capability() == (9, 0), 'requires actual H100 CUDA device')
        torch.cuda.set_device(0)
        props = torch.cuda.get_device_properties(0)
        gpu_uuid = str(props.uuid).removeprefix('GPU-').lower()
        require(gpu_uuid == a.expected_gpu_uuid.removeprefix('GPU-').lower(), 'physical GPU differs')
        require(not os.environ.get('LD_PRELOAD'), 'native preload is not part of this gate')
        require(torch.__version__ == '2.14.1+cu130' and torch.version.cuda == '13.0', 'pinned Torch/CUDA stack differs')
        os.environ['FLASHINFER_AUTOTUNER_LOAD_FROM_FILE'] = '0'
        self.result['import'] = self.preflight.import_current(a.source)
        import flashinfer
        from flashinfer.autotuner import AutoTuner
        from flashinfer.gemm import gemm_base
        self.flashinfer, self.AutoTuner, self.gb = flashinfer, AutoTuner, gemm_base
        require(flashinfer.bmm_fp8 is gemm_base.bmm_fp8 and hasattr(flashinfer.bmm_fp8, '__wrapped__'),
                'actual decorated public BMM binding changed')
        self.stage = 'native_build'
        def native_callback(name, spec, native):
            return NativeObserver(self, native) if name == 'gemm' else native
        self.result['native'] = self.preflight.explicit_native_build(a.source, native_module_callback=native_callback)
        # The native provider has been bound once; all later public functions stay unchanged.
        sys.path.insert(0, str(a.sglang_root/'python'))
        self.stage = 'fixture_setup'
        from safetensors.torch import load_file
        import sglang
        from sglang.kernels.ops.quantization import fp8_kernel
        from sglang.srt.layers.quantization import fp8_utils
        require(Path(sglang.__file__).resolve().is_relative_to(a.sglang_root/'python'), 'SGLang imported from another checkout')
        fixture = json.loads(a.fixture_manifest.read_text())
        require(fixture['shape'] == [144,4096,1024], 'fixture shape differs')
        for name, expected in fixture['source']['sglang_source_sha256'].items():
            require(sha(a.sglang_root/name) == expected, 'SGLang source changed: ' + name)
        for module in (fp8_kernel, fp8_utils):
            require(Path(module.__file__).resolve().is_relative_to(a.sglang_root/'python'), 'mixed SGLang source')
        require(fp8_utils._raw_flashinfer_bmm_fp8 is flashinfer.bmm_fp8 and
                fp8_utils.static_quant_fp8 is fp8_kernel.static_quant_fp8 and
                fp8_utils.flashinfer_per_tensor_fp8_supported(), 'actual static FP8 facade/quantizer binding changed')
        cpu = load_file(str(a.fixture), device='cpu')
        require(set(cpu) == set(fixture['tensors']), 'fixture tensor set differs')
        for name, tensor in cpu.items():
            observed = {'shape':list(tensor.shape),'dtype':str(tensor.dtype),
                        'sha256':self.tensor_sha(tensor),'nbytes':tensor.numel()*tensor.element_size()}
            require(observed == fixture['tensors'][name], 'fixture tensor bytes differ: '+name)
            require(bool(torch.isfinite(tensor.float()).all()), 'nonfinite fixture tensor')
        self.input = cpu['input_bf16'].to('cuda')
        self.saved_input = self.input.clone()
        self.weight = cpu['weight_fp8_rowmajor'].to('cuda')
        self.sa, self.sb = cpu['input_scale'].to('cuda'), cpu['weight_scale'].to('cuda')
        self.apply = fp8_utils.apply_fp8_linear_bmm_flashinfer
        torch.backends.cuda.matmul.allow_tf32 = False
        self.q, scale = fp8_kernel.static_quant_fp8(self.input, self.sa, repeat_scale=False)
        require(self.tensor_sha(self.q) == fixture['quantization']['independent_input_fp8_sha256'] and
                scale.data_ptr() == self.sa.data_ptr(), 'actual quantizer bytes/scale allocation differ')
        self.reference = self.q.float() @ self.weight.float().t() * self.sa * self.sb
        self.read_hashes = {name:self.tensor_sha(value) for name,value in
                            [('input',self.input),('weight',self.weight),('input_scale',self.sa),('weight_scale',self.sb)]}
        self.tuner = AutoTuner()
        require(not self.tuner._winner_cache() and not self.tuner._file_configs and
                self.tuner._active_managed_store is None and not self.tuner.is_tuning_mode,
                'fresh isolated tuner unexpectedly has state')
        self.original_choose = self.tuner.choose_one
        self.original_search = self.tuner.search_cache
        self.result['fixture'] = {'manifest_sha256':FIXTURE_MANIFEST_SHA,'tensor_file_sha256':FIXTURE_SHA,
                                  'shape':fixture['shape'],'quantized_input_sha256':self.tensor_sha(self.q),
                                  'sglang_source_sha256':fixture['source']['sglang_source_sha256']}
        self.result['runtime'] = {'gpu':props.name,'gpu_uuid':gpu_uuid,'torch':torch.__version__,
                                'torch_cuda':torch.version.cuda,'inference_mode':torch.is_inference_mode_enabled(),
                                'grad_enabled':torch.is_grad_enabled(),'allow_tf32':torch.backends.cuda.matmul.allow_tf32,
                                'bmm_public':{'module':flashinfer.bmm_fp8.__module__,'name':flashinfer.bmm_fp8.__name__,
                                              'decorated':hasattr(flashinfer.bmm_fp8,'__wrapped__')},
                                'facade_source_sha256':hashlib.sha256(inspect.getsource(self.apply).encode()).hexdigest()}

    def forbidden_profile(self, *args, **kwargs):
        self.profile_attempts += 1
        self.result['forbidden_profile_stages'].append(self.stage)
        raise RuntimeError('profiling is forbidden in this correctness-only gate')

    def choose(self, op, runners, config, inputs, **kwargs):
        require(op == 'fp8_gemm' and len(runners) == 1 and
                type(runners[0]).__name__ == 'CublasFp8GemmRunner' and not kwargs,
                'unexpected operation/backend pool')
        result = self.original_choose(op, runners, config, inputs, **kwargs)
        hit, idx, cached, _ = self.original_search(op,runners,tuple(tuple(t.shape) for t in inputs),config,inputs=inputs)
        require(result[1] == self.expected_tactic and result[0] is runners[idx], 'public call did not consume expected tactic')
        require(bool(hit) == (self.expected_tactic != -1), 'default must be genuine miss; explicit must be real hit')
        if hit:
            require(cached == self.expected_tactic, 'cache winner differs')
        capturing = bool(self.torch.cuda.is_current_stream_capturing())
        if not capturing:
            # Refresh new eager allocation before the actual runner writes it.
            inputs[4].fill_(float('nan'))
        row = {'stage':self.stage,'tactic':descriptor_json(result[1]),'hit':bool(hit),
               'lookup_tier':'memory' if hit else 'miss','capturing':capturing,
               'inputs':[self.metadata(t) for t in inputs],
               'nearest_profile':[list(s) for s in self.tuner._find_nearest_profile(tuple(tuple(t.shape) for t in inputs),config)]}
        self.result['selections'].append(row)
        if self.first_inputs is None:
            self.first_inputs, self.runner, self.config = inputs, runners[0], config
        return result

    def facade(self):
        return self.apply(self.input,self.weight.t(),self.sb,self.sa,bias=None)

    def check(self, output, label, zero=False):
        torch=self.torch
        torch.cuda.synchronize()
        reference = torch.zeros_like(self.reference) if zero else self.reference
        difference=(output.float()-reference).abs()
        maximum=float(difference.max().item())
        row={'check':label,'shape':list(output.shape),'output_ptr':output.data_ptr(),
             'finite':bool(torch.isfinite(output).all()),
             'max_abs_error':maximum if math.isfinite(maximum) else None,
             'zero_required':zero,'passed':False}
        self.result['correctness'].append(row)
        torch.testing.assert_close(output.float(),reference,rtol=0.02,atol=0.125)
        if zero:
            require(int(torch.count_nonzero(output).item()) == 0, 'zero input did not produce exact zero')
        row['passed']=True

    @contextlib.contextmanager
    def choice(self, tactic):
        require(not self.tuner.is_tuning_mode and self.tuner._active_managed_store is None,
                'unexpected tuning or managed store')
        names=('profiling_cache','_profiling_cache_policies')
        saved={name:dict(getattr(self.tuner,name)) for name in names}
        dirty=(self.tuner._dirty,self.tuner._dirty_seq)
        require(not self.tuner._file_configs, 'file winners are outside this gate')
        old_expected=self.expected_tactic
        try:
            for name in names:getattr(self.tuner,name).clear()
            self.expected_tactic=tactic
            if tactic != -1:
                shapes=tuple(tuple(t.shape) for t in self.first_inputs)
                key=self.tuner._get_cache_key('fp8_gemm',self.runner,shapes,self.config,
                                               self.runner.get_cache_key_extras(self.first_inputs))
                self.tuner._cache_profile_result(key,None,self.config,tactic)
            yield
        finally:
            self.expected_tactic=old_expected
            for name in names:
                target=getattr(self.tuner,name);target.clear();target.update(saved[name])
            self.tuner._dirty,self.tuner._dirty_seq=dirty
            require(all(getattr(self.tuner,name)==saved[name] for name in names),'winner cache restoration failed')

    def accepted_descriptor(self):
        torch=self.torch
        inputs144=self.first_inputs
        inputs129=[inputs144[0][:,:129,:].contiguous(),inputs144[1],inputs144[2],inputs144[3],
                   torch.empty((1,129,4096),dtype=torch.bfloat16,device='cuda'),inputs144[5]]
        enumeration_start=len(self.result['native_calls'])
        self.stage='enumerate_m144'
        pool144=list(self.runner.get_valid_tactics(inputs144,None))
        self.stage='enumerate_m129'
        other=self.gb.get_gemm_module().cublas_fp8_gemm_runner()
        pool129=list(other.get_valid_tactics(inputs129,None))
        require(0 < len(pool144) <= 100 and pool144 == pool129,'same-bucket candidate pools differ or are empty')
        enumerations=[row for row in self.result['native_calls'][enumeration_start:]
                      if row['api']=='bmm_fp8_get_algos']
        require(len(enumerations)==1 and enumerations[0]['actual_m']==144 and
                enumerations[0]['enumeration_m']==256 and enumerations[0]['count']==len(pool144),
                'actual shared-cache native enumeration differs from claimed bucket256')
        key144=self.tuner._get_cache_key('fp8_gemm',self.runner,tuple(tuple(t.shape) for t in inputs144),
                                        self.config,self.runner.get_cache_key_extras(inputs144))
        key129=self.tuner._get_cache_key('fp8_gemm',other,tuple(tuple(t.shape) for t in inputs129),
                                        self.config,other.get_cache_key_extras(inputs129))
        require(key144.file_key==key129.file_key,'same-bucket stable cache identities differ')
        require(self.tuner.get_effective_map_to_tuning_buckets(self.config)(144)==256 and
                self.tuner.get_effective_map_to_tuning_buckets(self.config)(129)==256,'hybrid mapping differs')
        self.result['candidate_pool']={'m144':[descriptor_json(t) for t in pool144],
                                      'm129':[descriptor_json(t) for t in pool129],
                                      'enumeration_m':enumerations[0]['enumeration_m'],
                                      'native_enumeration_calls':len(enumerations),
                                      'cache_file_key':key144.file_key,'identical':True}
        for index,tactic in enumerate(pool144):
            descriptor_json(tactic)
            row={'index':index,'tactic':descriptor_json(tactic),'actual_calls':[],'accepted_both':False}
            self.result['descriptor_probes'].append(row)
            both=True
            for m,runner,values in [(144,self.runner,inputs144),(129,other,inputs129)]:
                self.stage=f'descriptor_probe_{index}_m{m}'
                values[4].fill_(float('nan'))
                start=len(self.result['native_calls'])
                runner(values,tactic=tactic)
                torch.cuda.synchronize()
                calls=self.result['native_calls'][start:]
                actual=[c for c in calls if c['api']=='bmm_fp8_run_with_descriptor']
                require(len(actual)==1,'descriptor probe did not use actual native binding exactly once')
                used=actual[0]['used_descriptor'];require(used in (0,1),'unexpected native acceptance code')
                reference=self.reference[:m].unsqueeze(0)
                torch.testing.assert_close(values[4].float(),reference,rtol=0.02,atol=0.125)
                row['actual_calls'].append({'m':m,'used_descriptor':used,'numerics':'passed'})
                both &= used==1
            row['accepted_both']=both
            if both:
                self.result['selected_control_descriptor']=descriptor_json(tactic)
                self.result['selected_control_note']='First actual native-accepted descriptor at both concreteMs; functionality control, not a naturally tuned or fastest tactic.'
                return tactic
        raise RuntimeError('no explicit descriptor accepted at both M144 and M129; fallback is not qualification')

    def verify_public_path(self, tactic, name):
        torch=self.torch
        with self.choice(tactic):
            self.stage=name+'_eager'
            before=len(self.result['native_calls'])
            output=self.facade();self.check(output,self.stage)
            calls=self.result['native_calls'][before:]
            expected_api='bmm_fp8' if tactic == -1 else 'bmm_fp8_run_with_descriptor'
            require(len([r for r in calls if r['api']==expected_api])==1,'actual eager native route differs')
            if tactic != -1:
                require(all(r['used_descriptor']==1 for r in calls if r['api']==expected_api), 'explicit public route fell back')
            self.stage=name+'_eager_changed_input'
            self.input.zero_();self.check(self.facade(),self.stage,zero=True)
            self.input.copy_(self.saved_input)
            self.stage=name+'_eager_restored_input';self.check(self.facade(),self.stage)
            # Normal eager warmup only; no profiling or measurement loops.
            stream=torch.cuda.Stream();stream.wait_stream(torch.cuda.current_stream())
            with torch.cuda.stream(stream):
                self.stage=name+'_capture_warmup'
                self.facade();self.facade()
            torch.cuda.current_stream().wait_stream(stream);torch.cuda.synchronize()
            self.stage=name+'_capture'
            start=len(self.result['native_calls'])
            graph=torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph):
                captured_output=self.facade()
            torch.cuda.synchronize()
            calls=self.result['native_calls'][start:]
            require(len(calls)==1 and calls[0]['api']==expected_api,'graph capture native route differs')
            if tactic != -1:require(calls[0]['used_descriptor']==1,'explicit graph capture fell back')
            require(self.result['selections'][-1]['capturing'],'public facade was not captured')
            self.result['graphs'].append({'id':name,'graph_object_id':id(graph),
                                          'output':self.metadata(captured_output),
                                          'tactic':descriptor_json(tactic),
                                          'poison_nodes_captured':False})
            for label,zero in [('replay',False),('changed_input',True),('restored_input',False)]:
                if zero:self.input.zero_()
                else:self.input.copy_(self.saved_input)
                captured_output.fill_(float('nan'))
                torch.cuda.synchronize()
                self.stage=name+'_graph_'+label
                before_native=len(self.result['native_calls']);before_selections=len(self.result['selections'])
                graph.replay();self.check(captured_output,self.stage,zero=zero)
                require(len(self.result['native_calls'])==before_native and len(self.result['selections'])==before_selections,
                        'graph replay unexpectedly reentered Python/native selection')
            self.input.copy_(self.saved_input)
            return graph,captured_output

    def run(self):
        self.setup()
        torch=self.torch
        with patch.object(self.AutoTuner,'_instance',self.tuner), \
             patch.object(self.tuner,'choose_one',self.choose), \
             patch.object(self.tuner,'_profile_single_kernel',self.forbidden_profile):
            self.stage='initial_actual_facade_default'
            initial=self.facade();self.check(initial,self.stage)
            require(self.first_inputs[0].shape == (1,144,1024) and
                    self.first_inputs[1].stride() == (1024,1,1024),'actual public operand layout differs')
            require(self.tensor_sha(self.first_inputs[0])==self.result['fixture']['quantized_input_sha256'],
                    'public facade used different quantized bytes')
            require(self.first_inputs[2].data_ptr()==self.sa.data_ptr() and
                    self.first_inputs[3].data_ptr()==self.sb.data_ptr(),'public scale allocation changed')
            require(self.result['selections'][-1]['nearest_profile'][0][-2]==256,'runtime key did not map to256')
            selected=self.accepted_descriptor()
            # Keep both original objects alive through the final independent replays.
            retained=[self.verify_public_path(-1,'default'),self.verify_public_path(selected,'explicit')]
            self.input.copy_(self.saved_input)
            for index,(graph,output) in enumerate(retained):
                output.fill_(float('nan'));torch.cuda.synchronize();graph.replay()
                self.check(output,'final_independent_graph_'+str(index))
            require(len({output.data_ptr() for _,output in retained})==2,'retained graphs share an output allocation')
            require(self.profile_attempts==0 and not self.tuner.is_tuning_mode,'unexpected tuning or profiling')
            require(not self.tuner._winner_cache() and not self.tuner._file_configs,'forced cache scope leaked')
            require({name:self.tensor_sha(value) for name,value in
                     [('input',self.input),('weight',self.weight),('input_scale',self.sa),('weight_scale',self.sb)]} == self.read_hashes,
                    'serving operand bytes were not restored')
        explicit=[r for r in self.result['native_calls'] if r['api']=='bmm_fp8_run_with_descriptor' and not r['stage'].startswith('descriptor_probe_')]
        require(explicit and all(r['used_descriptor']==1 for r in explicit),'accepted public descriptor path lost native acceptance')
        self.result['profile_attempts']=self.profile_attempts
        self.result['limits']=[
            'Correctness/provider qualification only; no startup search, natural winner, latency or serving-performance claim.',
            'All graph replays use original captured allocations and include actual SGLang static quantization plus BMM.',
            'Native forwarding observation preserves actual return values; it is instrumentation, not an uninstrumented benchmark.',
            'AlgoCheck acceptance is established through actual native used_descriptor1 with the exact verified implementation; API-call counts are not claimed.',
            'No fresh-process persistence, broad shapes/backends, BF16 numerics, distributed behavior, managed store or policy-routing qualification.',
            'Separate official-harness refresh and retained/synthesized setup processes remain separate required gates.',
        ]
        self.result['status']='passed'


def main():
    args=parse_args()
    require(not args.output.exists(),'refusing to overwrite qualification evidence')
    for name in ('source','candidate_manifest','port_manifest','preflight_helper','sglang_root','fixture','fixture_manifest'):
        setattr(args,name,getattr(args,name).resolve())
    result={'schema_version':1,'status':'incomplete','source_commit':PIN,'worker_sha256':sha(__file__),
            'pid':os.getpid(),'arguments':{key:str(value) if isinstance(value,Path) else value for key,value in vars(args).items()},
            'native_calls':[],'selections':[],'descriptor_probes':[],'correctness':[],'graphs':[],'forbidden_profile_stages':[]}
    experiment=Qualification(args,result)
    try:
        import torch
        with torch.inference_mode():
            experiment.run()
    except Exception as error:
        result.update(status='failed',failure_stage=experiment.stage,error=f'{type(error).__name__}: {error}',traceback=traceback.format_exc(),
                      profile_attempts=experiment.profile_attempts)
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'status':result['status'],'output':str(args.output),'sha256':sha(args.output)}))
    return 0 if result['status']=='passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
