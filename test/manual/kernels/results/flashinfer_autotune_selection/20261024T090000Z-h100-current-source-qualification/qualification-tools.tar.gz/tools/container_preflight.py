"""Scratch-only source import/provider gate; never launches a numerical study."""
from __future__ import annotations
import argparse,ast,hashlib,importlib,importlib.metadata as md,json,os,platform,shutil,subprocess,sys,traceback
from pathlib import Path
from types import SimpleNamespace
PIN='27c62fdf0ab1cd4014df8a15b66a975541fda83c'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def command(argv):
 try:
  r=subprocess.run(argv,text=True,capture_output=True,timeout=30)
  return {'argv':argv,'returncode':r.returncode,'stdout':r.stdout,'stderr':r.stderr}
 except Exception as e:return {'argv':argv,'exception':repr(e)}
def prepare_data_links(source):
 # Execute only the exact official packaging function, never the install backend.
 file=source/'build_backend.py';tree=ast.parse(file.read_text())
 node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_create_data_dir')
 ns={'_root':source,'_data_dir':source/'flashinfer/data','shutil':shutil}
 exec(compile(ast.Module(body=[node],type_ignores=[]),str(file),'exec'),ns)
 ns['_create_data_dir'](use_symlinks=True)
 return {'file_sha256':digest(file),'function':'_create_data_dir','metadata_generated':False}
def inventory(source):
 from packaging.requirements import Requirement
 requirements=[]
 for line in (source/'requirements.txt').read_text().splitlines():
  line=line.split('#',1)[0].strip()
  if not line:continue
  req=Requirement(line)
  try:version=md.version(req.name)
  except md.PackageNotFoundError:version=None
  requirements.append({'requirement':line,'installed':version,'satisfied':version is not None and req.specifier.contains(version,prereleases=True)})
 wanted=('flashinfer-python','flashinfer-jit-cache','flashinfer-cubin','apache-tvm-ffi','torch','nvidia-cublas-cu13','nvidia-cuda-runtime-cu13','nvidia-cutlass-dsl','nvidia-cudnn-frontend')
 packages=[]
 for name in wanted:
  try:
   d=md.distribution(name);packages.append({'name':name,'version':d.version,'location':str(d.locate_file('')),'requires':d.requires})
  except md.PackageNotFoundError:packages.append({'name':name,'version':None})
 return {'python':sys.version,'platform':platform.platform(),'packages':packages,'requirements':requirements,'nvcc':command([shutil.which('nvcc') or '/usr/local/cuda/bin/nvcc','--version']),'cxx':command([os.environ.get('CXX','c++'),'--version']),'ninja':command([shutil.which('ninja') or 'ninja','--version']),'environment':{k:os.environ.get(k) for k in ('PYTHONPATH','FLASHINFER_CUDA_ARCH_LIST','FLASHINFER_WORKSPACE_BASE','FLASHINFER_DISABLE_VERSION_CHECK','FLASHINFER_DISABLE_JIT','CUDA_HOME','LD_PRELOAD')}}
def check_source(source,manifest_path,variant):
 manifest=json.loads(manifest_path.read_text());assert manifest['base_commit']==PIN
 record=next(x for x in manifest['candidates'] if x['name']==variant)
 assert not (source/'flashinfer/_build_meta.py').exists(),'Do not reuse image or fabricated build metadata'
 observed={}
 critical=['flashinfer/autotuner/autotuner.py','flashinfer/autotune_cache.py','flashinfer/autotuner/_graph_timing.py','flashinfer/jit/env.py','flashinfer/jit/core.py','flashinfer/jit/cpp_ext.py','flashinfer/jit/gemm/core.py','flashinfer/tllm_utils.py','flashinfer/jit/tllm_utils.py','build_backend.py','requirements.txt','version.txt']
 base=json.loads((manifest_path.parent/'complete-source-manifest.json').read_text())
 hashes={x['path']:x['sha256'] for x in base['files']}
 hashes.update({x['path']:x['candidate_sha256'] for x in record['tracked_changes']})
 for rel in set(critical)|{x['path'] for x in record['tracked_changes']}:
  got=digest(source/rel);assert got==hashes[rel],f'source mismatch: {rel}';observed[rel]=got
 for name,rel in [('csrc','csrc'),('include','include'),('cutlass','3rdparty/cutlass'),('cccl','3rdparty/cccl'),('spdlog','3rdparty/spdlog')]:
  p=source/'flashinfer/data'/name;assert p.is_symlink() and p.resolve()==(source/rel).resolve(),f'prepare data link in container: {p}'
 for rel in ('3rdparty/cutlass/include/cutlass/cutlass.h','3rdparty/cutlass/tools/util/include/cutlass/util/host_tensor.h','3rdparty/cccl/cub/cub/cub.cuh','3rdparty/cccl/libcudacxx/include/cuda/std/cstddef','3rdparty/cccl/thrust/thrust/device_vector.h','3rdparty/spdlog/include/spdlog/spdlog.h'):
  assert (source/rel).is_file(),f'missing pinned build dependency: {rel}'
 return {'source_commit':PIN,'variant':variant,'manifest_sha256':digest(manifest_path),'source_sha256':observed,'runtime_metadata':'absent; official fallback0.0.0+unknown is expected'}
def import_current(source):
 # Match both package-find roots declared by the pinned pyproject.toml.
 sys.path[:0]=[str(source),str(source/'flashinfer/experimental/b12x/_compat')]
 import flashinfer
 from flashinfer.jit import env
 assert Path(flashinfer.__file__).resolve()==source/'flashinfer/__init__.py'
 assert flashinfer.__version__=='0.0.0+unknown' and flashinfer.__git_commit__=='unknown'
 files={}
 for name,module in sys.modules.items():
  if name not in ('flashinfer','b12x') and not name.startswith(('flashinfer.','b12x.')):continue
  file=getattr(module,'__file__',None)
  if not file:continue
  p=Path(file).resolve();assert p.is_relative_to(source),f'mixed FlashInfer source: {name}={p}'
  files[name]={'path':str(p),'sha256':digest(p)}
 providers=[]
 for item in env.FLASHINFER_AOT_PROVIDERS:
  providers.append({'id':item.provider_id,'distribution':item.distribution,'version':item.version,'path':str(item.jit_cache_dir),'architectures':sorted(item.cuda_architectures),'modules':sorted(item.modules)})
 shim=sys.modules.get('flashinfer_jit_cache');cubin=sys.modules.get('flashinfer_cubin')
 def external(m):
  if m is None:return None
  p=Path(m.__file__).resolve();return {'path':str(p),'sha256':digest(p),'version':getattr(m,'__version__',None)}
 return {'flashinfer_runtime_version':flashinfer.__version__,'flashinfer_runtime_commit':flashinfer.__git_commit__,'source_modules':files,'aot_providers':providers,'provider_shim':external(shim),'cubin_package':external(cubin),'cubin_dir':str(env.FLASHINFER_CUBIN_DIR),'gemm_aot_artifacts':[{'path':str(a.path),'provider':a.provider_id} for a in env.get_aot_artifacts('gemm')],'trtllm_utils_aot_artifacts':[{'path':str(a.path),'provider':a.provider_id} for a in env.get_aot_artifacts('trtllm_utils')]}
def explicit_native_build(source, *, native_module_callback=None):
 import torch,tvm_ffi
 from flashinfer.gemm import gemm_base
 import flashinfer.tllm_utils as tllm
 from flashinfer.jit.tllm_utils import gen_trtllm_utils_module
 assert torch.__version__=='2.14.1+cu130' and torch.version.cuda=='13.0'
 assert gemm_base.get_gemm_module.cache_info().currsize==0
 assert tllm.get_trtllm_utils_module.cache_info().currsize==0
 specs=[('gemm',gemm_base.gen_gemm_module(),('bmm_fp8','bmm_fp8_get_algos','bmm_fp8_run_with_descriptor')),('trtllm_utils',gen_trtllm_utils_module(),('delay_kernel',))]
 built={};modules={}
 for name,spec,exports in specs:
  assert spec.name==name
  assert all(Path(p).resolve().is_relative_to(source) for p in spec.sources)
  spec.build(verbose=True,need_lock=True)
  # Explicit JIT path bypasses try_load/AOT lookup even when old providers exist.
  native=spec.load(spec.jit_library_path)
  assert all(hasattr(native,x) for x in exports),f'missing exports: {name}'
  built[name]={'library_path':str(spec.jit_library_path),'library_sha256':digest(spec.jit_library_path),'ninja_path':str(spec.ninja_path),'ninja_sha256':digest(spec.ninja_path),'sources':{str(p):digest(p) for p in spec.sources},'exports_checked':exports,'linkage':command(['ldd',str(spec.jit_library_path)]),'compile_commands':spec.get_compile_commands()}
  bound=native if native_module_callback is None else native_module_callback(name,spec,native)
  assert all(hasattr(bound,x) for x in exports),f'callback removed native exports: {name}'
  built[name]['qualification_callback_invoked']=native_module_callback is not None
  modules[name]=bound
 # One-time test bootstrap, as in prior qualification. No source file or timer changes.
 gemm_base.gen_gemm_module=lambda:SimpleNamespace(build_and_load=lambda:modules['gemm'])
 tllm.gen_trtllm_utils_module=lambda:SimpleNamespace(build_and_load=lambda:modules['trtllm_utils'])
 gemm_base.get_gemm_module();assert tllm.get_trtllm_utils_module() is modules['trtllm_utils']
 return {'providers':built,'tvm_ffi_file':str(Path(tvm_ffi.__file__).resolve()),'tvm_ffi_sha256':digest(tvm_ffi.__file__),'binding':'one-time explicit native provider bootstrap; original decorated public FP8 API and runner code retained','limits':'No actual BMM/default/descriptor call, device numerics, graph, timing or study qualified.'}
def main():
 p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--manifest',type=Path,required=True);p.add_argument('--variant',choices=('fp8-runtime','fp8-runtime-callback'),required=True);p.add_argument('--phase',choices=('inventory','import','build'),required=True);p.add_argument('--prepare-data-links',action='store_true');p.add_argument('--output',type=Path,required=True);a=p.parse_args();source=a.source.resolve()
 r={'schema_version':1,'phase':a.phase,'pid':os.getpid(),'status':'incomplete','executed_by_this_file':True}
 try:
  if a.prepare_data_links:r['packaging_preparation']=prepare_data_links(source)
  r['source']=check_source(source,a.manifest,a.variant);r['inventory']=inventory(source)
  if a.phase in ('import','build'):r['import']=import_current(source)
  if a.phase=='build':r['native']=explicit_native_build(source)
  r['status']='passed'
 except Exception as e:r['error']=repr(e);r['traceback']=traceback.format_exc()
 a.output.parent.mkdir(parents=True,exist_ok=True);a.output.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({'status':r['status'],'output':str(a.output),'sha256':digest(a.output)}));return 0 if r['status']=='passed' else 1
if __name__=='__main__':raise SystemExit(main())
