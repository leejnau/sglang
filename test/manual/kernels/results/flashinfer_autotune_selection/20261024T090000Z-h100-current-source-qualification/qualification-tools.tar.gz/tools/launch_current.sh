#!/usr/bin/env bash
# Four fresh containers, one bounded source/provider/correctness qualification.
set -euo pipefail
study_dir=$(realpath "${1:?usage: launch_current.sh STUDY_DIR SGLANG_COMMIT ATTEMPT}")
source_commit=${2:?frozen SGLang source commit required}
attempt=${3:?unique attempt required}
[[ "$source_commit" =~ ^[0-9a-f]{40}$ && "$attempt" =~ ^[a-zA-Z0-9_-]+$ ]] || exit 1
image=lmsysorg/sglang@sha256:c1f4d9fc6fcf50c2269adbc757ce7b1778883af04155edb888fa9eea3b6648c0
source_dir="$study_dir/source"
input_dir="$study_dir/input/current"
results_dir="$study_dir/results/current-source-qualification/$attempt"
runtime_dir="$study_dir/runtime-current-$attempt"
container_results="/study/results/current-source-qualification/$attempt"
container_runtime="/study/runtime-current-$attempt"
active_cid_file=
active_name=
results_created=0
started_seconds=$SECONDS
cleanup() {
    local code=$? cid actual_name
    trap - EXIT
    if [[ -n "$active_cid_file" && -f "$active_cid_file" ]]; then
        cid=$(cat "$active_cid_file")
        if [[ "$cid" =~ ^[0-9a-f]{64}$ ]]; then
            actual_name=$(docker inspect --format '{{.Name}}' "$cid" 2>/dev/null || true)
            if [[ "$actual_name" == "/$active_name" ]]; then docker rm -f "$cid" >/dev/null 2>&1 || true; fi
        fi
    fi
    if [[ "$results_created" == 1 ]]; then
        if [[ -d "$runtime_dir/cache" ]]; then
            cp -a "$runtime_dir/cache" "$results_dir/native-build-cache" || code=1
        fi
        git -C "$source_dir" rev-parse HEAD > "$results_dir/sglang-commit-after.txt" 2>&1 || code=1
        git -C "$source_dir" status --porcelain > "$results_dir/sglang-status-after.txt" 2>&1 || code=1
        [[ "$(cat "$results_dir/sglang-commit-after.txt")" == "$source_commit" && ! -s "$results_dir/sglang-status-after.txt" ]] || code=1
        nvidia-smi --query-gpu=index,name,uuid,driver_version,pstate,clocks.sm,clocks.mem,power.limit,temperature.gpu,memory.total,memory.used --format=csv > "$results_dir/gpu-after.csv" 2>&1 || code=1
        printf '%s\n' "$((SECONDS-started_seconds))" > "$results_dir/elapsed-seconds.txt"
        printf '%s\n' "$code" > "$results_dir/launcher.exit-code"
    fi
    exit "$code"
}
trap cleanup EXIT
trap 'exit 143' TERM
trap 'exit 130' INT
[[ "$(git -C "$source_dir" rev-parse HEAD)" == "$source_commit" && -z "$(git -C "$source_dir" status --porcelain)" ]] || exit 1
[[ ! -e "$results_dir" && ! -e "$runtime_dir" ]] || exit 1
[[ -f "$input_dir/manifests/execution-manifest.json" ]] || exit 1
mkdir -p "$results_dir"
results_created=1
mkdir -p "$runtime_dir/home" "$runtime_dir/cache/current"
cp -a "$study_dir/fixture" "$results_dir/fixture"
printf '%s\n' "$source_commit" > "$results_dir/sglang-commit-before.txt"
cp "$input_dir/manifests/execution-manifest.json" "$results_dir/execution-manifest.json"
docker image inspect "$image" | python3 -c '
import json,sys
x=json.load(sys.stdin)[0];assert x["Architecture"]=="amd64" and x["Os"]=="linux"
assert "lmsysorg/sglang@sha256:c1f4d9fc6fcf50c2269adbc757ce7b1778883af04155edb888fa9eea3b6648c0" in x["RepoDigests"]
print(json.dumps({k:x[k] for k in ("Id","RepoDigests","Created","Architecture","Os","Size")},indent=2))
' > "$results_dir/image.json"
nvidia-smi --query-gpu=index,name,uuid,driver_version,pstate,clocks.sm,clocks.mem,power.limit,temperature.gpu,memory.total,memory.used --format=csv > "$results_dir/gpu-before.csv"
nvidia-smi --query-compute-apps=pid,process_name,used_gpu_memory --format=csv,noheader > "$results_dir/gpu-processes-before.csv"
[[ ! -s "$results_dir/gpu-processes-before.csv" ]] || exit 1
lscpu -J > "$results_dir/host-cpu.json"
python3 - "$input_dir" "$results_dir" "$source_commit" "${BASH_SOURCE[0]}" <<'PY'
import ast,csv,hashlib,json,sys
from pathlib import Path
inputs,results=map(Path,sys.argv[1:3]);commit=sys.argv[3];launcher=Path(sys.argv[4]).resolve()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=json.loads((inputs/'manifests/execution-manifest.json').read_text())
assert spec['schema_version']==1 and spec['sglang_source_commit']==commit
assert spec['flashinfer_source_commit']=='27c62fdf0ab1cd4014df8a15b66a975541fda83c'
assert spec['image']=='lmsysorg/sglang@sha256:c1f4d9fc6fcf50c2269adbc757ce7b1778883af04155edb888fa9eea3b6648c0'
required={'tools/container_preflight.py','tools/qualify_cuda.py','tools/run_harness.py','tools/test_output_refresh.py','tools/adapter/sglang_captured_fixture.py','tools/adapter/adapter-contract.json','tools/launch_current.sh','manifests/candidate-manifest.json','manifests/complete-source-manifest.json','manifests/dependency-manifest.json','manifests/cutlass-source-manifest.json','manifests/cccl-source-manifest.json','manifests/spdlog-source-manifest.json','manifests/port-manifest.json','patches/fp8-current-main.patch','patches/harness-only.patch'}
assert required <= spec['files_sha256'].keys()
observed={}
for rel,expected in spec['files_sha256'].items():
    p=Path(rel);assert not p.is_absolute() and '..' not in p.parts
    actual=sha(inputs/p);assert actual==expected,rel;observed[rel]=actual
assert sha(launcher)==observed['tools/launch_current.sh']
assert observed['tools/container_preflight.py']=='b8d0f6bbc85eaca0e3ef1419ab99a97d5340c96b3da382cba81d7896768287ba'
assert observed['manifests/candidate-manifest.json']=='7c68529cfcb89ab47f1cae5f08ee3187626c0a6f2dadac3e6c4f862f42ded974'
assert observed['manifests/port-manifest.json']=='1ac5a30bb27519322e067b17f796a243bcec76814925a40c703797cfdfe31f14'
assert sha(results/'fixture/manifest.json')=='e13a86fab5db5796b22d8dab0f84080b8057b036ca7aef2c7be8832e76505bf1'
assert sha(results/'fixture/fixture.safetensors')=='c30aa761eba827bb0b4eb6de0e99d9b8dda8243dd16d00146f9718d2abb05e8b'
base=json.loads((inputs/'manifests/complete-source-manifest.json').read_text())
assert base['upstream_commit']==spec['flashinfer_source_commit'] and base['tracked_blobs_verified']==11671
candidate=json.loads((inputs/'manifests/candidate-manifest.json').read_text())
variant=next(x for x in candidate['candidates'] if x['name']=='fp8-runtime-callback')
for row in variant['tracked_changes']:assert sha(inputs/'source'/row['path'])==row['candidate_sha256'],row['path']
# Derive concrete synthesis endpoints from the exact pinned production helper.
utils=inputs/'source/flashinfer/fused_moe/utils.py'
assert sha(utils)==next(x['sha256'] for x in base['files'] if x['path']=='flashinfer/fused_moe/utils.py')
module=ast.parse(utils.read_text());nodes=[]
for node in module.body:
    if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id.startswith('_PHASE') for t in node.targets):nodes.append(node)
    if isinstance(node,ast.FunctionDef) and node.name=='get_hybrid_num_tokens_buckets':nodes.append(node)
namespace={'List':list,'Tuple':tuple}
exec(compile(ast.Module(body=nodes,type_ignores=[]),str(utils),'exec'),namespace)
expected_synth_ms=list(namespace['get_hybrid_num_tokens_buckets'](144))
assert expected_synth_ms==[1,2,4,8,16,32,64,128,144]
assert not (inputs/'source/flashinfer/_build_meta.py').exists()
assert not (inputs/'source/flashinfer/data').exists(),'native gate must own the one data-link preparation'
gpu=[{k.strip():v.strip() for k,v in r.items()} for r in csv.DictReader((results/'gpu-before.csv').open())]
assert len(gpu)==1 and gpu[0]['name']=='NVIDIA H100 NVL'
assert gpu[0]['uuid']=='GPU-240958a2-e8e1-3bac-b767-365c9e0b97bd' and gpu[0]['driver_version']=='580.159.04'
assert float(gpu[0]['power.limit [W]'].split()[0])==310.0 and int(gpu[0]['memory.used [MiB]'].split()[0])==0
(results/'input-preflight.json').write_text(json.dumps({'status':'passed','execution_manifest_sha256':sha(inputs/'manifests/execution-manifest.json'),'files_sha256':observed,'source_commit':spec['flashinfer_source_commit'],'source_variant':'fp8-runtime-callback','expected_synthesized_profile_ms':expected_synth_ms,'synthesis_helper_sha256':sha(utils),'source_version_metadata':'Absent generated metadata: official 0.0.0+unknown/unknown fallback; exact commit is established by manifests.','gpu':gpu[0]},indent=2)+'\n')
PY
run_gate() {
    local name=$1 limit=$2 writable=$3 remaining budget code
    shift 3
    remaining=$((1800-(SECONDS-started_seconds)))
    (( remaining>0 )) || return 124
    budget=$limit
    (( budget<=remaining )) || budget=$remaining
    mkdir -p "$runtime_dir/home/$name"
    active_name="fi-current-${attempt}-$name"
    active_cid_file="$results_dir/$name.container-id"
    local input_mount="type=bind,source=$input_dir,target=/study/input/current"
    [[ "$writable" == yes ]] || input_mount="$input_mount,readonly"
    if timeout --kill-after=15s "$budget" docker run --name "$active_name" --cidfile "$active_cid_file" \
        --rm --gpus all --user "$(id -u):$(id -g)" --network none \
        --mount "type=bind,source=$source_dir,target=/workspace,readonly" \
        --mount "$input_mount" \
        --mount "type=bind,source=$results_dir,target=$container_results" \
        --mount "type=bind,source=$runtime_dir,target=$container_runtime" \
        --env PYTHONNOUSERSITE=1 --env PYTHONDONTWRITEBYTECODE=1 --env SGLANG_RUST_BUILD_MODE=never \
        --env CUDA_VISIBLE_DEVICES=0 --env FLASHINFER_AUTOTUNER_LOAD_FROM_FILE=0 \
        --env FLASHINFER_CUDA_ARCH_LIST=9.0 --env MAX_JOBS=4 --env LD_PRELOAD= \
        --env "HOME=$container_runtime/home/$name" \
        --env "PYTHONPATH=/study/input/current/tools:/study/input/current/tools/adapter:/workspace/python" \
        --env "FLASHINFER_WORKSPACE_BASE=$container_runtime/cache/current" \
        --env "XDG_CACHE_HOME=$container_runtime/cache/xdg" \
        --env "CUDA_CACHE_PATH=$container_runtime/cache/cuda" \
        --env "TRITON_CACHE_DIR=$container_runtime/cache/triton" \
        --env "TORCHINDUCTOR_CACHE_DIR=$container_runtime/cache/inductor" \
        --workdir /workspace --entrypoint /opt/sglang/bin/python "$image" "$@" \
        > "$results_dir/$name.log" 2>&1; then
        printf '0\n' > "$results_dir/$name.exit-code"
    else
        code=$?; printf '%s\n' "$code" > "$results_dir/$name.exit-code"
        cat "$results_dir/$name.log"; return "$code"
    fi
    active_cid_file=
    active_name=
    if python3 - "$results_dir" "$name" > "$results_dir/$name.gate.log" 2>&1 <<'PY'
import hashlib,json,math,sys
from pathlib import Path
root=Path(sys.argv[1]);name=sys.argv[2];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=root/(name+'.json');r=json.loads(p.read_text())
if name=='native-facade':
    assert r['status']=='passed' and r['source_commit']=='27c62fdf0ab1cd4014df8a15b66a975541fda83c'
    assert r['profile_attempts']==0 and len(r['graphs'])==2 and all(x['passed'] for x in r['correctness'])
    assert r['selected_control_descriptor']!=-1
    native=r['native'];pid=r['pid']
else:
    b=json.loads(p.with_suffix('.bootstrap.json').read_text());assert b['status']=='passed'
    assert b['source']['variant']=='fp8-runtime-callback'
    native=b['native'];pid=b['pid']
    if name=='callback-controls':
        assert r['status']=='success' and len(r['cases'])==6 and len(r['unsafe_roles'])==4
        assert all(x['accepted']==x['expected'] for x in r['cases'])
    else:
        mode='retained' if name=='retained-auto' else 'synthesized'
        assert r['profile_inputs']==mode and len(r['trials'])==1 and r['reference']=='fixture reference and untuned default'
        row=r['trials'][0]
        assert row['policy']=='auto' and row['seed']==19 and row['cache_hit'] and row['numerics']=='passed'
        assert row['profile_count']==len(row['measurements'])>0
        assert r['validation']['output_refresh']=='fixture_callback'
        assert r['validation']['rounds']==2 and r['validation']['replays']==16 and r['validation']['prequeue_cycles']==10000000
        assert r['arguments']['cold_l2'] is None and r['arguments']['graph_policies']==['auto']
        groups={};ms=set()
        for x in row['measurements']:
            assert not x['use_cuda_graph'] and not x['cold_l2'] and x['warmup']==3 and x['repeat']==10
            key=repr(x['input_shapes']);groups.setdefault(key,[]).append(x);ms.add(x['input_shapes'][0][-2])
        expected_ms={144} if mode=='retained' else set(json.loads((root/'input-preflight.json').read_text())['expected_synthesized_profile_ms'])
        assert ms==expected_ms
        assert row['input_shapes'][0][-2]==144 and row['cache_profile'][0][-2]==(144 if mode=='retained' else 256)
        assert all(any(x['tactic']=='-1' and x['ms'] is not None and math.isfinite(x['ms']) and x['ms']>0 for x in group) for group in groups.values())
        assert r['flashinfer']=='0.0.0+unknown'
        for samples in row['validation_ms'].values():assert len(samples)==2 and all(math.isfinite(x) and x>0 for x in samples)
        assert (root/(name+'.fixture-provenance.json')).is_file()
    prior=json.loads((root/'native-facade.json').read_text())['native']
    for provider in ('gemm','trtllm_utils'):
        assert native['providers'][provider]['library_sha256']==prior['providers'][provider]['library_sha256']
        assert native['providers'][provider]['ninja_sha256']==prior['providers'][provider]['ninja_sha256']
for provider in ('gemm','trtllm_utils'):
    assert native['providers'][provider]['library_sha256'] and native['providers'][provider]['ninja_sha256']
cid=(root/(name+'.container-id')).read_text().strip();assert len(cid)==64 and all(c in '0123456789abcdef' for c in cid)
(root/(name+'.gate.json')).write_text(json.dumps({'status':'passed','container_id':cid,'container_pid':pid,'result_sha256':sha(p),'scope':'Native gate establishes its accepted control descriptor only; setup smokes establish API/cache/numerics, not selected-descriptor acceptance or performance.'},indent=2)+'\n')
PY
    then
        printf '0\n' > "$results_dir/$name.gate.exit-code"
    else
        code=$?; printf '%s\n' "$code" > "$results_dir/$name.gate.exit-code"
        cat "$results_dir/$name.gate.log"; return "$code"
    fi
}
run_gate native-facade 900 yes /study/input/current/tools/qualify_cuda.py \
    --source /study/input/current/source --candidate-manifest /study/input/current/manifests/candidate-manifest.json \
    --port-manifest /study/input/current/manifests/port-manifest.json --preflight-helper /study/input/current/tools/container_preflight.py \
    --variant fp8-runtime-callback --sglang-root /workspace \
    --fixture "$container_results/fixture/fixture.safetensors" --fixture-manifest "$container_results/fixture/manifest.json" \
    --expected-gpu-uuid 240958a2-e8e1-3bac-b767-365c9e0b97bd --prepare-data-links --output "$container_results/native-facade.json"
run_gate callback-controls 300 no /study/input/current/tools/run_harness.py \
    --source /study/input/current/source --manifest /study/input/current/manifests/candidate-manifest.json \
    --callback-tests /study/input/current/tools/test_output_refresh.py --output "$container_results/callback-controls.json"
for mode in retained synthesized; do
    run_gate "$mode-auto" 300 no /study/input/current/tools/run_harness.py \
        --source /study/input/current/source --manifest /study/input/current/manifests/candidate-manifest.json \
        --profile-inputs "$mode" --output "$container_results/$mode-auto.json"
done
python3 - "$results_dir" <<'PY'
import hashlib,json,sys
from pathlib import Path
r=Path(sys.argv[1]);names=('native-facade','callback-controls','retained-auto','synthesized-auto')
rows=[json.loads((r/(name+'.gate.json')).read_text()) for name in names]
assert all(x['status']=='passed' for x in rows) and len({x['container_id'] for x in rows})==4
(r/'final-gate.json').write_text(json.dumps({'status':'passed','fresh_containers':4,'gates':dict(zip(names,rows)),'source':'27c62 plus FP8-only runtime port and optional validation callback; generated version metadata absent','limits':['Correctness/provider and API/cache/numerics setup only.','Native acceptance is established only for native-facade worker control descriptor. Setup-selected descriptors may fall back; no acceptance or performance claim for them.','Before a real comparison, observe each selected native descriptor acceptance outside timing.']},indent=2)+'\n')
PY
