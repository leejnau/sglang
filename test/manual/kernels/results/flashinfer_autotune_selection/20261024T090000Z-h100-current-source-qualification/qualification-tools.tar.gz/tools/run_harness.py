"""Run one frozen harness setup gate after explicit current native loading."""

from __future__ import annotations

import argparse
import json
import os
import runpy
import sys
import traceback
from pathlib import Path

import container_preflight as provider


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--profile-inputs", choices=("retained", "synthesized"))
    parser.add_argument("--callback-tests", type=Path)
    args = parser.parse_args()
    if (args.profile_inputs is None) == (args.callback_tests is None):
        parser.error("choose exactly one setup gate")
    source = args.source.resolve()
    output = args.output.resolve()
    bootstrap_path = output.with_suffix(".bootstrap.json")
    if output.exists() or bootstrap_path.exists():
        raise FileExistsError("refusing to overwrite a qualification attempt")
    output.parent.mkdir(parents=True, exist_ok=True)
    record = {"status": "incomplete", "pid": os.getpid(), "phase": "bootstrap"}
    try:
        record["source"] = provider.check_source(
            source, args.manifest, "fp8-runtime-callback"
        )
        record["import"] = provider.import_current(source)
        record["native"] = provider.explicit_native_build(source)
        import torch

        torch.backends.cuda.matmul.allow_tf32 = False
        record["reference_allow_tf32"] = torch.backends.cuda.matmul.allow_tf32
        record["phase"] = "callback-tests" if args.callback_tests else "harness"
        bootstrap_path.write_text(json.dumps(record, indent=2) + "\n")
        harness = source / "benchmarks/bench_autotuner_accuracy.py"
        if args.callback_tests:
            sys.argv = [
                str(args.callback_tests),
                "--harness",
                str(harness),
                "--output",
                str(output),
            ]
            runpy.run_path(str(args.callback_tests), run_name="__main__")
        else:
            sys.argv = [
                str(harness),
                "--graph-selection-study",
                "--fixture",
                "sglang_captured_fixture:build",
                "--profile-inputs",
                args.profile_inputs,
                "--graph-policies",
                "auto",
                "--seeds",
                "1",
                "--seed",
                "19",
                "--warmup",
                "3",
                "--tuner-repeat",
                "10",
                "--oracle-rounds",
                "2",
                "--validation-replays",
                "16",
                "--prequeue-cycles",
                "10000000",
                "--rtol",
                "0.02",
                "--atol",
                "0.125",
                "--out",
                str(output),
            ]
            # Omitting cold-L2 retains the literal unspecified policy identity.
            record["harness_argv"] = list(sys.argv)
            runpy.run_path(str(harness), run_name="__main__")
        record["status"] = "passed"
    except SystemExit as exc:
        if exc.code not in (None, 0):
            record["status"] = "failed"
            record["error"] = repr(exc)
        else:
            record["status"] = "passed"
    except Exception as exc:
        record["status"] = "failed"
        record["error"] = repr(exc)
        record["traceback"] = traceback.format_exc()
    if record["status"] == "passed" and not output.is_file():
        record.update(status="failed", error="gate returned without result file")
    if output.is_file():
        record["result_sha256"] = provider.digest(output)
    bootstrap_path.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"status": record["status"], "output": str(output)}))
    return 0 if record["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
