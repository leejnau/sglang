"""Prove the narrow output-refresh fix using actual CPU inference tensors."""

from __future__ import annotations

import ast
import hashlib
import json
import subprocess
import tempfile
from pathlib import Path

ROOT = Path("/private/tmp/fi-next-steps-20261024")
HERE = Path(__file__).resolve().parent
LOADER = ROOT / "fixture-validation-callback/check_callback.py"
OLD = ROOT / "fixture-validation-callback/benchmarks/bench_autotuner_accuracy.py"
NEW = HERE / "benchmarks/bench_autotuner_accuracy.py"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


namespace = {"__file__": str(LOADER), "__name__": "inference_refresh_boundaries"}
exec(
    compile(
        LOADER.read_text().split("with contextlib.ExitStack() as boundaries:", 1)[0],
        str(LOADER),
        "exec",
    ),
    namespace,
)
torch, load = namespace["torch"], namespace["load"]
old, new = load(OLD, "old_refresh"), load(NEW, "new_refresh")
checks = []


def check(condition, label):
    if not condition:
        raise AssertionError(label)
    checks.append(label)


def helper(path):
    return next(
        node
        for node in ast.parse(path.read_text()).body
        if isinstance(node, ast.FunctionDef) and node.name == "prepare_fp8_validation"
    )


before, after = helper(OLD), helper(NEW)
check(
    [ast.dump(node) for node in before.body[:-1]]
    == [ast.dump(node) for node in after.body[:-1]],
    "all role and ownership guard ASTs remain unchanged",
)
check(
    isinstance(after.body[-1], ast.With)
    and len(after.body[-1].body) == 1
    and ast.dump(after.body[-1].body[0]) == ast.dump(before.body[-1]),
    "only the original fill is inside the added inference context",
)


def problem(inference, kind="valid"):
    with torch.inference_mode(inference):
        output = torch.ones(
            4, dtype=torch.int64 if kind == "integer" else torch.float32
        )
        inputs = [
            torch.ones(4),
            torch.ones(4),
            torch.ones(1),
            torch.ones(1),
            output,
            torch.empty(8, dtype=torch.uint8),
        ]
        if kind == "read_alias":
            inputs[0] = output
        elif kind == "scratch_alias":
            inputs[5] = output
        elif kind == "wrong_role":
            inputs[4] = torch.ones_like(output)
    return output, inputs


positive = []
unsafe = []
for inference in (False, True):
    output, inputs = problem(inference)
    check(
        not torch.is_inference_mode_enabled(),
        "old helper invoked outside inference mode",
    )
    try:
        old.prepare_fp8_validation(output, inputs)
    except RuntimeError as error:
        check(
            inference and "InferenceMode" in str(error),
            "old helper fails for inference output",
        )
        old_result = "RuntimeError: inference tensor update outside InferenceMode"
    else:
        check(not inference, "old helper only admits the normal output control")
        old_result = "passed"
    output, inputs = problem(inference)
    pointer = output.data_ptr()
    reads = [tensor.clone() for tensor in inputs[:4]]
    new.prepare_fp8_validation(output, inputs)
    check(torch.isnan(output).all().item(), "new helper refreshes the admitted output")
    check(
        output.is_inference() == inference and output.data_ptr() == pointer,
        "output allocation retained",
    )
    check(
        not torch.is_inference_mode_enabled(),
        "new helper restores caller inference state",
    )
    check(
        all(torch.equal(a, b) for a, b in zip(reads, inputs[:4])),
        "new helper preserves reads",
    )
    with torch.inference_mode():
        output.fill_(2)
    torch.testing.assert_close(output, torch.full_like(output, 2))
    check(True, "real correct write under inference mode remains valid")
    new.prepare_fp8_validation(output, inputs)
    try:
        torch.testing.assert_close(output, torch.full_like(output, 2))
    except AssertionError:
        check(True, "no-write leaves poison and is rejected")
    else:
        raise AssertionError("no-write output was accepted")
    positive.append(
        {
            "inference_allocation": inference,
            "old_helper": old_result,
            "new_helper": "passed",
        }
    )

    for kind in ("read_alias", "scratch_alias", "integer", "wrong_role"):
        for name, module in (("old", old), ("new", new)):
            output, inputs = problem(inference, kind)
            snapshot = [tensor.clone() for tensor in [output, *inputs]]
            try:
                module.prepare_fp8_validation(output, inputs)
            except ValueError:
                pass
            else:
                raise AssertionError("unsafe role admitted: " + kind)
            check(
                all(torch.equal(a, b) for a, b in zip(snapshot, [output, *inputs])),
                "unsafe role rejected before mutation",
            )
            check(
                not torch.is_inference_mode_enabled(),
                "unsafe rejection preserves caller inference state",
            )
            unsafe.append(
                {
                    "helper": name,
                    "inference_allocation": inference,
                    "kind": kind,
                    "rejected_before_mutation": True,
                }
            )

with tempfile.TemporaryDirectory(prefix="fi-refresh-revision02-apply-") as folder:
    root = Path(folder)
    target = root / "benchmarks/bench_autotuner_accuracy.py"
    target.parent.mkdir()
    target.write_bytes(
        (
            ROOT / "measurement-source/benchmarks/bench_autotuner_accuracy.py"
        ).read_bytes()
    )
    subprocess.run(
        ["git", "apply", str(HERE / "harness-only.patch")], cwd=root, check=True
    )
    check(
        target.read_bytes() == NEW.read_bytes(),
        "patch against pinned original reproduces exact new harness",
    )

result = {
    "status": "success",
    "checks": len(checks),
    "passed_checks": checks,
    "script_sha256": sha(__file__),
    "loader_sha256": sha(LOADER),
    "old_harness_sha256": sha(OLD),
    "new_harness_sha256": sha(NEW),
    "harness_patch_sha256": sha(HERE / "harness-only.patch"),
    "torch": torch.__version__,
    "outside_inference_mode_cases": positive,
    "unsafe_role_controls": unsafe,
    "limits": [
        "Actual CPU inference tensors and unchanged whole harness modules execute; GPU-only import boundaries use the disclosed existing loader.",
        "No CUDA capture, device timing, descriptor execution or SGLang GPU call is qualified by these controls.",
        "The fix changes only the ownership-validated output fill context, with no guard or timing placement changes.",
    ],
}
(HERE / "inference-refresh-cpu-controls.json").write_text(
    json.dumps(result, indent=2) + "\n"
)
print(
    json.dumps(
        {
            "status": result["status"],
            "checks": result["checks"],
            "unsafe_role_controls": len(unsafe),
        }
    )
)
