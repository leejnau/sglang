"""Admit the revised standalone gate at explicit CPU CUDA boundaries."""

from __future__ import annotations

import contextlib
import hashlib
import importlib.util
import json
from pathlib import Path
from unittest.mock import patch

ROOT = Path("/private/tmp/fi-next-steps-20261024")
HERE = Path(__file__).resolve().parent
LOADER = ROOT / "fixture-validation-callback/check_callback.py"
WORKER = ROOT / "current-source-coordinator/revision02/test_output_refresh.py"
HARNESS = HERE / "benchmarks/bench_autotuner_accuracy.py"
namespace = {"__file__": str(LOADER), "__name__": "revision02_cuda_boundaries"}
exec(
    compile(
        LOADER.read_text().split("with contextlib.ExitStack() as boundaries:", 1)[0],
        str(LOADER),
        "exec",
    ),
    namespace,
)
torch, state = namespace["torch"], namespace["state"]
spec = importlib.util.spec_from_file_location("revision02_cuda_gate", WORKER)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
real_add, real_empty, real_ones = torch.add, torch.empty, torch.ones


def add(*args, **kwargs):
    if state.active is not None:

        def action():
            # A CUDA graph replays captured device work without re-entering
            # Python Tensor mutation admission. Preserve the runner's declared
            # inference write context at this CPU graph boundary.
            with torch.inference_mode():
                real_add(*args, **kwargs)

        state.active.actions.append(action)
        return kwargs["out"]
    return real_add(*args, **kwargs)


def cpu(function):
    def construct(*args, **kwargs):
        if kwargs.get("device") == "cuda":
            kwargs["device"] = "cpu"
        return function(*args, **kwargs)

    return construct


with contextlib.ExitStack() as stack:
    for name, value in [
        ("is_available", lambda: True),
        ("get_device_name", lambda: "CPU boundary control; actual CUDA pending"),
        ("CUDAGraph", namespace["Graph"]),
        ("graph", namespace["capture"]),
        ("Event", namespace["Event"]),
        ("synchronize", lambda: None),
        ("_sleep", lambda _: None),
        ("is_current_stream_capturing", lambda: state.active is not None),
    ]:
        stack.enter_context(patch.object(torch.cuda, name, value))
    for name, value in [
        ("add", add),
        ("empty", cpu(real_empty)),
        ("ones", cpu(real_ones)),
    ]:
        stack.enter_context(patch.object(torch, name, value))
    result = module.run(HARNESS)

assert result["status"] == "success"
assert len(result["cases"]) == 12 and len(result["unsafe_roles"]) == 4
for allocation in ("normal", "inference"):
    rows = [row for row in result["cases"] if row["allocation_mode"] == allocation]
    assert len(rows) == 6
    assert [row["accepted"] for row in rows] == [True, False, True, True, False, False]
    assert all(
        row["output_is_inference"] == (allocation == "inference") for row in rows
    )
report = {
    "status": "CPU admission passed; actual CUDA pending",
    "worker_sha256": hashlib.sha256(WORKER.read_bytes()).hexdigest(),
    "admission_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "actual_harness_source_sha256": result["harness_sha256"],
    "cases": result["cases"],
    "unsafe_role_rejections": len(result["unsafe_roles"]),
    "boundaries": [
        "Complete revised worker, whole current harness and real tuner/cache/policy execute with actual CPU inference and normal tensors.",
        "Only allocations/device queries, capture/replay, events and captured add execution use disclosed CPU CUDA boundaries. Inference write admission is preserved for the captured runner actions.",
        "Profiling times are controlled by the standalone worker as intended. No actual CUDA, native provider or GPU numerical pass is claimed.",
    ],
}
(HERE / "cuda-gate-cpu-admission.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": report["status"], "cases": 12, "unsafe_roles": 4}))
