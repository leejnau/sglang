#!/usr/bin/env python3
"""Post hoc description of fixed historical evidence; no causal/statistical refit."""
from __future__ import annotations
import argparse,collections,hashlib,json,math,re,statistics,struct
from pathlib import Path
PIN='bdcd1d9bf844022bae45652c1a7979f3fe8477bd'
RAW=Path('/private/tmp/fi-next-steps-20261024/coordinator/raw/attempt02')
SOURCE=Path('/private/tmp/fi-next-steps-20261024/coordinator/qualified-fi-source')
HERE=Path(__file__).parent

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path):return json.loads(Path(path).read_text())
def check(value,message):
 if not value:raise AssertionError(message)
def token(tactic):return 'default' if tactic==-1 else hashlib.sha256(struct.pack('<8Q',*tactic)).hexdigest()
def summary(values):return {'median':statistics.median(values),'range':[min(values),max(values)]}
def signature(event):
 args=event['args']
 return {'name':event['name'],'device':args['device'],'grid':args['grid'],'block':args['block'],
         'registers_per_thread':args['registers per thread'],'shared_memory':args['shared memory']}
def raw_trace(data,root):
 trace=data['selection_history']['post_timing_trace'];path=root/Path(trace['path']).name
 check(sha(path)==trace['sha256'],'trace hash mismatch')
 events=load(path)['traceEvents'];observed={};ids=set();capture={row['id']:row for row in data['graph_controls']['graphs']}
 trace_rows={row['graph_id']:row for row in trace['graphs']}
 for graph in ('winner','default'):
  markers=[e for e in events if e.get('cat')=='user_annotation' and e.get('name')=='retained_'+graph]
  check(len(markers)==1,'CPU marker ambiguity');marker=markers[0]
  launches=sorted([e for e in events if e.get('cat')=='cuda_runtime' and 'cudaGraphLaunch' in e.get('name','') and marker['ts']<=e['ts']<=marker['ts']+marker['dur']],key=lambda e:e['ts'])
  check(len(launches)==3,'three original-object launches required')
  sequences=[];actual_graph_ids=set()
  for launch in launches:
   kernels=sorted([e for e in events if e.get('cat')=='kernel' and e.get('args',{}).get('correlation')==launch['args']['correlation']],key=lambda e:e['ts'])
   check(len(kernels)==2,'expected quantizer and GEMM kernels per replay')
   sequences.append([signature(e) for e in kernels]);actual_graph_ids.update(e['args']['graph id'] for e in kernels)
  check(sequences[0]==sequences[1]==sequences[2] and len(actual_graph_ids)==1,'replay identity changed')
  check(capture[graph]['graph_object_id']==trace_rows[graph]['graph_object_id'] and capture[graph]['output']['data_ptr']==trace_rows[graph]['output_data_ptr'],'trace replaced original graph/output')
  gid=next(iter(actual_graph_ids));check(gid not in ids,'retained objects share actual CUDA graph ID');ids.add(gid)
  observed[graph]={'cuda_graph_id':gid,'signatures':sequences[0],'graph_object_id':capture[graph]['graph_object_id'],'output_data_ptr':capture[graph]['output']['data_ptr']}
 return {'path':str(path),'sha256':sha(path),'original_graphs':observed,'same_ordered_launch_signature':observed['winner']['signatures']==observed['default']['signatures']}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--raw-root',type=Path,default=RAW);p.add_argument('--output',type=Path,default=HERE/'posthoc-diagnostics.json');a=p.parse_args()
 files=[a.raw_root/f'trial{trial}-h{h}f{f}-timing.json' for trial in range(8) for h in range(2) for f in range(2)]
 check(all(path.is_file() for path in files),'incomplete immutable cohort')
 order=None;records=[];descriptors={};flags=collections.Counter();catalog={};trace_ids={};all_rows=[];default_descending=[];input_hashes=collections.Counter()
 for path in files:
  d=load(path);check(d['status']=='success' and d['environment']['sglang_commit']==PIN,'wrong source/status')
  check(d['profile_attempts']==81 and len(d['profiles'])==81 and not d['forbidden_profile_attempts'],'profiling cohort changed')
  profiles=d['profiles'];runtime=[row for row in profiles if row['input_shapes'][0][-2]==144]
  check(len(runtime)==9 and len({json.dumps(r['normalized_profile']) for r in runtime})==1 and runtime[0]['normalized_profile'][0][-2]==256,'wrong runtime profile domain')
  current=[token(r['tactic']) for r in runtime]
  if order is None:order=current
  check(current==order and current[0]=='default','runtime candidate order differs')
  check([i for i,r in enumerate(profiles) if r in runtime]==list(range(72,81)),'runtime profile is not last nine attempts')
  check([r['input_shapes'][0][-2] for i,r in enumerate(profiles) if i%9==0]==[1,2,4,8,16,32,64,128,144],'profile sequence changed')
  for row in profiles:
   s=row['autotuner_settings'];cfg=s['config']
   key=(row['use_cuda_graph'],row['use_cold_l2_cache'],s['warmup'],s['repeat'],s['stream_delay_micro_secs'],s['cuda_graph_delay_micro_secs'],s['use_global_timer'],json.dumps(s['effective_measure_policy']),s['effective_policy_timer'],cfg['effective_profiling_repeat'])
   flags[key]+=1
   check(row['profiler_ms'] is not None and math.isfinite(row['profiler_ms']) and row['profiler_ms']>0 and not row.get('error'),'failed/invalid historical candidate must remain visible')
  default=runtime[0];best=min(runtime[1:],key=lambda row:row['profiler_ms']);winner=min(runtime,key=lambda row:row['profiler_ms'])
  check(winner['tactic']==d['natural']['tactic'],'natural winner is not actual measured minimum')
  times=[row['profiler_ms']*1000 for row in runtime]
  prior_descriptors={token(row['tactic']) for row in profiles[:72] if row['tactic']!=-1}
  for i,row in enumerate(runtime[1:],1):
   t=token(row['tactic']);descriptors.setdefault(t,{'position_zero_based':i,'raw_words':row['tactic'],'raw64_hex':struct.pack('<8Q',*row['tactic']).hex(),'prior_smaller_M_occurrences':0})
   descriptors[t]['prior_smaller_M_occurrences']+=int(t in prior_descriptors)
  ratios=[];wall=[]
  for block in d['graph_controls']['blocks']:
   table={row['graph_id']:row for row in block['measurements']};check(set(table)=={'winner','default'},'paired block incomplete')
   ratios.append((table['winner']['gpu_event_batch_ms']/table['winner']['iterations'])/(table['default']['gpu_event_batch_ms']/table['default']['iterations']))
   wall.append((table['winner']['wall_batch_ms']/table['winner']['iterations'])/(table['default']['wall_batch_ms']/table['default']['iterations']))
  check(len(ratios)==24,'fixed paired blocks changed')
  trace=raw_trace(d,a.raw_root)
  trace_key=[]
  for graph in ('winner','default'):
   seq=trace['original_graphs'][graph]['signatures'];text=json.dumps(seq,sort_keys=True);key=hashlib.sha256(text.encode()).hexdigest();catalog[key]=seq;trace_key.append(key)
  natural=token(d['natural']['tactic']);explicit=natural!='default'
  check(trace['same_ordered_launch_signature']==(not explicit),'selected descriptor/default physical signature relation differs')
  row={'worker':path.stem,'trial':d['trial'],'cell':path.stem.split('-')[1],'result_sha256':sha(path),
       'default_runtime_profile_position':0,'global_attempt_position_zero_based':72,'default_profile_us':times[0],
       'all_candidate_profile_us_by_fixed_position':times,'best_explicit_position':runtime.index(best),
       'best_explicit_descriptor':token(best['tactic']),'best_explicit_over_default_profile':best['profiler_ms']/default['profiler_ms'],
       'winner':natural,'winner_position':runtime.index(winner),'selected_profile_advantage_fraction':1-winner['profiler_ms']/default['profiler_ms'],
       'selected_over_default_graph_event_paired_median':statistics.median(ratios),'selected_over_default_graph_wall_paired_median':statistics.median(wall),
       'winner_trace_signature':trace_key[0],'default_trace_signature':trace_key[1],
       'actual_same_ordered_launch_signature':trace['same_ordered_launch_signature'],'trace_sha256':trace['sha256'],
       'all_runtime_explicit_descriptors_new_to_this_profile_sequence':not(set(current[1:]) & prior_descriptors),
       'fingerprint_enabled':d['selection_history']['inline_fingerprinting'],'history_enabled':d['selection_history']['history_enabled']}
  if row['fingerprint_enabled']:
   group=d['profiling_input_groups'][runtime[0]['profiling_input_group']];input_hashes[group['activation']['sha256']]+=1
  records.append(row);all_rows.append(runtime);default_descending.append(row)
 ranks={row['worker']:i+1 for i,row in enumerate(sorted(default_descending,key=lambda row:row['default_profile_us'],reverse=True))}
 for row in records:row['default_time_rank_descending_of32']=ranks[row['worker']]
 by_position=[]
 for position,key in enumerate(order):
  times=[row['all_candidate_profile_us_by_fixed_position'][position] for row in records]
  relative=[row['all_candidate_profile_us_by_fixed_position'][position]/row['default_profile_us'] for row in records]
  by_position.append({'position_zero_based':position,'identity':key,'profile_us':summary(times),'over_same_worker_default':summary(relative),
                      'best_explicit_count':sum(row['best_explicit_position']==position for row in records),
                      'natural_winner_count':sum(row['winner_position']==position for row in records)})
 bad=[row for row in records if row['winner']!='default'];defaults=[row for row in records if row['winner']=='default']
 result={
  'status':'posthoc_diagnostic_complete_no_causal_or_new_cohort_claim',
  'source_commit':PIN,'cohort':'Original fixed32workers, eight blocked repetitions x4heterogeneous H/F cells. All successful workers retained; no statistical cohort or preregistered estimand changed.',
  'script_sha256':sha(__file__),'raw_root':str(a.raw_root),'raw_archive_sha256':'0eeedb2912c10089c743f1249701e8c65347a8a585e734023a2fbedb2404448b',
  'totals':{'workers':32,'runtime_profile_attempts':288,'all_profile_attempts':2592,'explicit_winners':len(bad),'default_winners':len(defaults),'original_graph_replays_traced':192},
  'fixed_order':{'default_position_zero_based':0,'M144_global_attempt_positions_zero_based':[72,80],
                 'all32_share_identical_order':True,'descriptor_order':order,'descriptors':descriptors,
                 'explicit_candidates_already_seen_at_smallerM':sum(v['prior_smaller_M_occurrences'] for v in descriptors.values()),
                 'qualification':'Raw descriptor identity has not appeared at smallerM. This is not direct measurement of native cold-cache validation cost; the native cache also keys exactM.'},
  'timing_settings':[{'profile_rows':count,'use_cuda_graph':key[0],'cold_L2':key[1],'warmup':key[2],'repeat':key[3],'stream_delay_us':key[4],'graph_delay_us':key[5],'use_global_timer':key[6],'measurement_policy':json.loads(key[7]),'effective_policy_timer':key[8],'effective_repeat':key[9]} for key,count in flags.items()],
  'position_descriptions':by_position,'workers':records,
  'explicit_winner_cases':bad,
  'signature_catalog':catalog,
  'posthoc_descriptions':{
   'default_profile_us_when_explicit_selected':summary([row['default_profile_us'] for row in bad]),
   'default_profile_us_when_default_selected':summary([row['default_profile_us'] for row in defaults]),
   'best_explicit_profile_us_when_explicit_selected':summary([min(row['all_candidate_profile_us_by_fixed_position'][1:]) for row in bad]),
   'best_explicit_profile_us_when_default_selected':summary([min(row['all_candidate_profile_us_by_fixed_position'][1:]) for row in defaults]),
   'three_explicit_selection_default_time_ranks_descending':[row['default_time_rank_descending_of32'] for row in bad],
   'slowest_default_measurement_worker':max(records,key=lambda row:row['default_profile_us'])['worker'],
   'per_cell_explicit_counts':{f'h{h}f{f}':sum(row['winner']!='default' and row['cell']==f'h{h}f{f}' for row in records) for h in (0,1) for f in (0,1)},
   'F1_runtime_activation_hashes':dict(input_hashes),
  },
  'source_interpretation':[
   'The exact old qualified0.7.2+6148 engine prepends default-1 to the candidate list for every profile. M144 is the ninth/last profile, not the first global tuning call.',
   'All eight opaque runtime descriptors are newly introduced at that profile in every worker. Their raw order is identical across workers; candidates7/8 win all three explicit cases but are also frequent best-explicit candidates when default wins. Algorithm identity and order are inseparable in this cohort.',
   'Runner preparation invokes default once before candidate iteration; each candidate then has three runner warmups before its ten-call event measurement. Native descriptor validation/cache preparation is expected in warmup for a fresh exact problem; it was not separately timed or traced here.',
   'The old eager/hot event path has a5000us delay and a cached timing-helper lookup. A first-ever helper build/load belongs to an earlier profile under this sequence; raw data cannot attribute the rare M144 ranking changes directly to that one-time load. Broader device/history effects remain possible.',
   'Profiling uses synthesized dynamicFP8 activation at actualM144 and an eager runner objective, whereas serving measurements replay the full quantizer+BMM graph on captured actual input. Distribution, objective and setup history can all affect rankings; no one mechanism is identified by this association.',
  ],
  'findings':[
   'A consistent fixed-order/first-use structure is visible, but there is no unique first-candidate or first-explicit occurrence distinguishing the three bad selections from the other29workers.',
   'The three explicit winners coincide with the second-, third- and fourth-slowest default profiling times of32. The slowest default profile still wins by a tiny margin. This is post hoc association, not evidence that those timings were invalid or caused by first-use overhead.',
   'All natural winners equal their actual finite profiler minima. The issue is agreement of the profiling objective with actual graph serving, not an observed wrong argmin or silent native fallback.',
   'All three explicit-winner graphs have a different actual GEMM launch signature from their own default graph and run roughly19% to22%slower in the fixed paired serving measurements. Default-winning graphs share the same signatures. These are runtime regressions, not startup costs.',
   'No fixed candidate order intervention exists here, so attributing late-candidate wins to order rather than actual algorithm differences would require a separate controlled study. This diagnostic does not authorize it.'
  ],
  'rare_failure_detection_limit':{
   'observed_counts_are_descriptive_only':'Do not pool32heterogeneous H/F workers into an iid binomial failure-rate estimate. The blocked repetitions/cells and post hoc selection make that inference inappropriate.',
   'hypothetical_iid_examples_only':[{'assumed_event_probability':p,'assumed_independent_identical_trials':6,'probability_of_zero_events':(1-p)**6} for p in (0.05,0.10)],
   'conclusion':'Six neutral fresh trials cannot establish absence of a rare bad selection. The examples assume a hypothetical homogeneous iid process and do not estimate a rate from this cohort.'
  },
  'next_step_relevance':'Finish the bounded current-source provider/freshness qualification before interpreting a new comparison. If asking about representative values, preserve the existing nine-profile sequence using the separately reviewed targetM144 initializer, rather than confounding values with retained-domain removal. No automatic GPU trial, performance threshold or cohort expansion follows.',
  'source_evidence':{'tuner':{'path':str(SOURCE/'flashinfer/autotuner/autotuner.py'),'sha256':sha(SOURCE/'flashinfer/autotuner/autotuner.py')},'runner':{'path':str(SOURCE/'flashinfer/gemm/gemm_base.py'),'sha256':sha(SOURCE/'flashinfer/gemm/gemm_base.py')}}
 }
 check(all(row['winner_position'] in (0,7,8) for row in records),'unexpected selection position')
 check(sorted(result['posthoc_descriptions']['three_explicit_selection_default_time_ranks_descending'])==[2,3,4],'post hoc rank description differs')
 a.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
 print(json.dumps({'status':'success','output':str(a.output),'sha256':sha(a.output),'explicit_winners':len(bad)}))
if __name__=='__main__':main()
