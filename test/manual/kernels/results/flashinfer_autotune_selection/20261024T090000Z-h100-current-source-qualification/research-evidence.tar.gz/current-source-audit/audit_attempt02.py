#!/usr/bin/env python3
"""Independent raw source/provider/correctness audit; no study-worker imports."""
from __future__ import annotations
import argparse,ast,collections,hashlib,json,math,statistics,struct
from pathlib import Path
PIN='27c62fdf0ab1cd4014df8a15b66a975541fda83c'
FIXTURE='c30aa761eba827bb0b4eb6de0e99d9b8dda8243dd16d00146f9718d2abb05e8b'
TUNER='0db42ad90d1a3fec6f81509a2c520c1892cea0a433f5dbd7f43468a2a10243ca'
GEMM='0bba9240029a5e09f331e7a2267f7067e126d57a7a341ca535f7c9557599adca'
BASE=Path('/private/tmp/fi-next-steps-20261024/current-source-qualification/complete-source-manifest.json')
checks=[]
def check(value,label):
 if not value:raise AssertionError(label)
 checks.append(label)
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def load(path):return json.loads(Path(path).read_text())
def status(root,name,code):check((root/(name+'.exit-code')).read_text().strip()==str(code),'process exit '+name)
def artifact(root,path,expected):
 candidates=[p for p in (root/'native-artifacts').iterdir() if p.suffix==Path(path).suffix and sha(p)==expected]
 check(bool(candidates),'retained native artifact '+str(path));return candidates[0]
def source_records(record,execution):
 base={row['path']:row['sha256'] for row in load(BASE)['files']}
 check(sha(BASE)==execution['files_sha256']['manifests/complete-source-manifest.json'],'exact exhaustive official source manifest')
 base.update({'csrc/bmm_fp8.cu':'ac00c1cdba76e653ead25a77d2b1ca9d07f35a89f65221334fbbab1a695a4709',
              'csrc/flashinfer_gemm_binding.cu':'4cfdde4e2d7928ffa442d4a386c8f545de61d68820a6d01e4bf78c1b4a490e8e',
              'include/flashinfer/gemm/bmm_fp8.cuh':'5a35da070efbc028e565721110e059c5b143d6a49697995e3c70fdae258eae72',
              'flashinfer/gemm/gemm_base.py':GEMM,
              'benchmarks/bench_autotuner_accuracy.py':'9f6f8db43d5b584fa07852e42c640f4c22a2ac8b535519bde637858841142efe'})
 check(record['source']['manifest_sha256']==execution['files_sha256']['manifests/candidate-manifest.json'],'exact actual combined source contract')
 check(len(record['source']['source_sha256'])==17,'all critical current-source files observed')
 for rel,digest in record['source']['source_sha256'].items():check(base[rel]==digest,'actual critical source '+rel)
 imported=record['import']
 check(imported['flashinfer_runtime_version']=='0.0.0+unknown' and imported['flashinfer_runtime_commit']=='unknown','truthful absent generated metadata fallback')
 for module,row in imported['source_modules'].items():
  prefix='/study/input/current/source/'
  module_id=hashlib.sha256(module.encode()).hexdigest()
  check(row['path'].startswith(prefix),'actual imported source containment module_sha256='+module_id)
  check(base[row['path'][len(prefix):]]==row['sha256'],'actual imported Python source module_sha256='+module_id)
 return {'critical_source_files':17,'imported_source_files':len(imported['source_modules']),'source_version':imported['flashinfer_runtime_version']}

def providers(root,record,reference=None):
 native=record['native'];result={};base={row['path']:row['sha256'] for row in load(BASE)['files']}
 base.update({'csrc/bmm_fp8.cu':'ac00c1cdba76e653ead25a77d2b1ca9d07f35a89f65221334fbbab1a695a4709',
              'csrc/flashinfer_gemm_binding.cu':'4cfdde4e2d7928ffa442d4a386c8f545de61d68820a6d01e4bf78c1b4a490e8e'})
 for name in ('gemm','trtllm_utils'):
  item=native['providers'][name]
  library=artifact(root,item['library_path'],item['library_sha256'])
  ninja=artifact(root,item['ninja_path'],item['ninja_sha256'])
  header=library.read_bytes()[:64]
  check(header[:4]==b'\x7fELF' and header[4:6]==bytes((2,1)) and struct.unpack_from('<H',header,18)[0]==62,'actual Linux x86_64 ELF '+name)
  check(item['linkage']['returncode']==0 and item['compile_commands'],'linkage and compile provenance '+name)
  check(len(item['sources'])==(3 if name=='gemm' else 5),'translation unit count '+name)
  source_rows={}
  for path,expected in item['sources'].items():
   suffix=path.split('/source/',1)[1]
   suffix=suffix.replace('flashinfer/data/csrc/','csrc/').replace('flashinfer/data/include/','include/')
   check(base[suffix]==expected,'actual current translation source '+suffix);source_rows[suffix]=expected
  if reference:
   check(item['library_sha256']==reference[name]['library_sha256'] and item['ninja_sha256']==reference[name]['ninja_sha256'],'same actual native build across processes '+name)
  result[name]={'library_sha256':item['library_sha256'],'ninja_sha256':item['ninja_sha256'],'retained_library':str(library),'retained_ninja':str(ninja),'sources':source_rows,'compile_commands':len(item['compile_commands'])}
 return result

def native_gate(root,execution):
 p=root/'native-facade.json';d=load(p);status(root,'native-facade',0)
 check(d['status']=='passed' and d['source_commit']==PIN,'native source/status')
 check(d['worker_sha256']==execution['files_sha256']['tools/qualify_cuda.py'],'actual qualification worker hash')
 check(d['source']['manifest_sha256']==execution['files_sha256']['manifests/candidate-manifest.json'],'actual source manifest hash')
 observed=d['source']['source_sha256'];check(observed['flashinfer/autotuner/autotuner.py']==TUNER and observed['flashinfer/gemm/gemm_base.py']==GEMM,'current engine and ported runner pins')
 check(d['profile_attempts']==0 and not d['forbidden_profile_stages'],'no prohibited profiling')
 runtime=d['runtime'];check(runtime['gpu_uuid']=='240958a2-e8e1-3bac-b767-365c9e0b97bd' and runtime['torch']=='2.14.1+cu130' and runtime['torch_cuda']=='13.0','actual target runtime')
 check(runtime['inference_mode'] and not runtime['grad_enabled'] and not runtime['allow_tf32'] and runtime['bmm_public']['decorated'],'actual decorated/inference public path')
 check(d['fixture']['tensor_file_sha256']==FIXTURE,'same fixture')
 pool=d['candidate_pool'];control=d['selected_control_descriptor'];check(isinstance(control,list) and len(control)==8 and all(type(x)is int and 0<=x<2**64 for x in control),'actual eight-word control descriptor')
 check(pool['m144']==pool['m129'] and control in pool['m144'] and pool['identical'] and pool['native_enumeration_calls']==1 and pool['enumeration_m']==256,'same-bucket candidate identity')
 calls=d['native_calls'];enumerations=[r for r in calls if r['api']=='bmm_fp8_get_algos']
 check(len(enumerations)==1 and enumerations[0]['actual_m']==144 and enumerations[0]['enumeration_m']==256 and enumerations[0]['count']==len(pool['m144']),'one actual native bucket256 enumeration')
 raw=struct.pack('<8Q',*control).hex()
 selected=d['descriptor_probes'][-1];check(selected['accepted_both'] and selected['tactic']==control and {r['m'] for r in selected['actual_calls']}=={129,144} and all(r['used_descriptor']==1 and r['numerics']=='passed' for r in selected['actual_calls']),'native descriptor accepted at both actual Ms')
 for row in calls:
  if row['api']=='bmm_fp8_run_with_descriptor' and not row['stage'].startswith('descriptor_probe_'):
   check(row['used_descriptor']==1 and row['descriptor_raw_hex']==raw,'explicit actual public native acceptance '+row['stage'])
 check(len(d['selections'])==13,'expected actual public choose_one count')
 for row in d['selections']:
  explicit=row['stage'].startswith('explicit_')
  check(row['tactic']==(control if explicit else -1) and row['hit']==explicit and row['lookup_tier']==('memory' if explicit else 'miss'),'real public hit/default miss '+row['stage'])
  check(row['nearest_profile'][0][-2]==256,'actual public runtime cache bucket')
  check(row['capturing']==row['stage'].endswith('_capture'),'capture boundary '+row['stage'])
 graphs={r['id']:r for r in d['graphs']};check(set(graphs)=={'default','explicit'},'both retained graphs')
 check(graphs['default']['graph_object_id']!=graphs['explicit']['graph_object_id'] and graphs['default']['output']['data_ptr']!=graphs['explicit']['output']['data_ptr'],'distinct retained graphs/output allocations')
 check(all(not r['poison_nodes_captured'] for r in graphs.values()),'no poison nodes declared in captured graphs')
 expected={'initial_actual_facade_default'}
 for kind in graphs:
  expected|={kind+'_eager',kind+'_eager_changed_input',kind+'_eager_restored_input',kind+'_graph_replay',kind+'_graph_changed_input',kind+'_graph_restored_input'}
 expected|={'final_independent_graph_0','final_independent_graph_1'}
 check({r['check'] for r in d['correctness']}==expected and len(d['correctness'])==15,'all eager/changed/restored/independent numerical assertions')
 for row in d['correctness']:
  check(row['passed'] and row['finite'] and row['max_abs_error'] is not None and math.isfinite(row['max_abs_error']),'passed finite actual numerical record '+row['check'])
  if row['zero_required']:check(row['max_abs_error']==0,'changed-zero input exact result '+row['check'])
  if row['check'].startswith(('default_graph_','explicit_graph_')):
   kind=row['check'].split('_graph_',1)[0];check(row['output_ptr']==graphs[kind]['output']['data_ptr'],'original captured output checked '+row['check'])
  if row['check'].startswith('final_independent_graph_'):
   kind=('default','explicit')[int(row['check'][-1])];check(row['output_ptr']==graphs[kind]['output']['data_ptr'],'final retained output pointer')
 return {'status':'passed','result_sha256':sha(p),'checks':len(d['correctness']),'native_acceptance_control':control,'native_calls':len(calls),'actual_public_selections':len(d['selections']),'providers':providers(root,d),'source_records':source_records(d,execution),'scope':'Actual native accepted-control and actual decorated facade/eager/graph correctness; no natural selection, profiling, persistence or performance claim.'}

def callback_gate(root,execution,reference,expected_cases):
 p=root/'callback-controls.json';d=load(p);b=load(p.with_suffix('.bootstrap.json'));status(root,'callback-controls',0)
 check(d['status']=='success' and b['status']=='passed','callback process passed')
 check(d['worker_sha256']==execution['files_sha256']['tools/test_output_refresh.py'] and d['tuner_sha256']==TUNER,'callback actual worker/tuner source')
 check(len(d['cases'])==expected_cases and len(d['unsafe_roles'])==4,'bounded callback case set')
 check({(row['allocation_mode'],row['callback_enabled'],row['kind']) for row in d['cases']}=={(allocation,enabled,kind) for allocation in ('normal','inference') for enabled in (False,True) for kind in ('correct','wrong','no_write')},'complete normal/inference callback matrix')
 for row in d['cases']:
  check(row['output_is_inference']==(row['allocation_mode']=='inference'),'actual allocation mode observed')
  expected=row['kind']=='correct' or (row['kind']=='no_write' and not row['callback_enabled'])
  check(row['accepted']==row['expected']==expected,'actual controlled CUDA outcome '+str((row.get('allocation_mode','original'),row['callback_enabled'],row['kind'])))
  check(row['profile_tactics']==[-1,0] and row['final_assertions']==(3 if expected else 2),'actual minimum and independent validation boundary')
  check(row['callback_calls']==((3 if expected else 2) if row['callback_enabled'] else 0),'refresh only final independent checks')
 for row in d['unsafe_roles']:check(row['rejected_before_mutation'],'unsafe role rejected before mutation '+row['kind'])
 return {'status':'passed','result_sha256':sha(p),'cases':d['cases'],'unsafe_roles':d['unsafe_roles'],'providers':providers(root,b,reference),'source_records':source_records(b,execution),'scope':'Actual CUDA graph/tensor/tuner control with controlled profiling times; no native descriptor-acceptance claim.'}

def harness_gate(root,name,execution,reference):
 p=root/(name+'.json');d=load(p);b=load(p.with_suffix('.bootstrap.json'));mode='retained' if name=='retained-auto' else 'synthesized'
 status(root,name,0);check(b['status']=='passed','actual harness bootstrap completed '+name)
 check(d['op']=='fp8_gemm' and d['profile_inputs']==mode and len(d['trials'])==1,'bounded official fixture operation '+name)
 check(d['source_commit'] is None and d['flashinfer']=='0.0.0+unknown','truthful source-archive metadata '+name)
 check(d['source_sha256']=={'/study/input/current/source/benchmarks/bench_autotuner_accuracy.py':'9f6f8db43d5b584fa07852e42c640f4c22a2ac8b535519bde637858841142efe','/study/input/current/source/flashinfer/autotuner/autotuner.py':TUNER},'actual harness/current engine hashes '+name)
 check(d['torch']=='2.14.1+cu130' and d['cuda']=='13.0' and d['gpu']=='NVIDIA H100 NVL','actual harness CUDA stack '+name)
 args=d['arguments'];check(args['fixture']=='sglang_captured_fixture:build' and args['seeds']==1 and args['seed']==19 and args['graph_policies']==['auto'] and args['cold_l2'] is None and args['profile_inputs']==mode,'literal unspecified auto fixture request '+name)
 check(d['validation']['output_refresh']=='fixture_callback' and d['validation']['rounds']==2 and d['validation']['replays']==16 and d['validation']['prequeue_cycles']==10000000 and d['validation']['warmup']==3,'declared bounded refreshed validation recipe '+name)
 check(d['reference']=='fixture reference and untuned default' and all(math.isfinite(v) for v in d['reference_error'].values()),'actual independent quantized reference checked '+name)
 row=d['trials'][0];check(row['trial']==0 and row['seed']==19 and row['policy']=='auto' and row['runner']=='CublasFp8GemmRunner' and row['cache_hit'] and row['numerics']=='passed','actual natural winner/cache/numerics '+name)
 check(row['input_shapes']==[[1,144,1024],[1,1024,4096],[1],[1],[1,144,4096],[41943040]],'actual public captured geometry '+name)
 expected_key=row['input_shapes'] if mode=='retained' else [[1,256,1024],[1,1024,4096],[1],[1],[1,-1,4096],[-1]]
 check(row['cache_profile']==expected_key,'actual retained versus synthesized key '+name)
 groups={}
 for attempt in row['measurements']:
  check(attempt['runner']=='CublasFp8GemmRunner' and not attempt['use_cuda_graph'] and not attempt['cold_l2'] and attempt['repeat']==10 and attempt['warmup']==3,'unchanged operation hot/eager timing flags '+name)
  check(attempt['profiling_policy']==['cuda_graph_profile_replays',None,'l2_cache_policy','hot'],'actual profiling policy '+name)
  check(attempt['ms'] is not None and math.isfinite(attempt['ms']) and attempt['ms']>0 and 'error' not in attempt,'finite actual profiling attempt '+name)
  m=attempt['input_shapes'][0][-2];groups.setdefault(m,[]).append(attempt)
 expected_ms=[144] if mode=='retained' else [1,2,4,8,16,32,64,128,144]
 check(list(groups)==expected_ms and row['profile_count']==len(row['measurements'])==9*len(expected_ms),'actual profile sequence/count '+name)
 for m,attempts in groups.items():
  check(len(attempts)==9 and attempts[0]['tactic']=='-1' and len({r['tactic'] for r in attempts})==9,'default first and full eight-explicit candidate pool '+str(m))
  for attempt in attempts:
   shapes=attempt['input_shapes'];check(shapes[0]==[1,m,1024] and shapes[4]==[1,m,4096],'concrete synthesized dimensions '+str(m))
   mapped=m if mode=='retained' else 1 << (m-1).bit_length()
   profile=shapes if mode=='retained' else [[1,mapped,1024],[1,1024,4096],[1],[1],[1,-1,4096],[-1]]
   check(attempt['cache_profile']==profile,'exact canonical/cache shape '+str(m))
  check(any(r['tactic']=='-1' and r['ms'] is not None for r in attempts),'default participates '+str(m))
 target=groups[144];minimum=min(target,key=lambda r:r['ms']);check(row['tactic']==minimum['tactic'],'actual runtime winner equals finite minimum '+name)
 # The actual runs select default. No unobserved selected-descriptor acceptance is inferred.
 check(row['tactic']=='-1','reported successful setup default winner '+name)
 native_pool=load(root/'native-facade.json')['candidate_pool']['m144']
 actual_pool=[list(ast.literal_eval(r['tactic'])) for r in target[1:]]
 check(actual_pool==native_pool,'exact runtime descriptor identity/order matches native qualification '+name)
 for graph,samples in row['validation_ms'].items():
  check(graph in ('default_before','selected','default_after') and len(samples)==2 and all(math.isfinite(v) and v>0 for v in samples),'finite bounded graph samples '+name+':'+graph)
  check(math.isclose(statistics.median(samples),row['median_ms'][graph],rel_tol=1e-12),'preserved sample median arithmetic '+name+':'+graph)
 check(math.isclose(row['selected_over_default_after'],row['median_ms']['selected']/row['median_ms']['default_after'],rel_tol=1e-12),'preserved incidental ratio arithmetic '+name)
 provenance=load(root/(name+'.fixture-provenance.json'))
 check(provenance['adapter_sha256']==execution['files_sha256']['tools/adapter/sglang_captured_fixture.py'] and provenance['contract_sha256']==execution['files_sha256']['tools/adapter/adapter-contract.json'],'actual adapter/contract binding '+name)
 check(provenance['upstream_commit']==PIN and provenance['fixture_tensor_sha256']==FIXTURE and provenance['fixture_manifest_sha256']==sha(root/'fixture/manifest.json'),'actual immutable fixture provenance '+name)
 check(provenance['factory_preflight_public_calls']==1 and provenance['retains_original_capture_tensors'] and provenance['final_graph_no_write_refresh_supported'],'actual fixture hook/refresh contract '+name)
 roles=provenance['capture']['roles'];check(roles['read_indices']==[0,1,2,3] and roles['output_index']==4 and roles['scratch_index']==5 and roles['output_role_validated'],'declared FP8 read/output/scratch ownership '+name)
 fixture=load(root/'fixture/manifest.json')
 check(provenance['capture']['quantized_input_sha256']==fixture['quantization']['independent_input_fp8_sha256'] and provenance['capture']['weight_rowmajor_sha256']==fixture['tensors']['weight_fp8_rowmajor']['sha256'],'actual public operand hashes '+name)
 return {'status':'passed','result_sha256':sha(p),'profile_domain':mode,'concrete_M_endpoints':expected_ms,'candidate_attempts':len(row['measurements']),'runtime_cache_profile':row['cache_profile'],'selected_tactic':row['tactic'],'genuine_cache_hit':row['cache_hit'],'fixture_reference_error':d['reference_error'],'refreshed_graph_numerics':row['numerics'],'providers':providers(root,b,reference),'source_records':source_records(b,execution),'scope':'One fresh process/seed setup and numerical check; timing samples retained and arithmetic verified but not performance evidence. No selected explicit-descriptor acceptance claim.'}


def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--raw-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=a.raw_root
 preservation=load(root/'preservation-manifest.json')
 check(len(preservation['files'])==80,'expected complete preservation file count')
 for row in preservation['files']:
  rel=Path(row['path']);check(not rel.is_absolute() and '..' not in rel.parts,'owned archive path')
  check((root/rel).stat().st_size==row['size_bytes'] and sha(root/rel)==row['sha256'],'byte-identical preserved member '+str(rel))
 execution=load(root/'execution-manifest.json');check(execution['flashinfer_source_commit']==PIN and execution['sglang_source_commit']=='12447b7d6219d54d1296401c0b8cfeeff1568931','declared exact source commits')
 check((root/'sglang-commit-before.txt').read_text().strip()==(root/'sglang-commit-after.txt').read_text().strip()==execution['sglang_source_commit'],'unchanged SGLang source commit')
 check(not (root/'sglang-status-after.txt').read_text().strip(),'clean SGLang checkout after attempt')
 check((root/'launcher.exit-code').read_text().strip()=='0','all four sequential gates finished')
 native=native_gate(root,execution);callback=callback_gate(root,execution,native['providers'],12)
 retained=harness_gate(root,'retained-auto',execution,native['providers']);synthesized=harness_gate(root,'synthesized-auto',execution,native['providers'])
 names=('native-facade','callback-controls','retained-auto','synthesized-auto')
 cids=[(root/(name+'.container-id')).read_text().strip() for name in names]
 check(len(set(cids))==4 and all(len(cid)==64 for cid in cids),'four fresh container identities')
 final=load(root/'final-gate.json');check(final['status']=='passed' and final['fresh_containers']==4 and set(final['gates'])==set(names),'actual final gate success')
 for name,cid in zip(names,cids):
  gate=load(root/(name+'.gate.json'));check(gate['status']=='passed' and gate['container_id']==cid and gate['result_sha256']==sha(root/(name+'.json')),'actual gate/result binding '+name)
 report={'status':'independent_audit_passed_bounded_qualification_complete','checks':len(checks),'passed_checks':checks,'script_sha256':sha(__file__),
         'raw_root':str(root),'preserved_members_verified':80,'archive_sha256':'f78f59b928f68ee6108121e0920ae462ab32caaa562b64fd8d31bc8870b7e7f1','execution_manifest_sha256':sha(root/'execution-manifest.json'),
         'source_commit':PIN,'sglang_commit':execution['sglang_source_commit'],'native_facade':native,'callback_controls':callback,'retained':retained,'synthesized':synthesized,
         'conclusion':'All four bounded correctness/provider/API setup gates pass for exact27c62 plus the declared FP8-only port and revised output-refresh callback. Attempt01 remains a separately preserved failed qualification. Both setup runs select default; no comparative performance or universal selection-quality conclusion follows.',
         'limits':['This audit independently verifies preserved source/build/actual assertion and native-acceptance records; it does not rerun CUDA or recompute output tensors that were not retained.','Native descriptor used1 is observed only for the native-facade functionality control, not an arbitrary naturally selected future explicit winner. Both actual setup winners were default-1.','Retained versus synthesized changes profile domain/count/keys and setup history; this is not a values-only comparison.','The official harness times runner-only BMM component graphs and retains two short samples. The native functionality gate covers full SGLang helper graph correctness. Neither establishes serving throughput or statistical performance.','Harness source_commit is truthfully null because archive has no Git metadata; exact upstream identity is established by manifests and actual source hashes.','No broad shapes/backends/models, distributed behavior, managed-store migration, fresh-process persistence or explicit serving-policy routing is qualified.']}
 a.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
 print(json.dumps({'status':report['status'],'checks':len(checks),'output':str(a.output),'sha256':sha(a.output)}))
if __name__=='__main__':main()
