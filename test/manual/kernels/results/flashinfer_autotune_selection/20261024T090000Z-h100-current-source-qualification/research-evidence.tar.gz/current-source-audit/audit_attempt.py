#!/usr/bin/env python3
"""Independent raw source/provider/correctness audit; no study-worker imports."""
from __future__ import annotations
import argparse,collections,hashlib,json,math,struct
from pathlib import Path
PIN='27c62fdf0ab1cd4014df8a15b66a975541fda83c'
FIXTURE='c30aa761eba827bb0b4eb6de0e99d9b8dda8243dd16d00146f9718d2abb05e8b'
TUNER='0db42ad90d1a3fec6f81509a2c520c1892cea0a433f5dbd7f43468a2a10243ca'
GEMM='0bba9240029a5e09f331e7a2267f7067e126d57a7a341ca535f7c9557599adca'
BASE=Path('/private/tmp/fi-next-steps-20261024/current-source-qualification/complete-source-manifest.json')
checks=[]
def check(value,label):
 if not value:raise AssertionError(label)
 checks.append(label)
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def load(path):return json.loads(Path(path).read_text())
def status(root,name,code):check((root/(name+'.exit-code')).read_text().strip()==str(code),'process exit '+name)
def artifact(root,path,expected):
 candidates=[p for p in (root/'native-artifacts').iterdir() if p.suffix==Path(path).suffix and sha(p)==expected]
 check(bool(candidates),'retained native artifact '+str(path));return candidates[0]
def source_records(record,execution):
 base={row['path']:row['sha256'] for row in load(BASE)['files']}
 check(sha(BASE)==execution['files_sha256']['manifests/complete-source-manifest.json'],'exact exhaustive official source manifest')
 base.update({'csrc/bmm_fp8.cu':'ac00c1cdba76e653ead25a77d2b1ca9d07f35a89f65221334fbbab1a695a4709',
              'csrc/flashinfer_gemm_binding.cu':'4cfdde4e2d7928ffa442d4a386c8f545de61d68820a6d01e4bf78c1b4a490e8e',
              'include/flashinfer/gemm/bmm_fp8.cuh':'5a35da070efbc028e565721110e059c5b143d6a49697995e3c70fdae258eae72',
              'flashinfer/gemm/gemm_base.py':GEMM,
              'benchmarks/bench_autotuner_accuracy.py':'094f66306d6e6080cdb5b50915f21fb643cdb40cb82471b58e5bdce6f451ce86'})
 check(record['source']['manifest_sha256']==execution['files_sha256']['manifests/candidate-manifest.json'],'exact actual combined source contract')
 check(len(record['source']['source_sha256'])==17,'all critical current-source files observed')
 for rel,digest in record['source']['source_sha256'].items():check(base[rel]==digest,'actual critical source '+rel)
 imported=record['import']
 check(imported['flashinfer_runtime_version']=='0.0.0+unknown' and imported['flashinfer_runtime_commit']=='unknown','truthful absent generated metadata fallback')
 for module,row in imported['source_modules'].items():
  prefix='/study/input/current/source/'
  check(row['path'].startswith(prefix),'actual imported source containment '+module)
  check(base[row['path'][len(prefix):]]==row['sha256'],'actual imported Python source '+module)
 return {'critical_source_files':17,'imported_source_files':len(imported['source_modules']),'source_version':imported['flashinfer_runtime_version']}

def providers(root,record,reference=None):
 native=record['native'];result={};base={row['path']:row['sha256'] for row in load(BASE)['files']}
 base.update({'csrc/bmm_fp8.cu':'ac00c1cdba76e653ead25a77d2b1ca9d07f35a89f65221334fbbab1a695a4709',
              'csrc/flashinfer_gemm_binding.cu':'4cfdde4e2d7928ffa442d4a386c8f545de61d68820a6d01e4bf78c1b4a490e8e'})
 for name in ('gemm','trtllm_utils'):
  item=native['providers'][name]
  library=artifact(root,item['library_path'],item['library_sha256'])
  ninja=artifact(root,item['ninja_path'],item['ninja_sha256'])
  header=library.read_bytes()[:64]
  check(header[:4]==b'\x7fELF' and header[4:6]==bytes((2,1)) and struct.unpack_from('<H',header,18)[0]==62,'actual Linux x86_64 ELF '+name)
  check(item['linkage']['returncode']==0 and item['compile_commands'],'linkage and compile provenance '+name)
  check(len(item['sources'])==(3 if name=='gemm' else 5),'translation unit count '+name)
  source_rows={}
  for path,expected in item['sources'].items():
   suffix=path.split('/source/',1)[1]
   suffix=suffix.replace('flashinfer/data/csrc/','csrc/').replace('flashinfer/data/include/','include/')
   check(base[suffix]==expected,'actual current translation source '+suffix);source_rows[suffix]=expected
  if reference:
   check(item['library_sha256']==reference[name]['library_sha256'] and item['ninja_sha256']==reference[name]['ninja_sha256'],'same actual native build across processes '+name)
  result[name]={'library_sha256':item['library_sha256'],'ninja_sha256':item['ninja_sha256'],'retained_library':str(library),'retained_ninja':str(ninja),'sources':source_rows,'compile_commands':len(item['compile_commands'])}
 return result

def native_gate(root,execution):
 p=root/'native-facade.json';d=load(p);status(root,'native-facade',0)
 check(d['status']=='passed' and d['source_commit']==PIN,'native source/status')
 check(d['worker_sha256']==execution['files_sha256']['tools/qualify_cuda.py'],'actual qualification worker hash')
 check(d['source']['manifest_sha256']==execution['files_sha256']['manifests/candidate-manifest.json'],'actual source manifest hash')
 observed=d['source']['source_sha256'];check(observed['flashinfer/autotuner/autotuner.py']==TUNER and observed['flashinfer/gemm/gemm_base.py']==GEMM,'current engine and ported runner pins')
 check(d['profile_attempts']==0 and not d['forbidden_profile_stages'],'no prohibited profiling')
 runtime=d['runtime'];check(runtime['gpu_uuid']=='240958a2-e8e1-3bac-b767-365c9e0b97bd' and runtime['torch']=='2.14.1+cu130' and runtime['torch_cuda']=='13.0','actual target runtime')
 check(runtime['inference_mode'] and not runtime['grad_enabled'] and not runtime['allow_tf32'] and runtime['bmm_public']['decorated'],'actual decorated/inference public path')
 check(d['fixture']['tensor_file_sha256']==FIXTURE,'same fixture')
 pool=d['candidate_pool'];control=d['selected_control_descriptor'];check(isinstance(control,list) and len(control)==8 and all(type(x)is int and 0<=x<2**64 for x in control),'actual eight-word control descriptor')
 check(pool['m144']==pool['m129'] and control in pool['m144'] and pool['identical'] and pool['native_enumeration_calls']==1 and pool['enumeration_m']==256,'same-bucket candidate identity')
 calls=d['native_calls'];enumerations=[r for r in calls if r['api']=='bmm_fp8_get_algos']
 check(len(enumerations)==1 and enumerations[0]['actual_m']==144 and enumerations[0]['enumeration_m']==256 and enumerations[0]['count']==len(pool['m144']),'one actual native bucket256 enumeration')
 raw=struct.pack('<8Q',*control).hex()
 selected=d['descriptor_probes'][-1];check(selected['accepted_both'] and selected['tactic']==control and {r['m'] for r in selected['actual_calls']}=={129,144} and all(r['used_descriptor']==1 and r['numerics']=='passed' for r in selected['actual_calls']),'native descriptor accepted at both actual Ms')
 for row in calls:
  if row['api']=='bmm_fp8_run_with_descriptor' and not row['stage'].startswith('descriptor_probe_'):
   check(row['used_descriptor']==1 and row['descriptor_raw_hex']==raw,'explicit actual public native acceptance '+row['stage'])
 check(len(d['selections'])==13,'expected actual public choose_one count')
 for row in d['selections']:
  explicit=row['stage'].startswith('explicit_')
  check(row['tactic']==(control if explicit else -1) and row['hit']==explicit and row['lookup_tier']==('memory' if explicit else 'miss'),'real public hit/default miss '+row['stage'])
  check(row['nearest_profile'][0][-2]==256,'actual public runtime cache bucket')
  check(row['capturing']==row['stage'].endswith('_capture'),'capture boundary '+row['stage'])
 graphs={r['id']:r for r in d['graphs']};check(set(graphs)=={'default','explicit'},'both retained graphs')
 check(graphs['default']['graph_object_id']!=graphs['explicit']['graph_object_id'] and graphs['default']['output']['data_ptr']!=graphs['explicit']['output']['data_ptr'],'distinct retained graphs/output allocations')
 check(all(not r['poison_nodes_captured'] for r in graphs.values()),'no poison nodes declared in captured graphs')
 expected={'initial_actual_facade_default'}
 for kind in graphs:
  expected|={kind+'_eager',kind+'_eager_changed_input',kind+'_eager_restored_input',kind+'_graph_replay',kind+'_graph_changed_input',kind+'_graph_restored_input'}
 expected|={'final_independent_graph_0','final_independent_graph_1'}
 check({r['check'] for r in d['correctness']}==expected and len(d['correctness'])==15,'all eager/changed/restored/independent numerical assertions')
 for row in d['correctness']:
  check(row['passed'] and row['finite'] and row['max_abs_error'] is not None and math.isfinite(row['max_abs_error']),'passed finite actual numerical record '+row['check'])
  if row['zero_required']:check(row['max_abs_error']==0,'changed-zero input exact result '+row['check'])
  if row['check'].startswith(('default_graph_','explicit_graph_')):
   kind=row['check'].split('_graph_',1)[0];check(row['output_ptr']==graphs[kind]['output']['data_ptr'],'original captured output checked '+row['check'])
  if row['check'].startswith('final_independent_graph_'):
   kind=('default','explicit')[int(row['check'][-1])];check(row['output_ptr']==graphs[kind]['output']['data_ptr'],'final retained output pointer')
 return {'status':'passed','result_sha256':sha(p),'checks':len(d['correctness']),'native_acceptance_control':control,'native_calls':len(calls),'actual_public_selections':len(d['selections']),'providers':providers(root,d),'source_records':source_records(d,execution),'scope':'Actual native accepted-control and actual decorated facade/eager/graph correctness; no natural selection, profiling, persistence or performance claim.'}

def callback_gate(root,execution,reference,expected_cases):
 p=root/'callback-controls.json';d=load(p);b=load(p.with_suffix('.bootstrap.json'));status(root,'callback-controls',0)
 check(d['status']=='success' and b['status']=='passed','callback process passed')
 check(d['worker_sha256']==execution['files_sha256']['tools/test_output_refresh.py'] and d['tuner_sha256']==TUNER,'callback actual worker/tuner source')
 check(len(d['cases'])==expected_cases and len(d['unsafe_roles'])==4,'bounded callback case set')
 for row in d['cases']:
  expected=row['kind']=='correct' or (row['kind']=='no_write' and not row['callback_enabled'])
  check(row['accepted']==row['expected']==expected,'actual controlled CUDA outcome '+str((row.get('allocation_mode','original'),row['callback_enabled'],row['kind'])))
  check(row['profile_tactics']==[-1,0] and row['final_assertions']==(3 if expected else 2),'actual minimum and independent validation boundary')
  check(row['callback_calls']==((3 if expected else 2) if row['callback_enabled'] else 0),'refresh only final independent checks')
 for row in d['unsafe_roles']:check(row['rejected_before_mutation'],'unsafe role rejected before mutation '+row['kind'])
 return {'status':'passed','result_sha256':sha(p),'cases':d['cases'],'unsafe_roles':d['unsafe_roles'],'providers':providers(root,b,reference),'source_records':source_records(b,execution),'scope':'Actual CUDA graph/tensor/tuner control with controlled profiling times; no native descriptor-acceptance claim.'}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--raw-root',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args();root=a.raw_root
 preservation=load(root/'preservation-manifest.json')
 for row in preservation['files']:
  rel=Path(row['path']);check(not rel.is_absolute() and '..' not in rel.parts,'owned archive path')
  check((root/rel).stat().st_size==row['size_bytes'] and sha(root/rel)==row['sha256'],'byte-identical preserved member '+str(rel))
 execution=load(root/'execution-manifest.json');check(execution['flashinfer_source_commit']==PIN,'declared exact source')
 check((root/'sglang-commit-before.txt').read_text().strip()==(root/'sglang-commit-after.txt').read_text().strip()==execution['sglang_source_commit'],'unchanged SGLang source commit')
 check(not (root/'sglang-status-after.txt').read_text().strip(),'clean SGLang checkout after attempt')
 native=native_gate(root,execution);callback=callback_gate(root,execution,native['providers'],6)
 retained=load(root/'retained-auto.json');bootstrap=load(root/'retained-auto.bootstrap.json');status(root,'retained-auto',1)
 check(retained['status']=='failed' and bootstrap['status']=='failed' and 'inference tensor outside InferenceMode' in retained['error'],'exact retained callback failure')
 check('prepare_fp8_validation' in bootstrap['traceback'] and 'output.fill_' in bootstrap['traceback'],'failure located at refresh, not kernel numerical assertion')
 check(not (root/'synthesized-auto.json').exists() and not (root/'synthesized-auto.container-id').exists(),'synthesized gate not launched after failure')
 check(not (root/'final-gate.json').exists() and (root/'launcher.exit-code').read_text().strip()!='0','no full qualification success')
 native_build=providers(root,bootstrap,native['providers']);retained_sources=source_records(bootstrap,execution)
 cids=[(root/(name+'.container-id')).read_text().strip() for name in ('native-facade','callback-controls','retained-auto')]
 check(len(set(cids))==3 and all(len(cid)==64 for cid in cids),'three attempted fresh containers')
 report={'status':'independent_audit_passed_partial_qualification_failed','checks':len(checks),'passed_checks':checks,'script_sha256':sha(__file__),
         'raw_root':str(root),'preserved_members_verified':len(preservation['files']),'execution_manifest_sha256':sha(root/'execution-manifest.json'),
         'source_commit':PIN,'sglang_commit':execution['sglang_source_commit'],'native_facade':native,'callback_controls':callback,
         'retained':{'status':'failed','result_sha256':sha(root/'retained-auto.json'),'error':retained['error'],'location':'Declared output-only NaN fill after sampled windows, outside inference mode on actual inference-created fixture output.','same_native_providers':native_build,'source_records':retained_sources},
         'synthesized':{'status':'not_launched'},'conclusion':'Native/provider and original callback controls passed their bounded scope. Retained setup exposed a real inference-tensor refresh-context defect, so the combined four-gate qualification failed. No synthesized or performance success may be inferred.',
         'limits':['This audit verifies preserved source/build/actual assertion and native-acceptance records; it does not rerun CUDA or recompute output tensors that were not retained.','The callback controls used an outer inference context in attempt01 and therefore did not exercise the factory-created inference tensor after that context exits. Revision02 must add that exact coverage.','No performance, natural winner quality, broad model/backend/distributed coverage or fresh-process persistence claim.']}
 a.output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
 print(json.dumps({'status':report['status'],'checks':len(checks),'output':str(a.output),'sha256':sha(a.output)}))
if __name__=='__main__':main()
