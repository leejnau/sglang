from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
STUDY=ROOT.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
raw=STUDY/'current-source-coordinator/raw/attempt02'
proposal=STUDY/'next-study-design/proposal.json'
final=json.loads((raw/'final-gate.json').read_text());assert final['status']=='passed' and final['fresh_containers']==4
assert (raw/'launcher.exit-code').read_text().strip()=='0'
smokes={name:json.loads((raw/(name+'-auto.json')).read_text()) for name in ('retained','synthesized')}
assert all(d['trials'][0]['tactic']=='-1' and d['trials'][0]['numerics']=='passed' for d in smokes.values())
callbacks=json.loads((raw/'callback-controls.json').read_text());assert callbacks['status']=='success' and len(callbacks['cases'])==12
report={
 'schema_version':1,
 'status':'read_only_decision_audit_no_new_experiment_or_PR',
 'proposal_review_resolution':'Root incorporated all four review changes: balanced design is not an absolute minimum; arithmetic mean of eight block-log contrasts; modified-control physical-history wording; all-four-cell GPU admission. Bootstrap implementation details remain to be frozen before launch.',
 'parent_reported_independent_qualification_audit_checks':5086,
 'recommendation':'Prepare the narrow upstream harness validation fix as the next contribution. The proposed32-process current-source factorial is an appropriate next mechanism pilot after its initializer and acceptance admission gates; do not resume scoped persistence or change SGLang production policy.',
 'evidence_boundary':{
  'historical_objective':'The old-source12-process objective comparison selected default in every worker and demonstrated no objective benefit; this is not equivalence or proof the old failure is fixed.',
  'historical_history':'The fixed32-process study had three explicit selections with approximately18.9–22.0percent slower independent graphs and different actual GEMM signatures. H/F factor results did not establish a causal explanation or equivalence.',
  'calibration':'The queued16 and plain5120 recipes differed about1.3–1.5percent. Sub-percent capture resolution remained unresolved. These are protocol-specific findings, not a universal error floor or permission to subtract host cost.',
  'current_qualification':'Attempt02 passed all four fresh-container gates on pinned27c62 plus unmerged FP8 port/callback. Actual provider/facade,12 normal/inference callback cases, and both API/cache/numeric smokes passed.',
  'current_acceptance_limit':'Only the native worker specific explicit control was observed accepted at M129/M144. Both smokes actually selected−1, so they supply no natural explicit-winner acceptance coverage and no selection-quality/performance inference.',
  'release_limit':'This is an exact source-qualified research variant with unknown generated runtimeversion metadata, not stock0.7.2 or a dependency upgrade qualification.'},
 'smallest_next_experiment':{
  'do_first':'Disposable GPU initializer admission, covering all four objective×values cells, with hashes outside performance execution: actual nine-profile domain/keys, candidate order, RNG draws, weights/scales and only targeted M144 A replacement. Reuse qualified native providers; do not repeat the whole source qualification.',
  'then_if_both_questions_remain':'Freeze and execute8 complete blocks×2 objectives×2 M144-values settings =32 fresh processes. No third objective, extra shapes, seeds or model matrix in this pilot.',
  'strict_smaller_alternative':'If only objective selection is the next decision,8 blocks×2 objectives at a fixed synthetic setting =16 processes is smaller and valid. Choose that scope before data; it does not answer the input-values question.',
  'not_needed':'Another oracle calibration, another unmodified current-source smoke, or a model throughput benchmark before a concrete mechanism contrast.'},
 'factorial_audit':{
  'verdict':'Adequately methodical as a fixed-case mechanism pilot, not rare-regression safety certification.',
  'strengths':['Fresh processes, fixed source/fixture/RNG and common default race; no historical pooling.','Complete four-cell blocks, balanced Williams launch schedule and independently balanced capture order.','Eight independent block units; paired rounds remain within-worker observations.','Prespecified two-factor contrasts, all-cell reporting, exploratory multiplicity adjustment and fixed stopping.','Real default misses, retained original graphs, owned-output poison/zero/restoration, traces after timing and no inline startup fingerprints.'],
  'freeze_before_launch':['The revised proposal fixes the arithmetic mean of eight block log contrasts, with median/range descriptive. Freeze bootstrap seed, resample count, interval construction and endpoint conventions before launch; do not change estimator after outcomes.','Use exact retained actual-public-capture inputs/tactic for post-timing raw acceptance, not factory preflight tensors; keep submitted lookup/capture provenance and trace of the same original graph. No native forwarding observer during profiling.','The revised proposal now declares the synthetic matched-copy arm as a modified initializer control. Retain that language in results: it is not untouched production auto, and values differences include source-address/content and unavoidable copy history.','State the exact failure/admission handling. Preserve unsupported selected descriptors, nonpositive measurements, incomplete blocks and all queue-query outcomes; no replacement or outcome-driven retries.'],
  'small_n':'Eight blocks can expose large failures but give weak tail-rate evidence. Zero/8 has approximately31.2percent one-sided95percent upper failure bound under the binomial model; fresh processes do not prove stationarity or statistical independence.',
  'estimand_limit':'A median across blocks can hide occasional large wrong choices; retain all failure counts/severities and cell distributions even if central factor contrasts are neutral.',
  'values_limit':'The intervention changes only exactM144 activation initialization while retaining nine profiles. It does not establish benefits from captured values at other shapes or isolate data distribution from all physical initialization effects.'},
 'next_PR_ranking':[
  {'rank':1,'owner':'FlashInfer','candidate':'Harness output-refresh validation: optional fixture-owned callback, guarded built-in FP8 refresh and honest coverage metadata.','size':'51 additions/2 removals in the benchmark before focused regression tests.','why':'Real no-write false acceptance is reproduced, and actual inference-output failure exposed/fixed a context gap. This is useful independently of which timing objective wins.','scope':'Keep FP8 descriptor port, configured-timer guard, SGLang adapter, dependency changes and performance assertions out of this PR. Preserve generic callers without callbacks and mark their refresh coverage unavailable.','go_gates':'Carry forward complete normal/inference × callback × correct/wrong/no-write CUDA evidence and unsafe-role controls; add/update compact upstream regressions with old-source failure controls, then check current upstream for duplicate work/rebase before opening. No32-process performance result is needed for this validation fix.'},
  {'rank':2,'owner':'FlashInfer','candidate':'Configured-timer distributed phase agreement, independent10-addition/2-removal correctness fix.','why':'Actual two-rank Gloo source-method controls demonstrate the guard omission and a conservative fix preserving None/events equivalence and persistent bytes.','limit':'Current single-rank/all-unspecified SGLang path is unaffected. It does not solve dynamic CUPTI fallback, delegated profilers or private globaltimer semantics; do not bundle or call it a performance blocker.'},
  {'rank':3,'owner':'Research/manual qualification','candidate':'Keep the captured-fixture adapter and acceptance evidence as manual study support.','limit':'No permanent SGLang flag solely to expose ReplayCoverage. Revisit operator-facing diagnostics only when an actionable operational need and released API exist.'}
 ],
 'production_no_go':['No graph-default policy change from a neutral or single-fixture pilot.','No old scoped prototype revival; current public context/persistence adoption remains a separate release/lifecycle decision.','Reviewed stable0.7.2.post1 lacks the newly reviewed APIs; verify the exact intended released dependency before adoption, rather than treating main-source qualification as release coverage.','No serving-throughput, full-model accuracy, fresh-process persistence, target/draft lifecycle or distributed GPU claim from these gates.'],
 'what_would_change_recommendation':['A failed GPU initializer/actual-selected acceptance admission blocks the factorial until its mechanism is understood.','A clear material graph-ranking regression with accepted explicit descriptor and same-object trace justifies a focused individual-timing follow-up at one prespecified values setting.','A reproducible factor benefit justifies confirmation without the matched-copy assay and then a bounded model-serving/lifecycle evaluation.','All-default or neutral factorial results justify stopping this fixed-case optimization claim; do not automatically widen the search.'],
 'publication_caution':'Final summaries should replace stale running/pending language with attempt02 success while preserving attempt01 failure separately. Historical plans/proposals remain historical. Qualify each result by its exact source/patch/protocol.',
 'evidence_sha256':{str(p.relative_to(STUDY)):sha(p) for p in (proposal,raw/'final-gate.json',raw/'native-facade.json',raw/'callback-controls.json',raw/'retained-auto.json',raw/'synthesized-auto.json',STUDY/'history-statistics-audit/final-summary.json',STUDY/'calibration-statistics-audit/final-summary.json',STUDY/'current-source-acceptance-design/design.json')}
}
# Plain wording around identifiers/counts for the review artifact.
replacements={'proposed32':'proposed 32','old-source12':'old-source 12','fixed32':'fixed 32','approximately18.9':'approximately 18.9','about1.3':'about 1.3','pinned27c62':'pinned 27c62',',12 normal':', 12 normal','selected−1':'selected −1','runtimeversion':'runtime version','stock0.7.2':'stock 0.7.2','execute8':'execute 8','only exactM144':'only exact M144','descriptor0':'descriptor 0','independent10':'independent 10','No32':'No 32','stable0.7.2':'stable 0.7.2','newly reviewed APIs':'newly reviewed APIs','block log-contrasts':'block log contrasts','approximately31.2':'approximately 31.2','one-sided95percent':'one-sided 95 percent'}
def clean(x):
 if isinstance(x,str):
  for a,b in replacements.items():x=x.replace(a,b)
  return x
 if isinstance(x,list):return [clean(v) for v in x]
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
 return x
p=ROOT/'recommendation.json';p.write_text(json.dumps(clean(report),indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p),'script_sha256':sha(__file__)},indent=2))
