"""Package two distinct qualification attempts and bounded research follow-ups."""

from __future__ import annotations

import argparse
import copy
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

ROOT = Path("/private/tmp/fi-next-steps-20261024")
OUTPUT = Path(
    "/private/tmp/sglang-autotune-selection-study/test/manual/kernels/results/"
    "flashinfer_autotune_selection/20261024T090000Z-h100-current-source-qualification"
)
TOKEN = bytes([118, 108, 108, 109])
ATTEMPTS = {
    "attempt01": {
        "archive": "current-source-coordinator/20261024T090000Z-h100-current-source-qualification-attempt01-full-raw.tgz",
        "sha256": "395c7e543cf701d194ed27d6698db5dec1599ece06399be496fcca7c2002bcbe",
        "expected_files": 68,
        "expected_public_exact": 32,
        "expected_public_derived": 3,
        "expected_launcher_exit": "1",
    },
    "attempt02": {
        "archive": "current-source-coordinator/raw/20261024T090000Z-h100-current-source-qualification-attempt02-full-raw.tgz",
        "sha256": "f78f59b928f68ee6108121e0920ae462ab32caaa562b64fd8d31bc8870b7e7f1",
        "expected_files": 81,
        "expected_public_exact": 44,
        "expected_public_derived": 4,
        "expected_launcher_exit": "0",
    },
}
EVIDENCE_FILES = [
    "current-source-audit/audit_attempt.py",
    "current-source-audit/audit_attempt02.py",
    "current-source-audit/attempt02-audit.json",
    "current-source-audit/attempt02-summary.json",
    "history-selection-diagnostics/diagnose.py",
    "history-selection-diagnostics/posthoc-diagnostics.json",
    "next-study-design/proposal.json",
    "current-source-acceptance-design/design.json",
    "current-source-acceptance-design/write_design.py",
    "final-next-step-audit/recommendation.json",
    "final-next-step-audit/write_recommendation.py",
    "fixture-validation-callback-revision02/check_inference_refresh.py",
    "fixture-validation-callback-revision02/inference-refresh-cpu-controls.json",
    "fixture-validation-callback-revision02/check_cuda_gate_cpu.py",
    "fixture-validation-callback-revision02/cuda-gate-cpu-admission.json",
    "fixture-validation-callback-revision02/harness-only.patch",
    "fixture-validation-callback-revision02/revision02-only.patch",
    "fixture-validation-callback-revision02/proposal.json",
    "current-source-coordinator/final-resource-check.log",
    "current-source-coordinator/scheduler-final.log",
    "current-source-coordinator/scheduler-settled.log",
    "current-source-coordinator/package_qualification_results.py",
]
NEW_NAMES = {
    "attempt01-raw.tar.gz",
    "attempt01-raw-member-index.json",
    "attempt02-raw.tar.gz",
    "attempt02-raw-member-index.json",
    "research-evidence.tar.gz",
    "research-evidence-member-index.json",
    "summary.json",
    "validation.json",
    "artifact-index.json",
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def file_sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def encoded(value):
    return (
        json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode()


def read(root, relative):
    return json.loads((root / relative).read_bytes())


def safe(data, label):
    assert TOKEN not in data.lower(), label


def metadata(data):
    return {"sha256": sha(data), "size_bytes": len(data)}


def make_archive(path, members):
    with (
        path.open("wb") as raw,
        gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0) as compressed,
    ):
        with tarfile.open(fileobj=compressed, mode="w") as archive:
            for name, data in sorted(members.items()):
                safe(data, name)
                record = tarfile.TarInfo(name)
                record.size, record.mode, record.mtime = len(data), 0o644, 0
                archive.addfile(record, io.BytesIO(data))


def derived_record(data, original_name):
    result = copy.deepcopy(json.loads(data))
    removed = result["import"].pop("source_modules")
    removed_aot = result["import"].pop("aot_providers")
    assert isinstance(removed, dict) and len(removed) == 510
    assert isinstance(removed_aot, list) and len(removed_aot) == 6
    result["publication_derivation"] = {
        "original_relative_path": original_name,
        "original_sha256": sha(data),
        "original_size_bytes": len(data),
        "removed_json_fields": {
            "import.source_modules": {
                "entries": len(removed),
                "canonical_json_sha256": sha(encoded(removed)),
            },
            "import.aot_providers": {
                "entries": len(removed_aot),
                "canonical_json_sha256": sha(encoded(removed_aot)),
            },
        },
        "rule": "Remove the exhaustive module and unrelated AOT-provider inventories; preserve every other decoded field. This derived record is not byte-identical to the original.",
    }
    return encoded(result)


def attempt_members(root, name, spec):
    raw = root / "current-source-coordinator/raw" / name
    full_archive = root / spec["archive"]
    assert file_sha(full_archive) == spec["sha256"]
    manifest = read(raw, "preservation-manifest.json")
    original = {}
    for row in manifest["files"]:
        path = Path(row["path"])
        assert not path.is_absolute() and ".." not in path.parts
        actual = raw / path
        assert actual.is_file() and not actual.is_symlink()
        data = actual.read_bytes()
        assert metadata(data) == {
            "sha256": row["sha256"],
            "size_bytes": row["size_bytes"],
        }
        original[str(path)] = data
    original["preservation-manifest.json"] = (
        raw / "preservation-manifest.json"
    ).read_bytes()
    assert len(original) == spec["expected_files"]
    assert {
        str(path.relative_to(raw)) for path in raw.rglob("*") if path.is_file()
    } == set(original)
    assert (
        original["launcher.exit-code"].decode().strip()
        == spec["expected_launcher_exit"]
    )
    archived = set()
    with tarfile.open(full_archive, "r:gz") as archive:
        for member in archive.getmembers():
            if member.isdir():
                continue
            assert member.isfile() and not member.issym()
            parts = Path(member.name).parts
            assert parts[0] == name and ".." not in parts
            relative = str(Path(*parts[1:]))
            assert relative not in archived
            assert archive.extractfile(member).read() == original[relative]
            archived.add(relative)
    assert archived == set(original)
    public, exact, derived, excluded = {}, {}, {}, {}
    for relative, data in sorted(original.items()):
        path = Path(relative)
        if path.parts[0] in {
            "native-artifacts",
            "native-build-cache",
        } or path.suffix in {".safetensors", ".so"}:
            excluded[relative] = {
                **metadata(data),
                "reason": "Private fixture tensor, native binary or native build cache.",
            }
        elif path.name == "native-facade.json" or path.name.endswith(".bootstrap.json"):
            destination = "derived/" + relative
            public[destination] = derived_record(data, relative)
            derived[destination] = {
                **metadata(public[destination]),
                "original": relative,
                "original_sha256": sha(data),
            }
            excluded[relative] = {
                **metadata(data),
                "reason": "Inventory-bearing original stays private; explicitly derived record removes import.source_modules and import.aot_providers.",
            }
        else:
            safe(data, relative)
            public[relative] = data
            exact[relative] = metadata(data)
    assert len(exact) == spec["expected_public_exact"]
    assert len(derived) == spec["expected_public_derived"]
    for relative, data in public.items():
        safe(data, relative)
    index = {
        "schema_version": 1,
        "attempt": name,
        "full_private_archive": {
            "durable_path": "/home/lnau/flashinfer-autotune-study/" + full_archive.name,
            "sha256": spec["sha256"],
            "size_bytes": full_archive.stat().st_size,
            "original_file_count": len(original),
            "preservation_manifest_sha256": sha(original["preservation-manifest.json"]),
        },
        "public_exact_members": exact,
        "public_derived_members": derived,
        "excluded_originals": excluded,
        "counts": {
            "exact": len(exact),
            "derived": len(derived),
            "excluded_originals": len(excluded),
            "archive_members": len(public),
        },
        "scope": "Exact members preserve their original bytes. Derived records are separately named and indexed; no claim that this is the unmodified full raw archive.",
    }
    return public, index


def evidence_members(root):
    members = {}
    for relative in EVIDENCE_FILES:
        path = root / relative
        assert path.is_file() and not path.is_symlink(), relative
        data = path.read_bytes()
        safe(data, relative)
        members[relative] = data
    original_name = "current-source-audit/attempt01-audit.json"
    original = (root / original_name).read_bytes()
    audit = json.loads(original)
    removed = audit.pop("passed_checks")
    audit["publication_derivation"] = {
        "original_relative_path": original_name,
        "original_sha256": sha(original),
        "original_size_bytes": len(original),
        "removed_json_field": "passed_checks",
        "removed_entries": len(removed),
        "removed_canonical_json_sha256": sha(encoded(removed)),
        "rule": "Omit exhaustive assertion labels containing imported-module names; preserve every other decoded field. This is a derived audit, not an unchanged original.",
    }
    derived = encoded(audit)
    safe(derived, "derived/attempt01-audit.json")
    members["derived/attempt01-audit.json"] = derived
    return members


def summary(root, indices):
    raw = root / "current-source-coordinator/raw"
    first = read(root, "current-source-audit/attempt01-audit.json")
    second = read(root, "current-source-audit/attempt02-audit.json")
    native01, native02 = (read(raw / name, "native-facade.json") for name in ATTEMPTS)
    source01, source02 = (
        native01["source"]["source_sha256"],
        native02["source"]["source_sha256"],
    )
    assert set(source01) == set(source02)
    assert [key for key in source01 if source01[key] != source02[key]] == [
        "benchmarks/bench_autotuner_accuracy.py"
    ]
    retained = read(raw / "attempt02", "retained-auto.json")
    synthesized = read(raw / "attempt02", "synthesized-auto.json")
    assert retained["trials"][0]["profile_count"] == 9
    assert synthesized["trials"][0]["profile_count"] == 81
    assert all(
        report["trials"][0]["tactic"] == "-1" for report in (retained, synthesized)
    )
    return {
        "schema_version": 1,
        "status": "Current-source correctness/provider and fixture API setup qualified on revision02; revision01 failure preserved.",
        "flashinfer_commit": "27c62fdf0ab1cd4014df8a15b66a975541fda83c",
        "source_variant": "FP8-only descriptor port plus optional benchmark fixture output-refresh callback; not stock released FlashInfer.",
        "attempt01": {
            "frozen_sglang_commit": (raw / "attempt01/sglang-commit-before.txt")
            .read_text()
            .strip(),
            "result": "Native/facade and six callback controls passed. Retained fixture gate failed on an inference-allocated output refreshed outside InferenceMode. Synthesized gate was not launched; launcher failed fast.",
            "independent_audit_status": first["status"],
            "independent_audit_checks": first["checks"],
        },
        "revision02": {
            "change": "Only the already-owned output NaN fill enters inference_mode; every ownership guard and callback position remains unchanged. Standalone callback controls now cover both normal and inference tensor allocation.",
            "frozen_sglang_commit": (raw / "attempt02/sglang-commit-before.txt")
            .read_text()
            .strip(),
            "result": "All four gates pass in four fresh containers: native-facade, twelve callback correctness controls plus four unsafe-role checks, retained-auto and synthesized-auto.",
            "independent_audit_status": second["status"],
            "independent_audit_checks": second["checks"],
            "native_control": "One explicit functionality descriptor is accepted at M144 and M129, with true memory hits and genuine default misses. Fifteen numerical guards and two retained graphs pass; zero profiling attempts.",
            "setup_smokes": {
                "retained": {
                    "profiles": 9,
                    "default_profiles": 1,
                    "runtime_key_m": 144,
                    "winner": -1,
                },
                "synthesized": {
                    "profiles": 81,
                    "default_profiles": 9,
                    "runtime_key_m": 256,
                    "winner": -1,
                },
            },
            "scope": "Two short validation rounds per smoke establish API/cache/numerics only. They are not independent performance trials and do not establish selected-descriptor acceptance for a future comparison.",
        },
        "provider_identity": {
            "source_difference_between_attempts": "Benchmark callback inference context only; exact native/runtime source hashes match.",
            "providers": {
                name: {
                    key: {
                        field: report["native"]["providers"][name][field]
                        for field in ("library_sha256", "ninja_sha256")
                    }
                    for key, report in (
                        ("attempt01", native01),
                        ("attempt02", native02),
                    )
                }
                for name in ("gemm", "trtllm_utils")
            },
            "note": "Build locations and the delay-helper ELF differ across attempts and are retained explicitly. Each attempt's fresh workers are checked against its own exact provider bytes; do not claim universal binary identity across attempts.",
        },
        "publication": {name: index["counts"] for name, index in indices.items()},
        "resources": {
            "allocation": 2793046,
            "deliberately_released_at_utc": "2026-10-24T09:23:46Z",
            "extern_completed_at_utc": "2026-10-24T09:23:47Z",
            "final_gpu": "No workload GPU processes and zero used memory; only the pre-existing monitor container remains.",
            "queue": "The settled snapshot has empty squeue output. The earlier CG snapshot is preserved separately and is not used as empty-queue evidence.",
        },
        "followups": {
            "history_diagnostics": "Exact posthoc diagnostic script/report retained separately; descriptive mechanisms and three observed slower explicit winners, not a new cohort or causal proof.",
            "next_study": "A proposed fixed objective-by-activation-values mechanism comparison is retained as a proposal, with individual timing deferred and rare-event/power limits explicit. No implementation or launch.",
            "native_acceptance_design": "Source-only design for guarding actual future selected-descriptor consumption outside timing; not implemented or established by the setup smokes.",
        },
        "limits": [
            "No serving-throughput, model-performance or small selection-improvement claim; setup smoke timings are deliberately not interpreted.",
            "Retained versus synthesized mode changes profile domain/cache keys and is not an activation-values-only contrast.",
            "No graph-policy persistence/restart, production dependency change, managed-store migration, distributed GPU/EP/MegaMoE/BF16 or full-model qualification.",
            "Public raw includes exact originals and clearly identified derived records. Exhaustive module manifests, private tensors, ELF/build cache and whole upstream source remain private.",
        ],
    }


def verify_archive(path, expected):
    with tarfile.open(path, "r:gz") as archive:
        actual = {}
        for member in archive.getmembers():
            assert member.isfile() and not member.issym()
            name = Path(member.name)
            assert not name.is_absolute() and ".." not in name.parts
            assert member.name not in actual
            data = archive.extractfile(member).read()
            safe(data, member.name)
            actual[member.name] = data
    assert actual == expected
    return len(actual)


def verify(root, output):
    count = 0
    indices = {}
    for name, spec in ATTEMPTS.items():
        members, index = attempt_members(root, name, spec)
        count += verify_archive(output / (name + "-raw.tar.gz"), members)
        assert read(output, name + "-raw-member-index.json") == index
        indices[name] = index
    evidence = evidence_members(root)
    count += verify_archive(output / "research-evidence.tar.gz", evidence)
    assert read(output, "research-evidence-member-index.json")["members"] == {
        name: metadata(data) for name, data in sorted(evidence.items())
    }
    assert read(output, "summary.json") == summary(root, indices)
    for name, expected in read(output, "artifact-index.json")["files"].items():
        assert metadata((output / name).read_bytes()) == expected
        count += 1
    for path in output.rglob("*"):
        if not path.is_file():
            continue
        safe(path.read_bytes(), str(path.relative_to(output)))
        if path.suffix == ".gz":
            with tarfile.open(path, "r:gz") as archive:
                for member in archive.getmembers():
                    assert member.isfile()
                    safe(archive.extractfile(member).read(), member.name)
                    count += 1
    return {
        "status": "success",
        "member_and_integrity_checks": count,
        "public_raw_members": {
            name: index["counts"] for name, index in indices.items()
        },
        "evidence_members": len(evidence),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path, default=OUTPUT)
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    if not args.verify_only:
        args.output.mkdir(parents=True, exist_ok=True)
        assert not NEW_NAMES.intersection(
            path.name for path in args.output.iterdir()
        ), "Do not overwrite packaged evidence."
        indices = {}
        for name, spec in ATTEMPTS.items():
            members, index = attempt_members(args.root, name, spec)
            indices[name] = index
            make_archive(args.output / (name + "-raw.tar.gz"), members)
            (args.output / (name + "-raw-member-index.json")).write_bytes(
                encoded(index)
            )
        evidence = evidence_members(args.root)
        make_archive(args.output / "research-evidence.tar.gz", evidence)
        (args.output / "research-evidence-member-index.json").write_bytes(
            encoded(
                {
                    "schema_version": 1,
                    "derived_members": ["derived/attempt01-audit.json"],
                    "members": {
                        name: metadata(data) for name, data in sorted(evidence.items())
                    },
                }
            )
        )
        (args.output / "summary.json").write_bytes(encoded(summary(args.root, indices)))
        validation = {
            "status": "success",
            "packager_sha256": file_sha(Path(__file__)),
            "private_full_archive_hashes_verified": {
                name: spec["sha256"] for name, spec in ATTEMPTS.items()
            },
            "full_preservation_members_rehashed": {
                name: spec["expected_files"] - 1 for name, spec in ATTEMPTS.items()
            },
            "all_original_extracted_files_compared_with_full_archives": {
                name: spec["expected_files"] for name, spec in ATTEMPTS.items()
            },
            "exact_and_derived_rule": "Only separately indexed public_exact_members are byte-identical. Derived raw copies remove import.source_modules and import.aot_providers, retain every other decoded field and record original/removed-field SHA and count. A derived audit separately omits exhaustive assertion labels.",
            "followups": "Posthoc diagnostics and two source-only future-study designs are evidence/proposals, not extra qualification results.",
            "scan": "Required case-insensitive byte pattern absent from every public file and every decompressed archive member. No fixture tensor, native binary/cache or whole upstream source included.",
            "limits": "Full original records remain in the hash-verified private durable archives. Numerical tensors are not independently reconstructed from these JSON reports; source/control assertions and native binaries are independently audited against the originals.",
        }
        (args.output / "validation.json").write_bytes(encoded(validation))
        files = {
            str(path.relative_to(args.output)): metadata(path.read_bytes())
            for path in sorted(args.output.rglob("*"))
            if path.is_file()
        }
        (args.output / "artifact-index.json").write_bytes(
            encoded({"schema_version": 1, "files": files})
        )
    print(json.dumps(verify(args.root, args.output), sort_keys=True))


if __name__ == "__main__":
    main()
