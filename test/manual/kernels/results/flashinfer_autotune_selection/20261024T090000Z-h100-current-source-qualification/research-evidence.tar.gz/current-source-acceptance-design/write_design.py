from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
STUDY=ROOT.parent
FI=STUDY/'current-source-qualification/fp8-runtime'
HARNESS=STUDY/'fixture-validation-callback-revision02/benchmarks/bench_autotuner_accuracy.py'
SG=Path('/private/tmp/sglang-autotune-selection-study/python/sglang/srt/layers/quantization/fp8_utils.py')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files=[(FI/'flashinfer/gemm/gemm_base.py',[230,237,273,281,334,349]),(FI/'csrc/bmm_fp8.cu',[140,197,206]),(FI/'include/flashinfer/gemm/bmm_fp8.cuh',[168,204,332]),(FI/'csrc/flashinfer_gemm_binding.cu',[26,37]),(HARNESS,[442,486,569,609]),(SG,[532,549,2351])]
report={
 'schema_version':1,
 'status':'source_design_only_no_implementation_or_GPU_execution',
 'decision':'Use the exact raw descriptor entrypoint on the selected graph retained operands after all primary timing; no native proxy or observer in profiling.',
 'source_commit':'27c62fdf0ab1cd4014df8a15b66a975541fda83c',
 'sglang_frozen_execution_commit':'12447b7d6219d54d1296401c0b8cfeeff1568931',
 'runtime_port_patch_sha256':'e5c0a130690cd9fe9f1204b11368433430345f066ee8dc3bd376cf49c7ef4d64',
 'source_evidence':[{'path':str(p),'sha256':sha(p),'relevant_lines':lines} for p,lines in files],
 'exact_call':{
  'selected_runner':'CublasFp8GemmRunner only; no additional runner kwargs for the pinned FP8 call.',
  'original_input_order':['a','b','scale_a','scale_b','out','workspace_buffer'],
  'descriptor_helper':'flashinfer.gemm.gemm_base._cublaslt_algo_arg(tactic)',
  'descriptor_contract':'Use the actual selected tuple of eight uint64 words, not a heuristic ordinal or re-enumerated algorithm. The unchanged helper returns a cached contiguous CPU uint8 tensor of exactly64bytes.',
  'native_call':'int(raw_gemm_native.bmm_fp8_run_with_descriptor(a, b, out, scale_a, scale_b, workspace_buffer, gemm_base._cublaslt_algo_arg(tactic)))',
  'required_return':1,
  'faithfulness':'This is exactly the explicit-tactic call made by CublasFp8GemmRunner.forward, with the original argument reordering. The omitted Python _check_cublaslt_descriptor_ran only raises on rejection during profiling; the diagnostic instead always requires returned1.',
  'default_tactic':'For actualtactic−1, skip descriptoracceptance and report native-default route. The runner calls raw_gemm_native.bmm_fp8(a,b,out,scale_a,scale_b,workspace_buffer). run_with_descriptor(None) is a different exported route and is not defaultpath proof.'},
 'raw_provider_retention':{
  'requirement':'Use the exact raw TVM FFI module already explicitly built/loaded and bound to the public runner, with the same recorded ELF SHA. Do not load another artifact or recover it through a forwarding observer.',
  'existing_bootstrap_option':'container_preflight.explicit_native_build(source,native_module_callback=retain_raw) can retain native in setup and return the identical object. No wrapper, native-method replacement or per-call callback is needed; callback executes only during one-time bootstrap.',
  'helper_sha256':sha(STUDY/'current-source-qualification/container_preflight.py'),
  'provenance_wording':'A setup callback retaining the original object is not a native-call observation. Record that the bound provider is the original raw module.'},
 'minimal_order':[
  'Complete tuning, graph capture, all primary timing blocks and their normal numerical checks with the raw unwrapped provider. Retain the original selected tactic, input tensors and graph object.',
  'Outside every timing region, profile-measurement scope and CUDA capture, restore any changed logical input and replay the original graph once if needed so captured quantized activation is current. Synchronize the intended current stream.',
  'Assert the exact recorded graph-input objects, ptrs, dtypes, shapes, strides, workspace pointer/bytes and descriptor bytes remain unchanged. Preserve strong ownership; do not clone or recreate operands, output or workspace.',
  'Run the already-reviewed output-role guard. Poison only declared floating output4 inside torch.inference_mode(); all alias/dtype/device/contiguity checks remain before mutation.',
  'On the same host thread/device and intended current stream, make the exact raw descriptor call. Require returned1; synchronize and validate output against the frozen actual-quantized FP32 reference. Native successreturn alone is insufficient for asynchronous errors or no-write.',
  'Poison that output again outside capture and replay the same original selected graph. Synchronize and validate independently so the preceding directcall cannot satisfy graph numerics through stale output.',
  'Retain all raw results and any returned0/exception as an explicit validity failure. Do not choose another descriptor, retry, drop the trial or claim selected-descriptor speed from fallback. No more primary timing follows diagnostics.'
 ],
 'graph_scope_boundary':{
  'official_harness':'capture_choose_one_calls obtains the actual public-call sixinput objects; graph_selection_study then captures runner graphs with those retained inputs. The rawcall gate can use its localinputs and selectedtactic directly with no new profiling/capture hook. This qualifies BMMcomponent graphs, excluding SGLang quantizer/public lookup/allocation.',
  'full_public_SGLang_graph':'SGLang apply_fp8_linear_bmm_flashinfer quantizes afresh and calls decorated public BMM without out; that API allocates output. Factory captured_problem buffers therefore do not identify the later publicgraph actual A/output.',
  'full_public_requirement':'Reuse existing capture-input retention if available. Otherwise a capture-only forwarding choose_one recorder may retain actualinputs/returnedrunner/tactic, installed only during untimed capture after profiling and removed before timing. It must return the untouched original result, do no tensor hashing/copy/extra CUDA work, and never run inside profiling. Then diagnose those exact retained capture objects after primary timing.',
  'pre_capture_limit':'The exact private quantizer/output allocations of a full publicgraph do not exist before its capture. A beforecapture probe on different allocations cannot establish an exact-input claim for it.',
  'perturbation_limit':'Posttiming CUDA probes cannot change completed measurements. Any capture-only tensor ownership/recording remains declared setup history; this is not a claim of universally zero process-history effects.'},
 'what_return1_means':{
  'proven':'The exact checked exported implementation resolved to caller descriptor and enqueued cublasLtMatmul with it; native wrapper raises on immediate cuBLAS failure. Synchronization/numerics add completion and output-write checks.',
  'memoization_limit':'ResolvedAlgoCache caches from_descriptor by descriptor bytes and exact device/batch/M/N/K/dtypes/workspace bytes. A returned1 may come from that existing memo, not a fresh cublasLtMatmulAlgoCheck. Do not claim AlgoCheck counts or fresh validation.',
  'graph_limit':'The actual returned flag is observed on the posttiming rawcall. Capture uses the same source/provider/descriptor/problem; do not label the flag as directly observed during graph capture/replay or as physical kernel-launch identity.',
  'not_proven':'Fastest selection, graph objective quality, portability to other shapes/workspaces/libraries, persistence compatibility, broad backends or serving speed.'},
 'consumption_evidence_boundary':{
  'raw_diagnostic_claim':'Observed post-timing raw return checks viability/submission of the chosen descriptor on the exact retained actual-public-capture problem after timing. It is not a recorded native return from capture.',
  'required_companion_provenance':'Real capture lookup hit, submitted tactic/runner and exact input object/pointer metadata must bind to the original public graph object. Factory preflight inputs are insufficient.',
  'required_same_graph_trace':'Trace replays of that same original retained graph only after all primary timings; preserve actual CUDA graph/launch correlation and ordered kernel launch signatures. Do not recapture a similar graph for this evidence.',
  'interpretation':'Together these support descriptor-consumption reasoning for the checked source and actual graph. Keep the post-timing acceptance flag, submitted capture tactic and observed launch trace as distinct evidence; do not collapse them into an unobserved capture-time flag or opaque algorithm physical-identity proof.'},
 'minimal_evidence':[
  'Provider ELF/ninja/source hashes; exact source/patch pin; selected runner/tactic tuple and serialized64byte hash.',
  'Original graph ID/object ownership and pointers/metadata for all6actualcapturedinputs; cache-hit selection and policy identity as separate evidence.',
  'Chronology proving primary timing ended before output poison/native diagnostic/replay; no profiling or CUDA capture active.',
  'Actual returnedflag1, synchronization completion, independent directcall numerics and separately poisoned originalgraph replay numerics.',
  'Submitted capture tactic/lookup provenance plus same original publicgraph replay trace after timing; no replacement capture.',
  'Default−1 explicitly marked notapplicable for descriptoracceptance; rejected0/exception retained without replacement.'
 ],
 'stopping_boundary':'No third qualification now. Prepare this narrow diagnostic only when the next performance protocol is reviewed and frozen.'}
# Keep prose readable while preserving identifiers.
replacements={'exactly64bytes':'exactly 64 bytes','returned1':'returned 1','actualtactic−1':'actual tactic −1','descriptoracceptance':'descriptor acceptance','defaultpath':'default path','sixinput':'six-input','localinputs':'local inputs','selectedtactic':'selected tactic','rawcall':'raw call','publicgraph':'public graph','beforecapture':'before-capture','Posttiming':'Post-timing','posttiming':'post-timing','successreturn':'success return','directcall':'direct call','BMMcomponent':'BMM component','serialized64byte':'serialized 64-byte','all6actualcapturedinputs':'all six actual captured inputs','returnedflag1':'returned flag 1','Default−1':'Default −1','notapplicable':'not applicable','rejected0':'rejected 0','originalgraph':'original graph'}
def clean(x):
 if isinstance(x,str):
  for a,b in replacements.items():x=x.replace(a,b)
  return x
 if isinstance(x,list):return [clean(v) for v in x]
 if isinstance(x,dict):return {k:clean(v) for k,v in x.items()}
 return x
report=clean(report)
p=ROOT/'design.json';p.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'path':str(p),'sha256':sha(p),'script_sha256':sha(__file__)},indent=2))
