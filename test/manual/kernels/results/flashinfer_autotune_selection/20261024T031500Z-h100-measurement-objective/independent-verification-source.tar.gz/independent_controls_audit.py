"""Independent stdlib audit of preserved objective-study numerical/control evidence."""
import argparse
import ast
import collections
import hashlib
import itertools
import json
import math
import random
import re
import struct
import subprocess
from pathlib import Path

REPO = Path("/private/tmp/sglang-autotune-selection-study")
WORKER = "test/manual/kernels/flashinfer_autotune_measurement_objective.py"
POLICY_SHA = "7be4f83162ce3afada8593f5acd863769356da74102e6762ece133548a4d8bda"
POLICY = {"execution_mode": "cuda_graph", "cold_l2": None, "_timer": "auto"}
IDENTITY = "('__policy__', ('measure_execution_mode', 'cuda_graph'))"
IDS = ("winner", "default")

def sha(data):
    return hashlib.sha256(data).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)

def read(path):
    return json.loads(path.read_text())

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    root = args.root
    checks, errors = 0, []
    def check(name, condition):
        nonlocal checks
        checks += 1
        if not condition:
            errors.append(name)
    commit = (root/"execution-commit.txt").read_text().strip()
    outer = read(root/"manifest.json")
    fixture = read(root/"fixture/manifest.json")
    build = read(root/"native-build-provenance.json")
    blob = lambda name: subprocess.check_output(["git","show",commit+":"+name],cwd=REPO)
    check("successful launcher", (root/"launcher.exit-code").read_text().strip()=="0")
    for path,value in outer["source_sha256"].items():
        check("frozen source "+path,sha(blob(path))==value)
    worker_bytes=blob(WORKER)
    check("frozen worker SHA",sha(worker_bytes)=="fc69ed3a7f90d579144cfa557e5d69e104e00204689e3842cd152fe097112541")
    check("policy source pin",sha(Path("/private/tmp/fi-descriptor-source/repo/flashinfer/autotune_cache.py").read_bytes())==POLICY_SHA)
    fixture_bytes=(root/"fixture/fixture.safetensors").read_bytes()
    check("private fixture SHA",sha(fixture_bytes)==fixture["tensor_file"]["sha256"]==outer["fixture_tensor_file_sha256"])
    size=struct.unpack("<Q",fixture_bytes[:8])[0]
    header=json.loads(fixture_bytes[8:8+size]);payload=fixture_bytes[8+size:]
    tensors={}
    for name,row in fixture["tensors"].items():
        metadata=header[name];start,end=metadata["data_offsets"];value=payload[start:end]
        check("private fixture tensor "+name,sha(value)==row["sha256"] and len(value)==row["nbytes"] and metadata["shape"]==row["shape"])
        tensors[name]=value
    b_sha=sha(b"".join(tensors["weight_fp8_rowmajor"][i::1024] for i in range(1024)))
    zero_sha=sha(bytes(144*4096*2))
    lib=root/"native-builds/candidate/gemm.so";ninja=root/"native-builds/candidate/build.ninja"
    library_bytes=lib.read_bytes();native=build["arms"]["candidate"]
    check("private ELF header",library_bytes[:4]==b"\x7fELF" and library_bytes[4]==2 and struct.unpack("<H",library_bytes[18:20])[0]==62)
    check("private ELF SHA/size",sha(library_bytes)==native["library"]["sha256"] and len(library_bytes)==native["library"]["size"])
    check("native ninja SHA",sha(ninja.read_bytes())==native["ninja"]["sha256"])
    text=ninja.read_text()
    check("SM90a compile target","-gencode=arch=compute_90a,code=sm_90a" in text)
    compiled=re.findall(r"^build .+: (?:cuda_compile|compile) (.+)$",text,re.M)
    check("three native translation units",len(compiled)==3 and {Path(p).name for p in compiled}=={"bmm_fp8.cu","group_gemm.cu","flashinfer_gemm_binding.cu"})
    check("native collector success",build["status"]=="success" and not build["errors"] and not build["missing_records"] and build["validated_native_records"]==12)
    references={r["result"]:r["result_sha256"] for r in native["validated_worker_results"]}
    counts=collections.Counter();signatures=[];outputs=set();containers=set();summaries=[]
    raw_hashes={}
    for trial in range(6):
        check("trial exit "+str(trial),(root/f"trial{trial}.launcher.exit-code").read_text().strip()=="0")
        for arm in ("auto","cuda_graph"):
            name=f"trial{trial}-{arm}-timing";path=root/(name+".json");x=read(path);raw_hashes[path.name]=sha(path.read_bytes())
            label=name+": "
            policy=None if arm=="auto" else POLICY
            identity="None" if arm=="auto" else IDENTITY
            fields={} if arm=="auto" else {"measure_execution_mode":"cuda_graph"}
            check(label+"worker identity",x["status"]=="success" and x["implementation"]=="candidate" and x["mode"]=="timing" and x["phase"]=="cold" and x["trial"]==trial and x["arm"]==arm and x["seed"]==19 and x["shape"]==[144,4096,1024])
            check(label+"source identity",x["worker_sha256"]==sha(worker_bytes) and x["environment"]["sglang_commit"]==commit)
            check(label+"collector binding",references[path.name]==sha(path.read_bytes()))
            check(label+"worker exit",(root/(name+".exit-code")).read_text().strip()=="0")
            cid=(root/(name+".container-id")).read_text().strip();check(label+"container ID",re.fullmatch("[0-9a-f]{64}",cid) is not None);containers.add(cid)
            env=x["environment"];actual_native=env["native_artifact"]
            check(label+"policy source",env["flashinfer_autotune_cache_sha256"]==POLICY_SHA)
            check(label+"unobserved native build",not env["LD_PRELOAD"] and actual_native["library_sha256"]==sha(library_bytes) and actual_native["ninja_sha256"]==sha(ninja.read_bytes()) and actual_native["source_sha256"]==native["all_runtime_source_sha256"])
            check(label+"fixture bytes",env["operand_sha256"]=={n:r["sha256"] for n,r in fixture["tensors"].items()})
            profiles=x["profiles"];counts["profiles"]+=len(profiles)
            check(label+"only startup profiles",len(profiles)==x["profile_attempts"]==81 and not x["forbidden_profile_attempts"])
            by_bucket=collections.defaultdict(list);signature=[]
            for i,p in enumerate(profiles):
                q=label+f"profile{i}: ";group=x["profiling_input_groups"][p["profiling_input_group"]]
                check(q+"scope/objective",p["stage"]=="startup" and p["runner"]=="CublasFp8GemmRunner" and p["use_cuda_graph"]==(arm=="cuda_graph") and p["use_cold_l2_cache"] is False and p["default_race_enabled"] is True)
                check(q+"positive finite",type(p["profiler_ms"]) in (int,float) and math.isfinite(p["profiler_ms"]) and p["profiler_ms"]>0 and not p.get("error"))
                counts["finite_profiles"]+=1;counts["default_profiles"]+=p["tactic"]==-1
                check(q+"policy identity",p["policy_identity"]==identity and p["policy_manifest_fields"]==fields)
                s=p["autotuner_settings"];cfg=s["config"]
                check(q+"nonobjective settings",(s["warmup"],s["repeat"],s["stream_delay_micro_secs"],s["cuda_graph_delay_micro_secs"],s["use_global_timer"])==(3,10,5000,100,False) and cfg=={"use_cuda_graph":arm=="cuda_graph","use_cold_l2_cache":False,"cuda_graph_profile_replays":1,"profiling_repeat":None,"effective_profiling_repeat":10})
                check(q+"actual policy/timer",s["effective_measure_policy"]==policy and s["effective_policy_timer"]==("events" if arm=="cuda_graph" else None))
                check(q+"input fingerprint",set(group)=={"activation","weight","input_scale","weight_scale"} and sha(canonical(group).encode())==p["profiling_input_group"])
                check(q+"actual static profiling operands",group["weight"]["sha256"]==b_sha and group["input_scale"]["sha256"]==fixture["tensors"]["input_scale"]["sha256"] and group["weight_scale"]["sha256"]==fixture["tensors"]["weight_scale"]["sha256"])
                for j,n in enumerate(("activation","weight","input_scale","weight_scale")):
                    check(q+"operand shape "+n,group[n]["shape"]==p["input_shapes"][j])
                key=canonical(p["normalized_profile"]);by_bucket[key].append(p)
                signature.append({k:p[k] for k in ("runner","tactic","input_shapes","normalized_profile","profiling_input_group")}|{"defaults":{k:s[k] for k in ("warmup","repeat","stream_delay_micro_secs","cuda_graph_delay_micro_secs","use_global_timer")},"repeat":cfg["effective_profiling_repeat"]})
            check(label+"nine profile input groups",len(x["profiling_input_groups"])==len(by_bucket)==9)
            signatures.append(canonical({"profiles":signature,"groups":x["profiling_input_groups"]}))
            for bucket,rows in by_bucket.items():
                check(label+"complete candidate bucket "+bucket,len(rows)==9 and rows[0]["tactic"]==-1 and len({canonical(p["tactic"]) for p in rows})==9 and len({p["profiling_input_group"] for p in rows})==1)
            runtime=[p for p in profiles if p["normalized_profile"]==x["runtime_profile_summary"]["normalized_profile"]]
            minimum=min(p["profiler_ms"] for p in runtime);minima=[p["tactic"] for p in runtime if p["profiler_ms"]==minimum]
            check(label+"runtime winner/minimum",x["natural"]["tactic"] in minima and x["natural"]["tactic"]==-1 and len(runtime)==9 and x["runtime_profile_summary"]["minimum_ms"]==minimum and x["runtime_profile_summary"]["minimum_tactics"]==minima)
            counts["default_runtime_winners"]+=1
            objective=x["objective"]
            check(label+"requested policy",objective["requested_policy"]==policy and objective["manifest_fields"]==fields and objective["startup_api_calls"]==[{"mode":"tune","persistent_cache":False,"measurement_policy":policy}] and not objective["protocol_errors"])
            for row in objective["scope_records"]:
                active=row["event"]!="after_exit";startup=row["stage"]=="startup"
                check(label+"scope lifecycle",row["active_v2"] is active and row["measurement_policy"]==(policy if active else None) and row["winner_identity"]==(identity if active else "None") and row["managed_store"] is False and row["is_tuning_mode"] is startup and row["tuning_contexts"]==(2 if startup and active else 1 if startup else 0))
            check(label+"scope final state",objective["final_state"]=={"active_v2":False,"measurement_policy":None,"is_tuning_mode":False,"tuning_contexts":0,"managed_store":False,"caller_stream_restored":True})
            selection={s["stage"]:s for s in x["selections"]}
            check(label+"no loaded file choices",all(s["lookup_tier"] in ("miss","memory") for s in x["selections"]))
            graph_rows={g["id"]:g for g in x["graph_controls"]["graphs"]}
            check(label+"distinct retained outputs",set(graph_rows)==set(IDS) and len({g["output"]["data_ptr"] for g in graph_rows.values()})==2)
            for gid,g in graph_rows.items():
                tier="memory" if gid=="winner" else "miss"
                check(label+"capture "+gid,g["tactic"]==-1 and g["lookup_tier"]==tier and g["policy_identity"]==identity and g["measurement_policy"]==policy and g["selection"]["capturing"] is True and g["selection"]["active_v2"] is True and g["selection"]["is_tuning_mode"] is False and g["selection"]["cache_hit"] is (gid=="winner") and g["inputs"][4]["data_ptr"]==g["output"]["data_ptr"])
                check(label+"capture actual fixture "+gid,g["quantized_input_sha256"]==fixture["quantization"]["independent_input_fp8_sha256"] and g["weight_rowmajor_sha256"]==fixture["tensors"]["weight_fp8_rowmajor"]["sha256"] and g["input_scale_sha256"]==fixture["tensors"]["input_scale"]["sha256"] and g["weight_scale_sha256"]==fixture["tensors"]["weight_scale"]["sha256"])
                counts["retained_graphs"]+=1
            rows=x["correctness"]["checks"];counts["numerical_checks"]+=len(rows);check(label+"64 distinct numerical checks",len(rows)==len({r["check"] for r in rows})==64 and x["correctness"]["passed"] is True)
            metrics_max=0.0
            for row in rows:
                q=label+row["check"]+": ";zero=row["exact_zero_required"];qr=row["quantized_reference"];br=row["bf16_reference"]
                check(q+"reference pass",qr["passed"] is True and qr["max_normalized_error"]<=1 and qr["max_abs_error"]==row["max_abs_error"] and br["diagnostic_only"] is True)
                for ref in (qr,br):
                    check(q+"finite metrics",all(math.isfinite(v) and v>=0 for k,v in ref.items() if type(v) in (int,float)))
                metrics_max=max(metrics_max,qr["max_normalized_error"])
                if zero:
                    counts["exact_zero_checks"]+=1
                    check(q+"independent zero-output SHA",row["output_sha256"]==zero_sha and all(qr[k]==0 and br[k]==0 for k in ("max_abs_error","max_normalized_error","rmse","relative_l2")))
                else: outputs.add(row["output_sha256"])
                gid=row["graph_id"]
                if gid is not None:
                    counts["owned_output_checks"]+=1
                    check(q+"actual graph output owner",gid in graph_rows and row["output_data_ptr"]==graph_rows[gid]["output"]["data_ptr"])
            for gid in IDS:
                for suffix in ("_changed_input","_restored_input"):
                    row=next(r for r in rows if r["check"]==gid+suffix)
                    check(label+"changed/restored graph "+gid+suffix,row["graph_id"]==gid and row["exact_zero_required"] is (suffix=="_changed_input"))
            bindings=x["binding_acceptance_checks"];counts["native_acceptance_guards"]+=len(bindings)
            check(label+"default native entry guards",len(bindings)==9 and all(r["accepted"] is True and r["tactic"]==-1 and r["used_descriptor"]==[] for r in bindings))
            poisons=x["actual_layer"]["native_output_poison_checks"]
            check(label+"actual native poison gates",len(poisons)==9 and all(r["poisoned_actual_allocation"] is (not r["capturing"]) for r in poisons))
            public=x["actual_layer"]["observed_public_inputs"]
            for row in public:
                if row["capturing"] or row["stage"] in ("startup","natural_eager_changed_input"):continue
                check(label+"observed actual input bytes "+row["stage"],row["quantized_input_sha256"]==fixture["quantization"]["independent_input_fp8_sha256"] and row["weight_rowmajor_sha256"]==fixture["tensors"]["weight_fp8_rowmajor"]["sha256"] and row["input_scale_sha256"]==fixture["tensors"]["input_scale"]["sha256"] and row["weight_scale_sha256"]==fixture["tensors"]["weight_scale"]["sha256"])
            scope=x["graph_controls"]["miss_scope"][0]
            check(label+"genuine miss restoration",scope["winner_entries_before"]==9 and scope["file_entries_before"]==scope["winner_entries_after_removal"]==scope["file_entries_after_removal"]==0 and scope["restored"] is True and scope["all_cache_state_restored"] is True and scope["winner_contents_sha256_before"]==scope["winner_contents_sha256_after"] and scope["file_contents_sha256_before"]==scope["file_contents_sha256_after"] and scope["cache_sha256_before"]==scope["cache_sha256_after"])
            cache_path=root/"caches"/(name+".json");cache=read(cache_path);generation=cache.pop("_generation")
            check(label+"incidental cache bytes/generation",sha(cache_path.read_bytes())==x["cache"]["after_startup_sha256"]==x["cache"]["after_controls_sha256"] and sha(canonical(cache).encode())==generation)
            entries={k:v for k,v in cache.items() if k.startswith("(")}
            check(label+"legacy scope exclusion",not x["cache"]["persistence_under_test"] and len(entries)==x["cache"]["incidental_legacy_entries"]==(9 if arm=="auto" else 0))
            for key,value in entries.items():
                node=ast.parse(key,mode="eval").body;bucket=ast.literal_eval(node.elts[2]);candidates=by_bucket[canonical([list(s) for s in bucket])]
                best=min(p["profiler_ms"] for p in candidates)
                check(label+"actual legacy partition serialization",value[1] in [p["tactic"] for p in candidates if p["profiler_ms"]==best] and value[2]==["cuda_graph_profile_replays",None,"l2_cache_policy","hot"])
            controls=x["graph_controls"];expected=[list(p) for _ in range(12) for p in itertools.permutations(IDS)];random.Random(5000+trial).shuffle(expected)
            check(label+"balanced paired block orders",controls["schedule"]==expected and len(controls["blocks"])==24 and controls["common_iterations"]==5120)
            for row in controls["sequential"]:
                check(label+"sequential outside scopes",row["policy_scope_active"] is False and row["tuning_mode"] is False and row["profile_attempts_before"]==row["profile_attempts_after"]==81 and row["measurement"]["warmup_actual_ms"]>=500)
            for i,block in enumerate(controls["blocks"]):
                check(label+f"block{i} order",block["index"]==i and block["order"]==expected[i] and [r["graph_id"] for r in block["measurements"]]==expected[i])
                for row in block["measurements"]:
                    counts["replay_batches"]+=1
                    check(label+"bare replay batch",row["iterations"]==5120 and row["policy_scope_active"] is False and row["tuning_mode"] is False and row["rewarm_actual_ms"]>=20 and row["rewarm_calls"]>=5120)
                    check(label+"event/wall normalization",all(math.isfinite(row[k]) and row[k]>0 for k in ("wall_batch_ms","gpu_event_batch_ms")) and math.isclose(row["wall_batch_ms"]/5120,row["wall_per_call_ms"],rel_tol=1e-12) and math.isclose(row["gpu_event_batch_ms"]/5120,row["gpu_event_per_call_ms"],rel_tol=1e-12))
            check(label+"observer absent",x["observer"]["enabled"] is False and not x["observer"]["preload_files"] and not x["observer"]["phases"] and x["observer"]["trace"] is None)
            summaries.append({"trial":trial,"arm":arm,"profiles":len(profiles),"runtime_winner":x["natural"]["tactic"],"numerical_checks":len(rows),"maximum_quantized_normalized_error":metrics_max,"legacy_entries":len(entries)})
    check("12 fresh containers",len(containers)==12)
    check("identical candidates/profiling operands/nonobjective settings",len(set(signatures))==1)
    check("all restored/nonzero outputs bitwise identical",len(outputs)==1)
    check("all 972 profiles finite",counts["profiles"]==counts["finite_profiles"]==972)
    check("all 12 runtime winners default",counts["default_runtime_winners"]==12)
    tree=ast.parse(worker_bytes)
    interleave=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=="interleave")
    timed=[n for n in ast.walk(interleave) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=="batch"]
    check("source raw replay passed to batch",len(timed)==1 and ast.unparse(timed[0].args[1])=="graph.graph.replay")
    report={"status":"success" if not errors else "failure","immutable_final":True,"source_commit":commit,"worker_sha256":sha(worker_bytes),"audit_source_sha256":sha(Path(__file__).read_bytes()),"independent_assertions":checks,"errors":errors,"counts":dict(counts),"workers":summaries,"all_nonzero_output_sha256":sorted(outputs),"independent_zero_output_sha256":zero_sha,"fixture_sha256":sha(fixture_bytes),"native_elf_sha256":sha(library_bytes),"native_elf_size_bytes":len(library_bytes),"native_ninja_sha256":sha(ninja.read_bytes()),"policy_source_sha256":POLICY_SHA,"profile_inputs_and_candidates_identical_all_12":len(set(signatures))==1,"worker_result_sha256":raw_hashes,"limitations":["Audit imports no main analyzer and executes no GPU operation or benchmark worker.","Checks reported numerical metrics and actual zero-output hashes, not unavailable full intermediate output arrays or independent native-kernel calculations.","All runtime winners are default -1: native default-path guards run, but this cohort has no selected explicit-descriptor serving winner.","Private fixture tensor bytes and actual preserved native ELF/ninja are rehashed; native source input bindings also rely on the preserved on-host collector record.","One fixed FP8 linear fixture. No full-model accuracy, persistence, physical kernel identity or serving-performance claim."]}
    args.output.write_text(json.dumps(report,indent=2)+"\n");args.output.chmod(0o444)
    print(json.dumps({k:report[k] for k in ("status","independent_assertions","errors","counts")}))
    if errors: raise SystemExit(1)

if __name__=="__main__":main()
