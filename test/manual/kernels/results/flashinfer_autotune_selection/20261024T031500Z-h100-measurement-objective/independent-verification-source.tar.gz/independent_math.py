#!/usr/bin/env python3
"""Recompute objective-study arithmetic from raw records, without analyzer imports."""

from __future__ import annotations

import argparse
import functools
import hashlib
import itertools
import json
import math
import statistics
from pathlib import Path

ARMS = ("auto", "cuda_graph")
GRAPHS = ("winner", "default")
CHANNELS = {"gpu_event": "gpu_event_batch_ms", "wall": "wall_batch_ms"}
SOURCE_COMMIT = "e1024dc062cd252f72730359ab1d695d0c221178"


def check(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    def invalid(value):
        raise ValueError("nonfinite JSON: " + value)
    data = json.loads(path.read_text(), parse_constant=invalid)
    return data


def positive(value):
    return type(value) in (int, float) and math.isfinite(value) and value > 0


def percentile(ordered, probability):
    position = probability * (len(ordered) - 1)
    left, right = math.floor(position), math.ceil(position)
    return ordered[left] + (ordered[right] - ordered[left]) * (position - left)


@functools.lru_cache(maxsize=None)
def bootstrap(values):
    """Enumerate all ordered resamples of whole trial estimates independently."""
    if len(values) < 2:
        return None
    distribution = sorted(
        statistics.median(values[index] for index in indices)
        for indices in itertools.product(range(len(values)), repeat=len(values))
    )
    return {"level": 0.95, "lower": percentile(distribution, 0.025),
            "upper": percentile(distribution, 0.975), "ordered_resamples": len(distribution),
            "independent_trials": len(values), "exploratory_unadjusted": True,
            "method": "exhaustive ordered percentile bootstrap of whole trial medians"}


def summary(rows, with_bootstrap=True):
    check(rows and len({row["trial"] for row in rows}) == len(rows), "duplicate/empty trial units")
    values = [row["ratio"] for row in rows]
    check(all(positive(value) for value in values), "invalid trial ratio")
    return {"trial_estimates": rows, "independent_trials": len(values),
            "median_ratio": statistics.median(values), "min_ratio": min(values), "max_ratio": max(values),
            "median_change_percent": (statistics.median(values) - 1) * 100,
            "ratios_below_one": sum(value < 1 for value in values),
            "ratios_equal_one": sum(value == 1 for value in values),
            "ratios_above_one": sum(value > 1 for value in values),
            "exploratory_whole_trial_bootstrap_95_percent": bootstrap(tuple(values)) if with_bootstrap else None}


def runtime_shape(shape):
    m, n, k = shape
    return [[1, 2 ** (m - 1).bit_length(), k], [1, k, n], [1], [1], [1, -1, n], [-1]]


def profile_margins(data):
    expected = runtime_shape(data["shape"])
    rows = [row for row in data["profiles"] if row["normalized_profile"] == expected]
    finite = [row for row in rows if positive(row.get("profiler_ms"))]
    check(finite and len([row for row in rows if row["tactic"] == -1]) == 1, "runtime profile/default coverage")
    default = next(row for row in finite if row["tactic"] == -1)
    explicit = [row for row in finite if row["tactic"] != -1]
    best = min(finite, key=lambda row: row["profiler_ms"])
    winner = data["natural"]["tactic"]
    check(winner == best["tactic"], "selected winner is not first finite minimum")
    costs = sorted(row["profiler_ms"] for row in finite)
    minimum, default_ms = costs[0], default["profiler_ms"]
    explicit_ms = min((row["profiler_ms"] for row in explicit), default=None)
    return {"selected_tactic": winner, "selected_kind": "default" if winner == -1 else "explicit",
            "runtime_profiles": len(rows), "finite_profiles": len(finite),
            "nonfinite_or_failed_profiles": len(rows) - len(finite), "minimum_ms": minimum,
            "minimum_tactics": [row["tactic"] for row in finite if row["profiler_ms"] == minimum],
            "default_profiler_ms": default_ms, "best_explicit_profiler_ms": explicit_ms,
            "winner_over_default_profiler_ratio": minimum / default_ms,
            "default_minus_winner_profiler_ms": default_ms - minimum,
            "best_explicit_over_default_profiler_ratio": None if explicit_ms is None else explicit_ms / default_ms,
            "best_explicit_minus_default_profiler_ms": None if explicit_ms is None else explicit_ms - default_ms,
            "runner_up_minus_winner_profiler_ms": None if len(costs) < 2 else costs[1] - minimum,
            "runner_up_over_winner_profiler_ratio": None if len(costs) < 2 else costs[1] / minimum}


def worker_math(path, trial, arm):
    data = read(path)
    check(data["status"] == "success" and (data["trial"], data["arm"], data["mode"]) == (trial, arm, "timing"),
          "worker identity/status: " + path.name)
    check(data["environment"]["sglang_commit"] == SOURCE_COMMIT and data["shape"] == [144, 4096, 1024],
          "source/shape changed: " + path.name)
    controls = data["graph_controls"]
    check(len(controls["blocks"]) == 24 and controls["common_iterations"] == 5120, "block count/protocol")
    paired = {channel: [] for channel in CHANNELS}
    strata = {channel: {name: [] for name in ("winner_first", "default_first")} for channel in CHANNELS}
    graph_times = {channel: {name: [] for name in GRAPHS} for channel in CHANNELS}
    orders = []
    for index, block in enumerate(controls["blocks"]):
        measurements = block["measurements"]
        order = [row["graph_id"] for row in measurements]
        check(block["index"] == index and block["order"] == order and sorted(order) == sorted(GRAPHS), "paired block coverage")
        orders.append(order)
        by_graph = {row["graph_id"]: row for row in measurements}
        stratum = "winner_first" if order[0] == "winner" else "default_first"
        for channel, batch_field in CHANNELS.items():
            per_call = {}
            for graph_id, row in by_graph.items():
                check(row["iterations"] == 5120 and positive(row[batch_field]), "raw timing/count")
                per_call[graph_id] = row[batch_field] / row["iterations"]
                reported_field = "gpu_event_per_call_ms" if channel == "gpu_event" else "wall_per_call_ms"
                check(math.isclose(per_call[graph_id], row[reported_field], rel_tol=1e-12), "reported timing normalization")
                graph_times[channel][graph_id].append(per_call[graph_id])
            ratio = per_call["winner"] / per_call["default"]
            paired[channel].append(ratio)
            strata[channel][stratum].append(ratio)
    check(sum(order[0] == "winner" for order in orders) == 12, "unbalanced within-block order")
    expected_capture = ["winner", "default"] if trial % 2 == 0 else ["default", "winner"]
    check(controls["capture_order"] == expected_capture, "capture parity")
    channels = {}
    for channel in CHANNELS:
        stratum_medians = {name: statistics.median(values) for name, values in strata[channel].items()}
        channels[channel] = {"winner_over_default_ratio": statistics.median(paired[channel]),
            "winner_change_percent": (statistics.median(paired[channel]) - 1) * 100,
            "block_ratios": paired[channel], "block_ratio_min": min(paired[channel]), "block_ratio_max": max(paired[channel]),
            "graph_median_per_call_ms": {name: statistics.median(values) for name, values in graph_times[channel].items()},
            "block_order_strata": {name: {"blocks": len(values), "median_ratio": stratum_medians[name],
                                                 "min_ratio": min(values), "max_ratio": max(values)}
                                   for name, values in strata[channel].items()},
            "winner_first_over_default_first_ratio": stratum_medians["winner_first"] / stratum_medians["default_first"]}
    return {"trial": trial, "arm": arm, "file": str(path), "sha256": sha(path), "pid": data["pid"],
            "launch_position": (1 if arm == "auto" else 2) if trial % 2 == 0 else (2 if arm == "auto" else 1),
            "capture_order": expected_capture, "profile_selection": profile_margins(data), "channels": channels}


def analyze(raw_root, trials):
    workers = [worker_math(raw_root / f"trial{trial}-{arm}-timing.json", trial, arm)
               for trial in trials for arm in ARMS]
    arm_summaries, cross_arm, order_summaries, parity_summaries = [], [], [], []
    for channel in CHANNELS:
        for arm in ARMS:
            cohort = [row for row in workers if row["arm"] == arm]
            arm_summaries.append({"channel": channel, "arm": arm, "ratio": "winner/default",
                **summary([{"trial": row["trial"], "ratio": row["channels"][channel]["winner_over_default_ratio"]} for row in cohort])})
            for stratum in ("winner_first", "default_first"):
                order_summaries.append({"channel": channel, "arm": arm, "stratum": stratum,
                    **summary([{"trial": row["trial"], "ratio": row["channels"][channel]["block_order_strata"][stratum]["median_ratio"]}
                               for row in cohort])})
            order_summaries.append({"channel": channel, "arm": arm, "stratum": "winner_first/default_first",
                **summary([{"trial": row["trial"], "ratio": row["channels"][channel]["winner_first_over_default_first_ratio"]} for row in cohort])})
            for parity in (0, 1):
                subset = [row for row in cohort if row["trial"] % 2 == parity]
                if subset:
                    parity_summaries.append({"channel": channel, "arm": arm, "trial_parity": parity,
                        "capture_order": subset[0]["capture_order"], "launch_position": subset[0]["launch_position"],
                        **summary([{"trial": row["trial"], "ratio": row["channels"][channel]["winner_over_default_ratio"]}
                                   for row in subset])})
        by_key = {(row["trial"], row["arm"]): row for row in workers}
        for comparison in ("normalized_winner_default", "winner_latency", "default_latency"):
            estimates = []
            for trial in trials:
                auto, graph = (by_key[trial, arm]["channels"][channel] for arm in ARMS)
                if comparison == "normalized_winner_default":
                    numerator, denominator = graph["winner_over_default_ratio"], auto["winner_over_default_ratio"]
                else:
                    graph_id = "winner" if comparison == "winner_latency" else "default"
                    numerator, denominator = graph["graph_median_per_call_ms"][graph_id], auto["graph_median_per_call_ms"][graph_id]
                estimates.append({"trial": trial, "ratio": numerator / denominator,
                                  "cuda_graph_estimate": numerator, "auto_estimate": denominator})
            cross_arm.append({"channel": channel, "comparison": comparison, "ratio": "cuda_graph/auto", **summary(estimates)})
    selections = []
    for arm in ARMS:
        cohort = [row for row in workers if row["arm"] == arm]
        selections.append({"arm": arm, "default_winners": sum(row["profile_selection"]["selected_kind"] == "default" for row in cohort),
                           "explicit_winners": sum(row["profile_selection"]["selected_kind"] == "explicit" for row in cohort),
                           "trials": [{"trial": row["trial"], **row["profile_selection"]} for row in cohort]})
    return {"status": "success", "schema_version": 1, "source_commit": SOURCE_COMMIT,
            "script": str(Path(__file__).resolve()), "script_sha256": sha(Path(__file__)),
            "raw_root": str(raw_root), "trials": trials, "independent_trials_per_arm": len(trials),
            "full_six_trial_cohort": trials == list(range(6)), "no_performance_acceptance_gate": True,
            "workers": workers, "arm_summaries": arm_summaries, "matched_cross_arm": cross_arm,
            "within_block_order_strata": order_summaries, "capture_and_launch_parity_strata": parity_summaries,
            "selection_counts_and_profiler_margins": selections,
            "limitations": [
                "Arithmetic reanalysis of raw records only; it does not independently establish source/build, cache-hit, launch identity or numerical correctness.",
                "Whole worker trials are independent units. Replay blocks and within-worker order strata are repeated observations.",
                "Capture order and launch position both follow trial parity; parity summaries cannot distinguish their individual effects.",
                "Order-stratum differences are descriptive. Their absence does not exclude process or device history effects.",
                "Profiling costs under different measurement objectives are different quantities. Profiler margins describe each race, not serving speedup.",
                "This is one fixed layer on one H100, with no persistence, full-model accuracy or serving-throughput qualification.",
            ]}


def self_test():
    check(runtime_shape([144, 4096, 1024])[0] == [1, 256, 1024], "runtime bucket")
    check(summary([{"trial": 0, "ratio": 1.2}])["exploratory_whole_trial_bootstrap_95_percent"] is None,
          "one trial must have no interval")
    check(summary([{"trial": 0, "ratio": 0.9}, {"trial": 1, "ratio": 1.1}])["median_ratio"] == 1,
          "trial median")
    check(bootstrap((0.8, 0.9, 1, 1.1, 1.2, 1.4))["ordered_resamples"] == 46656, "whole-trial resamples")
    check(statistics.median([2 / 1, 5 / 5, 3 / 1]) == 2,
          "median within-block ratios must precede aggregation")
    check(math.isclose((9 / 12) / (11 / 10), 0.6818181818181818), "matched normalized ratio")
    try:
        summary([{"trial": 0, "ratio": 1}, {"trial": 0, "ratio": 1.1}])
    except ValueError:
        pass
    else:
        raise ValueError("duplicate trial accepted")
    return {"status": "success", "cpu_only": True, "checks": 7, "script_sha256": sha(Path(__file__))}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("raw_root", type=Path, nargs="?")
    parser.add_argument("--trials", type=int, nargs="+", default=list(range(6)))
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    check(args.trials and args.trials == sorted(set(args.trials)) and all(t in range(6) for t in args.trials), "trial IDs")
    if args.self_test:
        result = self_test()
    else:
        if args.raw_root is None:
            parser.error("raw_root is required")
        result = analyze(args.raw_root.resolve(), args.trials)
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
