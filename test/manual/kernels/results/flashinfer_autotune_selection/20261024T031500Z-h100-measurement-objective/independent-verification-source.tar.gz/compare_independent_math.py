#!/usr/bin/env python3
"""Compare independent raw arithmetic with the frozen analysis JSON."""
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "raw/attempt01"
MATH = ROOT / "independent-math.json"
FINAL = RAW / "final-analysis.json"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    independent, frozen = (json.loads(path.read_text()) for path in (MATH, FINAL))
    comparisons, mismatches, nonexact = [], [], []

    def compare(label, actual, expected):
        comparisons.append(label)
        if actual != expected:
            nonexact.append({"label": label, "independent": actual, "frozen": expected})
            if not (type(actual) in (int, float) and type(expected) in (int, float)
                    and math.isclose(actual, expected, rel_tol=1e-14, abs_tol=0)):
                mismatches.append(nonexact[-1])

    def compare_summary(label, ours, theirs):
        for key in ("independent_trials", "median_ratio", "min_ratio", "max_ratio",
                    "ratios_below_one", "ratios_above_one", "ratios_equal_one"):
            compare(label + "/" + key, ours[key], theirs[key])
        own_ci, frozen_ci = (ours["exploratory_whole_trial_bootstrap_95_percent"],
                             theirs["exploratory_cluster_bootstrap_95_percent"])
        for key in ("level", "lower", "upper", "ordered_resamples", "exploratory_unadjusted"):
            compare(label + "/bootstrap/" + key, own_ci[key], frozen_ci[key])
        compare(label + "/bootstrap/independent_units", own_ci["independent_trials"], frozen_ci["independent_units"])

    compare("source_commit", independent["source_commit"], frozen["source_commit"])
    compare("trials", independent["trials"], frozen["trials"])
    frozen_workers = {(row["trial"], row["arm"]): row for row in frozen["validated_workers"]}
    workers = {(row["trial"], row["arm"]): row for row in independent["workers"]}
    compare("worker_count", len(workers), len(frozen_workers))
    for key, row in workers.items():
        compare(str(key) + "/raw_result_sha256", row["sha256"], frozen_workers[key]["sha256"])
    for theirs in frozen["analysis"]["within_arm"]:
        arm, channel = theirs["arm"], theirs["channel"]
        label = arm + "/" + channel
        ours = next(row for row in independent["arm_summaries"] if (row["arm"], row["channel"]) == (arm, channel))
        compare_summary(label, ours, theirs)
        for trial_row in theirs["trial_estimates"]:
            own_worker = workers[trial_row["trial"], arm]
            own_channel = own_worker["channels"][channel]
            base = label + "/trial" + str(trial_row["trial"])
            compare(base + "/ratio", own_channel["winner_over_default_ratio"], trial_row["ratio"])
            compare(base + "/block_ratio_min", own_channel["block_ratio_min"], trial_row["block_ratio_min"])
            compare(base + "/block_ratio_max", own_channel["block_ratio_max"], trial_row["block_ratio_max"])
            for index, (our_ratio, their_ratio) in enumerate(zip(own_channel["block_ratios"], trial_row["block_ratios"])):
                compare(base + "/block" + str(index), our_ratio, their_ratio)
            for graph_id in ("winner", "default"):
                compare(base + "/graph_median_ms/" + graph_id,
                        own_channel["graph_median_per_call_ms"][graph_id], trial_row["graph_median_ms"][graph_id])
            compare(base + "/natural_tactic", own_worker["profile_selection"]["selected_tactic"], trial_row["natural_tactic"])
    for theirs in frozen["analysis"]["paired_cross_arm"]:
        label = "cross/" + theirs["channel"] + "/" + theirs["measure"]
        ours = next(row for row in independent["matched_cross_arm"]
                    if (row["channel"], row["comparison"]) == (theirs["channel"], theirs["measure"]))
        compare_summary(label, ours, theirs)
        own_trials = {row["trial"]: row for row in ours["trial_estimates"]}
        for row in theirs["trial_estimates"]:
            for key in ("ratio", "cuda_graph_estimate", "auto_estimate"):
                compare(label + "/trial" + str(row["trial"]) + "/" + key, own_trials[row["trial"]][key], row[key])
    for theirs in frozen["analysis"]["selections"]:
        ours = next(row for row in independent["selection_counts_and_profiler_margins"] if row["arm"] == theirs["arm"])
        for key in ("default_winners", "explicit_winners"):
            compare(theirs["arm"] + "/" + key, ours[key], theirs[key])
        for row in theirs["trial_tactics"]:
            own = workers[row["trial"], theirs["arm"]]["profile_selection"]
            compare(theirs["arm"] + "/trial" + str(row["trial"]) + "/profile_minimum_ms", own["minimum_ms"], row["runtime_profile_summary"]["minimum_ms"])
            compare(theirs["arm"] + "/trial" + str(row["trial"]) + "/profile_minimum_tactics", own["minimum_tactics"], row["runtime_profile_summary"]["minimum_tactics"])
    result = {"status": "success" if not mismatches else "error", "checks": len(comparisons),
              "exact_agreements": len(comparisons) - len(nonexact), "nonexact_count": len(nonexact),
              "numerical_disagreements": mismatches, "nonexact": nonexact,
              "independent_math_sha256": sha(MATH), "frozen_final_analysis_sha256": sha(FINAL),
              "script_sha256": sha(Path(__file__))}
    print(json.dumps(result, indent=2, allow_nan=False))
    if mismatches:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
