"""Retain exact CPU lifecycle evidence and independent audit sources."""

import hashlib
import json
import shutil
import tarfile
from pathlib import Path

ROOT = Path('/private/tmp/sglang-policy-lifecycle-final')
REPO = Path('/private/tmp/sglang-autotune-selection-study')
BATCH = REPO / 'test/manual/kernels/results/flashinfer_autotune_selection/20261020T153000Z-policy-lifecycle'
RAW = ROOT / 'attempt01'
INDEPENDENT = Path('/private/tmp/fi-policy-lifecycle-final-independent/attempt01')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rec(path):
    return {'sha256': sha(path), 'size_bytes': path.stat().st_size}


def read(path):
    return json.loads(path.read_text())


def write(name, data):
    (BATCH / name).write_text(json.dumps(data, indent=2) + '\n')


def archive(name, pairs):
    index = []
    with tarfile.open(BATCH / name, 'w:gz') as out:
        for path, member in pairs:
            assert path.is_file() and not path.is_symlink()
            assert bytes([118, 108, 108, 109]) not in path.read_bytes().lower(), path
            out.add(path, arcname=member, recursive=False)
            index.append({'path': member, **rec(path)})
    with tarfile.open(BATCH / name) as data:
        for row in index:
            content = data.extractfile(row['path']).read()
            assert hashlib.sha256(content).hexdigest() == row['sha256']
            assert len(content) == row['size_bytes']
    return {'archive': name, **rec(BATCH / name), 'members': index}


result = read(RAW / 'result.json')
independent = read(INDEPENDENT / 'result.json')
assert result['status'] == independent['status'] == 'success'
assert result['assertions_passed'] == independent['assertions_passed'] == 191
assert result['worker_sha256'] == sha(REPO / 'test/manual/kernels/flashinfer_autotune_policy_lifecycle.py')
assert result['manifest_sha256'] == sha(BATCH / 'plan.json')
shutil.copyfile(RAW / 'result.json', BATCH / 'results.json')
reports = [Path('/private/tmp/fi-policy-lifecycle-final-independent-audit.json'), Path('/private/tmp/sglang-policy-lifecycle-independent-readiness.json')]
sources = [Path('/private/tmp/audit_policy_lifecycle_final.py'), Path('/private/tmp/sglang-policy-lifecycle-readiness-audit.py'), Path(__file__)]
for report in reports:
    assert read(report)['status'] in ('success', 'passed')
write('summary.json', {
    'status': 'success',
    'execution_commit': result['sglang_execution_commit'],
    'results_sha256': sha(RAW / 'result.json'),
    'fresh_cpu_processes_per_run': 5,
    'proof_assertions_per_run': 191,
    'independent_runs': 2,
    'independent_audit_assertions': [64, 246],
    'stages': [{'name': item['stage'], 'checks': len(item['checks']), 'controlled_profiles': len(item['profiles'])} for item in result['reports']],
    'findings': [
        'Unspecified-policy legacy winner0 remains available after context exit and through real v1 save/load.',
        'Explicit graph-policy winner1 is reachable inside its memory-only scope; plain v1 saving omits it and bare lookup returns legacy0 or fallback on a graph-only process.',
        'Replay can accept wrong-policy legacy file0. Graph tuning rejects mismatched provenance and profiles1; replay must not be confused with a nested outer active tuning context.',
        'Loading phase files into the same singleton is last-wins for overlapping keys; separate filenames alone do not isolate identities.',
        'Guarded detached export and isolated file-bank activation preserve winner1 after fresh-process reload with zero profiling while bare legacy lookup keeps0.',
        'Wrong-policy, modified cache bytes, existing export paths and shadowing live graph memory are rejected; normal/exceptional activation preserves recorded live banks and original file-map identities.',
        'V1 per-entry provenance omits full timer identity, and a unique fresh output filename does not force an existing memory winner to retune.',
    ],
    'production_pr_ready': False,
    'next_decision': read(BATCH / 'plan.json')['design']['next_checkpoint'],
    'limits': result['limits'],
})
pairs = []
for prefix, base in [('root', RAW), ('independent', INDEPENDENT), ('preflight', Path('/private/tmp/sglang-policy-lifecycle-preflight'))]:
    pairs.extend((p, prefix + '/' + str(p.relative_to(base))) for p in sorted(base.rglob('*')) if p.is_file())
pairs.extend((ROOT / name, name) for name in ('commands.json', 'requirements.txt'))
raw_index = archive('attempt01-raw.tar.gz', pairs)
write('raw-member-index.json', raw_index)
source_index = archive('independent-audit-sources.tar.gz', [(p, p.name) for p in sources])
write('validation.json', {
    'status': 'success',
    'execution_commit': result['sglang_execution_commit'],
    'worker_sha256': result['worker_sha256'],
    'plan_sha256': result['manifest_sha256'],
    'actual_proof': rec(RAW / 'result.json'),
    'independent_proof': rec(INDEPENDENT / 'result.json'),
    'independent_audits': [{'report': read(p), **rec(p)} for p in reports],
    'retained_exact_audit_sources': source_index,
    'raw_archive': rec(BATCH / 'attempt01-raw.tar.gz'),
    'raw_original_byte_comparison_passed': True,
    'commands': read(ROOT / 'commands.json'),
    'source_repository_checks': (Path('/private/tmp/sglang-policy-lifecycle-preflight/final-source-pre-commit.log')).read_text(),
    'scope': 'Manual deterministic CPU proof; no GPU job, CI trigger, new registered test, production policy or PR.',
})
print(json.dumps({'raw_members': len(raw_index['members']), 'raw_archive': rec(BATCH / 'attempt01-raw.tar.gz'), 'audit_sources': len(source_index['members'])}))
