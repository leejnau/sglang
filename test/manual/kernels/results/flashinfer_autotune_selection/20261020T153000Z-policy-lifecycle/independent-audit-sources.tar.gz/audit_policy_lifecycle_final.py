"""Independent frozen-source CPU lifecycle execution and raw-file audit."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

COMMIT = "5f64a0cefab2e7bc310581a20eb5e859d1306a9b"
WORKER = "test/manual/kernels/flashinfer_autotune_policy_lifecycle.py"
PLAN = "test/manual/kernels/results/flashinfer_autotune_selection/20261020T153000Z-policy-lifecycle/plan.json"
checks = 0


def need(condition, label):
    global checks
    if not condition:
        raise AssertionError(label)
    checks += 1


def sha(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--worktree", type=Path, default=Path("/private/tmp/sglang-autotune-selection-study"))
    parser.add_argument("--python", type=Path, default=Path("/private/tmp/sglang-policy-lifecycle-venv/bin/python"))
    parser.add_argument("--flashinfer-source", type=Path, default=Path("/private/tmp/fi-descriptor-source/repo"))
    parser.add_argument("--proof-output", type=Path, default=Path("/private/tmp/fi-policy-lifecycle-final-independent/attempt01"))
    parser.add_argument("--report", type=Path, default=Path("/private/tmp/fi-policy-lifecycle-final-independent-audit.json"))
    args = parser.parse_args()
    need(not args.proof_output.exists() and not args.report.exists(), "fresh independent proof and report paths")
    worker = args.worktree / WORKER
    plan_path = args.worktree / PLAN
    worker_blob = subprocess.check_output(["git", "show", COMMIT + ":" + WORKER], cwd=args.worktree)
    plan_blob = subprocess.check_output(["git", "show", COMMIT + ":" + PLAN], cwd=args.worktree)
    need(worker.read_bytes() == worker_blob, "working worker matches exact committed source")
    need(plan_path.read_bytes() == plan_blob, "working plan matches exact committed source")
    manifest = json.loads(plan_blob)
    for name, expected in manifest["flashinfer_source_sha256"].items():
        need(sha((args.flashinfer_source / name).read_bytes()) == expected, "actual qualified FlashInfer source: " + name)
    args.proof_output.mkdir(parents=True)
    command = [str(args.python), str(worker), "--flashinfer-source", str(args.flashinfer_source), "--manifest", str(plan_path), "--output-dir", str(args.proof_output)]
    executed = subprocess.run(command, capture_output=True, text=True)
    (args.proof_output / "independent-driver.log").write_text(executed.stdout + executed.stderr)
    need(executed.returncode == 0, "actual frozen controller and all subprocesses succeed")
    need(worker.read_bytes() == worker_blob and plan_path.read_bytes() == plan_blob, "source and plan unchanged throughout independent execution")
    result_path = args.proof_output / "result.json"
    result = json.loads(result_path.read_text())
    need(result["status"] == "success" and result["worker_sha256"] == sha(worker_blob) and result["manifest_sha256"] == sha(plan_blob), "actual controller result binds frozen bytes")
    reports = result["reports"]
    stages = ("seed", "plain_reload", "bridge_reload", "file_order", "controls")
    need(tuple(r["stage"] for r in reports) == stages and result["fresh_processes"] == 5, "five complete independent lifecycle stages")
    need(len({r["pid"] for r in reports}) == 5, "five actual distinct fresh subprocess PIDs")
    need(sum(len(r["checks"]) for r in reports) == result["assertions_passed"] == 191, "191 recorded proof assertions")
    expected_profile_counts = dict(zip(stages, (6, 3, 0, 0, 6)))
    for report in reports:
        stage = report["stage"]
        need(report["status"] == "success" and report["torch"] == "2.14.1" and not report["cuda_available"], "actual CPU Torch execution: " + stage)
        need(report["source_sha256"] == manifest["flashinfer_source_sha256"] and report["seams"] == manifest["controlled_boundaries"], "full source qualification and disclosed boundaries: " + stage)
        need(all(c["passed"] is True for c in report["checks"]), "actual stage assertions passed: " + stage)
        need(len(report["profiles"]) == expected_profile_counts[stage], "controlled profiling participation: " + stage)
        for profile in report["profiles"]:
            need(profile["time_fixture"] in (1.0, 2.0, 4.0) and not profile["use_cold_l2_cache"], "finite controlled timing and policy path")
    by_stage = {r["stage"]: r for r in reports}
    need([p["use_cuda_graph"] for p in by_stage["seed"]["profiles"]] == [False] * 3 + [True] * 3, "same production operation tunes distinct legacy and graph-policy choices")
    need(all(p["use_cuda_graph"] for p in by_stage["plain_reload"]["profiles"]), "mismatched tuning provenance triggers graph-policy retuning")
    need(not by_stage["bridge_reload"]["profiles"] and not by_stage["file_order"]["profiles"], "fresh scoped graph bank and load-order negative control perform zero profiling")
    graph_policy = {"measure_execution_mode": "cuda_graph"}
    bank_key = hashlib.sha256(json.dumps(graph_policy, sort_keys=True).encode()).hexdigest()
    expected_tactics = {
        "legacy.json": [0],
        "plain-save-after-graph.json": [0],
        bank_key + ".json": [1],
        "graph-only-plain-save.json": [],
        "empty-policy.json": [0],
    }
    generations = {}
    for name, tactics in expected_tactics.items():
        path = args.proof_output / name
        payload = json.loads(path.read_text())
        generation = payload["_generation"]
        need(sha(canonical({k: v for k, v in payload.items() if k != "_generation"}).encode()) == generation, "actual v1 cache generation: " + name)
        need([value[1] for key, value in payload.items() if key.startswith("(")] == tactics, "actual persisted production-path tactic: " + name)
        generations[name] = {"sha256": sha(path.read_bytes()), "generation": generation, "tactics": tactics}
    stamp = json.loads((args.proof_output / (bank_key + ".manifest.json")).read_text())
    need(stamp["policy"] == graph_policy and stamp["source_sha256"] == manifest["flashinfer_source_sha256"] and stamp["cache_sha256"] == generations[bank_key + ".json"]["sha256"], "manual bank's full identity stamp binds exact cache/source")
    summary = {
        "status": "passed", "state": "FINAL_IMMUTABLE", "execution_commit": COMMIT,
        "worker_sha256": sha(worker_blob), "manifest_sha256": sha(plan_blob),
        "audit_source_sha256": sha(Path(__file__).read_bytes()), "audit_assertions": checks,
        "proof_assertions": 191, "fresh_processes": 5, "distinct_pids": [r["pid"] for r in reports],
        "controlled_profile_counts": expected_profile_counts, "total_controlled_profiles": 15,
        "fresh_bridge_profiling_attempts": 0, "real_v1_cache_generations_verified": 5,
        "persisted_caches": generations, "result_sha256": sha(result_path.read_bytes()),
        "raw_output": str(args.proof_output),
        "finding": "Explicit graph-policy winners are isolated from legacy bare lookup and v1 serialization. A hash/policy-guarded detached manual phase bank restores the desired file choice only inside its explicit replay scope.",
        "limits": manifest["limits"],
        "errors": [],
    }
    args.report.write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    args.report.chmod(0o444)
    print(json.dumps({"status": summary["status"], "audit_assertions": checks, "proof_assertions": 191, "fresh_processes": 5, "report_sha256": sha(args.report.read_bytes())}))


if __name__ == "__main__":
    main()
