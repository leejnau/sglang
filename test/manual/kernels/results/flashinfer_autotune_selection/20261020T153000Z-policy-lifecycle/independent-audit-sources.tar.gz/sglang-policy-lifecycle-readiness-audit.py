#!/usr/bin/env python3
"""Independent read-only audit of the completed CPU lifecycle proof."""
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/private/tmp/sglang-autotune-selection-study')
RAW = Path('/private/tmp/sglang-policy-lifecycle-final/attempt01')
FI = Path('/private/tmp/fi-descriptor-source/repo')
OUT = Path('/private/tmp/sglang-policy-lifecycle-independent-readiness.json')
COMMIT = '5f64a0cefab2e7bc310581a20eb5e859d1306a9b'
WORKER = 'test/manual/kernels/flashinfer_autotune_policy_lifecycle.py'
PLAN = 'test/manual/kernels/results/flashinfer_autotune_selection/20261020T153000Z-policy-lifecycle/plan.json'
count = 0


def require(condition, label):
    global count
    if not condition:
        raise AssertionError(label)
    count += 1


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def blob(path):
    return subprocess.check_output(['git', 'show', COMMIT + ':' + path], cwd=ROOT)


def git_sha(path):
    return hashlib.sha256(blob(path)).hexdigest()


def read(path):
    return json.loads(path.read_text())


result = read(RAW / 'result.json')
plan = json.loads(blob(PLAN))
require(result['status'] == 'success', 'controller result')
require(result['sglang_execution_commit'] == COMMIT, 'execution commit')
require(result['worker_sha256'] == sha(ROOT / WORKER) == git_sha(WORKER), 'frozen worker bytes')
require(result['manifest_sha256'] == sha(ROOT / PLAN) == git_sha(PLAN), 'frozen plan bytes')
require(result['limits'] == plan['limits'], 'limits preserved in actual result')
expected = {'seed': 44, 'plain_reload': 30, 'bridge_reload': 48, 'file_order': 21, 'controls': 48}
reports = result['reports']
require([r['stage'] for r in reports] == list(expected), 'five ordered fresh subprocess stages')
require(len(reports) == result['fresh_processes'] == 5, 'process count')
require(len({r['pid'] for r in reports}) == 5, 'distinct process identities')
require(sum(len(r['checks']) for r in reports) == result['assertions_passed'] == 191, 'assertion accounting')
profiles, stage_files = {}, []
for report in reports:
    stage = report['stage']
    path = RAW / (stage + '.json')
    require(read(path) == report, stage + ': original stage report binding')
    require(report['status'] == 'success' and report['cuda_available'] is False and report['torch'] == '2.14.1', stage + ': actual CPU dependency conditions')
    require(report['source_commit'] == plan['flashinfer_release_commit'] and report['source_sha256'] == plan['flashinfer_source_sha256'], stage + ': exact declared engine source')
    require(report['seams'] == plan['controlled_boundaries'], stage + ': declared controlled boundaries')
    require(len(report['checks']) == expected[stage], stage + ': assertion count')
    for check in report['checks']:
        require(check['passed'] is True, stage + ': ' + check['name'])
    profiles[stage] = len(report['profiles'])
    stage_files.append({'stage': stage, 'pid': report['pid'], 'sha256': sha(path), 'checks': len(report['checks'])})
require(profiles == {'seed': 6, 'plain_reload': 3, 'bridge_reload': 0, 'file_order': 0, 'controls': 6}, 'controlled profiler counts including zero-profile reloads')
for path, expected_sha in plan['flashinfer_source_sha256'].items():
    require(sha(FI / path) == expected_sha, 'actual engine source: ' + path)
for path, expected_sha in plan['sglang_phase_source_sha256'].items():
    require(git_sha(path) == expected_sha, 'frozen SGLang phase source: ' + path)
manifests = list(RAW.glob('*.manifest.json'))
require(len(manifests) == 1, 'one isolated graph bank manifest')
meta = read(manifests[0])
bank_path = manifests[0].with_name(manifests[0].name.replace('.manifest.json', '.json'))
require(meta['policy'] == {'measure_execution_mode': 'cuda_graph'}, 'exact graph policy manifest')
require(meta['source_sha256'] == plan['flashinfer_source_sha256'] and meta['cache_sha256'] == sha(bank_path), 'bank source and content binding')


def tactics(path):
    return [value[1] for key, value in read(path).items() if key.startswith('(')]


require(tactics(bank_path) == [1] and tactics(RAW / 'legacy.json') == [0], 'real v1 files preserve distinct fixture winners')
require(tactics(RAW / 'plain-save-after-graph.json') == [0] and tactics(RAW / 'graph-only-plain-save.json') == [], 'naive serialization negative controls')
design = plan['design']
require(design['production_pr_ready'] is False and design['gpu_experiment_launched'] is False and design['registered_test_added'] is False, 'bounded readiness claims')
require('private' in design['manual_bridge'].lower() and 'not production' in design['manual_bridge'].lower(), 'private adapter limitation')
require('supported' in design['next_checkpoint'].lower() and 'before implementing production phase routing' in design['next_checkpoint'].lower(), 'next engineering boundary')
require(not OUT.exists(), 'unique immutable report destination')
output = {
    'status': 'success',
    'audit_checks_passed': count,
    'execution_commit': COMMIT,
    'auditor_sha256': sha(Path(__file__)),
    'proof_worker_sha256': git_sha(WORKER),
    'plan_sha256': git_sha(PLAN),
    'actual_result_sha256': sha(RAW / 'result.json'),
    'proof_fresh_cpu_processes': 5,
    'proof_assertions_passed': 191,
    'stage_reports': stage_files,
    'controlled_profile_counts': profiles,
    'readiness': {
        'cpu_policy_lifecycle_proof_complete': True,
        'production_policy_integration_ready': False,
        'gpu_objective_comparison_qualified': False,
        'next_decision': 'Review a supported policy-aware persistence and lookup API boundary before production phase routing; retain unspecified-policy eager behavior and separate explicit graph winners.'
    },
    'claim_limits': [
        'Whole hash-checked tuner/cache modules execute on CPU with declared import, metadata and profiling controls.',
        'Synthetic CPU winner outputs and controlled profiler values do not qualify native kernels, CUDA Graph capture, serving performance, distributed behavior or target/draft behavior.',
        'Detached private serializer and file-bank activation are manual single-thread proof machinery; export failure was injected before actual save.',
        'Current production code is source-reviewed here; production phase routing is not executed by this proof.'
    ]
}
OUT.write_text(json.dumps(output, indent=2) + '\n')
OUT.chmod(0o444)
print(json.dumps({'status': 'success', 'audit_checks_passed': count, 'report': str(OUT), 'report_sha256': sha(OUT), 'actual_result_sha256': output['actual_result_sha256']}))
