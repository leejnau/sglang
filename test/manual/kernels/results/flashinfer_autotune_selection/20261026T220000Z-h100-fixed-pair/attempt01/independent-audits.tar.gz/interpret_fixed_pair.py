"""Independent descriptive interpretation of the frozen fixed-pair cohort."""
import argparse
import collections
import hashlib
import json
import math
import random
import statistics
from pathlib import Path

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--raw',type=Path,default=Path('/private/tmp/fi-fixed-pair-20261026/coordinator/raw-timing/attempt01'))
parser.add_argument('--official',type=Path,default=Path('/private/tmp/fi-fixed-pair-20261026/analysis/timing-analysis.json'))
parser.add_argument('--output',type=Path,default=Path('/private/tmp/fi-fixed-pair-20261026/interpretation.json'))
a=parser.parse_args()

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def gm(xs): return math.exp(sum(math.log(x) for x in xs)/len(xs))
def quantile(xs,p):
    location=(len(xs)-1)*p
    lower=math.floor(location); upper=math.ceil(location)
    return xs[lower]+(location-lower)*(xs[upper]-xs[lower])
def paired(groups,value,role):
    result=[]
    for group in groups:
        rows={r[role]:r for r in group['measurements']}
        assert set(rows)=={'winner','default'}
        result.append(rows['winner'][value]/rows['default'][value])
    return result

def trace_signatures(path,graph):
    events=json.loads(path.read_text())['traceEvents']
    markers=[e for e in events if e.get('cat')=='user_annotation' and e.get('name')=='retained_'+graph]
    assert len(markers)==1
    marker=markers[0]
    inside=[e for e in events if marker['ts']<=e.get('ts',-1)<=marker['ts']+marker['dur']]
    assert sum('cudaGraphLaunch' in e.get('name','') for e in inside)==3
    kernels=sorted((e for e in inside if e.get('cat')=='kernel'),key=lambda e:e['ts'])
    fields=('device','grid','block','registers per thread','shared memory')
    signatures=[{'name':e['name'],**{k:e.get('args',{}).get(k) for k in fields}} for e in kernels]
    assert len(signatures)==6 and signatures[:2]==signatures[2:4]==signatures[4:6]
    return signatures[:2]

processes=[]; metric_values=collections.defaultdict(list); queue=collections.Counter(); kernels={}; provider_hashes=collections.defaultdict(set)
late_pair_signs=collections.Counter(); layer_pair_signs=collections.Counter()
for block in range(8):
    path=a.raw/f'block{block}-auto_synthetic-timing.json'
    x=json.loads(path.read_text())
    bootstrap=json.loads(path.with_name(path.stem+'.bootstrap.json').read_text())
    assert x['status']=='success' and path.with_suffix('.exit-code').read_text().strip()=='0'
    assert sha(path)==bootstrap['result_sha256']
    baseline=x['startup']['profiles']; assert len(baseline)==81
    assert baseline[72]['tactic']==-1 and baseline[74]['tactic']==x['fixed_descriptor']
    assert x['natural']['tactic']==min(baseline[72:81],key=lambda row:row['elapsed_ms'])['tactic']==-1
    assert x['declared_late_profile_attempts']==48 and x['total_actual_profiler_calls']==129
    assert not x['forbidden_profile_attempts'] and all(r['passed'] for r in x['correctness']+x['profile_correctness'])
    assert x['post_timing_acceptance']['used_descriptor']==1
    assert x['synthetic_acceptance'][0]['used_descriptor']==1
    assert x['default_acceptance']['descriptor_acceptance']=='not_applicable_default_route'
    assert x['synthetic_acceptance'][1]['descriptor_acceptance']=='not_applicable_default_route'
    assert all(r['restored'] and r['before_sha256']==r['after_sha256'] for r in x['cache_partition_restorations'])
    assert all(r['restored'] for r in x['miss_scopes'])
    assert x['final']['cache_unchanged'] and x['final']['operands_unchanged']
    initial=baseline[74]['elapsed_ms']/baseline[72]['elapsed_ms']
    layer=paired(x['rounds'],'gpu_event_per_replay_ms','graph_id')
    late={p['objective']:paired(p['rounds'],'elapsed_ms','role') for p in x['paired_profiles']}
    values={'original_history_profiler':initial,'layer_graph':statistics.median(layer),'late_auto_profiler':statistics.median(late['auto']),'late_graph_profiler':statistics.median(late['graph'])}
    values['late_graph_over_auto_profiler']=values['late_graph_profiler']/values['late_auto_profiler']
    for key,value in values.items(): metric_values[key].append(value)
    layer_strata={role:statistics.median([value for value,group in zip(layer,x['rounds']) if group['order'][0]==role]) for role in ('winner','default')}
    late_strata={}
    for group in x['paired_profiles']:
        objective=group['objective']; ratios=late[objective]
        late_strata[objective]={role:statistics.median([value for value,pair in zip(ratios,group['rounds']) if pair['order'][0]==role]) for role in ('winner','default')}
        for v in ratios: late_pair_signs[(objective,'explicit_faster' if v<1 else 'explicit_slower' if v>1 else 'tie')]+=1
    for group in x['rounds']:
        for measurement in group['measurements']:
            queue[measurement['queue_evidence']]+=1
            assert measurement['profile_attempts_before']==measurement['profile_attempts_after']==81
    for value in layer:layer_pair_signs['explicit_faster' if value<1 else 'explicit_slower' if value>1 else 'tie']+=1
    trace=path.with_suffix('.trace.json'); assert sha(trace)==x['trace']['sha256']
    observed={graph:trace_signatures(trace,graph) for graph in ('winner','default')}
    if not kernels:kernels=observed
    assert observed==kernels
    for provider,evidence in bootstrap['native']['providers'].items(): provider_hashes[provider].add(evidence['library_sha256'])
    processes.append({'block':block,'raw_sha256':sha(path),'capture_order':x['capture_order'],'profiler_objective_order':x['profiler_objective_order'],'natural_tactic':-1,'metrics':values,'layer_replay_order_strata':layer_strata,'late_pair_order_strata':late_strata,'layer_per_role_median_us':{role:statistics.median([r['gpu_event_per_replay_ms']*1000 for group in x['rounds'] for r in group['measurements'] if r['graph_id']==role]) for role in ('winner','default')},'correctness_counts':{'serving':len(x['correctness']),'synthetic':len(x['profile_correctness'])}})

# Sample whole process indices once per replicate and share them over all metrics.
# No analysis-module import or within-process pseudoreplication.
rng=random.Random(202610262200); samples={key:[] for key in metric_values}
logs={key:[math.log(x) for x in values] for key,values in metric_values.items()}
for _ in range(100000):
    indices=[rng.randrange(8) for _ in range(8)]
    for key,values in logs.items(): samples[key].append(math.exp(sum(values[i] for i in indices)/8))
metrics={key:{'geometric_mean_ratio':gm(values),'process_min':min(values),'process_max':max(values),'processes_above_one':sum(x>1 for x in values),'processes_below_one':sum(x<1 for x in values),'exploratory_whole_process_bootstrap_95pct':[quantile(sorted(samples[key]),.025),quantile(sorted(samples[key]),.975)]} for key,values in metric_values.items()}
official=json.loads(a.official.read_text()); assert official['status']=='passed'
for key,metric in metrics.items():
    theirs=official['metrics'][key]
    assert math.isclose(metric['geometric_mean_ratio'],theirs['geometric_mean_ratio'],rel_tol=1e-13)
    assert all(math.isclose(u,v,rel_tol=1e-13) for u,v in zip(metric['exploratory_whole_process_bootstrap_95pct'],theirs['exploratory_process_bootstrap_95pct']))

capture={order:{'n':4,'layer_graph_geometric_mean':gm([row['metrics']['layer_graph'] for row in processes if row['capture_order']==order]),'layer_default_median_us_range':[min(row['layer_per_role_median_us']['default'] for row in processes if row['capture_order']==order),max(row['layer_per_role_median_us']['default'] for row in processes if row['capture_order']==order)],'layer_fixed_median_us_range':[min(row['layer_per_role_median_us']['winner'] for row in processes if row['capture_order']==order),max(row['layer_per_role_median_us']['winner'] for row in processes if row['capture_order']==order)]} for order in ('winner-first','default-first')}
objective_order={first:{metric:gm([row['metrics'][metric] for row in processes if row['profiler_objective_order'][0]==first]) for metric in ('late_auto_profiler','late_graph_profiler','layer_graph')} for first in ('auto','graph')}
report={
 'status':'success','final':True,'scope':'Independent raw interpretation and arithmetic check; all eight fresh timing processes retained. Admission excluded from estimates.',
 'execution_commit':'a21cdf4ee624ebdb00b5d0e911ddbe3fd4648cfe','flashinfer_commit':'27c62fdf0ab1cd4014df8a15b66a975541fda83c','hardware':'H100 NVL, UUID240958a2-e8e1-3bac-b767-365c9e0b97bd, driver580.159.04,310W','shape_m_n_k':[144,4096,1024],
 'raw_archive_sha256':'84e44c807d2a897723e793eeb0dd676d1c254491fdf2c95149511953ee4272f5','official_analysis_sha256':sha(a.official),'arithmetic_matches_official':True,
 'metrics':metrics,'processes':processes,'natural_winner_counts':{'default':8,'fixed_explicit':0,'other_explicit':0},'layer_pair_signs':dict(layer_pair_signs),'late_pair_signs':{f'{k[0]}:{k[1]}':v for k,v in late_pair_signs.items()},'queue_outcomes':dict(queue),
 'capture_order_association':capture,'profiler_objective_order_association':objective_order,'trace_signatures_equal_across_all_eight_processes':True,'serving_trace_signatures':kernels,'native_library_sha256':{k:sorted(v) for k,v in provider_hashes.items()},
 'historical_gemm_library_sha256':'20fb6a5cf2579332d784585caa9785f46a7a8f7306040dfe30b3acc76b764f9d',
 'findings':[
  'The fixed historical descriptor remains slower than default in the actual retained SGLang layer graphs: all192 paired ratios exceed1, including both replay-order strata. Its physical GEMM launch signature differs from the default while quantizer signature matches.',
  'The historical false-win did not recur: natural startup selected default in all8 processes, and the original fixed/default profiler contrast favored default in all8.',
  'Late auto and explicit graph profiling agree on the slower candidate; graph profiling separates it more strongly. Both modes therefore have the same correct fixed-pair ranking in this cohort. No policy-driven serving improvement was demonstrated.',
  'Capture-order association is substantial despite identical observed launch signatures: fixed-graph medians are about8.16–8.30us when captured first versus8.75–8.89us when captured second; default is about7.08–7.29us. This is an order/allocation/history association, not a proven capture mechanism.',
  'Late profiler objective-block order changes little relative to the measured fixed-pair gaps; comparisons remain post-graph history diagnostics on synthetic values, not reproductions of the original historical measurement window.',
  'Current GEMM ELF differs from the historical counterexample artifact, although qualified source contract and dependencies are pinned. ELF hashes can differ for build metadata/path reasons; this alone neither proves a runtime code change nor permits claiming byte-identical historical reproduction.'
 ],
 'limitations':[
  'One fixed input fixture, one candidate pair, same GPU and contiguous eight processes. Exploratory intervals resample processes, not rounds; no rare-error-rate, population or full-model serving claim.',
  'Retaining profiling tensors extends allocation lifetime; shadow profiler preparation and numerical/reference work alter later history. Auto and graph objective blocks are sequential with balanced order, not simultaneous.',
  'Synthetic profiler activations differ from serving captured activations; serving replay also includes quantization. Cross-domain absolute ratios do not isolate objective alone.',
  'Post-timing native acceptance on exact captured/synthetic operands proves descriptor acceptance there; serving traces do not directly observe each timed profiler invocation.',
  'NaN/output checks surround a full profiler invocation including warmups; they do not independently validate every inner timed iteration.',
  'Capture-order subgroup is n4 per group and confounded with that declared capture/allocation/history bundle. Identical grid/block/register/shared signatures do not establish identical device execution conditions.'
 ],
 'next_smallest_action':{
  'recommendation':'Record this cohort and prepare a source-only design/CPU proof for a benchmark-only balanced confirmation of an explicit finalist against default; do not change production winner selection or force graph policy from this result.',
  'why':'The slow fixed candidate is verified, but the current original search already rejects it8/8; this experiment does not reproduce the rare false-win mechanism. A confirmation design can test a concrete safeguard without claiming the current selector is uniformly wrong.',
  'boundary':'No new GPU run is required to complete this checkpoint. If a confirmation experiment is later authorized, preregister its history and preserve first-pass winners; never add performance-conditioned retries or discard neutral outcomes.',
  'capture_effect':'Do not chase the capture-order association merely to refine a speedup claim: the ranking is unchanged in both capture orders. Investigate it only if a later decision requires precise magnitude or comparable subpercent effects.'
 },
 'reproducibility':{'script_sha256':sha(__file__),'bootstrap_replicates':100000,'seed':202610262200,'quantile':'linear type7','official_imported':False}
}
encoded=json.dumps(report,indent=2,allow_nan=False)+'\n'
assert bytes([118,108,108,109]) not in encoded.lower().encode()
a.output.write_text(encoded)
print(json.dumps({'status':'success','output':str(a.output),'sha256':sha(a.output),'metrics':metrics,'capture_order':capture},indent=2))
