"""Compare three pinned checkpoint byte slices to the frozen fused QKV tensor."""

import argparse
import hashlib
import json
import struct
from pathlib import Path

REVISION = 'c1899de289a04d12100db370d81485cdf75e47ca'
ROOT = Path('/tmp/fi-linear-2679896')


def sha(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def read_header(path):
    with path.open('rb') as stream:
        count = struct.unpack('<Q', stream.read(8))[0]
        if not 0 < count < 64 * 1024 * 1024:
            raise ValueError('invalid safetensors header size')
        raw = stream.read(count)
    return json.loads(raw), count + 8, hashlib.sha256(raw).hexdigest()


def require(condition, detail):
    if not condition:
        raise ValueError(detail)


def hash_slice(path, offset, size, aggregate=None):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        stream.seek(offset)
        remaining = size
        while remaining:
            block = stream.read(min(remaining, 1024 * 1024))
            require(block, 'truncated tensor byte slice')
            value.update(block)
            if aggregate is not None:
                aggregate.update(block)
            remaining -= len(block)
    return value.hexdigest()


def audit(args):
    manifest_path = args.fixture.parent / 'manifest.json'
    manifest = json.loads(manifest_path.read_text())
    require(args.checkpoint.parent.name == REVISION, 'checkpoint path is not the pinned revision')
    require(manifest['model']['revision'] == manifest['model']['resolved_snapshot_revision'] == REVISION, 'fixture revision differs')
    require(manifest['model']['repo_id'] == 'Qwen/Qwen3-0.6B', 'fixture model differs')
    require(manifest['capture']['weight_order'] == ['q_proj', 'k_proj', 'v_proj'], 'fixture order differs')
    require(manifest['shape'] == [144, 4096, 1024], 'fixture shape differs')
    expected_file = manifest['checkpoint_files']['model.safetensors']
    require(args.checkpoint.stat().st_size == expected_file['size_bytes'], 'checkpoint file size differs from captured provenance')
    fixture_sha = sha(args.fixture)
    require(fixture_sha == manifest['tensor_file']['sha256'], 'fixture byte identity differs')
    checkpoint, checkpoint_base, checkpoint_header_sha = read_header(args.checkpoint)
    fixture, fixture_base, fixture_header_sha = read_header(args.fixture)
    fused = fixture['weight_bf16_rowmajor']
    require(fused['dtype'] == 'BF16' and fused['shape'] == [4096, 1024], 'fixture weight is not the declared row-major BF16 tensor')
    require(fused['data_offsets'][1] - fused['data_offsets'][0] == 4096 * 1024 * 2, 'fixture weight storage size differs')
    projections, rows_so_far = [], 0
    concatenated = hashlib.sha256()
    for projection, rows in zip(('q_proj', 'k_proj', 'v_proj'), (2048, 1024, 1024)):
        name = 'model.layers.0.self_attn.' + projection + '.weight'
        tensor = checkpoint[name]
        start, end = tensor['data_offsets']
        size = rows * 1024 * 2
        require(tensor['dtype'] == 'BF16' and tensor['shape'] == [rows, 1024] and end - start == size, 'checkpoint tensor layout differs: ' + name)
        require(0 <= start < end <= args.checkpoint.stat().st_size - checkpoint_base, 'checkpoint tensor offset invalid: ' + name)
        original_sha = hash_slice(args.checkpoint, checkpoint_base + start, size, concatenated)
        actual_sha = hash_slice(args.fixture, fixture_base + fused['data_offsets'][0] + rows_so_far * 1024 * 2, size)
        require(original_sha == actual_sha, 'fixture rows differ from original checkpoint: ' + name)
        projections.append({'checkpoint_key': name, 'dtype': tensor['dtype'], 'shape': tensor['shape'], 'checkpoint_data_offsets': [start, end], 'fixture_row_range': [rows_so_far, rows_so_far + rows], 'checkpoint_slice_sha256': original_sha, 'fixture_slice_sha256': actual_sha, 'matches': True})
        rows_so_far += rows
    require(concatenated.hexdigest() == manifest['tensors']['weight_bf16_rowmajor']['sha256'], 'concatenated original Q/K/V bytes differ from frozen tensor')
    return {'status': 'success', 'schema_version': 1, 'model_id': 'Qwen/Qwen3-0.6B', 'model_revision': REVISION, 'fixture_manifest_sha256': sha(manifest_path), 'fixture_tensor_file_sha256': fixture_sha, 'checkpoint': {'logical_path': str(args.checkpoint), 'size_bytes': args.checkpoint.stat().st_size, 'header_sha256': checkpoint_header_sha, 'recorded_full_file_sha256': expected_file['sha256'], 'full_file_hash_recomputed': False}, 'fixture_header_sha256': fixture_header_sha, 'projections': projections, 'concatenated_checkpoint_sha256': concatenated.hexdigest(), 'total_compared_bf16_values': 4096 * 1024, 'scope': 'Standard-library byte comparison only. Hashes the three original BF16 checkpoint tensor slices and the exact corresponding frozen fused-QKV rows; no model load, CUDA access, or full checkpoint copy.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', type=Path, default=ROOT / 'model-cache/models--Qwen--Qwen3-0.6B/snapshots' / REVISION / 'model.safetensors')
    parser.add_argument('--fixture', type=Path, default=ROOT / 'fixture/fixture.safetensors')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    try:
        result = audit(args)
    except Exception as error:
        result = {'status': 'error', 'error': type(error).__name__ + ': ' + str(error)}
    text = json.dumps(result, indent=2) + '\n'
    if args.output is not None:
        if args.output.exists():
            raise RuntimeError('refusing to overwrite a prior checkpoint audit report')
        args.output.write_text(text)
    print(text, end='')
    return 0 if result['status'] == 'success' else 1


if __name__ == '__main__':
    raise SystemExit(main())
