#!/usr/bin/env python3
"""Audit the frozen selection cohort independently of its performance analyzer."""

import argparse
import collections
import itertools
import hashlib
import json
import math
import random
import re
import statistics
import struct
import subprocess
from pathlib import Path

BATCH = 'test/manual/kernels/results/flashinfer_autotune_selection/20261020T034000Z-h100-fp8-linear'
COMMIT = None
WORKER = 'test/manual/kernels/flashinfer_autotune_linear_layer.py'
WRAPPER = 'python/sglang/srt/model_executor/runner/flashinfer_autotune.py'
GROUP_SHA = '727c326e0f2270748f2c9036dba98fc1b64a6c70e2f8891d23633567cc808ecc'


def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()


def sha(path):
    return sha_bytes(path.read_bytes())


def load(path):
    def reject(value):
        raise ValueError('nonfinite JSON: ' + value)
    return json.loads(path.read_text(), parse_constant=reject)


def key(tactic):
    return json.dumps(tactic, separators=(',', ':'), allow_nan=False)


def check_generation(payload):
    content = {name: value for name, value in payload.items() if name != '_generation'}
    expected = sha_bytes(json.dumps(content, sort_keys=True, separators=(',', ':')).encode())
    if payload.get('_generation') != expected:
        raise ValueError('v1 cache generation does not match its actual content')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw-root', type=Path, required=True)
    parser.add_argument('--source-root', type=Path, required=True)
    parser.add_argument('--execution-commit', required=True)
    parser.add_argument('--trials', type=int, nargs='+', choices=range(6), default=list(range(6)))
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    raw, source = args.raw_root.resolve(), args.source_root.resolve()
    shapes = (144,)
    trials = args.trials
    if sorted(set(trials)) != trials or not trials:
        parser.error('trials must be ordered unique IDs in 0..5')
    result = {'schema_version': 1, 'status': 'error', 'execution_commit': args.execution_commit, 'shapes': list(shapes), 'trials': trials, 'checks': [], 'errors': []}
    records, container_ids = {}, set()

    def require(condition, label):
        if not condition:
            raise ValueError(label)

    def blob(path):
        return subprocess.check_output(['git', 'show', args.execution_commit + ':' + path], cwd=source)

    def check(name, fn):
        try:
            detail = fn()
            result['checks'].append({'check': name, 'status': 'passed', 'detail': detail})
        except Exception as error:
            result['errors'].append({'check': name, 'error': str(error)})

    plan = json.loads(blob(BATCH + '/plan.json'))
    inputs = plan['flashinfer_source']['input_batch']
    manifest = json.loads(blob(inputs + '/source-manifest.json'))
    expected_runtime = {row['installed_package_path']: row['candidate_sha256'] for row in manifest['files'] if row['runtime_overlay']}
    fixture_manifest = json.loads(blob(BATCH + '/fixture-manifest.json'))
    expected_names = [f'trial{trial}-seed19-{arm}-{phase}' for trial in trials for arm in ('default', 'v1', 'v2') for phase in ('cold', 'warm')]

    def locate(stored):
        path = Path(stored)
        if 'caches' in path.parts:
            suffix = path.parts[path.parts.index('caches') + 1:]
            target = raw / 'caches' / Path(*suffix)
        else:
            target = raw / path.name
        require(target.is_file(), 'missing retained payload: ' + str(target))
        return target

    def outer():
        require((raw / 'execution-commit.txt').read_text().strip() == args.execution_commit, 'execution commit changed')
        for trial in trials:
            require((raw / f'trial{trial}.launcher.exit-code').read_text().strip() == '0', f'trial{trial} did not close successfully')
        if len(trials) == 6:
            require((raw / 'launcher.exit-code').read_text().strip() == '0', 'final launcher failed')
        launch = load(raw / 'manifest.json')
        require(launch['plan_sha256'] == sha_bytes(blob(BATCH + '/plan.json')), 'preregistered plan changed')
        require(sha_bytes(blob(BATCH + '/fixture-manifest.json')) == plan['fixture']['manifest_sha256'], 'fixture manifest differs from frozen plan')
        require(sha(raw / 'fixture/manifest.json') == plan['fixture']['manifest_sha256'] == launch['fixture_manifest_sha256'], 'archived fixture manifest differs')
        require(sha(raw / 'fixture/fixture.safetensors') == plan['fixture']['tensor_file_sha256'] == launch['fixture_tensor_file_sha256'] == fixture_manifest['tensor_file']['sha256'], 'private fixture bytes differ')
        require(launch['source_manifest_sha256'] == sha_bytes(blob(inputs + '/source-manifest.json')), 'FlashInfer source manifest changed')
        for path, value in launch['source_sha256'].items():
            require(sha_bytes(blob(path)) == value, 'producer source hash differs: ' + path)
        require(WORKER in launch['source_sha256'] and WRAPPER in launch['source_sha256'], 'missing source coverage')
        gpu = launch['gpu']
        environment = plan['environment']
        require(gpu['name'] == environment['gpu'], 'GPU model changed')
        require(gpu['uuid'].removeprefix('GPU-') == environment['physical_gpu_uuid'], 'physical GPU changed')
        require(gpu['driver_version'] == environment['driver'], 'GPU driver changed')
        image = load(raw / 'image.json')
        require(image['Architecture'] == 'amd64' and image['Os'] == 'linux', 'image architecture changed')
        require(any(v.split('@')[-1] == plan['container_image'].split('@')[-1] for v in image['RepoDigests']), 'image digest changed')
        require((raw / 'prepare.exit-code').read_text().strip() == '0', 'source preparation failed')
        preparation = load(raw / 'prepared-packages.json')
        require(preparation['source_manifest_sha256'] == sha_bytes(blob(inputs + '/source-manifest.json')), 'materialized source identity differs')
        require(preparation['arms']['candidate']['sha256'] == expected_runtime, 'materialized seven-source overlay changed')
        require(not (raw / 'gpu-processes-before.csv').read_text().strip(), 'GPU was not idle at allocation start')
        require(sha(raw / 'collect_build_provenance.py') == sha_bytes(blob(BATCH + '/collect_build_provenance.py')), 'executed native collector source differs from frozen source')
        return {'expected_workers': len(expected_names), 'gpu': gpu['name'], 'uuid': environment['physical_gpu_uuid'], 'scope': 'This NVL cohort is separate from prior HBM3 measurements.'}
    check('frozen producer, image and hardware identity', outer)

    def fixture_link():
        public_manifest_bytes = blob(BATCH + '/fixture-manifest.json')
        captured = fixture_manifest['source']
        capture_path = BATCH + '/capture_fixture.py'
        capture_sha = sha_bytes(subprocess.check_output(['git', 'show', captured['sglang_commit'] + ':' + capture_path], cwd=source))
        require(capture_sha == captured['capture_script_sha256'] == sha_bytes(blob(capture_path)), 'executed capture source changed between acquisition and workers')
        require(captured['sglang_commit'] == 'a29b31850c7b68cafde022614b00ab01d6ff5cde', 'capture commit changed')
        for name, expected in captured['sglang_source_sha256'].items():
            require(sha_bytes(blob(name)) == expected == sha_bytes(subprocess.check_output(['git', 'show', captured['sglang_commit'] + ':' + name], cwd=source)), 'production source changed since fixture capture: ' + name)
        binary = (raw / 'fixture/fixture.safetensors').read_bytes()
        header_length = struct.unpack('<Q', binary[:8])[0]
        header = json.loads(binary[8:8 + header_length])
        payloads = {name: binary[8 + header_length + item['data_offsets'][0]:8 + header_length + item['data_offsets'][1]] for name, item in header.items() if name != '__metadata__'}
        for name, payload in payloads.items():
            require(sha_bytes(payload) == fixture_manifest['tensors'][name]['sha256'], 'retained fixture tensor bytes differ: ' + name)
        proof_bytes = blob(BATCH + '/checkpoint-slice-audit.json')
        proof = json.loads(proof_bytes)
        capture_raw = raw / 'capture-attempt01'
        checkpoint_script_sha = sha(capture_raw / 'checkpoint-slice-audit.py')
        require(checkpoint_script_sha == '33f9330355ec34a5016e72bcc448a20bae75b60c0923070dfc1b03d8fd6b8cda', 'executed original-checkpoint slice audit source differs')
        require((capture_raw / 'checkpoint-slice-audit.json').read_bytes() == proof_bytes, 'raw original-checkpoint report differs from frozen report')
        require((capture_raw / 'exit-code').read_text().strip() == '0' and not (capture_raw / 'gpu-processes-after.csv').read_text().strip(), 'model capture failed or left a GPU process')
        require(re.fullmatch(r'[0-9a-f]{64}', (capture_raw / 'container-id').read_text().strip()), 'capture lacks its own container identity')
        require(proof['status'] == 'success' and proof['fixture_manifest_sha256'] == sha_bytes(public_manifest_bytes) and proof['fixture_tensor_file_sha256'] == sha_bytes(binary), 'original checkpoint slice proof is not linked to this fixture')
        require(proof['model_revision'] == fixture_manifest['model']['revision'] == 'c1899de289a04d12100db370d81485cdf75e47ca', 'checkpoint slice proof revision differs')
        require(proof['concatenated_checkpoint_sha256'] == sha_bytes(payloads['weight_bf16_rowmajor']) and proof['total_compared_bf16_values'] == 4194304, 'full checkpoint QKV concatenation differs')
        offset = 0
        require(len(proof['projections']) == 3, 'checkpoint projection proof coverage differs')
        for row, name, rows in zip(proof['projections'], ('q_proj', 'k_proj', 'v_proj'), (2048,1024,1024)):
            size = rows * 1024 * 2
            expected = sha_bytes(payloads['weight_bf16_rowmajor'][offset * 1024 * 2:(offset + rows) * 1024 * 2])
            require(row['checkpoint_key'] == 'model.layers.0.self_attn.' + name + '.weight' and row['dtype'] == 'BF16' and row['shape'] == [rows,1024] and row['fixture_row_range'] == [offset,offset + rows] and row['matches'] and row['checkpoint_slice_sha256'] == row['fixture_slice_sha256'] == expected, 'original checkpoint projection slice differs: ' + name)
            offset += rows
        return {'capture_commit': captured['sglang_commit'], 'capture_script_sha256': capture_sha, 'production_source_files': len(captured['sglang_source_sha256']), 'fixture_manifest_sha256': sha_bytes(public_manifest_bytes), 'fixture_tensor_file_sha256': sha_bytes(binary), 'checkpoint_slice_audit_source_sha256': checkpoint_script_sha, 'checkpoint_slice_report_sha256': sha_bytes(proof_bytes), 'original_bf16_checkpoint_values_linked': 4194304, 'tensor_slices_verified': len(payloads)}
    check('acquisition source, all six fixture slices and original checkpoint QKV linkage', fixture_link)

    def measure(row):
        iterations = row['effective_iterations']
        require(type(iterations) is int and 20 <= iterations <= 65536, 'invalid iteration count')
        require(row['requested_iterations'] == 20 and row['iterations_per_sample'] == iterations, 'normalization count changed')
        require(row['warmup_actual_ms'] >= 500 and row['calibration_batches'][-1]['wall_ms'] >= 20, 'timing preparation incomplete')
        require(len(row['samples_ms']) == len(row['wall_batch_ms']) == 15, 'wrong sample count')
        for sample, batch in zip(row['samples_ms'], row['wall_batch_ms']):
            require(math.isfinite(sample) and sample > 0 and math.isclose(sample * iterations, batch, rel_tol=1e-12), 'invalid wall normalization')
        require(math.isclose(statistics.median(row['samples_ms']), row['median_ms'], rel_tol=1e-12), 'incorrect worker median')

    def layer_controls(row, natural_payload, file_key, phase):
        layer = row['actual_layer']
        fixture = row['fixture']
        require(fixture['manifest_sha256'] == sha_bytes(blob(BATCH + '/fixture-manifest.json')) and fixture['tensor_file_sha256'] == fixture_manifest['tensor_file']['sha256'], 'worker fixture identity changed')
        require(all(fixture[k] == fixture_manifest[k] for k in ('shape', 'model', 'capture', 'tensors')), 'worker fixture metadata changed')
        require(layer['function'] == 'apply_fp8_linear_bmm_flashinfer' and layer['custom_op'] == 'flashinfer_bmm_fp8' and layer['quantizer'] == 'static_quant_fp8', 'actual layer path changed')
        require(layer['inference_mode'] and not layer['grad_enabled'] and not layer['allow_tf32'] and not layer['dispatch_modes'] and not layer['function_modes'] and not layer['torch_profiler_enabled'] and not layer['compiling'] and not layer['kernel_api_log_level'] and layer['custom_op_direct_wrapper'], 'normal inference fast path changed')
        require(layer['source_sha256'] == fixture_manifest['source']['sglang_source_sha256'], 'actual layer source coverage changed')
        for path, actual in layer['source_sha256'].items():
            require(sha_bytes(blob(path)) == actual, 'actual layer source changed: ' + path)
        quant = layer['quantization_reference']
        require(quant['byte_match'] and quant['cpu_and_gpu_independent_references_match'] and quant['actual_input_fp8_sha256'] == quant['independent_input_fp8_sha256'] == fixture_manifest['quantization']['independent_input_fp8_sha256'] and quant['scale_sha256'] == fixture_manifest['tensors']['input_scale']['sha256'], 'actual static quantizer byte proof changed')
        require(row['oracle'] == [] and row['timing_protocol']['oracle_order'] == [], 'unexpected candidate sweep')
        settings = row['autotuner_settings']
        for observed in (settings['initial'], settings['after']):
            require(observed['warmup'] == 3 and observed['repeat'] == 10 and observed['stream_delay_micro_secs'] == 5000 and observed['cuda_graph_delay_micro_secs'] == 100, 'tuner timing defaults changed')
            require(type(observed['use_global_timer']) is bool and observed['effective_measure_policy'] is None and observed['effective_policy_timer'] is None, 'measurement policy changed')
        require({k: v for k, v in settings['initial'].items() if k != 'config'} == {k: v for k, v in settings['after'].items() if k != 'config'}, 'timer state changed')
        require(settings['after']['config'] == {'use_cuda_graph': False, 'use_cold_l2_cache': False, 'cuda_graph_profile_replays': 1, 'profiling_repeat': None, 'effective_profiling_repeat': 10}, 'operation flags changed')
        for profile in row['profiles']:
            require(profile['autotuner_settings'] == settings['after'], 'inside-profile policy changed')
        stages = {'setup', 'startup', 'natural_eager_changed_input', 'natural_eager_restored_input', 'natural_before', 'natural_capture', 'natural_after', 'natural_after_oracle'}
        observations = layer['observed_public_inputs']
        require(collections.Counter(v['stage'] for v in observations) == collections.Counter(stages), 'public operand observation coverage changed')
        digest_stages = {'setup', 'natural_eager_restored_input', 'natural_before', 'natural_after', 'natural_after_oracle'}
        actual_digests = {'quantized_input_sha256': fixture_manifest['quantization']['independent_input_fp8_sha256'], 'weight_rowmajor_sha256': fixture_manifest['tensors']['weight_fp8_rowmajor']['sha256'], 'input_scale_sha256': fixture_manifest['tensors']['input_scale']['sha256'], 'weight_scale_sha256': fixture_manifest['tensors']['weight_scale']['sha256']}
        for observation in observations:
            stage = observation['stage']
            require(observation['capturing'] == (stage == 'natural_capture') and observation['backend'] == 'cublas', 'public backend/capture differs')
            inputs = observation['inputs']
            require(len(inputs) == 6 and [v['shape'] for v in inputs[:5]] == [[1,144,1024],[1,1024,4096],[1],[1],[1,144,4096]], 'actual native operand shapes differ')
            require([v['dtype'] for v in inputs[:5]] == ['torch.float8_e4m3fn','torch.float8_e4m3fn','torch.float32','torch.float32','torch.bfloat16'], 'actual native operand dtypes differ')
            require(inputs[0]['stride'][-2:] == [1024,1] and inputs[1]['stride'][-2:] == [1,1024] and inputs[4]['stride'][-2:] == [4096,1], 'actual row/column-major layout differs')
            if stage in digest_stages:
                require(all(observation[k] == v for k,v in actual_digests.items()), 'actual native operand bytes differ')
            else:
                require(not set(actual_digests).intersection(observation), 'byte read intruded capture/zero/startup')
        poison = layer['native_output_poison_checks']
        guarded_stages = stages - {'setup', 'startup'}
        require(collections.Counter(v['stage'] for v in poison) == collections.Counter(guarded_stages), 'real allocated-output poison coverage differs')
        for v in poison:
            capturing = v['stage'] == 'natural_capture'
            require(v['capturing'] == capturing and v['poisoned_actual_allocation'] == (not capturing), 'poison entered capture or missed actual output')
        checks = row['correctness']['checks']
        expected_checks = {'initial_untuned','natural_eager_changed_input','natural_eager_restored_input','natural_before','natural_changed_input','natural_restored_input','natural_measured_eager','natural_measured_cuda_graph','natural_after','natural_after_oracle'}
        require(collections.Counter(v['check'] for v in checks) == collections.Counter(expected_checks), 'actual eager/graph numerical coverage differs')
        for v in checks:
            require(v['quantized_reference']['passed'] and v['bf16_reference']['diagnostic_only'] and v['quantized_reference']['max_normalized_error'] <= 1, 'reference roles/numerical gate changed')
            zero = v['check'] in {'natural_eager_changed_input','natural_changed_input'}
            require(v['exact_zero_required'] == zero, 'changed-input zero gate differs')
            if zero:
                require(v['quantized_reference']['max_abs_error'] == v['bf16_reference']['max_abs_error'] == 0, 'changed-input execution did not produce exact zeros')
        selections = row['selections']
        require(collections.Counter(v['stage'] for v in selections) == collections.Counter(stages), 'selection coverage differs')
        for v in selections:
            expected = -1 if v['stage'] == 'setup' else row['natural']['tactic']
            tier = 'miss' if v['stage'] == 'setup' or row['arm'] == 'default' else 'memory' if phase == 'cold' else 'file'
            require(v['tactic'] == expected and v['lookup_tier'] == tier and v['cache_hit'] == (tier != 'miss') and v['capturing'] == (v['stage'] == 'natural_capture'), 'actual selection/tier differs')
        bindings = row['binding_acceptance_checks']
        require(collections.Counter(v['stage'] for v in bindings) == collections.Counter(guarded_stages), 'native descriptor guard coverage differs')
        for v in bindings:
            expected = row['natural']['tactic']
            require(v['tactic'] == expected and v['accepted'] and v['used_descriptor'] == ([] if expected == -1 else [1]), 'selected descriptor fell back')
        return {'public_observations': len(observations), 'native_acceptance_guards': len(bindings), 'real_output_poison_records': len(poison), 'numerical_checks': len(checks)}

    for name in expected_names:
        def worker(name=name):
            path = raw / (name + '.json')
            row = load(path)
            require(row.get('status') == 'success', 'worker did not succeed')
            require((raw / (name + '.exit-code')).read_text().strip() == '0', 'worker process failed')
            match = re.fullmatch(r'trial([0-5])-seed(19)-(default|v1|v2)-(cold|warm)', name)
            trial, seed, arm, phase = match.groups()
            m, trial, seed = 144, int(trial), int(seed)
            require(row['trial'] == trial, 'trial identity differs')
            require(row['shape'] == [m, 4096, 1024] and row['seed'] == seed and row['arm'] == arm and row['phase'] == phase, 'workload labels changed')
            require(row['implementation'] == 'candidate', 'source arm changed')
            require(row['worker_sha256'] == sha_bytes(blob(WORKER)), 'worker source changed')
            require(row['manifest_sha256'] == sha_bytes(blob(inputs + '/source-manifest.json')), 'worker source manifest changed')
            env = row['environment']
            require(env['sglang_commit'] == args.execution_commit and env['sglang_wrapper_sha256'] == sha_bytes(blob(WRAPPER)), 'SGLang source changed')
            require(set(env['helper_sha256']) == {'flashinfer_autotune_descriptor_selection.py', 'flashinfer_autotune_descriptor_qualification.py', 'flashinfer_autotune_eager_setup.py'}, 'helper source coverage differs')
            for helper, actual in env['helper_sha256'].items():
                require(actual == sha_bytes(blob('test/manual/kernels/' + helper)), 'helper source changed')
            require(env['flashinfer_tuner_sha256'] == expected_runtime['flashinfer/autotuner/autotuner.py'], 'tuner source changed')
            require(env['gpu'] == plan['environment']['gpu'] and env['physical_gpu_uuid'].removeprefix('GPU-') == plan['environment']['physical_gpu_uuid'], 'worker hardware changed')
            require(env['capability'] == [9, 0] and env['torch'] == '2.14.1+cu130' and env['torch_cuda'] == '13.0', 'software/device stack changed')
            require(env['flashinfer'] == '0.7.2' and not env['LD_PRELOAD'] and not env['managed_store'] and env['measurement_policy'] == 'unspecified', 'runtime control changed')
            native = env['native_artifact']
            require(native['source_sha256'] == expected_runtime and native['cuda_arch_list'] == '9.0' and 'bmm_fp8_run_with_descriptor' in native['required_native_exports'], 'native bootstrap changed')
            container = (raw / (name + '.container-id')).read_text().strip()
            require(re.fullmatch(r'[0-9a-f]{64}', container) and container not in container_ids, 'missing/reused container identity')
            container_ids.add(container)
            require(row['correctness']['passed'] and row['correctness']['checks'], 'no numerical correctness evidence')
            require(row['forbidden_profile_attempts'] == [], 'profiling guard recorded a forbidden attempt')
            require(row['profile_attempts'] == len(row['profiles']), 'profiling attempt count differs from evidence')
            if phase == 'warm' or arm == 'default':
                require(row['profile_attempts'] == 0, 'default/warm profiling occurred')
            else:
                require(row['profile_attempts'] > 0, 'cold tuning did not profile')
            tier = 'miss' if arm == 'default' else 'memory' if phase == 'cold' else 'file'
            natural = row['natural']
            require(natural['lookup_tier'] == tier and natural['cache_hit'] == (tier != 'miss'), 'wrong natural cache tier')
            if arm == 'default':
                require(natural['tactic'] == -1, 'true-miss default changed')
            bucket = 1 << (m - 1).bit_length()
            normalized = ((1, bucket, 1024), (1, 1024, 4096), (1,), (1,), (1, -1, 4096), (-1,))
            file_key = f"('fp8_gemm', 'CublasFp8GemmRunner', {normalized!r}, (torch.float8_e4m3fn, torch.float8_e4m3fn, torch.bfloat16))"
            require(row['cache']['runtime_file_key'] == file_key, 'runtime key is not the independently reconstructed bucket key')
            natural_path = locate(row['cache']['path'])
            natural_payload = load(natural_path)
            check_generation(natural_payload)
            require(natural_payload['_metadata']['gpu'] == plan['environment']['gpu'] and natural_payload['_metadata']['flashinfer_version'] == '0.7.2' and natural_payload['_metadata']['cuda_version'] == '13.0' and natural_payload['_metadata']['cublas_version'] == '13.1.1', 'persisted environment fingerprint differs from this pinned NVL cohort')
            require(sha(natural_path) == row['cache']['after_startup_sha256'] == row['cache']['after_oracle_sha256'], 'natural cache payload changed')
            if arm == 'default':
                require(file_key not in natural_payload, 'default control unexpectedly persisted a winner')
            else:
                require(natural_payload[file_key][0] == 'CublasFp8GemmRunner' and natural_payload[file_key][1] == natural['tactic'], 'persisted natural winner differs')
            runtime_profiles = []
            for profile in row['profiles']:
                actual = profile['input_shapes']
                require(actual[4][-2] == actual[0][-2], 'output synthesis violated its dependent M constraint')
                canonical = [list(shape) for shape in actual]
                canonical[0][-2] = 1 << (actual[0][-2] - 1).bit_length()
                canonical[4][-2] = -1
                canonical[5][0] = -1
                require(canonical == profile['normalized_profile'], 'reported profile normalization differs from the source contract')
                if tuple(tuple(v) for v in canonical) == normalized:
                    runtime_profiles.append(profile)
            if arm == 'v2' and phase == 'cold':
                require(any(p['tactic'] == -1 and p.get('profiler_ms') is not None for p in runtime_profiles), 'v2 did not finitely profile the default for the runtime bucket')
            if arm == 'v1':
                require(all(p['tactic'] != -1 for p in row['profiles']), 'v1 unexpectedly profiled default')
            finite = [p for p in runtime_profiles if p.get('profiler_ms') is not None]
            if finite:
                winner = min(finite, key=lambda p: p['profiler_ms'])
                require(winner['tactic'] == natural['tactic'], 'natural winner differs from first finite profile minimum')
            measure(natural['eager'])
            measure(natural['cuda_graph'])
            controls = layer_controls(row, natural_payload, file_key, phase)
            records[name] = row
            return {'result_sha256': sha(path), 'natural_generation': natural_payload['_generation'], 'actual_layer': controls}
        check('worker ' + name, worker)

    def chains():
        all_inputs = []
        for trial in trials:
            for arm in ('default', 'v1', 'v2'):
                cold = records[f'trial{trial}-seed19-{arm}-cold']
                warm = records[f'trial{trial}-seed19-{arm}-warm']
                require(cold['cache']['before_sha256'] is None, 'cold cache existed before startup')
                require(cold['cache']['path'] == warm['cache']['path'], 'warm worker used another natural file')
                require(cold['cache']['after_startup_sha256'] == cold['cache']['after_oracle_sha256'] == warm['cache']['before_sha256'] == warm['cache']['after_startup_sha256'] == warm['cache']['after_oracle_sha256'], 'natural cold/warm byte chain broke')
                require(cold['natural']['tactic'] == warm['natural']['tactic'], 'natural winner changed on restart')
                require(cold['environment']['operand_sha256'] == warm['environment']['operand_sha256'], 'cold/warm operands differ')
                all_inputs.extend([cold['environment']['operand_sha256'], warm['environment']['operand_sha256']])
        require(all(value == {name: meta['sha256'] for name,meta in fixture_manifest['tensors'].items()} for value in all_inputs), 'not every worker matches all six frozen fixture operands')
        return {'cold_warm_pairs': len(trials) * 3, 'distinct_fresh_containers': len(container_ids), 'identical_input_workers': len(all_inputs)}
    check('natural file byte chains and paired operand identities', chains)

    def native_build():
        candidate_paths = [raw / 'build-provenance.json', *[raw / f'build-provenance-m{m}.json' for m in shapes]]
        available = [p for p in candidate_paths if p.is_file()]
        require(available, 'missing node-local native build collection')
        provenance = load(available[0])
        require(provenance['status'] == 'success' and provenance['validated_native_records'] >= len(expected_names), 'native collection incomplete')
        data = provenance['arms']['candidate']
        require(data['all_runtime_source_sha256'] == expected_runtime, 'final native source mismatch')
        require({t['repository_path'] for t in data['translation_units']} == {'csrc/bmm_fp8.cu', 'csrc/group_gemm.cu', 'csrc/flashinfer_gemm_binding.cu'}, 'missing native translation unit')
        ninja = raw / data['ninja']['retained_relative_path']
        require(sha(ninja) == data['ninja']['sha256'], 'retained ninja file changed')
        text = ninja.read_text()
        require('-gencode=arch=compute_90a,code=sm_90a' in text, 'native architecture changed')
        for unit in data['translation_units']:
            expected = GROUP_SHA if unit['repository_path'] == 'csrc/group_gemm.cu' else expected_runtime['flashinfer/data/' + unit['repository_path']]
            require(unit['sha256'] == expected and unit['container_path'] in text, 'native source hash/build rule mismatch')
        library = raw / 'native-builds/candidate/gemm.so'
        require(sha(library) == data['library']['sha256'] and library.read_bytes().startswith(b'\x7fELF'), 'retained native binary changed')
        require(b'bmm_fp8_run_with_descriptor' in library.read_bytes(), 'native binary lacks descriptor API')
        references = {r['result']: r['result_sha256'] for r in data['validated_worker_results']}
        for name, row in records.items():
            require(references.get(name + '.json') == sha(raw / (name + '.json')), 'native collection cites a different worker')
            native = row['environment']['native_artifact']
            require(native['library_sha256'] == data['library']['sha256'] and native['ninja_sha256'] == data['ninja']['sha256'], 'native artifact changed across workers')
        return {'library_sha256': data['library']['sha256'], 'ninja_sha256': data['ninja']['sha256'], 'translation_units': 3, 'validated_worker_references': len(expected_names)}
    check('actual retained native binary, all three inputs and build rules', native_build)
    result['status'] = 'success' if not result['errors'] else 'error'
    result['scope'] = 'Independent source/cache/native audit for the actual static FP8 fused-QKV layer. Includes immutable fixture operands, real quantization, dynamic output/graph evidence, native acceptance, true default versus cold-memory/warm-file paths and unchanged natural persistence. Timing statistics are analyzed separately; no full-model accuracy, serving-throughput or physical-kernel causality claim.'
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'passed_checks': len(result['checks']), 'errors': result['errors']}))
    return 0 if result['status'] == 'success' else 1


if __name__ == '__main__':
    raise SystemExit(main())
