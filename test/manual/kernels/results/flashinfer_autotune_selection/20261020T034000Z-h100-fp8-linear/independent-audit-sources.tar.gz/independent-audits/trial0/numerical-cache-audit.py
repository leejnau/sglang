"""Independent stdlib audit of actual FP8 linear-layer raw evidence.

No worker or analyzer is imported. Numerical evidence is checked against frozen
source, recorded metrics, and exact zero-output bytes, without GPU recomputation.
"""
import argparse
import ast
import collections
import functools
import hashlib
import itertools
import json
import math
import re
import statistics
import struct
import subprocess
from pathlib import Path

WORKER = "test/manual/kernels/flashinfer_autotune_linear_layer.py"
BASE = "test/manual/kernels/flashinfer_autotune_descriptor_selection.py"
BATCH = "test/manual/kernels/results/flashinfer_autotune_selection/20261020T034000Z-h100-fp8-linear"
ARMS, PHASES = ("default", "v1", "v2"), ("cold", "warm")
checks = 0


def need(condition, message):
    global checks
    if not condition:
        raise AssertionError(message)
    checks += 1


def sha_bytes(value):
    return hashlib.sha256(value).hexdigest()


def sha(path):
    return sha_bytes(path.read_bytes())


def finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError("nonfinite JSON literal: " + value)
    return result


def load(path):
    def invalid(value):
        raise ValueError("nonfinite JSON constant: " + value)
    return json.loads(path.read_text(), parse_float=finite_float, parse_constant=invalid)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)


def positive(value):
    return type(value) in (int, float) and math.isfinite(value) and value > 0


def valid_tactic(value):
    return value == -1 or (isinstance(value, list) and len(value) == 8 and all(type(v) is int and 0 <= v < 1 << 64 for v in value))


def settings(row, label, config):
    need(row["warmup"] == 3 and row["repeat"] == 10, label + ": tuner repeat/warmup")
    need(row["stream_delay_micro_secs"] == 5000 and row["cuda_graph_delay_micro_secs"] == 100, label + ": retained delays")
    need(type(row["use_global_timer"]) is bool and row["effective_measure_policy"] is None and row["effective_policy_timer"] is None, label + ": actual timer without policy override")
    expected = {"use_cuda_graph": False, "use_cold_l2_cache": False, "cuda_graph_profile_replays": 1, "profiling_repeat": None, "effective_profiling_repeat": 10}
    need(row["config"] == (expected if config else None), label + ": retained operation profiling flags")


def timing(row, label):
    count = row["effective_iterations"]
    need(type(count) is int and 20 <= count <= 65536 and row["iterations_per_sample"] == count and row["requested_iterations"] == 20, label + ": calibrated iterations")
    need(row["warmup_actual_ms"] >= 500 and row["warmup_calls"] >= 20, label + ": untimed warmup")
    cal = row["calibration_batches"]
    need(cal[0]["iterations"] == 20 and cal[-1]["iterations"] == count and cal[-1]["wall_ms"] >= 20, label + ": calibrated final batch")
    for before, after in zip(cal, cal[1:]):
        need(before["wall_ms"] < 20 and after["iterations"] == min(2 * before["iterations"], 65536), label + ": bounded calibration progression")
    for samples, batches in (("samples_ms", "wall_batch_ms"), ("gpu_event_samples_ms", "gpu_event_batch_ms")):
        need(len(row[samples]) == len(row[batches]) == 15 and all(positive(v) for v in row[samples] + row[batches]), label + ": fifteen finite positive raw samples")
        need(all(math.isclose(x * count, y, rel_tol=1e-12) for x, y in zip(row[samples], row[batches])), label + ": per-call normalization")
    need(row["median_ms"] == statistics.median(row["samples_ms"]), label + ": wall median")


def acceptance(row, expected, label):
    need(row["tactic"] == expected and row["accepted"] is True, label + ": expected accepted tactic")
    need(row["used_descriptor"] == ([] if expected == -1 else [1]), label + ": actual descriptor used without fallback")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--trials", type=int, nargs="+", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--expected-source-commit")
    parser.add_argument("--source-root", type=Path, default=Path("/private/tmp/sglang-autotune-selection-study"))
    parser.add_argument("--fixture-root", type=Path, default=Path("/private/tmp/sglang-fp8-linear-20261020T034000Z/capture-raw/fixture"))
    args = parser.parse_args()
    need(len(args.trials) == len(set(args.trials)) and all(t in range(6) for t in args.trials), "valid trial subset")
    commit = args.expected_source_commit or (args.root / "execution-commit.txt").read_text().strip()

    @functools.lru_cache(None)
    def blob(name):
        return subprocess.check_output(["git", "show", commit + ":" + name], cwd=args.source_root)

    def source_sha(name):
        return sha_bytes(blob(name))

    plan = json.loads(blob(BATCH + "/plan.json"))
    source_manifest = json.loads(blob(plan["flashinfer_source"]["input_batch"] + "/source-manifest.json"))
    need(sha_bytes(blob(plan["flashinfer_source"]["input_batch"] + "/source-manifest.json")) == plan["flashinfer_source"]["source_manifest_sha256"], "qualified descriptor source manifest SHA")
    native_sources = {row["installed_package_path"]: row["candidate_sha256"] for row in source_manifest["files"] if row["runtime_overlay"]}
    fixture = load(args.fixture_root / "manifest.json")
    need(sha(args.fixture_root / "manifest.json") == plan["fixture"]["manifest_sha256"], "private fixture manifest matches preregistration")
    need(fixture == json.loads(blob(BATCH + "/fixture-manifest.json")), "private and public frozen manifests agree")
    raw = (args.fixture_root / "fixture.safetensors").read_bytes()
    need(sha_bytes(raw) == fixture["tensor_file"]["sha256"] == plan["fixture"]["tensor_file_sha256"], "private fixture actual file SHA")
    need(len(raw) == fixture["tensor_file"]["size_bytes"] == 12879616, "private fixture actual file size")
    header_size = struct.unpack("<Q", raw[:8])[0]
    header = json.loads(raw[8:8 + header_size])
    payload = raw[8 + header_size:]
    need(set(header) - {"__metadata__"} == set(fixture["tensors"]), "safetensors exact key set")
    for name, meta in fixture["tensors"].items():
        row = header[name]
        lo, hi = row["data_offsets"]
        need(row["shape"] == meta["shape"] and hi - lo == meta["nbytes"], "actual safetensors shape/size: " + name)
        need(sha_bytes(payload[lo:hi]) == meta["sha256"], "independently reconstructed tensor raw-byte SHA: " + name)
    m, n, k = fixture["shape"]
    need([m, n, k] == [144, 4096, 1024], "actual fused QKV dimensions")
    fixture_shas = {name: value["sha256"] for name, value in fixture["tensors"].items()}
    for name, expected in fixture["source"]["sglang_source_sha256"].items():
        need(source_sha(name) == expected, "runtime source bytes match captured source: " + name)

    # Independently inspect the frozen worker rather than importing it.
    text = blob(WORKER).decode()
    cls = next(node for node in ast.parse(text).body if isinstance(node, ast.ClassDef) and node.name == "LinearLayerExperiment")
    methods = {node.name: node for node in cls.body if isinstance(node, ast.FunctionDef)}
    calls = [node for node in ast.walk(methods["operation"]) if isinstance(node, ast.Call)]
    need(len(calls) == 1 and isinstance(calls[0].func, ast.Attribute) and calls[0].func.attr == "apply_layer", "timed eager operation calls actual facade once without output copy")
    measured = ast.get_source_segment(text, methods["measurements"])
    need("measure(self.torch, graph.graph.replay, self.args)" in measured, "graph timing uses raw replay without binding/proxy")
    need(measured.index('self.check_output(label + "_measured_eager")') < measured.index('self.stage = label + "_measure_cuda_graph"'), "eager result checked before graph overwrite")
    need('self.out = graph.output' in measured and 'self.out.fill_(float("nan"))' in measured, "timed graph checks actual captured output and poisons outside timing")
    need('graph.output.fill_(float("nan"))' in ast.get_source_segment(text, methods["check_graph"]), "changed/restored graph controls poison actual owned allocation")
    need('if not capturing:' in ast.get_source_segment(text, methods["native_observation"]), "native observation inserts no poison node into graph")
    checked = ast.get_source_segment(text, methods["check_output"])
    need("rtol=0.02, atol=0.125" in checked and "self.zero_expected" in checked and "self.out.ne(0)" in checked, "numerical source enforces fixed tolerance and exact zero control")
    base_text = blob(BASE).decode()
    base_cls = next(node for node in ast.parse(base_text).body if isinstance(node, ast.ClassDef) and node.name == "SelectionExperiment")
    profile = ast.get_source_segment(base_text, next(node for node in base_cls.body if isinstance(node, ast.FunctionDef) and node.name == "profile_hook"))
    need(profile.index("self.profile_attempts += 1") < profile.index("if not self.allow_profiling"), "profile attempts counted before exceptions can be swallowed")
    helpers = {name: source_sha("test/manual/kernels/" + name) for name in ("flashinfer_autotune_descriptor_selection.py", "flashinfer_autotune_descriptor_qualification.py", "flashinfer_autotune_eager_setup.py")}
    facade_text = blob("python/sglang/srt/layers/quantization/fp8_utils.py").decode()
    facade_fn = next(node for node in ast.parse(facade_text).body if isinstance(node, ast.FunctionDef) and node.name == "apply_fp8_linear_bmm_flashinfer")
    facade_function_sha = sha_bytes((ast.get_source_segment(facade_text, facade_fn) + "\n").encode())
    zero_sha = sha_bytes(bytes(m * n * 2))
    library_path = args.root / "native-builds/candidate/gemm.so"
    ninja_path = args.root / "native-builds/candidate/build.ninja"
    need(library_path.is_file() and ninja_path.is_file(), "actual native binary and ninja artifacts preserved")
    library_sha, ninja_sha = sha(library_path), sha(ninja_path)
    ninja = ninja_path.read_text()
    need("-gencode=arch=compute_90a,code=sm_90a" in ninja, "actual native build targets SM90a")
    translation_units = re.findall(r"^build .+: (?:cuda_compile|compile) (.+)$", ninja, re.MULTILINE)
    need(len(translation_units) == 3 and {Path(path).name for path in translation_units} == {"bmm_fp8.cu", "group_gemm.cu", "flashinfer_gemm_binding.cu"}, "actual native build uses exactly the three audited translation units")
    outputs, profile_summaries = {}, []
    profiles_total = numeric_total = 0
    ranges = collections.defaultdict(list)
    common_settings = None
    natural_stages = ["natural_eager_changed_input", "natural_eager_restored_input", "natural_before", "natural_capture", "natural_after", "natural_after_oracle"]
    numeric_labels = ["initial_untuned", "natural_eager_changed_input", "natural_eager_restored_input", "natural_before", "natural_changed_input", "natural_restored_input", "natural_measured_eager", "natural_measured_cuda_graph", "natural_after", "natural_after_oracle"]

    for trial, arm, phase in itertools.product(args.trials, ARMS, PHASES):
        name = f"trial{trial}-seed19-{arm}-{phase}"
        d = load(args.root / (name + ".json"))
        outputs[trial, arm, phase] = d
        need(d["status"] == "success" and (args.root / (name + ".exit-code")).read_text().strip() == "0", name + ": actual successful worker/exit")
        need((d["trial"], d["seed"], d["arm"], d["phase"], d["shape"]) == (trial, 19, arm, phase, [m, n, k]), name + ": worker identity")
        env, layer = d["environment"], d["actual_layer"]
        need(d["worker_sha256"] == source_sha(WORKER) and env["sglang_commit"] == commit and env["helper_sha256"] == helpers, name + ": frozen worker/helper source provenance")
        need(d["fixture"]["manifest_sha256"] == plan["fixture"]["manifest_sha256"] and d["fixture"]["tensor_file_sha256"] == fixture["tensor_file"]["sha256"], name + ": immutable actual fixture identity")
        for key in ("shape", "model", "capture", "tensors"):
            need(d["fixture"][key] == fixture[key], name + ": fixture metadata " + key)
        need(env["operand_sha256"] == fixture_shas, name + ": all six actual operand byte hashes")
        need(env["gpu"] == plan["environment"]["gpu"] and env["physical_gpu_uuid"] == plan["environment"]["physical_gpu_uuid"], name + ": fixed physical GPU")
        need(plan["environment"]["driver"] in env["gpu_status_before"] and plan["environment"]["physical_gpu_uuid"] in env["gpu_status_before"], name + ": observed actual driver and UUID")
        need(env["torch"] == "2.14.1+cu130" and env["torch_cuda"] == "13.0" and env["flashinfer"] == "0.7.2", name + ": fixed package stack")
        need(env["sglang_wrapper_sha256"] == source_sha("python/sglang/srt/model_executor/runner/flashinfer_autotune.py"), name + ": actual landed startup wrapper")
        need(not env["LD_PRELOAD"] and not env["managed_store"] and env["measurement_policy"] == "unspecified" and d["implementation"] == "candidate", name + ": qualified overlay without preload/store/policy override")
        native = env["native_artifact"]
        need(native["source_sha256"] == native_sources and native["cuda_arch_list"] == "9.0" and native["required_native_exports"] == ["bmm_fp8", "bmm_fp8_get_algos", "bmm_fp8_run_with_descriptor"], name + ": exact qualified source/architecture/exports")
        need(native["library_sha256"] == library_sha and native["ninja_sha256"] == ninja_sha, name + ": actual preserved native artifacts match every worker")
        need(native["library_path"].endswith("/cached_ops/gemm/gemm.so") and native["ninja_path"].endswith("/cached_ops/gemm/build.ninja") and "JitSpec.build then JitSpec.load" in native["bootstrap"], name + ": explicit native JIT path, no AOT substitution")
        need(d["manifest_sha256"] == plan["flashinfer_source"]["source_manifest_sha256"] and env["flashinfer_tuner_sha256"] == native_sources["flashinfer/autotuner/autotuner.py"], name + ": actual tuner and source-manifest hashes")
        need(layer["function"] == "apply_fp8_linear_bmm_flashinfer" and layer["custom_op"] == "flashinfer_bmm_fp8" and layer["quantizer"] == "static_quant_fp8", name + ": actual production layer path")
        need(layer["source_sha256"] == fixture["source"]["sglang_source_sha256"], name + ": actual layer source hashes")
        need(layer["function_source_sha256"] == facade_function_sha, name + ": independently extracted actual facade function source")
        need(layer["inference_mode"] and layer["custom_op_direct_wrapper"] and not any(layer[field] for field in ("grad_enabled", "allow_tf32", "dispatch_modes", "function_modes", "torch_profiler_enabled", "compiling", "kernel_api_log_level")), name + ": normal inference fast path")
        qr = layer["quantization_reference"]
        need(qr["byte_match"] and qr["cpu_and_gpu_independent_references_match"] and qr["actual_input_fp8_sha256"] == qr["independent_input_fp8_sha256"] == fixture["quantization"]["independent_input_fp8_sha256"], name + ": actual static quantizer hard byte gate")
        need(qr["scale_sha256"] == fixture_shas["input_scale"], name + ": actual input quantization scale")
        need(d["profile_attempts"] == len(d["profiles"]) and not d["forbidden_profile_attempts"], name + ": no hidden/swallowed profiling attempts")
        cold_tuned = phase == "cold" and arm != "default"
        need(d["profile_attempts"] > 0 if cold_tuned else d["profile_attempts"] == 0, name + ": correct default/warm/cold participation")
        profiles_total += len(d["profiles"])
        settings(d["autotuner_settings"]["initial"], name + ": initial", False)
        settings(d["autotuner_settings"]["after"], name + ": after", True)
        if common_settings is None:
            common_settings = d["autotuner_settings"]["after"]
        need(d["autotuner_settings"]["after"] == common_settings, name + ": same actual timer/config across workers")
        for row in d["profiles"]:
            need(row["stage"] == "startup" and not row["use_cuda_graph"] and not row["use_cold_l2_cache"], name + ": profiling confined to unchanged startup policy")
            need(row["autotuner_settings"] == common_settings and valid_tactic(row["tactic"]), name + ": candidate timer/schema")
            if row.get("profiler_ms") is not None:
                need(positive(row["profiler_ms"]), name + ": finite positive profile")
        summary = d["runtime_profile_summary"]
        runtime = [row for row in d["profiles"] if row["normalized_profile"] == summary["normalized_profile"]]
        finite = [row for row in runtime if row.get("profiler_ms") is not None]
        need(summary["normalized_profile"][0] == [1, 256, k] and summary["profiles"] == len(runtime) and summary["finite_profiles"] == len(finite), name + ": runtime normalized shape/count")
        if cold_tuned:
            minimum = min(row["profiler_ms"] for row in finite)
            minima = [row["tactic"] for row in finite if row["profiler_ms"] == minimum]
            need(d["natural"]["tactic"] in minima and summary["minimum_ms"] == minimum and summary["minimum_tactics"] == minima, name + ": real finite profile minimum wins")
            need(all(row["input_shapes"][0] == [1, m, k] for row in runtime), name + ": actual M144 profiles normalize to256")
            need(any(row["tactic"] == -1 and row.get("profiler_ms") is not None for row in runtime) if arm == "v2" else not any(row["tactic"] == -1 for row in d["profiles"]), name + ": v2-only default candidate")
            ordered = sorted(finite, key=lambda row: row["profiler_ms"])
            profile_summaries.append({"trial": trial, "arm": arm, "winner": d["natural"]["tactic"], "minimum_ms": minimum, "runner_up_over_minimum": ordered[1]["profiler_ms"] / minimum if len(ordered) > 1 else None})
        else:
            need(not runtime and summary["minimum_ms"] is None, name + ": no default/warm profiles")
        tier = "miss" if arm == "default" else ("memory" if phase == "cold" else "file")
        natural = d["natural"]
        need(natural["lookup_tier"] == tier and natural["cache_hit"] == (tier != "miss"), name + ": actual natural cache source")
        need(valid_tactic(natural["tactic"]) and (arm != "default" or natural["tactic"] == -1), name + ": true default miss/schema")
        acceptance(natural["acceptance"], natural["tactic"], name + ": natural")
        need([row["stage"] for row in d["binding_acceptance_checks"]] == natural_stages, name + ": full native acceptance sequence")
        for row in d["binding_acceptance_checks"]:
            acceptance(row, natural["tactic"], name + ": native " + row["stage"])
        observed = collections.defaultdict(list)
        for row in d["selections"]:
            observed[row["stage"]].append(row)
        for stage in natural_stages:
            need(len(observed[stage]) == 1, name + ": unique public observation " + stage)
            row = observed[stage][0]
            need(row["lookup_tier"] == tier and row["cache_hit"] == (tier != "miss") and row["tactic"] == natural["tactic"] and row["capturing"] == (stage == "natural_capture"), name + ": actual natural tactic/tier " + stage)
        need(len(observed["startup"]) == 1 and observed["startup"][0]["on_forward_stream"] and not observed["startup"][0]["capturing"], name + ": wrapper forward stream")
        need(all(row["on_caller_stream"] for row in d["selections"] if row["stage"] not in ("setup", "startup") and not row["capturing"]), name + ": caller stream restored")
        public = layer["observed_public_inputs"]
        need([row["stage"] for row in public] == [row["stage"] for row in d["selections"]], name + ": every observed public call has actual operand metadata")
        for row in public:
            ins = row["inputs"]
            need(row["backend"] == "cublas" and [v["shape"] for v in ins[:5]] == [[1, m, k], [1, k, n], [1], [1], [1, m, n]], name + ": actual public operand/output shapes/backend")
            need([v["dtype"] for v in ins[:5]] == ["torch.float8_e4m3fn", "torch.float8_e4m3fn", "torch.float32", "torch.float32", "torch.bfloat16"] and ins[1]["stride"][-2:] == [1, k], name + ": actual dtypes and column-major weight")
            if not row["capturing"] and row["stage"] not in ("natural_eager_changed_input", "startup"):
                need(row["quantized_input_sha256"] == fixture["quantization"]["independent_input_fp8_sha256"], name + ": public quantized activation bytes")
                need(row["weight_rowmajor_sha256"] == fixture_shas["weight_fp8_rowmajor"] and row["input_scale_sha256"] == fixture_shas["input_scale"] and row["weight_scale_sha256"] == fixture_shas["weight_scale"], name + ": actual public weight/scalar bytes")
        poisons = layer["native_output_poison_checks"]
        need([row["stage"] for row in poisons] == natural_stages, name + ": allocation poison observation occurs only outside timing")
        need(all(row["capturing"] == (row["stage"] == "natural_capture") and row["poisoned_actual_allocation"] == (row["stage"] != "natural_capture") for row in poisons), name + ": poison actual eager allocation; no graph poison node")
        numeric = d["correctness"]
        need(numeric["passed"] and numeric["rtol"] == 0.02 and numeric["atol"] == 0.125 and [row["check"] for row in numeric["checks"]] == numeric_labels, name + ": exact dynamic-output numerical control sequence")
        numeric_total += len(numeric["checks"])
        for row in numeric["checks"]:
            quantized, dense = row["quantized_reference"], row["bf16_reference"]
            need(quantized["passed"] and dense["diagnostic_only"], name + ": quantized gate versus BF16 diagnostic")
            for ref in (quantized, dense):
                need(all(type(ref[field]) in (int, float) and math.isfinite(ref[field]) and ref[field] >= 0 for field in ("max_abs_error", "max_normalized_error", "rmse", "relative_l2")), name + ": finite nonnegative numeric metrics")
            need(quantized["max_normalized_error"] <= 1.000001 and row["max_abs_error"] == quantized["max_abs_error"], name + ": error within fixed normalized tolerance")
            changed = row["check"] in ("natural_eager_changed_input", "natural_changed_input")
            need(row["exact_zero_required"] == changed, name + ": exact zero-control scope")
            if changed:
                need(quantized["max_abs_error"] == dense["max_abs_error"] == 0 and row["output_sha256"] == zero_sha, name + ": actual changed-input BF16 output bytes are all zero")
            else:
                ranges["quantized_max_normalized_error"].append(quantized["max_normalized_error"])
                ranges["bf16_max_abs_error"].append(dense["max_abs_error"])
                ranges["bf16_relative_l2"].append(dense["relative_l2"])
        need(not d["oracle"] and not d["timing_protocol"]["oracle_order"], name + ": no candidate oracle")
        for execution in ("eager", "cuda_graph"):
            timing(natural[execution], name + ": " + execution)
        path_parts = Path(d["cache"]["path"]).parts
        path = args.root.joinpath(*path_parts[path_parts.index("caches"):])
        need(path.is_file(), name + ": actual natural cache file exists")
        cache = load(path)
        need(sha_bytes(canonical({key: value for key, value in cache.items() if key != "_generation"}).encode()) == cache["_generation"], name + ": actual saved cache generation valid")
        need(sha(path) == d["cache"]["after_startup_sha256"] == d["cache"]["after_oracle_sha256"], name + ": runtime/graph checks preserve exact cache bytes")
        need(d["cache"]["before_sha256"] is None if phase == "cold" else d["cache"]["before_sha256"] == sha(path), name + ": initial cold/warm file state")
        entries = {key: value for key, value in cache.items() if not key.startswith("_")}
        if arm == "default":
            need(not entries, name + ": true-miss control persists no winners")
        else:
            need(entries[d["cache"]["runtime_file_key"]][1] == natural["tactic"], name + ": actual saved runtime winner")
            cold = outputs[trial, arm, "cold"]
            need(len(entries) == len({canonical(row["normalized_profile"]) for row in cold["profiles"]}), name + ": all tuned buckets retained")

    need(len({(args.root / f"trial{trial}-seed19-{arm}-{phase}.container-id").read_text().strip() for trial, arm, phase in outputs}) == len(outputs), "each worker has a distinct fresh container")
    need(len({d["environment"]["native_artifact"]["library_sha256"] for d in outputs.values()}) == 1, "identical explicitly built native binary across arms")
    need(len({canonical(d["environment"]["native_artifact"]["source_sha256"]) for d in outputs.values()}) == 1, "identical qualified native sources across arms")
    for trial, arm in itertools.product(args.trials, ARMS):
        cold, warm = outputs[trial, arm, "cold"], outputs[trial, arm, "warm"]
        need(cold["natural"]["tactic"] == warm["natural"]["tactic"], f"trial{trial}/{arm}: cold winner survives fresh-process load")
        need(cold["cache"]["after_startup_sha256"] == warm["cache"]["before_sha256"] == warm["cache"]["after_oracle_sha256"], f"trial{trial}/{arm}: exact cold/warm byte chain")
        need(warm["profile_attempts"] == 0 and not warm["profiles"], f"trial{trial}/{arm}: no warm profiling attempts")
    contrasts = []
    for phase, execution, channel, pair in itertools.product(PHASES, ("eager", "cuda_graph"), ("wall", "gpu_event"), (("v2", "v1"), ("v1", "default"), ("v2", "default"))):
        left, right = pair
        def median(d):
            row = d["natural"][execution]
            return row["median_ms"] if channel == "wall" else statistics.median(row["gpu_event_samples_ms"])
        ratios = [median(outputs[t, left, phase]) / median(outputs[t, right, phase]) for t in args.trials]
        contrasts.append({"phase": phase, "execution": execution, "channel": channel, "primary": channel == ("wall" if execution == "eager" else "gpu_event"), "numerator": left, "denominator": right, "trial_ratios": ratios, "median_ratio": statistics.median(ratios), "wins": sum(value < 1 for value in ratios), "independent_trials": len(ratios)})
    winners = {}
    for arm in ARMS:
        count = collections.Counter(canonical(outputs[t, arm, "cold"]["natural"]["tactic"]) for t in args.trials)
        winners[arm] = [{"tactic": json.loads(key), "count": value} for key, value in count.items()]
    report = {
        "status": "passed", "immutable_raw": True, "complete_six_trial_batch": len(args.trials) == 6, "source_commit": commit, "trials": args.trials,
        "workers": len(outputs), "assertions": checks, "cold_profile_attempts": profiles_total,
        "warm_profile_attempts": sum(d["profile_attempts"] for (_, _, phase), d in outputs.items() if phase == "warm"),
        "forbidden_profile_attempts": 0, "numerical_checks": numeric_total, "exact_zero_byte_checks": 2 * len(outputs),
        "winner_frequencies": winners, "natural_paired_contrasts": contrasts, "runtime_profile_minima": profile_summaries,
        "numerical_ranges": {name: {"minimum": min(values), "maximum": max(values)} for name, values in ranges.items()},
        "input_sha256": fixture_shas, "quantized_input_sha256": fixture["quantization"]["independent_input_fp8_sha256"],
        "scope": "Independent stdlib source/cache/fixture/timing/numerical-evidence audit, without analyzer import or GPU recomputation. Repeated trials on one fixed layer fixture, not pooled timing samples. No full-model or serving-throughput claim.",
        "concerns": [],
    }
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps({key: report[key] for key in ("status", "workers", "assertions", "cold_profile_attempts", "warm_profile_attempts", "numerical_checks", "winner_frequencies")}))


if __name__ == "__main__":
    main()
