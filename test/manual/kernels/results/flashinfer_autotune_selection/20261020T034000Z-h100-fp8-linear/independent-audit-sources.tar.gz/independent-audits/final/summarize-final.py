"""Derive a final readable summary after independent raw arithmetic validation."""
import collections,hashlib,json,statistics
from pathlib import Path
base=Path('/private/tmp/sglang-fp8-linear-20261020T034000Z')
analysis_path=Path('/private/tmp/fi-fp8-linear-final-frozen-analysis.json');d=json.loads(analysis_path.read_text());a=d['analysis']
assert analysis_path.read_bytes()==(base/'analysis.json').read_bytes()
raw=base/'raw'/'attempt01';audit_path=Path('/private/tmp/fi-fp8-linear-final-analysis-audit.json');audit=json.loads(audit_path.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def compact(row):
 ci=row['exploratory_cluster_bootstrap_95_percent']
 return {**{k:row[k] for k in ('phase','execution','channel','primary','comparison','numerator_lookup_tier','denominator_lookup_tier') if k in row},
  'median_paired_ratio':row['median_ratio'],'trial_ratios':[r['ratio'] for r in row['trial_estimates']],
  'range':[row['min_ratio'],row['max_ratio']],'ratios_below_one':row['ratios_below_one'],'ratios_above_one':row['ratios_above_one'],
  'exploratory_95_percent_whole_trial_bootstrap':[ci['lower'],ci['upper']]}
workers={(t,arm,phase):json.loads((raw/f'trial{t}-seed19-{arm}-{phase}.json').read_text()) for t in range(6) for arm in ('default','v1','v2') for phase in ('cold','warm')}
all_profiles=[r for w in workers.values() for r in w['profiles']]
all_checks=[r for w in workers.values() for r in w['correctness']['checks']]
nonzero=[r for r in all_checks if not r['exact_zero_required']]
# Aliases preserve complete eight-word identities without repeating long arrays.
aliases={};identities={'default':-1}
for group in a['cold_winner_frequencies']:
 for entry in group['winners']:
  tactic=entry['tactic'];key=json.dumps(tactic)
  if tactic==-1:aliases[key]='default'
  elif key not in aliases:
   name='explicit_'+str(len([v for v in aliases.values() if v!='default'])+1)
   aliases[key]=name;identities[name]=tactic
frequencies=[];profiles=[]
for group in a['cold_winner_frequencies']:
 frequencies.append({'arm':group['arm'],'fresh_trials':6,'winners':[{'id':aliases[json.dumps(r['tactic'])],'count':r['count']} for r in group['winners']]})
for arm in ('v1','v2'):
 rows=[r for r in a['startup_profiler_rankings'] if r['arm']==arm];margins=[r['runner_up_fractional_margin'] for r in rows]
 profiles.append({'arm':arm,'winner_by_trial':[aliases[json.dumps(r['selected_tactic'])] for r in rows],
  'minimum_ms_by_trial':[r['ranked_profiles'][0]['profiler_ms'] for r in rows],
  'runner_up_fractional_margin_by_trial':margins,'margin_median':statistics.median(margins),'margin_range':[min(margins),max(margins)],
  'finite_runtime_candidates':[r['finite_candidates'] for r in rows]})
absolute=[]
for phase in ('cold','warm'):
 for arm in ('default','v1','v2'):
  rows=[workers[t,arm,phase] for t in range(6)]
  absolute.append({'phase':phase,'arm':arm,
   'median_of_worker_eager_wall_medians_ms':statistics.median(statistics.median(r['natural']['eager']['samples_ms']) for r in rows),
   'median_of_worker_graph_event_medians_ms':statistics.median(statistics.median(r['natural']['cuda_graph']['gpu_event_samples_ms']) for r in rows),
   'scope':'Descriptive absolute medians; primary effects use median paired ratios by trial, not division of these medians.'})
startup=[]
for row in a['startup_diagnostics']:
 if row['comparison']=='v2_over_v1':
  item=compact(row)
  for arm in ('v1','v2'):item[arm+'_median_wrapper_startup_ms']=statistics.median(workers[t,arm,row['phase']]['startup_ms'] for t in range(6))
  startup.append(item)
quantized_metrics={key:sorted({r['quantized_reference'][key] for r in nonzero}) for key in ('max_abs_error','max_normalized_error','rmse','relative_l2')}
bf16_metrics={key:sorted({r['bf16_reference'][key] for r in nonzero}) for key in ('max_abs_error','max_normalized_error','rmse','relative_l2')}
cold_gap=[compact(r) for r in a['natural_latency_comparisons'] if r['phase']=='cold' and r['execution']=='cuda_graph' and r['comparison']=='v2_over_default']
audit['root_analysis_byte_identical']=True
audit['report_status']='FINAL; immutable after readiness'
audit['observed_cold_graph_control_gap']={'primary_v2_over_untuned_default':next(r for r in cold_gap if r['primary']),
 'same_public_tactic':-1,'default_and_v2_effective_replay_iterations':sorted({workers[t,arm,'cold']['natural']['cuda_graph']['effective_iterations'] for t in range(6) for arm in ('default','v2')}),
 'scope':'Post-tuning graph replay latency; separate from initialization/startup time. Observation is descriptive and is not a validation speedup threshold.'}
audit_path.write_text(json.dumps(audit,indent=2)+'\n')
summary={
 'status':'success','report_status':'FINAL; immutable after readiness',
 'headline':'V2 consistently selects the default and improves layer graph latency versus v1; a repeatable cold-process graph regression versus untuned default remains unresolved.',
 'source_commit':d['source_commit'],'analyzer_sha256':d['analyzer_sha256'],
 'analysis_sha256':sha(analysis_path),'audit_report_sha256':sha(audit_path),
 'scope':{'hardware':d['outer_provenance']['environment'],'image':d['outer_provenance']['plan']['container_image'],
  'layer':'Actual apply_fp8_linear_bmm_flashinfer, static SGLang quantizer, normal custom-op dispatch/allocation and FlashInfer cublas',
  'model':'Qwen/Qwen3-0.6B revisionc1899de289a04d12100db370d81485cdf75e47ca; layer0 fused Q/K/V checkpoint weights and144-token captured activations',
  'shape':[144,4096,1024],'normalized_runtime_cache_m':256,'input_seed':19,
  'input_scope':'One fixed captured BF16 input/checkpoint weight fixture adapted to static per-tensor FP8 using this single batch; not a pre-calibrated deployed FP8 checkpoint.',
  'fixture_manifest_sha256':d['fixture_manifest_sha256'],'fixture_tensor_file_sha256':d['outer_provenance']['fixture_manifest']['tensor_file']['sha256'],
  'implementation':'FlashInfer0.7.2 plus exact descriptor PR6148 diff at14c5c67a1eb9ad3a608b8d3da3bf6d8924037c5c; experimental overlay.',
  'fresh_trials':6,'workers':36,'arm_order':'All six permutations of default/v1/v2 used once; each arm cold then fresh warm process.',
  'persistence':'Existing v1 JSON save/load; unspecified policy, managed store disabled.',
  'primary_timing':{'eager':'Whole linear-helper public-call wall latency','cuda_graph':'GPU-event replay span including possible host submission gaps; Python cache lookup occurs during capture, not replay.'},
  'measurement':'15 natural samples per mode/channel;500ms warmup,20ms calibration target, actual batch normalization; no forced candidate sweep or timed observation hooks.',
  'uncertainty':'Six fresh paired trial units; exact46,656 ordered whole-trial resamples, exploratory unadjusted percentile95% intervals. Worker samples are not independent trials.'},
 'validation':{'independent_actual_data_checks':audit['checks_passed'],'fresh_workers':36,'numerical_checks':audit['numerical_checks'],
  'native_acceptance_checks':audit['native_acceptance_checks'],'actual_native_output_poison_checks':audit['actual_native_output_poison_checks'],
  'profiles':len(all_profiles),'v1_profiles':432,'v2_profiles':486,'finite_profiles':sum(r.get('profiler_ms') is not None for r in all_profiles),'profile_errors':sum(bool(r.get('error')) for r in all_profiles),
  'default_or_warm_profile_attempts':0,'forbidden_profile_attempts':0,
  'persistence':'All18 cold/warm pairs preserve natural cache bytes and winner; tuned warm serving/capture consumes true file hits without memory promotion.',
  'graphs':'All36 eager and captured-allocation changed/restored-input tests pass exact zero and quantized-reference gates; poisoning is outside capture/timing.',
  'source_and_binary':'Original execution source, complete descriptor overlay and shared native .so/Ninja rehashed and bound to every fresh worker.',
  'private_fixture':'Whole retained safetensors and all six exact tensor byte ranges independently rehashed.',
  'original_input_output_sha_count':len({r['output_sha256'] for r in nonzero}),
  'root_and_independent_frozen_analysis_byte_identical':True},
 'candidate_identities':identities,'cold_winner_frequencies':frequencies,'startup_profiler_minimum_margins':profiles,
 'natural_primary_comparisons':[compact(r) for r in a['natural_latency_comparisons'] if r['primary']],
 'absolute_layer_latencies':absolute,
 'cold_process_graph_control_gap':{
  'classification':'Observed post-tuning graph runtime regression versus untuned default; not cold-start tuning cost.',
  'comparisons':cold_gap,
  'same_public_tactic_in_both_arms':-1,
  'all_cold_default_and_v2_graph_batches_use_iterations':5120,
  'warm_graph_v2_over_default':next(compact(r) for r in a['natural_latency_comparisons'] if r['phase']=='warm' and r['execution']=='cuda_graph' and r['comparison']=='v2_over_default' and r['primary']),
  'interpretation':'Cold v2 replay is slower in every trial: median ratio1.040151, range1.032082–1.074208, exploratory interval[1.035184,1.060628]. Wall timing agrees. Warm reuse is neutral versus untuned default. Current data does not identify the cause; both use public-1 but kernel identity and capture/process state are unobserved.',
  'guardrail':'Keep this regression visible and investigate it before broader performance or policy claims. The user prioritizing warm serving over startup cost does not waive a post-startup replay regression.'},
 'numerical_references':{'quantized_input_FP32_gate':quantized_metrics,'original_BF16_projection_diagnostic_only':bf16_metrics,
  'scope':'All nonzero recorded outputs are bit-identical across arms/trials here. This validates the tested quantized layer, not full-model quantized accuracy; BF16 relativeL2 is~2.306% for this single-batch calibration.'},
 'startup_secondary_diagnostics':startup,
 'interpretation':[
  'V2 selected default-1 in all6 fresh tunings, persisted it and served it from warm files. V1 selected three explicit descriptors3/2/1 times. V2 runtime-bucket profiler margins are5.95–8.63% (median6.64%); v1 margins are0–0.78% (median0.29%), including a tie.',
  'Relative to v1, warm layer graph replay favors v2 in all6 trials: median ratio0.862714, range0.726794–0.880813, exploratory interval[0.786159,0.878873]. This is a measured layer result, not serving throughput.',
  'Warm eager v2/v1 is close to neutral: median0.986103, exploratory interval[0.973782,1.001173], with one1.007245 regression. Do not claim a resolved eager speedup from the point estimate.',
  'Both tuned eager paths beat the natural untuned default in all6 warm trials, with median ratios0.928556(v1/default) and0.917791(v2/default). These configurations use cached file hits versus genuine default misses, so the result includes lookup/dispatch differences and does not isolate candidate GPU-kernel quality.',
  'Warm graph v2/default is neutral: median0.997132, exploratory interval[0.991544,1.003476], with4 ratios below1 and2 above. V1/default warm graph is slower in every trial (median1.157930).',
  'Cold-process graph v2/default is slower in all6 trials despite the same public default tactic: median1.040151 and both timing channels agree. This is post-tuning replay runtime, distinct from wrapper startup time, and remains an unresolved regression.',
  'Actual operation profiling remains eager/hot-L2 with3 warmups,10 repeats, legacy5000us stream delay, global timer false and no measurement policy. Dynamic profiling activations are synthesized while serving quantizes the captured BF16 input; startup minima do not establish a serving-global optimum.',
  'V2 wrapper tuning duration is~9.76% higher than v1 here (~511.6ms versus466.0ms median); this is a secondary operation diagnostic excluding acquisition/build/preparation, with no cold-start serving claim.'
 ],
 'limits':[
  'One H100 NVL, one captured144-token fused-QKV layer and six repetitions; no traffic-distribution/model/backend/device generalization.',
  'Natural timings are separate fresh-worker windows; multiple paired comparisons and bootstrap intervals are exploratory and unadjusted.',
  'Untuned default misses and tuned memory/file hits differ; graph lookup is excluded from replay, so cache lookup cost alone cannot explain the observed graph control gap.',
  'No forced serving-candidate oracle or native/trace observation was collected. The same public-1 does not prove identical native algorithm or physical GPU launches.',
  'The dense BF16 checkpoint was adapted to single-batch static FP8 calibration; passing layer numerics and BF16 diagnostics do not establish full-model accuracy.',
  'No explicit-policy adoption, managed-store migration, multi-GPU/backend validation, full server or serving-throughput measurement.'
 ],
 'next_bounded_recommendation':{
  'action':'Investigate the cold-process default-1 graph control gap on this same frozen layer fixture before broadening performance claims or changing policy.',
  'uninstrumented_control':'Use fresh workers retaining the untuned graph captured before tuning, the cached-default graph captured after v2 tuning, and an untuned-miss graph captured after tuning with a reversible cache-state control. Replaying the retained pre-tuning graph after tuning helps separate capture/allocation changes from process-history effects.',
  'measurement':'Measure the retained graphs in balanced randomized interleaved blocks with common replay counts, fixed inputs and verified graph-owned outputs; preserve cold/warm labels, cache state and both wall/event channels.',
  'separate_observation':'In a separate non-performance pass, capture actual native algorithm bytes/settings and CUDA launch signatures for each graph capture, with GPU clock/power/context evidence. Instrumented duration must not be interpreted as performance.',
  'decision':'If the gap follows different graph/native launches or allocation state, isolate that mechanism; if it disappears under interleaving, quantify the earlier window/history effect. Retain the regression until explained rather than attributing it to startup overhead.',
  'launch_status':'Proposal only; no new experiment launched by this report.'}}
out=Path('/private/tmp/fi-fp8-linear-final-summary.json');out.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'status':'FINAL','audit_checks':audit['checks_passed'],'audit_sha256':sha(audit_path),'summary_sha256':sha(out)}))
