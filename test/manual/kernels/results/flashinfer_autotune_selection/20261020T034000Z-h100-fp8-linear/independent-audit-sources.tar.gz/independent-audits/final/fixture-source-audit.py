"""Independently audit the frozen model-layer fixture with the standard library."""

import array
import bisect
import hashlib
import json
import math
import runpy
import struct
import subprocess
import sys
from pathlib import Path

ROOT = Path('/private/tmp/sglang-autotune-selection-study')
BATCH = 'test/manual/kernels/results/flashinfer_autotune_selection/20261020T034000Z-h100-fp8-linear'
FIXTURE = Path('/private/tmp/sglang-fp8-linear-20261020T034000Z/capture-raw/fixture')
CAPTURE_COMMIT = 'a29b31850c7b68cafde022614b00ab01d6ff5cde'
CAPTURE_SHA = 'c3c88dbf3df9fe0dc73d89a5acb9038e5b09fb1efc6316bc36917d06251f92a4'
OUTPUT = Path('/private/tmp/fi-fp8-linear-fixture-source-audit.json')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def f32(value):
    return struct.unpack('<f', struct.pack('<f', value))[0]


def bf16(word):
    return struct.unpack('<f', struct.pack('<I', word << 16))[0]


def words(payload):
    result = array.array('H')
    result.frombytes(payload)
    if sys.byteorder != 'little':
        result.byteswap()
    return result


positive_fp8 = [
    mantissa * 2 ** -9 if exponent == 0 else (1 + mantissa / 8) * 2 ** (exponent - 7)
    for exponent in range(16)
    for mantissa in range(8)
    if not (exponent == 15 and mantissa == 7)
]


def round_fp8(value, negative):
    value = min(abs(value), 448.0)
    high = bisect.bisect_left(positive_fp8, value)
    if high == 0:
        code = 0
    elif high == len(positive_fp8):
        code = len(positive_fp8) - 1
    else:
        low = high - 1
        left, right = value - positive_fp8[low], positive_fp8[high] - value
        code = low if left < right else high if left > right else low if low % 2 == 0 else high
    return code | (128 if negative else 0)


def quantize_bf16(payload, scale, reciprocal):
    source = words(payload)
    lookup = {}
    multiplier = f32(1 / scale)
    for word in set(source):
        value = bf16(word)
        if not math.isfinite(value):
            raise ValueError('nonfinite original BF16 operand')
        scaled = f32(value * multiplier) if reciprocal else f32(value / scale)
        lookup[word] = round_fp8(scaled, bool(word & 0x8000))
    return bytes(lookup[word] for word in source)


def main():
    result = {'status': 'error', 'final': True, 'checks': [], 'errors': []}
    details = {}

    def require(condition, text):
        if not condition:
            raise ValueError(text)

    def check(name, operation):
        try:
            detail = operation()
            result['checks'].append({'name': name, 'status': 'passed', 'detail': detail})
        except Exception as error:
            result['errors'].append({'name': name, 'error': str(error)})

    manifest_bytes = (FIXTURE / 'manifest.json').read_bytes()
    manifest = json.loads(manifest_bytes)
    binary = (FIXTURE / 'fixture.safetensors').read_bytes()
    length = struct.unpack('<Q', binary[:8])[0]
    header = json.loads(binary[8:8 + length])
    data = binary[8 + length:]
    payloads = {name: data[row['data_offsets'][0]:row['data_offsets'][1]] for name, row in header.items() if name != '__metadata__'}

    def source():
        capture = subprocess.check_output(['git', 'show', CAPTURE_COMMIT + ':' + BATCH + '/capture_fixture.py'], cwd=ROOT)
        require(sha(capture) == CAPTURE_SHA == manifest['source']['capture_script_sha256'], 'capture source SHA differs')
        require(manifest['source']['sglang_commit'] == CAPTURE_COMMIT, 'capture commit differs')
        require((ROOT / BATCH / 'capture_fixture.py').read_bytes() == capture, 'current capture script differs')
        require((ROOT / BATCH / 'fixture-manifest.json').read_bytes() == manifest_bytes, 'public manifest differs from immutable private bytes')
        module = runpy.run_path(str(ROOT / BATCH / 'capture_fixture.py'))
        require(module['source_evidence'](ROOT) == manifest['source']['sglang_source_sha256'], 'production source/layout differs')
        for name, expected in manifest['source']['sglang_source_sha256'].items():
            require(sha(subprocess.check_output(['git', 'show', CAPTURE_COMMIT + ':' + name], cwd=ROOT)) == expected, 'capture source blob differs: ' + name)
        return {'commit': CAPTURE_COMMIT, 'script_sha256': CAPTURE_SHA, 'production_sources': len(manifest['source']['sglang_source_sha256']), 'manifest_sha256': sha(manifest_bytes)}
    check('frozen capture, public/private manifest and production QKV source order', source)

    def layout():
        require(manifest['shape'] == [144, 4096, 1024], 'workload shape differs')
        require(sha(binary) == manifest['tensor_file']['sha256'] and len(binary) == manifest['tensor_file']['size_bytes'], 'fixture byte identity differs')
        require(header['__metadata__']['revision'] == manifest['model']['revision'] == manifest['model']['resolved_snapshot_revision'] == 'c1899de289a04d12100db370d81485cdf75e47ca', 'checkpoint revision differs')
        require(header['__metadata__']['model_id'] == manifest['model']['repo_id'] == 'Qwen/Qwen3-0.6B', 'checkpoint identity differs')
        expected = {'input_bf16': ('BF16', 'torch.bfloat16', [144, 1024], 2), 'weight_bf16_rowmajor': ('BF16', 'torch.bfloat16', [4096, 1024], 2), 'weight_fp8_rowmajor': ('F8_E4M3', 'torch.float8_e4m3fn', [4096, 1024], 1), 'input_scale': ('F32', 'torch.float32', [1], 4), 'weight_scale': ('F32', 'torch.float32', [1], 4), 'input_ids': ('I64', 'torch.int64', [1, 144], 8)}
        require(set(payloads) == set(expected) == set(manifest['tensors']), 'unexpected tensor coverage')
        for name, (stored_dtype, reported_dtype, shape, size) in expected.items():
            actual, meta, payload = header[name], manifest['tensors'][name], payloads[name]
            require(actual['dtype'] == stored_dtype and meta['dtype'] == reported_dtype and actual['shape'] == meta['shape'] == shape, 'tensor dtype/shape differs: ' + name)
            require(len(payload) == meta['nbytes'] == math.prod(shape) * size and sha(payload) == meta['sha256'], 'tensor bytes differ: ' + name)
        ranges = sorted(row['data_offsets'] for name, row in header.items() if name != '__metadata__')
        require(ranges[0][0] == 0 and ranges[-1][1] == len(data) and all(left[1] == right[0] for left, right in zip(ranges, ranges[1:])), 'safetensors overlaps/gaps/trailing data')
        return {'tensor_file_sha256': sha(binary), 'size_bytes': len(binary), 'tensor_count': len(payloads), 'header_bytes': length}
    check('complete safetensors header, contiguous slices and all six tensor hashes', layout)

    def provenance():
        c = manifest['capture']
        require(c['captured_shape'] == [1, 144, 1024] and c['saved_shape'] == [144, 1024], 'hook reshape differs')
        require(c['projection_shapes'] == [[2048, 1024], [1024, 1024], [1024, 1024]] and c['weight_order'] == ['q_proj', 'k_proj', 'v_proj'], 'fused projection provenance differs')
        require(c['hook'] == 'model.layers.0.self_attn.q_proj:forward_pre_hook' and c['full_bf16_forward_completed'] and c['model_training'] is False and c['attention_implementation'] == 'eager' and c['device'] == 'cuda' and c['seed'] == 19 and c['bias'] is None and c['tensor_parallel_size'] == 1, 'capture execution facts differ')
        ids = list(struct.unpack('<144q', payloads['input_ids']))
        t = manifest['tokenization']
        require(t['input_ids'] == [ids] and t['attention_mask'] == [[1] * 144] and all(type(value) is int and 0 <= value < 151936 for value in ids), 'token IDs differ from retained tensor bytes')
        require(t['prompt'] and not t['add_special_tokens'] and not t['padding'] and t['truncation'] and t['max_length'] == 144, 'tokenization protocol differs')
        require({'config.json', 'model.safetensors', 'tokenizer_config.json'} <= manifest['checkpoint_files'].keys(), 'required checkpoint provenance absent')
        require(manifest['software']['torch'] == '2.14.1+cu130' and len(manifest['source']['upstream_source_sha256']) >= 2, 'runtime/capture source provenance absent')
        return {'input_ids': len(ids), 'checkpoint_files': len(manifest['checkpoint_files']), 'projection_rows': [2048, 1024, 1024], 'checkpoint_file_bytes_locally_rehashed': False}
    check('captured layer geometry, execution, token IDs and checkpoint provenance', provenance)

    def calibration():
        values = {}
        for operand, scale_name in [('input_bf16', 'input_scale'), ('weight_bf16_rowmajor', 'weight_scale')]:
            samples = words(payloads[operand])
            maximum_word = max(value & 0x7fff for value in samples)
            require(maximum_word < 0x7f80, 'nonfinite BF16 calibration operand')
            maximum = bf16(maximum_word)
            scale = struct.unpack('<f', payloads[scale_name])[0]
            require(scale > 0 and math.isfinite(scale) and struct.pack('<f', maximum / 448) == payloads[scale_name], 'scale is not correctly rounded BF16 absmaxFP32/448')
            values[operand] = {'absmax': maximum, 'scale': scale}
        details['scales'] = values
        return values
    check('independent BF16 byte decoding and exact FP32 static calibration', calibration)

    def weights():
        scale = struct.unpack('<f', payloads['weight_scale'])[0]
        expected = quantize_bf16(payloads['weight_bf16_rowmajor'], scale, reciprocal=False)
        require(expected == payloads['weight_fp8_rowmajor'], 'independent RN-even FP8 weight quantization differs')
        k, offset, projections = 1024, 0, []
        for name, rows in zip(('q_proj', 'k_proj', 'v_proj'), (2048, 1024, 1024)):
            size = rows * k * 2
            projections.append({'projection': name, 'rows': rows, 'original_bf16_slice_sha256': sha(payloads['weight_bf16_rowmajor'][offset:offset + size])})
            offset += size
        return {'quantized_values_verified': len(expected), 'fp8_sha256': sha(expected), 'projection_slices': projections}
    check('every FP8 weight independently reconstructed with FP32 division and RN-even rounding', weights)

    def activation():
        scale = struct.unpack('<f', payloads['input_scale'])[0]
        expected = quantize_bf16(payloads['input_bf16'], scale, reciprocal=True)
        require(sha(expected) == manifest['quantization']['independent_input_fp8_sha256'], 'independent reciprocal/multiply activation quantizer digest differs')
        return {'quantized_values_verified': len(expected), 'fp8_sha256': sha(expected)}
    check('independent captured activation FP32 reciprocal/multiply/clamp/RN-even FP8 reference', activation)
    require(bytes([118, 108, 108, 109]) not in manifest_bytes.lower(), 'restricted token in public manifest')
    result['status'] = 'success' if not result['errors'] else 'error'
    result['scope_limits'] = ['No GPU or third-party tensor library used by this audit.', 'Original full checkpoint file bytes are not local; their recorded hashes and pinned revision are provenance, not an independent local rehash.', 'Checkpoint-to-fused-QKV ordering is proved by frozen capture/source AST and reported projection sizes; the retained BF16 slices provide exact future checkpoint-comparison targets.', 'This fixture audit establishes capture and quantization integrity, not full-model FP8 accuracy or serving performance.']
    OUTPUT.write_text(json.dumps(result, indent=2) + '\n')
    OUTPUT.chmod(0o444)
    print(json.dumps({'status': result['status'], 'checks': len(result['checks']), 'errors': result['errors'], 'report_sha256': sha(OUTPUT.read_bytes())}))
    return 0 if result['status'] == 'success' else 1


if __name__ == '__main__':
    raise SystemExit(main())
