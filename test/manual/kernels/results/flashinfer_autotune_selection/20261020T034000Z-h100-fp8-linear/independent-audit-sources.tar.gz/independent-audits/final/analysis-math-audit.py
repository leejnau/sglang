"""Independent stdlib audit of raw layer workers; no experiment analyzer imports."""
import argparse,collections,hashlib,itertools,json,math,statistics,struct,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--raw-root',type=Path,required=True);p.add_argument('--analysis',type=Path,required=True);p.add_argument('--commit',required=True);p.add_argument('--trials',type=int,nargs='+',required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
source=Path('/private/tmp/sglang-autotune-selection-study');raw=args.raw_root;checks=0

def check(condition,message):
 global checks
 checks+=1
 if not condition:raise AssertionError(message)
def same(a,b,message):check(math.isclose(a,b,rel_tol=1e-12,abs_tol=1e-15),message)
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def blob(path,commit=None):return subprocess.check_output(['git','show',(commit or args.commit)+':'+path],cwd=source)
def locate(path):
 parts=Path(path).parts
 return raw/'caches'/Path(*parts[parts.index('caches')+1:]) if 'caches' in parts else raw/Path(path).name

def generation(payload):
 content={k:v for k,v in payload.items() if k!='_generation'}
 check(payload['_generation']==hashlib.sha256(json.dumps(content,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'payload generation')
def percentile(values,p):
 values=sorted(values);position=p*(len(values)-1);lo,hi=math.floor(position),math.ceil(position)
 return values[lo]+(values[hi]-values[lo])*(position-lo)
def check_stats(reported,ratios):
 same(reported['median_ratio'],statistics.median(ratios),'paired trial ratio median')
 same(reported['min_ratio'],min(ratios),'paired ratio min');same(reported['max_ratio'],max(ratios),'paired ratio max')
 check(reported['independent_trials']==len(args.trials),'independent trial count')
 check(reported['ratios_below_one']==sum(v<1 for v in ratios) and reported['ratios_above_one']==sum(v>1 for v in ratios),'preserve win/regression counts')
 ci=reported['exploratory_cluster_bootstrap_95_percent']
 if len(args.trials)==1:
  check(ci is None,'no n1 confidence interval')
 else:
  # Literal ordered whole-trial resamples are independent of the frozen
  # analyzer's compact multinomial-weight implementation.
  distribution=[statistics.median(ratios[i] for i in indices) for indices in itertools.product(range(len(ratios)),repeat=len(ratios))]
  same(ci['lower'],percentile(distribution,.025),'literal trial bootstrap lower')
  same(ci['upper'],percentile(distribution,.975),'literal trial bootstrap upper')
  check(ci['ordered_resamples']==len(args.trials)**len(args.trials) and ci['independent_units']==len(args.trials),'bootstrap units')
manifest=read(raw/'manifest.json');fixture=read(raw/'fixture'/'manifest.json');analysis=read(args.analysis)
check((raw/'execution-commit.txt').read_text().strip()==args.commit,'execution commit')
check(analysis['status']=='success' and analysis['source_commit']==args.commit,'frozen analysis source/status')
for path,value in manifest['source_sha256'].items():check(hashlib.sha256(blob(path)).hexdigest()==value,'frozen source '+path)
check(sha(raw/'fixture'/'manifest.json')==manifest['fixture_manifest_sha256']==analysis['fixture_manifest_sha256'],'fixture manifest source binding')
check(fixture['tensor_file']['sha256']==manifest['fixture_tensor_file_sha256'],'private tensor SHA binding')
m,n,k=fixture['shape'];check((m,n,k)==(144,4096,1024),'actual fused-QKV fixture shape')
check(fixture['model']['revision']=='c1899de289a04d12100db370d81485cdf75e47ca' and fixture['capture']['weight_order']==['q_proj','k_proj','v_proj'],'actual model revision/QKV order')
for path,value in fixture['source']['sglang_source_sha256'].items():
 check(hashlib.sha256(blob(path,fixture['source']['sglang_commit'])).hexdigest()==value==hashlib.sha256(blob(path)).hexdigest(),'capture/final source chain')
# Parse private safetensors without Torch or safetensors imports and verify each
# saved tensor's exact byte range against its public metadata.
private=raw/'fixture'/fixture['tensor_file']['name'];private_checked=False
if private.is_file():
 content=private.read_bytes();check(hashlib.sha256(content).hexdigest()==fixture['tensor_file']['sha256'],'private fixture file SHA')
 header_length=struct.unpack('<Q',content[:8])[0];header=json.loads(content[8:8+header_length]);payload=memoryview(content)[8+header_length:]
 for name,expected in fixture['tensors'].items():
  entry=header[name];begin,end=entry['data_offsets'];tensor_bytes=payload[begin:end]
  check(entry['shape']==expected['shape'] and end-begin==expected['nbytes'],'private tensor shape/extent')
  check(hashlib.sha256(tensor_bytes).hexdigest()==expected['sha256'],'private tensor exact bytes '+name)
 private_checked=True
workers={};allcids=[];profiles_total=0;numerical_total=0;acceptance_total=0;poison_total=0;profile_rows=[];metrics_summary=[]
for trial,arm,phase in itertools.product(args.trials,('default','v1','v2'),('cold','warm')):
 stem=f'trial{trial}-seed19-{arm}-{phase}';d=read(raw/(stem+'.json'));workers[trial,arm,phase]=d
 check(d['status']=='success' and (d['trial'],d['arm'],d['phase'])==(trial,arm,phase),'worker identity')
 check((raw/(stem+'.exit-code')).read_text().strip()=='0','worker exit')
 cid=(raw/(stem+'.container-id')).read_text().strip();allcids.append(cid)
 check(d['seed']==19 and d['shape']==fixture['shape'],'fixed worker workload')
 check(d['fixture']['manifest_sha256']==manifest['fixture_manifest_sha256'] and d['fixture']['tensor_file_sha256']==fixture['tensor_file']['sha256'],'per-worker fixture bytes')
 check(d['environment']['operand_sha256']=={name:r['sha256'] for name,r in fixture['tensors'].items()},'actual loaded tensor contents')
 check(d['environment']['sglang_commit']==args.commit and not d['environment']['LD_PRELOAD'],'worker source/uninstrumented')
 check(d['environment']['physical_gpu_uuid'].removeprefix('GPU-')==manifest['gpu']['uuid'].removeprefix('GPU-'),'worker GPU UUID')
 layer=d['actual_layer'];q=layer['quantization_reference'];expected_q=fixture['quantization']['independent_input_fp8_sha256']
 check(layer['function']=='apply_fp8_linear_bmm_flashinfer' and layer['custom_op']=='flashinfer_bmm_fp8' and layer['quantizer']=='static_quant_fp8','actual layer/quantizer/custom-op identity')
 check(layer['source_sha256']==fixture['source']['sglang_source_sha256'],'production source map')
 check(layer['inference_mode'] and not layer['grad_enabled'] and not layer['allow_tf32'] and not layer['dispatch_modes'] and not layer['function_modes'] and not layer['torch_profiler_enabled'] and not layer['compiling'] and layer['kernel_api_log_level']==0 and layer['custom_op_direct_wrapper'],'normal production fast path')
 check(q['byte_match'] and q['cpu_and_gpu_independent_references_match'] and q['actual_input_fp8_sha256']==q['independent_input_fp8_sha256']==expected_q,'independent actual quantizer byte gate')
 natural=d['natural'];tier='miss' if arm=='default' else 'memory' if phase=='cold' else 'file'
 check(natural['lookup_tier']==tier and natural['cache_hit']==(arm!='default'),'natural miss/memory/file source')
 if arm=='default':check(natural['tactic']==-1,'default true fallback')
 check(not d['forbidden_profile_attempts'] and d['profile_attempts']==len(d['profiles']),'all attempts accounted')
 check((d['profile_attempts']>0) if (phase=='cold' and arm!='default') else d['profile_attempts']==0,'cold-only tuned profiling')
 profiles_total+=d['profile_attempts']
 settings=d['autotuner_settings']['after'];config=settings['config']
 check(settings['effective_measure_policy'] is None and settings['effective_policy_timer'] is None and not config['use_cuda_graph'] and not config['use_cold_l2_cache'],'unchanged unspecified profiling policy')
 check(settings['warmup']==3 and settings['repeat']==10 and settings['stream_delay_micro_secs']==5000 and settings['cuda_graph_delay_micro_secs']==100 and config['effective_profiling_repeat']==10,'actual profiling timer defaults')
 expected_stages={'setup','startup','natural_eager_changed_input','natural_eager_restored_input','natural_before','natural_capture','natural_after','natural_after_oracle'}
 check(collections.Counter(r['stage'] for r in d['selections'])==collections.Counter(expected_stages),'real selection stage coverage')
 for r in d['selections']:
  expected_tier='miss' if r['stage']=='setup' else tier;expected_tactic=-1 if r['stage']=='setup' else natural['tactic']
  check(r['tactic']==expected_tactic and r['lookup_tier']==expected_tier and r['cache_hit']==(expected_tier!='miss') and r['capturing']==(r['stage']=='natural_capture'),'true chosen tactic/cache/capture')
 for r in d['binding_acceptance_checks']:
  check(r['accepted'] and r['used_descriptor']==([] if r['tactic']==-1 else [1]),'actual native explicit accepted no fallback');acceptance_total+=1
 check(len(d['binding_acceptance_checks'])==6,'native acceptance coverage')
 for r in layer['native_output_poison_checks']:
  check(r['capturing']==(r['stage']=='natural_capture') and r['poisoned_actual_allocation']==(r['stage']!='natural_capture'),'actual allocation poisoned only outside capture');poison_total+=1
 check(len(layer['native_output_poison_checks'])==6,'actual native output poison coverage')
 public=layer['observed_public_inputs'];check(len(public)==8,'native operand observation coverage')
 for r in public:
  check(r['backend']=='cublas' and len(r['inputs'])==6,'actual cublas operand pool')
  check(r['inputs'][0]['shape']==[1,m,k] and r['inputs'][1]['shape']==[1,k,n] and r['inputs'][1]['stride'][-2:]==[1,k] and r['inputs'][4]['shape']==[1,m,n],'actual public dimensions/layout')
  if r['stage'] in ('setup','natural_eager_restored_input','natural_before','natural_after','natural_after_oracle'):
   check(r['quantized_input_sha256']==expected_q and r['weight_rowmajor_sha256']==fixture['tensors']['weight_fp8_rowmajor']['sha256'] and r['input_scale_sha256']==fixture['tensors']['input_scale']['sha256'] and r['weight_scale_sha256']==fixture['tensors']['weight_scale']['sha256'],'actual public quantized/weight/scalar bytes')
  else:check('quantized_input_sha256' not in r,'no capture/changed input frozen-byte assertion')
 check(layer['graph_output_binding']=='actual captured allocation; output rebinding occurs outside timing','actual captured output allocation binding')
 numerical=d['correctness']['checks'];numerical_total+=len(numerical)
 expected_numeric={'initial_untuned','natural_eager_changed_input','natural_eager_restored_input','natural_before','natural_after','natural_after_oracle','natural_changed_input','natural_restored_input','natural_measured_eager','natural_measured_cuda_graph'}
 check({r['check'] for r in numerical}==expected_numeric and len(numerical)==10,'eager/dynamic graph numeric coverage')
 for r in numerical:
  check(r['quantized_reference']['passed'] and r['quantized_reference']['max_normalized_error']<=1 and r['bf16_reference']['diagnostic_only'],'quantized reference gate versus BF16 diagnostic')
  same(r['max_abs_error'],r['quantized_reference']['max_abs_error'],'numerical error source')
  for metric in ('quantized_reference','bf16_reference'):
   check(all(math.isfinite(r[metric][key]) and r[metric][key]>=0 for key in ('max_abs_error','max_normalized_error','rmse','relative_l2')),'finite numerical metrics')
  zero=r['check'] in ('natural_eager_changed_input','natural_changed_input')
  check(r['exact_zero_required']==zero,'actual changed-input zero requirement')
  if zero:check(r['max_abs_error']==0 and r['bf16_reference']['max_abs_error']==0,'exact zero eager/graph output')
 metrics_summary.append({'trial':trial,'arm':arm,'phase':phase,'max_quantized_reference_abs_error':max(r['quantized_reference']['max_abs_error'] for r in numerical),'max_BF16_diagnostic_abs_error':max(r['bf16_reference']['max_abs_error'] for r in numerical)})
 for mode in ('eager','cuda_graph'):
  timing=natural[mode];iterations=timing['effective_iterations']
  check(timing['requested_iterations']==20 and timing['iterations_per_sample']==iterations,'natural iteration metadata')
  check(timing['warmup_actual_ms']>=500 and timing['calibration_batches'][-1]['wall_ms']>=20,'natural calibration target')
  for samples,batches in (('samples_ms','wall_batch_ms'),('gpu_event_samples_ms','gpu_event_batch_ms')):
   check(len(timing[samples])==len(timing[batches])==15,'natural sample count')
   for sample,batch in zip(timing[samples],timing[batches]):check(sample>0 and batch>0,'positive timings');same(sample*iterations,batch,'raw timing normalization')
  same(timing['median_ms'],statistics.median(timing['samples_ms']),'natural wall median')
 key=d['cache']['runtime_file_key'];cache=locate(d['cache']['path']);payload=read(cache);generation(payload)
 check(sha(cache)==d['cache']['after_startup_sha256']==d['cache']['after_oracle_sha256'],'natural bytes stable')
 if arm=='default':check(key not in payload,'untuned default persisted no winner')
 else:check(payload[key][1]==natural['tactic'],'persisted natural tactic')
 if phase=='warm':
  cold=workers[trial,arm,'cold'];check(cold['cache']['before_sha256'] is None,'cold starts without cache')
  check(d['cache']['before_sha256']==cold['cache']['after_startup_sha256']==d['cache']['after_startup_sha256'],'fresh warm exact-byte reuse')
  check(cold['natural']['tactic']==natural['tactic'],'fresh warm winner reuse')
 if phase=='cold' and arm!='default':
  runtime=[r for r in d['profiles'] if r['input_shapes'][0][-2]==144]
  finite=sorted((r for r in runtime if r.get('profiler_ms') is not None),key=lambda r:r['profiler_ms'])
  check(finite and finite[0]['tactic']==natural['tactic'],'first finite profiler minimum')
  check(any(r['tactic']==-1 and r.get('profiler_ms') is not None for r in runtime) if arm=='v2' else all(r['tactic']!=-1 for r in d['profiles']),'v2 default participation/v1 exclusion')
  check(all(r['normalized_profile'][0][-2]==256 and r['autotuner_settings']==settings for r in runtime),'canonical key/timing policy')
  expected=next(r for r in analysis['analysis']['startup_profiler_rankings'] if r['trial']==trial and r['arm']==arm)
  margin=finite[1]['profiler_ms']/finite[0]['profiler_ms']-1
  same(expected['runner_up_fractional_margin'],margin,'profile minimum margin')
  check(expected['ranked_profiles']==[{'tactic':r['tactic'],'profiler_ms':r['profiler_ms']} for r in finite],'all profiler rankings')
  profile_rows.append({'trial':trial,'arm':arm,'winner':natural['tactic'],'minimum_ms':finite[0]['profiler_ms'],'runner_up_fractional_margin':margin,'finite_profiles':len(finite)})
check(len(set(allcids))==len(allcids),'all fresh containers')
check(len({json.dumps(w['environment']['operand_sha256'],sort_keys=True) for w in workers.values()})==1,'all fixed fixture operand bytes identical')
for r in analysis['analysis']['natural_latency_comparisons']:
 numerator,denominator=r['comparison'].split('_over_');ratios=[]
 for trial in args.trials:
  key='samples_ms' if r['channel']=='wall' else 'gpu_event_samples_ms'
  left=statistics.median(workers[trial,numerator,r['phase']]['natural'][r['execution']][key]);right=statistics.median(workers[trial,denominator,r['phase']]['natural'][r['execution']][key]);ratio=left/right;ratios.append(ratio)
  row=next(x for x in r['trial_estimates'] if x['trial']==trial);same(row['numerator_ms'],left,'natural numerator median');same(row['denominator_ms'],right,'natural denominator median');same(row['ratio'],ratio,'natural paired ratio')
 check_stats(r,ratios)
 check(r['primary']==(r['channel']==('wall' if r['execution']=='eager' else 'gpu_event')),'primary channel')
 if denominator=='default':check(r['denominator_lookup_tier']=='miss','baseline miss retained')
for r in analysis['analysis']['startup_diagnostics']:
 numerator,denominator=r['comparison'].split('_over_');ratios=[]
 for trial in args.trials:
  ratio=workers[trial,numerator,r['phase']]['startup_ms']/workers[trial,denominator,r['phase']]['startup_ms'];ratios.append(ratio)
  same(next(x['ratio'] for x in r['trial_estimates'] if x['trial']==trial),ratio,'startup paired ratio')
 check_stats(r,ratios)
for row in analysis['analysis']['cold_winner_frequencies']:
 counts=collections.Counter(json.dumps(workers[t,row['arm'],'cold']['natural']['tactic']) for t in args.trials)
 check(dict(counts)=={json.dumps(r['tactic']):r['count'] for r in row['winners']} and row['fresh_trials']==len(args.trials),'actual winner frequencies')
build=read(raw/('build-provenance-trial0.json' if len(args.trials)==1 else 'build-provenance.json'))['arms']['candidate']
for name,field in (('gemm.so','library'),('build.ninja','ninja')):
 path=raw/'native-builds'/'candidate'/name
 check(sha(path)==build[field]['sha256'] and path.stat().st_size==build[field]['size'],'retained native artifact bytes')
for worker in workers.values():
 artifact=worker['environment']['native_artifact']
 check(artifact['library_sha256']==build['library']['sha256'] and artifact['ninja_sha256']==build['ninja']['sha256'],'worker linked native library/build')
 check(artifact['source_sha256']==build['all_runtime_source_sha256'],'worker linked complete descriptor overlay')
report={'status':'success','report_status':'FINAL; immutable after readiness','source_commit':args.commit,'raw_root':str(raw),'frozen_analysis':str(args.analysis),'frozen_analysis_sha256':sha(args.analysis),'trials':args.trials,'independent_trial_triplets':len(args.trials),'checks_passed':checks,'workers':len(workers),'profile_attempts':profiles_total,'numerical_checks':numerical_total,'native_acceptance_checks':acceptance_total,'actual_native_output_poison_checks':poison_total,'private_safetensors_independently_rehashed':private_checked,'profile_minimum_audit':profile_rows,'numerical_diagnostics':metrics_summary,'primary_natural_ratios':[r for r in analysis['analysis']['natural_latency_comparisons'] if r['primary']],'limits':['Each independent unit is a fresh trial triplet on one fixed captured layer/input, not15 worker samples.','Default natural misses and tuned memory/file hits differ; ratios include this dispatch cost.','Quantized-input FP32 gates do not prove dense BF16/full-model accuracy; BF16 error is diagnostic.','Actual linear-layer microbenchmarks do not establish end-to-end serving performance or GPU-kernel identity.']}
args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ('status','checks_passed','workers','profile_attempts','numerical_checks')}))
