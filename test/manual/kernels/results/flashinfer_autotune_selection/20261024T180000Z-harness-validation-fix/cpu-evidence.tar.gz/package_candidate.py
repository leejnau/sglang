"""Package only the requested two-file upstream candidate and bounded evidence."""

from __future__ import annotations

import ast
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

SOURCE = Path(__file__).resolve().parent
OUTPUT = Path(
    "/private/tmp/sglang-autotune-selection-study/test/manual/kernels/results/"
    "flashinfer_autotune_selection/20261024T180000Z-harness-validation-fix"
)
TOKEN = bytes([118, 108, 108, 109])
REPORTS = {
    "cpu-green.json": {"passed": 16, "failed": 0, "skipped": 12},
    "cuda-boundary-green.json": {"passed": 28, "failed": 0, "skipped": 0},
    "red-without-callback.json": {"passed": 22, "failed": 6, "skipped": 0},
    "red-without-inference.json": {"passed": 15, "failed": 1, "skipped": 12},
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (
        json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode()


def metadata(data):
    return {"sha256": sha(data), "size_bytes": len(data)}


def safe(data, label):
    assert TOKEN not in data.lower(), label


def archive(path, members):
    with (
        path.open("wb") as stream,
        gzip.GzipFile(fileobj=stream, mode="wb", filename="", mtime=0) as compressed,
    ):
        with tarfile.open(fileobj=compressed, mode="w") as result:
            for name, data in sorted(members.items()):
                safe(data, name)
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
                result.addfile(entry, io.BytesIO(data))


def main():
    OUTPUT.mkdir(parents=True, exist_ok=True)
    assert not list(OUTPUT.iterdir()), "refuse to overwrite candidate evidence"
    manifest = json.loads((SOURCE / "candidate-manifest.json").read_text())
    candidate = {
        path: (SOURCE / "candidate" / path).read_bytes()
        for path in (
            "benchmarks/bench_autotuner_accuracy.py",
            "tests/autotuner/test_accuracy_harness.py",
        )
    }
    candidate["run_cuda_tests.py"] = (SOURCE / "run_cuda_tests.py").read_bytes()
    for row in manifest["files"]:
        assert sha(candidate[row["path"]]) == row["candidate_sha256"]
    assert sha(candidate["run_cuda_tests.py"]) == manifest["gpu_gate_script_sha256"]
    assert sha((SOURCE / "candidate.patch").read_bytes()) == manifest["patch_sha256"]
    report_data = {name: json.loads((SOURCE / name).read_text()) for name in REPORTS}
    for name, expected in REPORTS.items():
        assert report_data[name]["counts"] == expected
        assert report_data[name]["script_sha256"] == sha(
            (SOURCE / "run_cpu_controls.py").read_bytes()
        )
    red_inference = report_data["red-without-inference.json"]["tests"]
    assert any(
        row["outcome"] == "failed" and "InferenceMode" in row["failure"]
        for row in red_inference
    )
    red_callback = report_data["red-without-callback.json"]["tests"]
    assert (
        sum(
            row["outcome"] == "failed" and "no_write" in row["nodeid"]
            for row in red_callback
        )
        == 2
    )
    for data in candidate.values():
        ast.parse(data)
    archive(OUTPUT / "candidate.tar.gz", candidate)
    (OUTPUT / "candidate-member-index.json").write_bytes(
        encoded(
            {
                "members": {
                    name: metadata(data) for name, data in sorted(candidate.items())
                }
            }
        )
    )
    (OUTPUT / "candidate.patch").write_bytes((SOURCE / "candidate.patch").read_bytes())
    (OUTPUT / "candidate-manifest.json").write_bytes(
        (SOURCE / "candidate-manifest.json").read_bytes()
    )
    (OUTPUT / "run_cuda_tests.py").write_bytes(candidate["run_cuda_tests.py"])
    status = {
        "schema_version": 1,
        "status": "Separate upstream candidate prepared; new actual-CUDA pytest gate pending.",
        "problem": "A selected tactic that writes nothing can inherit a valid default result in a shared output buffer and pass the graph selection study's final comparisons.",
        "change": "Add an optional fixture-owned prepare_validation callback before each final validation replay, after all timing. The built-in FP8 fixture opts in through validated read/output/workspace roles and inference-safe output NaN refresh. Unowned generic fixtures retain legacy behavior and report refresh unavailable.",
        "scope": "Only the benchmark and its focused tests change. No descriptor port, production tuner, cache format, measurement policy, SGLang runtime or serving-performance change.",
        "line_counts": manifest["files"],
        "CPU": {
            name: {
                "mode": report_data[name]["mode"],
                "counts": report_data[name]["counts"],
                "pytest_exit_code": report_data[name]["pytest_exit_code"],
            }
            for name in REPORTS
        },
        "red_green": {
            "missing_callback": "Removing only the callback invocation causes six expected admission failures, including both no-write outputs that cease to be rejected.",
            "missing_inference_context": "Removing only the inference context around fill causes one real CPU inference-output regression, with the other fifteen CPU controls still passing.",
        },
        "test_coverage": "Twelve CUDA correctness cases: normal/inference allocations x correct/wrong/no-write x callback present/omitted; sixteen CPU cases: output views, six unsafe roles x both allocation modes and optional factory-hook routing.",
        "runtime_boundary": "CPU proofs import complete 27c62 tuner/cache modules with disclosed GPU-only import shells. The separate28-test CUDA-boundary admission uses simulated graphs/events and is not a CUDA pass. The new real-CUDA gate remains pending.",
        "upstream_review": {
            "reviewed_main": "f5d4db2c488d77331afa653c282d2e03c87ba517",
            "both_touched_files_byte_identical_to27c62": True,
            "benchmark_last_change": "https://github.com/flashinfer-ai/flashinfer/pull/7155",
            "targeted_searches_without_match": [
                "repo:flashinfer-ai/flashinfer is:pr prepare_validation",
                "repo:flashinfer-ai/flashinfer is:pr in:title autotuner validation",
                "repo:flashinfer-ai/flashinfer is:pr in:title output validation autotuner",
            ],
            "limit": "Read-only snapshot during preparation; targeted searches are not an exhaustive guarantee. Recheck current head and reviews before any future PR.",
        },
        "pending": [
            "Run the separate real-CUDA pytest gate after the qualified bootstrap in a fresh container.",
            "No PR, push, commit, CI trigger or external message has been performed.",
        ],
        "limits": [
            "No candidate-selection improvement, numerical backend defect or serving-performance claim.",
            "Generic/in-place/integer fixtures are not blindly poisoned; unsupported FP8 output roles reject before mutation.",
            "The candidate archive contains only the two requested benchmark/test files and the own gate wrapper, not a FlashInfer source tree or provider package.",
        ],
    }
    (OUTPUT / "cpu-validation.json").write_bytes(encoded(status))
    evidence_names = [
        "run_cpu_controls.py",
        "package_candidate.py",
        "current-file-provenance.json",
        "harness-only.patch",
        "tests-only.patch",
    ]
    evidence_names += [
        item for name in REPORTS for item in (name, str(Path(name).with_suffix(".log")))
    ]
    evidence = {name: (SOURCE / name).read_bytes() for name in evidence_names}
    archive(OUTPUT / "cpu-evidence.tar.gz", evidence)
    (OUTPUT / "cpu-evidence-member-index.json").write_bytes(
        encoded(
            {
                "members": {
                    name: metadata(data) for name, data in sorted(evidence.items())
                }
            }
        )
    )
    readme = """# Owned-output validation candidate

This is a separate FlashInfer benchmark/test candidate. It does not change the qualified experiment runtime or open a PR. `candidate.patch` applies to the recorded 27c62 baseline and to the reviewed current head because both touched files are unchanged. The archive contains exactly those two candidate files plus the gate wrapper; it contains no FlashInfer provider package.

Extract `candidate.tar.gz` into a new directory. After the existing qualified current-source bootstrap, execute the loose `run_cuda_tests.py` in the same Python process with `--candidate <new-directory> --output <new-result.json>`. Keep the candidate directory out of `sys.path`; the real runtime continues to come from the qualified provider. `run_current.py --target` can perform this handoff. Use a separate `.container.log` for container stdout because the gate reserves its own result-adjacent `.log`. Expected real-GPU result: 28 passed, 0 skipped.

The CPU record is 16 passed and 12 CUDA-only skipped. The separate 28-pass graph/event boundary admission is simulated CUDA and is explicitly not a device result. Two red controls demonstrate the missing-callback and inference-tensor regressions. The retained CPU script uses the earlier disclosed boundary loader and pinned 27c62 source; that environment is required to replay it. Standard upstream pytest on CUDA uses the real library and no boundary loader.

The tar and patch are source artifacts only. `cpu-validation.json` records scope, hashes, controls and pending CUDA evidence. The output refresh occurs after timing and before final independent replays, so this fix makes no performance claim.
"""
    (OUTPUT / "README.md").write_text(readme)
    count = 0
    for name, expected in (
        ("candidate.tar.gz", candidate),
        ("cpu-evidence.tar.gz", evidence),
    ):
        actual = {}
        with tarfile.open(OUTPUT / name, "r:gz") as result:
            for member in result.getmembers():
                assert member.isfile() and not member.issym()
                path = Path(member.name)
                assert not path.is_absolute() and ".." not in path.parts
                data = result.extractfile(member).read()
                safe(data, member.name)
                actual[member.name] = data
                if member.name.endswith(".py"):
                    ast.parse(data)
                count += 1
        assert actual == expected
    files = {}
    for path in sorted(OUTPUT.iterdir()):
        data = path.read_bytes()
        safe(data, path.name)
        files[path.name] = metadata(data)
    (OUTPUT / "artifact-index.json").write_bytes(
        encoded({"files": files, "archive_members_verified": count})
    )
    print(
        json.dumps(
            {
                "status": "packaged",
                "output": str(OUTPUT),
                "candidate_members": len(candidate),
                "evidence_members": len(evidence),
                "archive_members_verified": count,
            }
        )
    )


if __name__ == "__main__":
    main()
