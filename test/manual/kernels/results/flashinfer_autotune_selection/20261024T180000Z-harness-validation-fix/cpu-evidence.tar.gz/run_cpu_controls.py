"""Run focused upstream tests with disclosed CPU-only import/CUDA boundaries."""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
from unittest.mock import patch

import pytest

LOADER = Path(
    "/private/tmp/fi-next-steps-20261024/fixture-validation-callback/check_callback.py"
)
SELECTION = (
    "graph_study_validates_owned_output or "
    "fp8_validation_refresh_preserves_views or "
    "fp8_validation_rejects_unsafe_roles or "
    "graph_study_fixture_refresh_is_optional"
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


class Results:
    def __init__(self):
        self.rows = []

    def pytest_runtest_logreport(self, report):
        if report.when == "call" or report.skipped:
            self.rows.append(
                {
                    "nodeid": report.nodeid,
                    "outcome": report.outcome,
                    "failure": str(report.longrepr) if report.failed else None,
                }
            )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--candidate-root", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--cuda-boundaries", action="store_true")
    args = parser.parse_args()
    if args.output.exists() or args.output.with_suffix(".log").exists():
        raise FileExistsError("do not overwrite a CPU control run")
    source = args.candidate_root.resolve()
    target = source / "tests/autotuner/test_accuracy_harness.py"
    harness = source / "benchmarks/bench_autotuner_accuracy.py"
    namespace = {"__file__": str(LOADER), "__name__": "upstream_fix_cpu_loader"}
    exec(
        compile(
            LOADER.read_text().split("with contextlib.ExitStack() as boundaries:", 1)[
                0
            ],
            str(LOADER),
            "exec",
        ),
        namespace,
    )
    torch, state, api = namespace["torch"], namespace["state"], namespace["api"]
    real_add, real_empty, real_ones = torch.add, torch.empty, torch.ones

    def add(*values, **kwargs):
        if state.active is not None:

            def action():
                with torch.inference_mode():
                    real_add(*values, **kwargs)

            state.active.actions.append(action)
            return kwargs["out"]
        return real_add(*values, **kwargs)

    def cpu(function):
        def construct(*values, **kwargs):
            if kwargs.get("device") == "cuda":
                kwargs["device"] = "cpu"
            return function(*values, **kwargs)

        return construct

    os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    records, captured = Results(), io.StringIO()
    initial = api.AutoTuner._instance
    with contextlib.ExitStack() as stack:
        if args.cuda_boundaries:
            for name, value in [
                ("is_available", lambda: True),
                ("CUDAGraph", namespace["Graph"]),
                ("graph", namespace["capture"]),
                ("Event", namespace["Event"]),
                ("synchronize", lambda: None),
                ("_sleep", lambda _: None),
                ("is_current_stream_capturing", lambda: state.active is not None),
            ]:
                stack.enter_context(patch.object(torch.cuda, name, value))
            for name, value in [
                ("add", add),
                ("empty", cpu(real_empty)),
                ("ones", cpu(real_ones)),
            ]:
                stack.enter_context(patch.object(torch, name, value))
        with contextlib.redirect_stdout(captured), contextlib.redirect_stderr(captured):
            code = pytest.main(
                [
                    "-q",
                    "-rA",
                    "--noconftest",
                    "--rootdir",
                    str(source),
                    "--confcutdir",
                    str(source / "tests"),
                    str(target),
                    "-k",
                    SELECTION,
                ],
                plugins=[records],
            )
    assert api.AutoTuner._instance is initial
    assert not torch.is_inference_mode_enabled()
    counts = {
        outcome: sum(row["outcome"] == outcome for row in records.rows)
        for outcome in ("passed", "failed", "skipped")
    }
    result = {
        "status": "passed" if code == 0 else "pytest failure retained",
        "pytest_exit_code": int(code),
        "counts": counts,
        "tests": records.rows,
        "mode": "CPU CUDA-boundary admission"
        if args.cuda_boundaries
        else "actual CPU tests",
        "candidate_root": str(source),
        "script_sha256": sha(__file__),
        "loader_sha256": sha(LOADER),
        "harness_sha256": sha(harness),
        "test_sha256": sha(target),
        "torch": torch.__version__,
        "pytest": pytest.__version__,
        "limits": [
            "Complete candidate benchmark and real current pinned tuner/cache/policy modules execute through the disclosed GPU-only import shells.",
            "CPU mode uses actual CPU tensors, inference mode and mutation/numerical assertions; CUDA-specific tests are skipped.",
            "The separate CUDA-boundary admission simulates allocations, graph/events/replay and captured add execution; it does not report a CUDA or device-timing pass.",
            "New GPU tests deliberately control profiling durations while retaining production selection/cache paths and actual graph writes on a real GPU run.",
        ],
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    args.output.with_suffix(".log").write_text(captured.getvalue())
    print(
        json.dumps({"mode": result["mode"], "exit_code": int(code), "counts": counts})
    )
    return int(code)


if __name__ == "__main__":
    raise SystemExit(main())
