# SPDX-FileCopyrightText: Copyright (c) 2026 NVIDIA CORPORATION & AFFILIATES. All rights reserved.
# SPDX-License-Identifier: Apache-2.0
from importlib.util import module_from_spec, spec_from_file_location
from pathlib import Path
import pytest
import torch
from flashinfer.autotuner import AutoTuner, TuningConfig
from flashinfer.autotune_cache import MeasurementPolicy


def test_policy_route(monkeypatch):
    spec = spec_from_file_location(
        "accuracy_harness",
        Path(__file__).resolve().parents[2] / "benchmarks/bench_autotuner_accuracy.py",
    )
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    tuner = AutoTuner()
    monkeypatch.setattr(AutoTuner, "_instance", tuner)
    seen = []
    monkeypatch.setattr(
        tuner, "_prepare_input_tensors_with_batches", lambda inputs, config: [inputs]
    )
    monkeypatch.setattr(
        tuner,
        "_profile_single_kernel",
        lambda runner, inputs, tactic, config, **kwargs: seen.append(
            (
                config.use_cuda_graph,
                config.use_cold_l2_cache,
                tuner.repeat,
                tuner._effective_measure_policy,
            )
        )
        or 1.0,
    )
    for mode in ("eager", "cuda_graph"):
        policy = MeasurementPolicy(execution_mode=mode, cold_l2=False)
        assert (
            module.measure_candidate(
                tuner, object(), [torch.ones(2)], 0, TuningConfig(), {}, policy, 7
            )
            == 1.0
        )
        assert seen[-1] == (mode == "cuda_graph", False, 7, policy)
        assert tuner._effective_measure_policy is None
        assert not tuner.is_tuning_mode


def _harness():
    spec = spec_from_file_location(
        "accuracy_harness",
        Path(__file__).resolve().parents[2] / "benchmarks/bench_autotuner_accuracy.py",
    )
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_retained_inputs_require_matching_metadata():
    module = _harness()
    inputs = [torch.arange(4.0)]
    config = module.retained_input_config(TuningConfig(), inputs)
    assert config.inputs_pre_hook([torch.zeros(4)])[0] is inputs[0]
    with pytest.raises(ValueError, match="metadata"):
        config.inputs_pre_hook([torch.zeros(8)])


@pytest.mark.skipif(not torch.cuda.is_available(), reason="requires CUDA")
@pytest.mark.parametrize("profile_inputs", ["retained", "synthesized"])
def test_graph_study_real_selection_and_numerics(monkeypatch, profile_inputs):
    from types import SimpleNamespace
    from flashinfer.autotuner import DynamicTensorSpec, TunableRunner

    module = _harness()
    original = AutoTuner._instance

    class Runner(TunableRunner):
        def get_valid_tactics(self, inputs, profile):
            return [0, 1]

        def forward(self, inputs, tactic=-1, **kwargs):
            value = inputs[0].clone() if tactic == 1 else inputs[0]
            return value + 1

    args = SimpleNamespace(
        cold_l2=False,
        profile_inputs=profile_inputs,
        seeds=1,
        graph_policies=["auto", "eager", "cuda_graph"],
        seed=42,
        warmup=2,
        tuner_repeat=3,
        oracle_rounds=2,
        validation_replays=3,
        prequeue_cycles=1_000_000,
        rtol=0,
        atol=0,
    )
    report = module.graph_selection_study(
        "test.accuracy",
        [Runner()],
        TuningConfig(
            dynamic_tensor_specs=(
                DynamicTensorSpec(
                    input_idx=(0,),
                    dim_idx=(0,),
                    gen_tuning_buckets=(1, 3),
                    map_to_tuning_buckets=lambda n: 1 if n == 1 else 4,
                ),
            ),
        ),
        [torch.ones(3, device="cuda")],
        {},
        args,
    )
    assert AutoTuner._instance is original
    assert len(report["trials"]) == 3
    assert report["validation"]["output_refresh"] == "unavailable"
    for row in report["trials"]:
        assert row["cache_hit"]
        assert row["profile_count"] == (3 if profile_inputs == "retained" else 6)
        assert row["input_shapes"] == ((3,),)
        assert row["cache_profile"] == ((3 if profile_inputs == "retained" else 4,),)
        assert {m["input_shapes"] for m in row["measurements"]} == (
            {((3,),)} if profile_inputs == "retained" else {((1,),), ((3,),)}
        )
        assert {m["cache_profile"] for m in row["measurements"]} == (
            {((3,),)} if profile_inputs == "retained" else {((1,),), ((4,),)}
        )
        assert row["numerics"] == "passed"
        assert all(
            m["use_cuda_graph"] == (row["policy"] == "cuda_graph")
            for m in row["measurements"]
        )
        assert all(len(values) == 2 for values in row["validation_ms"].values())


def _study_args(**overrides):
    from types import SimpleNamespace

    values = dict(
        cold_l2=False,
        profile_inputs="retained",
        seeds=1,
        graph_policies=["cuda_graph"],
        seed=42,
        warmup=1,
        tuner_repeat=2,
        oracle_rounds=1,
        validation_replays=1,
        prequeue_cycles=1_000_000,
        rtol=0,
        atol=0,
    )
    values.update(overrides)
    return SimpleNamespace(**values)


def test_graph_study_rejects_all_failed_tactics(monkeypatch):
    from .utils import DummyRunner

    module = _harness()
    original = AutoTuner._instance
    monkeypatch.setattr(torch.cuda, "is_current_stream_capturing", lambda: False)
    monkeypatch.setattr(
        AutoTuner, "_profile_single_kernel", lambda *a, **kw: float("inf")
    )
    monkeypatch.setattr(
        module, "capture_tactic_graph", lambda runner, inputs, *a: (None, inputs[0])
    )
    with pytest.raises(RuntimeError, match="no cached winner"):
        module.graph_selection_study(
            "test.failed",
            [DummyRunner()],
            TuningConfig(),
            [torch.ones(4)],
            {},
            _study_args(),
        )
    assert AutoTuner._instance is original


@pytest.mark.skipif(not torch.cuda.is_available(), reason="requires CUDA")
def test_graph_study_does_not_hide_bad_shared_output(monkeypatch):
    from flashinfer.autotuner import TunableRunner

    module = _harness()
    output = torch.empty(4, device="cuda")

    class Runner(TunableRunner):
        def get_valid_tactics(self, inputs, profile):
            return [0]

        def forward(self, inputs, tactic=-1, **kwargs):
            return torch.add(inputs[0], 1 if tactic == -1 else 2, out=output)

    monkeypatch.setattr(
        AutoTuner,
        "_profile_single_kernel",
        lambda self, runner, inputs, tactic, config, **kw: 1.0 if tactic == 0 else 2.0,
    )
    with pytest.raises(AssertionError):
        module.graph_selection_study(
            "test.bad_output",
            [Runner()],
            TuningConfig(),
            [torch.ones(4, device="cuda")],
            {},
            _study_args(),
        )


@pytest.mark.skipif(not torch.cuda.is_available(), reason="requires CUDA")
def test_graph_study_rejects_invalidated_retained_control(monkeypatch):
    from flashinfer.autotuner import TunableRunner

    module = _harness()

    class Runner(TunableRunner):
        def __init__(self):
            self.bias = torch.ones(4, device="cuda")
            self.output = torch.empty_like(self.bias)
            self.prepared = False

        def __hash__(self):
            return hash(type(self))

        def get_valid_tactics(self, inputs, profile):
            if not self.prepared:
                # Preparation reuses storage held by the old graph. Later
                # graphs bind the new bias and still produce correct output.
                self.bias.zero_()
                self.bias = torch.ones_like(self.bias)
                self.prepared = True
            return [0]

        def forward(self, inputs, tactic=-1, **kwargs):
            return torch.add(inputs[0], self.bias, out=self.output)

    monkeypatch.setattr(
        AutoTuner,
        "_profile_single_kernel",
        lambda self, runner, inputs, tactic, config, **kw: 1.0 if tactic == 0 else 2.0,
    )
    with pytest.raises(AssertionError):
        module.graph_selection_study(
            "test.invalidated_control",
            [Runner()],
            TuningConfig(),
            [torch.ones(4, device="cuda")],
            {},
            _study_args(),
        )


def test_unavailable_cupti_cannot_be_scored_as_an_oracle(monkeypatch):
    import importlib

    implementation = importlib.import_module("flashinfer.autotuner.autotuner")
    module = _harness()
    tuner = AutoTuner()
    monkeypatch.setattr(implementation, "_load_cupti", lambda: None)
    with pytest.raises(module.MeasurementUnavailable, match="CUPTI oracle unavailable"):
        module.measure_candidate(
            tuner,
            object(),
            [torch.ones(2)],
            0,
            TuningConfig(),
            {},
            MeasurementPolicy(_timer="cupti"),
            3,
        )


def test_exhaustive_report_preserves_unavailable_and_valid_shapes(
    monkeypatch, tmp_path
):
    import json
    import sys
    from types import SimpleNamespace

    module = _harness()
    output = tmp_path / "report.json"
    monkeypatch.setattr(
        sys,
        "argv",
        ["study", "--ops", "bmm_fp8", "--grid", "1", "2", "--out", str(output)],
    )
    monkeypatch.setattr(
        torch.cuda,
        "get_device_properties",
        lambda _: SimpleNamespace(name="test", major=9, minor=0),
    )
    monkeypatch.setitem(module.OPS, "bmm_fp8", {"axis": "m", "build": lambda *a: None})
    monkeypatch.setattr(
        module, "capture_choose_one_calls", lambda _: {"op": ([], None, [], {})}
    )
    visited = []

    def sweep(*args):
        visited.append(args[-1])
        if len(visited) == 1:
            raise module.MeasurementUnavailable("no finite oracle candidates")
        return {"op": "op", "valid": 1}

    monkeypatch.setattr(module, "sweep_captured_op", sweep)
    module.main()
    rows = json.loads(output.read_text())["shapes"]
    assert visited == ["bmm_fp8 m=1", "bmm_fp8 m=2"]
    assert rows[0] == {
        "api": "bmm_fp8",
        "op": "op",
        "m": 1,
        "error": "MeasurementUnavailable: no finite oracle candidates",
    }
    assert rows[1] == {"api": "bmm_fp8", "op": "op", "m": 2, "valid": 1}


@pytest.mark.skipif(not torch.cuda.is_available(), reason="requires CUDA")
@pytest.mark.parametrize("inference_output", [False, True])
@pytest.mark.parametrize("kind", ["correct", "wrong", "no_write"])
@pytest.mark.parametrize("refresh", [False, True])
def test_graph_study_validates_owned_output(
    monkeypatch, inference_output, kind, refresh
):
    from flashinfer.autotuner import TunableRunner

    module = _harness()
    original = AutoTuner._instance
    with torch.inference_mode(inference_output):
        output = torch.empty(4, device="cuda")
        unrelated = torch.empty_like(output)
        inputs = [
            torch.ones_like(output),
            torch.ones_like(output),
            torch.ones(1, device="cuda"),
            torch.ones(1, device="cuda"),
            output,
            torch.empty(8, dtype=torch.uint8, device="cuda"),
        ]
    assert output.is_inference() == inference_output
    profiles, refreshes = [], []
    sampled = False
    sample = module.interleaved_graph_samples

    class Runner(TunableRunner):
        def get_valid_tactics(self, inputs, profile):
            return [0]

        def forward(self, inputs, tactic=-1, **kwargs):
            with torch.inference_mode():
                if tactic == -1 or kind == "correct":
                    torch.add(inputs[0], 1, out=output)
                elif kind == "wrong":
                    torch.add(inputs[0], 2, out=output)
                else:
                    torch.add(inputs[1], 1, out=unrelated)
            return output

    def profile(self, runner, inputs, tactic, config, **kwargs):
        profiles.append(tactic)
        return 1.0 if tactic == 0 else 2.0

    def samples(*args, **kwargs):
        nonlocal sampled
        result = sample(*args, **kwargs)
        sampled = True
        return result

    def prepare(actual, actual_inputs):
        assert sampled and not torch.cuda.is_current_stream_capturing()
        assert not torch.is_inference_mode_enabled()
        assert actual is output and actual_inputs is inputs
        refreshes.append(actual.data_ptr())
        module.prepare_fp8_validation(actual, actual_inputs)

    monkeypatch.setattr(AutoTuner, "_profile_single_kernel", profile)
    monkeypatch.setattr(module, "interleaved_graph_samples", samples)
    kwargs = {"prepare_validation": prepare} if refresh else {}

    def study():
        return module.graph_selection_study(
            "test.owned_output",
            [Runner()],
            TuningConfig(),
            inputs,
            {},
            _study_args(),
            **kwargs,
        )

    accepted = kind == "correct" or (kind == "no_write" and not refresh)
    if accepted:
        report = study()
        row = report["trials"][0]
        assert row["cache_hit"] and row["tactic"] == "0"
        assert report["validation"]["output_refresh"] == (
            "fixture_callback" if refresh else "unavailable"
        )
    else:
        with pytest.raises(AssertionError):
            study()
    assert profiles == [-1, 0]
    assert len(refreshes) == ((3 if accepted else 2) if refresh else 0)
    assert AutoTuner._instance is original
    assert not torch.is_inference_mode_enabled()


@pytest.mark.parametrize("inference_output", [False, True])
def test_fp8_validation_refresh_preserves_views(inference_output):
    module = _harness()
    with torch.inference_mode(inference_output):
        declared = torch.ones(1, 2, 2)
        output = declared.view(2, 2)
        inputs = [
            torch.ones(4),
            torch.ones(4),
            torch.ones(1),
            torch.ones(1),
            declared,
            torch.empty(8, dtype=torch.uint8),
        ]
    reads = [tensor.clone() for tensor in inputs[:4]]
    pointer = output.data_ptr()
    module.prepare_fp8_validation(output, inputs)
    assert torch.isnan(output).all()
    assert output.data_ptr() == declared.data_ptr() == pointer
    assert output.is_inference() == inference_output
    assert all(torch.equal(a, b) for a, b in zip(reads, inputs[:4], strict=True))
    assert not torch.is_inference_mode_enabled()


@pytest.mark.parametrize("inference_output", [False, True])
@pytest.mark.parametrize(
    "kind",
    [
        "read_alias",
        "partial_read_alias",
        "scratch_alias",
        "integer",
        "wrong_role",
        "strided_output",
    ],
)
def test_fp8_validation_rejects_unsafe_roles(inference_output, kind):
    module = _harness()
    with torch.inference_mode(inference_output):
        output = torch.ones(
            4, dtype=torch.int64 if kind == "integer" else torch.float32
        )
        if kind == "strided_output":
            output = torch.ones(8)[::2]
        inputs = [
            torch.ones(4),
            torch.ones(4),
            torch.ones(1),
            torch.ones(1),
            output,
            torch.empty(8, dtype=torch.uint8),
        ]
        if kind == "read_alias":
            inputs[0] = output
        elif kind == "partial_read_alias":
            storage = torch.ones(8)
            output = inputs[4] = storage[:4]
            inputs[0] = storage[2:6]
        elif kind == "scratch_alias":
            inputs[5] = output
        elif kind == "wrong_role":
            inputs[4] = torch.ones_like(output)
    tensors = [output, *inputs]
    before = [tensor.clone() for tensor in tensors]
    with pytest.raises(ValueError):
        module.prepare_fp8_validation(output, inputs)
    assert all(torch.equal(a, b) for a, b in zip(before, tensors, strict=True))
    assert not torch.is_inference_mode_enabled()


@pytest.mark.parametrize("refresh", [False, True])
def test_graph_study_fixture_refresh_is_optional(monkeypatch, tmp_path, refresh):
    import sys
    from types import SimpleNamespace

    module = _harness()
    output = tmp_path / "report.json"

    def call():
        return torch.ones(4)

    def callback(*args):
        pass

    if refresh:
        call.prepare_validation = callback
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "study",
            "--graph-selection-study",
            "--ops",
            "bmm_fp8",
            "--grid",
            "1",
            "--out",
            str(output),
        ],
    )
    monkeypatch.setattr(
        torch.cuda,
        "get_device_properties",
        lambda _: SimpleNamespace(name="test", major=9, minor=0),
    )
    monkeypatch.setitem(module.OPS, "bmm_fp8", {"axis": "m", "build": lambda *a: call})
    monkeypatch.setattr(
        module,
        "capture_choose_one_calls",
        lambda *a, **kw: {
            "test.fixture": ([object()], TuningConfig(), [torch.ones(4)], {})
        },
    )
    seen = []

    def study(*args, **kwargs):
        seen.append(kwargs["prepare_validation"])
        return {"trials": []}

    monkeypatch.setattr(module, "graph_selection_study", study)
    module.main()
    assert seen == [callback if refresh else None]
    assert output.is_file()
