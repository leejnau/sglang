"""Run focused callback correctness controls with actual CUDA graphs and tuner paths.

The caller owns the one-time native bootstrap. Only profiling durations are
controlled here; graph capture/replay, Tensor writes and final assertions remain
real. This is an output-validation gate, with no performance claim.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import inspect
import json
import traceback
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

HARNESS_SHA256 = "094f66306d6e6080cdb5b50915f21fb643cdb40cb82471b58e5bdce6f451ce86"
TUNER_SHA256 = "0db42ad90d1a3fec6f81509a2c520c1892cea0a433f5dbd7f43468a2a10243ca"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run(harness_path):
    import torch
    from flashinfer.autotuner import AutoTuner, TunableRunner, TuningConfig

    if not torch.cuda.is_available():
        raise RuntimeError("this gate requires actual CUDA execution")
    if (
        sha(harness_path) != HARNESS_SHA256
        or sha(inspect.getfile(AutoTuner)) != TUNER_SHA256
    ):
        raise ValueError("the declared current-source harness or tuner changed")
    spec = importlib.util.spec_from_file_location(
        "qualified_callback_harness", harness_path
    )
    harness = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(harness)
    args = SimpleNamespace(
        cold_l2=None,
        profile_inputs="retained",
        seeds=1,
        graph_policies=["auto"],
        seed=19,
        warmup=1,
        tuner_repeat=2,
        oracle_rounds=2,
        validation_replays=2,
        prequeue_cycles=1_000_000,
        rtol=0,
        atol=0,
    )
    previous_instance, previous_profile = (
        AutoTuner._instance,
        AutoTuner._profile_single_kernel,
    )
    cases = []
    with torch.inference_mode():
        for enabled in (False, True):
            for kind in ("correct", "wrong", "no_write"):
                output = torch.empty(4, device="cuda")
                unrelated = torch.empty_like(output)
                inputs = [
                    torch.ones_like(output),
                    torch.ones_like(output),
                    torch.ones(1, device="cuda"),
                    torch.ones(1, device="cuda"),
                    output,
                    torch.empty(8, dtype=torch.uint8, device="cuda"),
                ]
                profiles, callbacks, assertions = [], [], []

                class Runner(TunableRunner):
                    def get_valid_tactics(self, inputs, profile):
                        return [0]

                    def forward(self, inputs, tactic=-1, **kwargs):
                        if tactic == -1 or kind == "correct":
                            torch.add(inputs[0], 1, out=output)
                        elif kind == "wrong":
                            torch.add(inputs[0], 2, out=output)
                        else:
                            # Keep genuine CUDA work without writing the observed
                            # output; avoid an empty-graph timing corner case.
                            torch.add(inputs[1], 1, out=unrelated)
                        return output

                def controlled_profile(self, runner, inputs, tactic, config, **kwargs):
                    profiles.append(tactic)
                    return 1.0 if tactic == 0 else 2.0

                def prepare(actual, actual_inputs):
                    if torch.cuda.is_current_stream_capturing():
                        raise RuntimeError("validation refresh entered graph capture")
                    callbacks.append(actual.data_ptr())
                    return harness.prepare_fp8_validation(actual, actual_inputs)

                real_assert = torch.testing.assert_close

                def numerical_assert(actual, expected, **kwargs):
                    assertions.append(actual.data_ptr())
                    return real_assert(actual, expected, **kwargs)

                kwargs = {"prepare_validation": prepare} if enabled else {}
                with (
                    patch.object(
                        AutoTuner, "_profile_single_kernel", controlled_profile
                    ),
                    patch.object(torch.testing, "assert_close", numerical_assert),
                ):
                    try:
                        report = harness.graph_selection_study(
                            "test.fixture_refresh",
                            [Runner()],
                            TuningConfig(),
                            inputs,
                            {},
                            args,
                            **kwargs,
                        )
                    except AssertionError as error:
                        accepted, reason = False, str(error).splitlines()[0]
                    else:
                        accepted, reason = True, None
                        row = report["trials"][0]
                        if (
                            not row["cache_hit"]
                            or row["tactic"] != "0"
                            or report["validation"]["output_refresh"]
                            != ("fixture_callback" if enabled else "unavailable")
                        ):
                            raise RuntimeError(
                                "the actual explicit winner or callback coverage changed"
                            )
                expected = kind == "correct" or (kind == "no_write" and not enabled)
                if (
                    accepted != expected
                    or profiles != [-1, 0]
                    or len(assertions) != (3 if accepted else 2)
                    or len(callbacks) != ((3 if accepted else 2) if enabled else 0)
                ):
                    raise RuntimeError(
                        "unexpected correctness, profiling or final-validation boundary"
                    )
                if (
                    AutoTuner._instance is not previous_instance
                    or AutoTuner._profile_single_kernel is not previous_profile
                ):
                    raise RuntimeError(
                        "callback control leaked tuner singleton or profiling method"
                    )
                torch.cuda.synchronize()
                cases.append(
                    {
                        "callback_enabled": enabled,
                        "kind": kind,
                        "accepted": accepted,
                        "expected": expected,
                        "rejection": reason,
                        "profile_tactics": profiles,
                        "final_assertions": len(assertions),
                        "callback_calls": len(callbacks),
                        "output_data_ptr": output.data_ptr(),
                    }
                )

        unsafe = []
        for kind in ("read_alias", "scratch_alias", "integer", "wrong_role"):
            output = torch.ones(
                4, dtype=torch.int64 if kind == "integer" else torch.float32
            )
            inputs = [
                torch.ones(4),
                torch.ones(4),
                torch.ones(1),
                torch.ones(1),
                output,
                torch.empty(8, dtype=torch.uint8),
            ]
            if kind == "read_alias":
                inputs[0] = output
            elif kind == "scratch_alias":
                inputs[5] = output
            elif kind == "wrong_role":
                inputs[4] = torch.ones_like(output)
            before = output.clone()
            try:
                harness.prepare_fp8_validation(output, inputs)
            except ValueError as error:
                reason = str(error)
            else:
                raise RuntimeError("unsafe output role was admitted: " + kind)
            if not torch.equal(output, before):
                raise RuntimeError("unsafe role was mutated before rejection")
            unsafe.append(
                {"kind": kind, "rejected_before_mutation": True, "reason": reason}
            )
    return {
        "status": "success",
        "worker_sha256": sha(__file__),
        "harness_sha256": sha(harness_path),
        "tuner_sha256": sha(inspect.getfile(AutoTuner)),
        "harness_path": str(harness_path),
        "torch": torch.__version__,
        "torch_cuda": torch.version.cuda,
        "gpu": torch.cuda.get_device_name(),
        "cases": cases,
        "unsafe_roles": unsafe,
        "scope": "Actual CUDA graph/tuner/validation gate with controlled profiling times. No replay-performance, native descriptor-acceptance or full-model accuracy claim.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--harness", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError("refusing to overwrite a callback gate result")
    try:
        result = run(args.harness.resolve())
    except Exception as error:
        traceback.print_exc()
        result = {
            "status": "error",
            "error": f"{type(error).__name__}: {error}",
            "worker_sha256": sha(__file__),
        }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    return 0 if result["status"] == "success" else 1


if __name__ == "__main__":
    raise SystemExit(main())
