"""CPU admission controls for the adapter using the complete official capture API.

GPU-only import dependencies are explicitly shimmed; choose_one, isolated-tuner
scopes and capture_choose_one_calls are real pinned modules. CUDA layer execution,
quantization kernels, native descriptors and performance remain unqualified.
"""

from __future__ import annotations

import importlib
import importlib.util
import json
import logging
import struct
import sys
import types
from pathlib import Path
from unittest.mock import patch

import sglang_captured_fixture as adapter
import torch
from prepare_validation_proposal import prepare_validation

HERE = Path(__file__).resolve().parent
SOURCE = Path("/private/tmp/fi-next-steps-20261024/upstream/flashinfer-main")
HARNESS = Path(
    "/private/tmp/fi-next-steps-20261024/measurement-source/benchmarks/bench_autotuner_accuracy.py"
)
FIXTURE = Path("/private/tmp/fi-next-steps-20261024/coordinator/raw/attempt02/fixture")
SG = Path("/private/tmp/sglang-autotune-selection-study")

checks = []


def check(condition, label):
    if not condition:
        raise AssertionError(label)
    checks.append(label)


def rejected(function, label):
    try:
        function()
    except (ValueError, AssertionError):
        checks.append(label)
    else:
        raise AssertionError("unsafe admission: " + label)


def package(name, path):
    module = types.ModuleType(name)
    module.__path__ = [str(path)]
    sys.modules[name] = module
    return module


def unavailable(*args, **kwargs):
    raise AssertionError("unexpected GPU-only boundary")


package("flashinfer", SOURCE / "flashinfer")
package("flashinfer.jit", SOURCE / "flashinfer/jit")
core = types.ModuleType("flashinfer.jit.core")
core.logger = logging.getLogger("fixture-adapter-proof")
sys.modules[core.__name__] = core
utils = types.ModuleType("flashinfer.utils")
utils.next_positive_power_of_2 = lambda n: 1 << (n - 1).bit_length()
utils.is_confidential_compute = lambda: False
utils.get_globaltimer_kernel = unavailable
sys.modules[utils.__name__] = utils
tllm = types.ModuleType("flashinfer.tllm_utils")
tllm.delay_kernel = unavailable
tllm.get_trtllm_utils_module = unavailable
sys.modules[tllm.__name__] = tllm
package("tests", SOURCE / "tests")
fp8 = types.ModuleType("tests.utils_fp8")
fp8.to_float8 = unavailable
sys.modules[fp8.__name__] = fp8
api = importlib.import_module("flashinfer.autotuner")
spec = importlib.util.spec_from_file_location("pinned_fixture_harness", HARNESS)
harness = importlib.util.module_from_spec(spec)
spec.loader.exec_module(harness)
contract = json.loads(adapter.CONTRACT_PATH.read_text())
manifest = json.loads((FIXTURE / "manifest.json").read_text())
check(
    adapter.sha(HARNESS) == contract["harness_sha256"],
    "exact official fixture-hook harness source",
)
for path, sha in contract["flashinfer_source_sha256"].items():
    check(adapter.sha(SOURCE / path) == sha, "exact official runtime source: " + path)
for path, sha in manifest["source"]["sglang_source_sha256"].items():
    check(adapter.sha(SG / path) == sha, "actual captured SGLang source: " + path)
check(
    adapter.sha(FIXTURE / "manifest.json") == contract["fixture_manifest_sha256"],
    "original manifest unchanged",
)
check(
    adapter.sha(FIXTURE / "fixture.safetensors") == contract["fixture_tensor_sha256"],
    "original private fixture unchanged",
)
# Independent stdlib reader avoids installing another dependency for CPU checks.
raw = (FIXTURE / "fixture.safetensors").read_bytes()
size = struct.unpack_from("<Q", raw)[0]
header = json.loads(raw[8 : 8 + size])
payload = raw[8 + size :]
dtypes = {
    "BF16": torch.bfloat16,
    "F8_E4M3": torch.float8_e4m3fn,
    "F32": torch.float32,
    "I64": torch.int64,
}
tensors = {}
for name, meta in header.items():
    if name == "__metadata__":
        continue
    first, last = meta["data_offsets"]
    tensors[name] = (
        torch.frombuffer(bytearray(payload[first:last]), dtype=dtypes[meta["dtype"]])
        .clone()
        .reshape(meta["shape"])
    )
adapter.validate_fixture(tensors, manifest)
check(True, "actual six fixture tensors satisfy runtime contract")
wrong = dict(tensors)
wrong.pop("input_ids")
rejected(lambda: adapter.validate_fixture(wrong, manifest), "missing tensor rejected")
wrong = dict(tensors)
wrong["input_scale"] = tensors["input_scale"].clone() * 2
rejected(
    lambda: adapter.validate_fixture(wrong, manifest), "changed scale/hash rejected"
)
wrong = dict(tensors)
wrong["input_bf16"] = tensors["input_bf16"].t()
rejected(
    lambda: adapter.validate_fixture(wrong, manifest), "changed input layout rejected"
)
q = (
    (tensors["input_bf16"].float() * tensors["input_scale"].reciprocal())
    .clamp(-448, 448)
    .to(torch.float8_e4m3fn)
)
check(
    adapter.tensor_sha(q) == manifest["quantization"]["independent_input_fp8_sha256"],
    "independent CPU quantized activation bytes match frozen manifest",
)
a = q.unsqueeze(0)
b = tensors["weight_fp8_rowmajor"].t().unsqueeze(0)
out = torch.empty((1, 144, 4096), dtype=torch.bfloat16)
workspace = torch.empty(1024, dtype=torch.uint8)
inputs = [a, b, tensors["input_scale"], tensors["weight_scale"], out, workspace]


class CublasFp8GemmRunner(api.TunableRunner):
    def get_valid_tactics(self, inputs, profile):
        return [0]

    def forward(self, inputs, tactic=-1, **kwargs):
        inputs[4].fill_(1)
        return inputs[4]


runner = CublasFp8GemmRunner()
config = api.TuningConfig()
pool = [runner]


def make_call(op="fp8_gemm", twice=False, none=False):
    def call():
        if none:
            return None
        tuner = api.AutoTuner.get()
        chosen, tactic = tuner.choose_one(op, pool, config, inputs)
        result = chosen(inputs, tactic=tactic)
        call.last_output = result.squeeze(0)
        if twice:
            tuner.choose_one(op, pool, config, inputs)
        return call.last_output

    call.kept = {"input_scale": inputs[2], "weight_scale": inputs[3]}
    call.expected_input_sha256 = manifest["quantization"][
        "independent_input_fp8_sha256"
    ]
    call.expected_weight_sha256 = manifest["tensors"]["weight_fp8_rowmajor"]["sha256"]
    return call


previous = api.AutoTuner._instance
choose = api.AutoTuner.choose_one
with patch.object(torch.cuda, "is_current_stream_capturing", lambda: False):
    call = make_call()
    problem = adapter.capture_problem(call, harness)
    check(
        problem[1] is pool and problem[2] is config and problem[3] is inputs,
        "capture returns original runner/config/input objects without copies",
    )
    check(
        problem[0] == "fp8_gemm" and problem[4] == {},
        "exact one relevant operation and kwargs",
    )
    check(
        call.capture_evidence["roles"]["output_index"] == 4
        and call.capture_evidence["roles"]["safe_output_refresh_not_enabled"],
        "output is explicitly declared and refresh remains inactive",
    )
    rejected(
        lambda: adapter.capture_problem(make_call(twice=True), harness),
        "second choose_one invocation rejected by official API",
    )
    rejected(
        lambda: adapter.capture_problem(make_call(none=True), harness),
        "no choose_one invocation rejected",
    )
    rejected(
        lambda: adapter.capture_problem(make_call(op="wrong"), harness),
        "wrong operation rejected",
    )
    call = make_call()
    call.expected_input_sha256 = "0" * 64
    rejected(
        lambda: adapter.capture_problem(call, harness),
        "changed captured activation rejected",
    )
    call = make_call()
    call.kept["input_scale"] = inputs[2].clone()
    rejected(
        lambda: adapter.capture_problem(call, harness),
        "replaced scale allocation rejected",
    )
check(
    api.AutoTuner._instance is previous and api.AutoTuner.choose_one is choose,
    "real singleton and capture method restored after positive and negative controls",
)
# The proposed callback is separate and deliberately not connected to harness.
role_inputs = [
    torch.ones(4),
    torch.ones(4),
    torch.ones(1),
    torch.ones(1),
    torch.zeros(4),
    torch.empty(8, dtype=torch.uint8),
]
actual = role_inputs[4]
roles = adapter.validate_roles(actual, role_inputs)
check(
    roles["output_data_ptr"] == actual.data_ptr(),
    "valid output-in-input-list admitted without mutation",
)
prepare_validation(actual, role_inputs)
check(bool(torch.isnan(actual).all()), "proposed callback poisons only admitted output")
actual.fill_(1)
prepare_validation(actual, role_inputs)
rejected(
    lambda: torch.testing.assert_close(actual, torch.ones_like(actual)),
    "stale no-write output fails after proposed refresh",
)
actual.fill_(1)
torch.testing.assert_close(actual, torch.ones_like(actual))
check(True, "correct post-refresh write passes real numerical check")
aliased = list(role_inputs)
aliased[0] = actual
before = actual.clone()
rejected(
    lambda: prepare_validation(actual, aliased),
    "read/output alias rejected before mutation",
)
check(torch.equal(actual, before), "read alias rejection preserves data")
aliased = list(role_inputs)
aliased[5] = actual
rejected(
    lambda: prepare_validation(actual, aliased),
    "scratch/output alias rejected before mutation",
)
integer = list(role_inputs)
integer[4] = torch.ones(4, dtype=torch.int64)
before = integer[4].clone()
rejected(
    lambda: prepare_validation(integer[4], integer),
    "integer output rejected before mutation",
)
check(torch.equal(integer[4], before), "integer rejection preserves data")
rejected(
    lambda: prepare_validation(actual.clone(), role_inputs),
    "wrong declared output rejected",
)
check(
    "prepare_validation" not in Path(HARNESS).read_text(),
    "current official harness does not consume the proposed callback",
)
files = [
    Path(adapter.__file__),
    adapter.CONTRACT_PATH,
    HERE / "prepare_validation_proposal.py",
    Path(__file__),
    HARNESS,
]
report = {
    "status": "success",
    "controls": len(checks),
    "checks": checks,
    "source_sha256": {str(p): adapter.sha(p) for p in files},
    "fixture_sha256": adapter.sha(FIXTURE / "fixture.safetensors"),
    "torch": torch.__version__,
    "limits": [
        "Complete official capture_choose_one_calls, isolated tuner and actual AutoTuner.choose_one execute on CPU. GPU-only import boundaries are disclosed shims.",
        "CPU runner writes are controlled stand-ins; the production SGLang facade, actual static quantizer kernel, module build/load and descriptor acceptance require later GPU qualification.",
        "The proposed callback is exercised directly only; the unchanged upstream harness does not invoke it. No output-refresh coverage is claimed for as-is harness.",
    ],
}
p = HERE / "cpu-controls.json"
p.write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"status": "success", "controls": len(checks), "report": str(p)}))
