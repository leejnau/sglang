"""Proposed optional fixture callback; the pinned official harness does not call it.

Only a future explicit upstream callback contract may activate this immediately
before each final independent replay, outside timing and after ownership checks.
"""

from sglang_captured_fixture import validate_roles


def prepare_validation(output, inputs):
    roles = validate_roles(output, inputs)
    output.fill_(float("nan"))
    return roles
