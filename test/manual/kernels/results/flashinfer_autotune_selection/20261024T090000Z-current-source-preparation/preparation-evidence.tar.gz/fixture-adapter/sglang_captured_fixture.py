"""Research fixture for the pinned official accuracy harness's module:build hook.

Stage the unchanged private fixture under Path(args.out).parent / 'fixture'.
The official harness subsequently times BMM runners, not this full SGLang call.
Its final validation has no output-refresh contract; no-write rejection is not
qualified by this adapter. No timing or production function is replaced.
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path

CONTRACT_PATH = Path(__file__).with_name("adapter-contract.json")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def tensor_sha(tensor):
    import torch

    raw = tensor.detach().contiguous().view(torch.uint8).cpu()
    return hashlib.sha256(bytes(raw.reshape(-1).tolist())).hexdigest()


def validate_fixture(tensors, manifest):
    import torch

    m, n, k = manifest["shape"]
    expected = {
        "input_bf16": (torch.bfloat16, [m, k]),
        "weight_fp8_rowmajor": (torch.float8_e4m3fn, [n, k]),
        "weight_bf16_rowmajor": (torch.bfloat16, [n, k]),
        "input_scale": (torch.float32, [1]),
        "weight_scale": (torch.float32, [1]),
        "input_ids": (torch.int64, [1, m]),
    }
    if (
        [m, n, k] != [144, 4096, 1024]
        or set(tensors) != set(expected)
        or set(manifest["tensors"]) != set(expected)
    ):
        raise ValueError("the exact six-tensor fixture geometry is required")
    for name, (dtype, shape) in expected.items():
        value, metadata = tensors[name], manifest["tensors"][name]
        actual = {
            "dtype": str(value.dtype),
            "shape": list(value.shape),
            "sha256": tensor_sha(value),
            "nbytes": value.numel() * value.element_size(),
        }
        if (
            value.dtype != dtype
            or list(value.shape) != shape
            or not value.is_contiguous()
            or actual != metadata
            or not bool(torch.isfinite(value.float()).all())
        ):
            raise ValueError("fixture tensor changed: " + name)
    if any(
        not bool(tensors[name].gt(0).all()) for name in ("input_scale", "weight_scale")
    ):
        raise ValueError("fixture scales must be positive")


def validate_roles(output, inputs):
    """Admit the known FP8 output role; do not mutate any operand."""
    if (
        len(inputs) != 6
        or output.data_ptr() != inputs[4].data_ptr()
        or output.numel() != inputs[4].numel()
        or not output.dtype.is_floating_point
    ):
        raise ValueError("the returned tensor must be the declared floating output")

    def storage(tensor):
        actual = tensor.untyped_storage()
        return actual.data_ptr(), actual.nbytes()

    begin, size = storage(output)
    if any(
        begin < other + length and other < begin + size
        for other, length in map(storage, inputs[:4] + inputs[5:])
    ):
        raise ValueError("the output aliases a read operand or workspace")
    return {
        "read_indices": [0, 1, 2, 3],
        "output_index": 4,
        "scratch_index": 5,
        "output_data_ptr": output.data_ptr(),
        "safe_output_refresh_not_enabled": True,
    }


def capture_problem(call, harness):
    """Return the actual (op, runners, config, inputs, kwargs), without copies."""
    with harness.use_isolated_tuner(harness.AutoTuner()):
        captured = harness.capture_choose_one_calls(call, require_single=True)
    if len(captured) != 1:
        raise ValueError("exactly one relevant choose_one invocation is required")
    op, (runners, config, inputs, kwargs) = next(iter(captured.items()))
    if (
        op != "fp8_gemm"
        or [type(r).__name__ for r in runners] != ["CublasFp8GemmRunner"]
        or kwargs
    ):
        raise ValueError("the captured operation or runner pool changed")
    roles = validate_roles(call.last_output, inputs)
    a, b, sa, sb = inputs[:4]
    if (
        list(a.shape) != [1, 144, 1024]
        or list(b.shape) != [1, 1024, 4096]
        or list(b.stride()) != [1024, 1, 1024]
        or tensor_sha(a) != call.expected_input_sha256
        or tensor_sha(b.squeeze(0).t()) != call.expected_weight_sha256
        or sa.data_ptr() != call.kept["input_scale"].data_ptr()
        or sb.data_ptr() != call.kept["weight_scale"].data_ptr()
    ):
        raise ValueError("captured public operands differ from the frozen fixture")
    call.capture_evidence = {
        "op": op,
        "runners": [type(r).__name__ for r in runners],
        "roles": roles,
        "inputs": [
            {
                "shape": list(t.shape),
                "stride": list(t.stride()),
                "dtype": str(t.dtype),
                "data_ptr": t.data_ptr(),
            }
            for t in inputs
        ],
        "quantized_input_sha256": tensor_sha(a),
        "weight_rowmajor_sha256": tensor_sha(b.squeeze(0).t()),
    }
    return op, runners, config, inputs, kwargs


def build(args):
    import torch
    from safetensors.torch import load_file

    contract = json.loads(CONTRACT_PATH.read_text())
    if contract["schema_version"] != 1 or (args.rtol, args.atol) != (0.02, 0.125):
        raise ValueError("use the declared contract and frozen numerical tolerances")
    folder = Path(args.out).resolve().parent / "fixture"
    manifest_path, tensor_path = (
        folder / "manifest.json",
        folder / "fixture.safetensors",
    )
    if (
        sha(manifest_path) != contract["fixture_manifest_sha256"]
        or sha(tensor_path) != contract["fixture_tensor_sha256"]
    ):
        raise ValueError("the immutable captured fixture files changed")
    manifest, cpu = (
        json.loads(manifest_path.read_text()),
        load_file(str(tensor_path), device="cpu"),
    )
    validate_fixture(cpu, manifest)
    torch.cuda.set_device(0)
    import flashinfer
    import sglang
    from sglang.kernels.ops.quantization import fp8_kernel
    from sglang.srt.layers.quantization import fp8_utils

    sg_root, fi_root = (
        Path(sglang.__file__).resolve().parents[2],
        Path(flashinfer.__file__).resolve().parents[1],
    )
    for path, expected in manifest["source"]["sglang_source_sha256"].items():
        if sha(sg_root / path) != expected:
            raise ValueError("SGLang source differs from fixture provenance: " + path)
    if any(
        not Path(module.__file__).resolve().is_relative_to(sg_root / "python")
        for module in (fp8_utils, fp8_kernel)
    ):
        raise ValueError("the actual layer imported from a different checkout")
    for path, expected in contract["flashinfer_source_sha256"].items():
        if sha(fi_root / path) != expected:
            raise ValueError(
                "FlashInfer source differs from the declared current-source contract: "
                + path
            )
    harness = sys.modules["__main__"]
    if sha(harness.__file__) != contract["harness_sha256"] or not hasattr(
        harness, "capture_choose_one_calls"
    ):
        raise ValueError("run this factory from the pinned official harness")
    if (
        torch.backends.cuda.matmul.allow_tf32
        or fp8_utils.static_quant_fp8 is not fp8_kernel.static_quant_fp8
        or fp8_utils._raw_flashinfer_bmm_fp8 is not flashinfer.bmm_fp8
        or not fp8_utils.flashinfer_per_tensor_fp8_supported()
    ):
        raise ValueError("the qualified cublas facade or FP32 reference mode changed")
    kept = {
        name: cpu[name].to("cuda")
        for name in ("input_bf16", "weight_fp8_rowmajor", "input_scale", "weight_scale")
    }
    with torch.inference_mode():
        qinput, scale = fp8_kernel.static_quant_fp8(
            kept["input_bf16"], kept["input_scale"], repeat_scale=False
        )
        if (
            tensor_sha(qinput)
            != manifest["quantization"]["independent_input_fp8_sha256"]
            or scale.data_ptr() != kept["input_scale"].data_ptr()
        ):
            raise ValueError("the actual static quantizer changed frozen operand bytes")
        reference = (
            qinput.float()
            @ kept["weight_fp8_rowmajor"].float().t()
            * kept["input_scale"]
            * kept["weight_scale"]
        )

    def call():
        with torch.inference_mode():
            call.last_output = fp8_utils.apply_fp8_linear_bmm_flashinfer(
                kept["input_bf16"],
                kept["weight_fp8_rowmajor"].t(),
                kept["weight_scale"],
                kept["input_scale"],
                bias=None,
            )
            return call.last_output

    call.kept, call.reference = kept, lambda: reference
    call.expected_input_sha256 = manifest["quantization"][
        "independent_input_fp8_sha256"
    ]
    call.expected_weight_sha256 = manifest["tensors"]["weight_fp8_rowmajor"]["sha256"]
    call.captured_problem = capture_problem(call, harness)
    torch.testing.assert_close(
        call.last_output.float(), reference, rtol=args.rtol, atol=args.atol
    )
    call.capture_problem = lambda: capture_problem(call, harness)
    call.provenance = {
        "adapter_sha256": sha(__file__),
        "contract_sha256": sha(CONTRACT_PATH),
        "fixture_manifest_sha256": sha(manifest_path),
        "fixture_tensor_sha256": sha(tensor_path),
        "upstream_commit": contract["upstream_commit"],
        "capture": call.capture_evidence,
        "factory_preflight_public_calls": 1,
        "retains_original_capture_tensors": True,
        "final_graph_no_write_refresh_supported": False,
        "native_provider_qualification": "Required before GPU experiments; this source/fixture adapter does not establish loaded ELF identity or descriptor acceptance.",
        "timed_scope": "Upstream harness BMM runner graphs; excludes SGLang quantizer, public lookup and allocation.",
        "profile_domain": "Retained mode removes dynamic profiles; synthesized mode retains the operation config. This is not an input-values-only contrast.",
    }
    sidecar = Path(args.out).with_suffix(".fixture-provenance.json")
    if sidecar.exists():
        raise FileExistsError("refusing to overwrite fixture provenance")
    sidecar.write_text(json.dumps(call.provenance, indent=2) + "\n")
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    return call
