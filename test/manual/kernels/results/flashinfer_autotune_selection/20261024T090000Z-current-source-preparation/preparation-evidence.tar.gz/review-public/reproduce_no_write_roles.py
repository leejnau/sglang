"""Exercise the unchanged upstream graph study with real CPU tuner/cache paths.

Only GPU import/timer/capture boundaries and profiling times are controlled.
No GPU timing or hardware failure is claimed.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib
import importlib.util
import json
import logging
import math
import os
from pathlib import Path
import sys
import types
from unittest.mock import patch

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--source-root',type=Path,required=True)
parser.add_argument('--harness',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
arguments=parser.parse_args()
SOURCE=arguments.source_root.resolve()
HARNESS=arguments.harness.resolve()
EXPECTED={
    SOURCE/'flashinfer/autotuner/autotuner.py':'0db42ad90d1a3fec6f81509a2c520c1892cea0a433f5dbd7f43468a2a10243ca',
    SOURCE/'flashinfer/autotune_cache.py':'1ab2ed7208ed1bf1007b1f74de29fc818c93a5ab091beea0833474177fbb29ad',
    HARNESS:'7947647d266ec6a837bedd8e9c87d7d4dcbb4683bb9d16fef4b2d01c3f43b0dd',
}
for path,expected in EXPECTED.items():
    assert hashlib.sha256(path.read_bytes()).hexdigest()==expected, str(path)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def package(name,path):
    module=types.ModuleType(name);module.__path__=[str(path)];sys.modules[name]=module;return module

def unavailable(*args,**kwargs):raise AssertionError('unexpected GPU-only import boundary')
os.environ['FLASHINFER_AUTOTUNER_LOAD_FROM_FILE']='0'
os.environ['FLASHINFER_AUTOTUNE_TIMER']='cuda_event'
package('flashinfer',SOURCE/'flashinfer')
package('flashinfer.jit',SOURCE/'flashinfer/jit')
core=types.ModuleType('flashinfer.jit.core');core.logger=logging.getLogger('no-write-proof');sys.modules[core.__name__]=core
utils=types.ModuleType('flashinfer.utils');utils.next_positive_power_of_2=lambda n:1<<(n-1).bit_length();utils.is_confidential_compute=lambda:False;utils.get_globaltimer_kernel=unavailable;sys.modules[utils.__name__]=utils
tllm=types.ModuleType('flashinfer.tllm_utils');tllm.delay_kernel=unavailable;tllm.get_trtllm_utils_module=unavailable;sys.modules[tllm.__name__]=tllm
# Built-in fixture construction is unused; our retained CPU fixture is supplied.
package('tests',SOURCE/'tests')
fp8=types.ModuleType('tests.utils_fp8');fp8.to_float8=unavailable;sys.modules[fp8.__name__]=fp8
import torch
assert torch.__version__.split('+')[0]=='2.14.1' and not torch.cuda.is_available()
api=importlib.import_module('flashinfer.autotuner')
engine=importlib.import_module('flashinfer.autotuner.autotuner')
cache=importlib.import_module('flashinfer.autotune_cache')
spec=importlib.util.spec_from_file_location('actual_accuracy_harness',HARNESS)
harness=importlib.util.module_from_spec(spec);spec.loader.exec_module(harness)

state=types.SimpleNamespace(active=None,clock=0,captures=[],replays=[])
class Graph:
    def __init__(self):self.actions=[];self.tactics=[];self.output_ptrs=[]
    def replay(self):
        for action in self.actions:action()
        state.clock+=1;state.replays.append(list(self.tactics))
@contextlib.contextmanager
def graph_capture(graph):
    assert state.active is None;state.active=graph
    try:yield
    finally:state.active=None;state.captures.append(graph)
class Event:
    def __init__(self,**kwargs):self.value=None
    def record(self):self.value=state.clock
    def synchronize(self):pass
    def elapsed_time(self,other):return float(other.value-self.value)

def controlled_profile(self,runner,inputs,tactic,config,**kwargs):
    # Force an explicit winner without mocking choose_one, policy or cache logic.
    return 1.0 if tactic==0 else 2.0

def run_case(kind,poison_validation=False):
    state.active=None;state.clock=0;state.captures=[];state.replays=[]
    output=torch.empty(4)
    operands=[torch.ones(4),torch.ones(4),torch.ones(1),torch.ones(1),output,torch.empty(8,dtype=torch.uint8)]
    class Runner(api.TunableRunner):
        def get_valid_tactics(self,inputs,profile):return [0]
        def forward(self,inputs,tactic=-1,**kwargs):
            def action():
                if tactic==-1 or kind=='correct':torch.add(inputs[0],1,out=output)
                elif kind=='destructive_wrong':torch.add(inputs[0],2,out=output)
                # no_write intentionally returns the existing caller-owned output.
            if state.active is not None:
                state.active.actions.append(action);state.active.tactics.append(tactic);state.active.output_ptrs.append(output.data_ptr())
            else:action()
            return output
    args=types.SimpleNamespace(cold_l2=None,profile_inputs='retained',seeds=1,graph_policies=['auto'],seed=19,warmup=1,tuner_repeat=2,oracle_rounds=3,validation_replays=2,prequeue_cycles=1,rtol=0,atol=0)
    original_assert=torch.testing.assert_close
    validations=[]
    def observed_assert(actual,expected,**kwargs):
        validations.append({'actual':[value if math.isfinite(value) else str(value) for value in actual.tolist()],'expected':expected.tolist(),'same_data_ptr':actual.data_ptr()==output.data_ptr()})
        return original_assert(actual,expected,**kwargs)
    context=poisoned_validation(operands) if poison_validation else contextlib.nullcontext()
    with context,patch.object(torch.testing,'assert_close',observed_assert):
        try:
            result=harness.graph_selection_study('manual.no_write',[Runner()],api.TuningConfig(),operands,{},args)
        except AssertionError as error:
            outcome={'accepted':False,'error_type':type(error).__name__,'error':str(error).splitlines()[0]}
        else:
            row=result['trials'][0]
            outcome={'accepted':True,'selected_tactic':row['tactic'],'actual_cache_hit':row['cache_hit'],'profile_count':row['profile_count'],'numerics':row['numerics']}
    outcome.update(kind=kind,validation_poison_control=poison_validation,declared_read_input_ptrs=[value.data_ptr() for value in operands[:4]],declared_output_input_index=4,declared_output_input_ptr=operands[4].data_ptr(),validation_values=validations,capture_tactics=[graph.tactics for graph in state.captures],capture_output_ptrs=[graph.output_ptrs for graph in state.captures],all_captures_share_output=all(pointer==output.data_ptr()for graph in state.captures for pointer in graph.output_ptrs))
    return outcome

def prepare_fp8_validation(output, inputs):
    """Research callback: declared FP8 read0..3/output4/scratch5 roles only."""
    if len(inputs) != 6 or not isinstance(output, torch.Tensor):
        raise ValueError('unsupported output-role contract')
    if not (output.is_floating_point() or output.is_complex()):
        raise ValueError('poison callback does not support integer outputs')
    storage = output.untyped_storage().data_ptr()
    if storage != inputs[4].untyped_storage().data_ptr():
        raise ValueError('returned tensor is not the declared output buffer')
    if any(storage == value.untyped_storage().data_ptr() for value in inputs[:4]):
        raise ValueError('output aliases declared read operands; poisoning forbidden')
    output.fill_(float('nan'))

@contextlib.contextmanager
def poisoned_validation(inputs):
    # Minimal fix experiment: poison the caller-owned tensor immediately before
    # each of the three final independent validation replays, not timing loops.
    # This wraps only that final loop's graph handles after sampling completes.
    original=harness.interleaved_graph_samples
    def samples(graphs,*args,**kwargs):
        result=original(graphs,*args,**kwargs)
        for graph in graphs.values():
            replay=graph.replay
            # The real selected output is shared with every capture in this case.
            def poisoned(replay=replay):
                prepare_fp8_validation(captured_outputs[0], inputs)
                return replay()
            graph.replay=poisoned
        return result
    # Capture the actual output only at the external capture boundary. Source
    # capture_tactic_graph stays unchanged and returns its real Tensor output.
    capture=harness.capture_tactic_graph
    captured_outputs=[]
    def capture_output(*args,**kwargs):
        result=capture(*args,**kwargs);captured_outputs.append(result[1]);return result
    with patch.object(harness,'interleaved_graph_samples',samples),patch.object(harness,'capture_tactic_graph',capture_output):yield

with contextlib.ExitStack()as stack:
    for name,value in [('CUDAGraph',Graph),('graph',graph_capture),('Event',Event),('synchronize',lambda:None),('_sleep',lambda _:None),('is_current_stream_capturing',lambda:state.active is not None)]:
        stack.enter_context(patch.object(torch.cuda,name,value))
    stack.enter_context(patch.object(api.AutoTuner,'_profile_single_kernel',controlled_profile))
    stack.enter_context(patch.object(harness,'sm_clock_mhz',lambda:None))
    original_instance=api.AutoTuner._instance
    rows=[run_case(kind)for kind in ['correct','destructive_wrong','no_write']]
    rows += [run_case(kind,True)for kind in ['correct','destructive_wrong','no_write']]
    assert api.AutoTuner._instance is original_instance
expected=[True,False,True,True,False,False]
assert [row['accepted']for row in rows]==expected
assert all(row['all_captures_share_output']for row in rows)
assert rows[2]['actual_cache_hit'] and rows[2]['selected_tactic']=='0' and rows[2]['numerics']=='passed'
assert len(rows[2]['validation_values'])==3
# Output is itself in the input list; reject only aliasing declared read roles.
read=torch.ones(4);output=torch.empty(4)
roles=[read,torch.ones(4),torch.ones(1),torch.ones(1),output,torch.empty(8,dtype=torch.uint8)]
prepare_fp8_validation(output,roles)
assert torch.isnan(output).all() and torch.equal(read,torch.ones(4))
role_controls=['declared output-in-input-list accepted without changing read operands']
for kind in ['read_alias','integer','wrong_output_role']:
    target=torch.ones(4) if kind!='integer' else torch.ones(4,dtype=torch.int64)
    operands=[torch.ones(4),torch.ones(4),torch.ones(1),torch.ones(1),target,torch.empty(8,dtype=torch.uint8)]
    if kind=='read_alias':operands[0]=target
    if kind=='wrong_output_role':operands[4]=torch.empty(4)
    prior=target.clone()
    try:prepare_fp8_validation(target,operands)
    except ValueError:pass
    else:raise AssertionError('unsafe poison callback accepted: '+kind)
    assert torch.equal(target,prior)
    role_controls.append(kind+' rejected before mutation')
source_files=[HARNESS,*[SOURCE/'flashinfer'/name for name in ['autotuner/autotuner.py','autotuner/__init__.py','autotuner/initializers.py','autotuner/protocol.py','autotune_cache.py','tactics_blocklist.py','version.py']]]
report={'status':'success','script_sha256':sha(__file__),'source_sha256':{str(path):sha(path)for path in source_files},'torch':torch.__version__,'cases':rows,'role_controls':role_controls,'conclusion':'The unchanged graph_selection_study accepts a real cached explicit no-write winner whose three captured outputs alias the correctly populated default buffer. Poisoning only immediately before final independent validation replays rejects it while preserving the correct control.','boundaries':['Complete production AutoTuner.choose_one, policy context, cache-key construction, winner insertion and search_cache remain real.','Complete unchanged upstream graph_selection_study and capture_tactic_graph execute; only GPU events/capture/streams and measured profiling times are controlled.','CPU Tensor writes and torch.testing.assert_close remain real.','No GPU kernel, timing, hardware error, native library, serving performance or actual backend defect is established.'],'fix_proposal':['Add an optional fixture-owned prepare_validation(output, inputs) callback, invoked only before final independent validation replays. The FP8 callback declares read0..3/output4/scratch5 roles, validates output storage ownership and no read alias, then poisons the floating output.','Add a no-write selected-tactic shared-output regression beside the existing destructive-wrong shared-output test.','Retain replay-before-assert and post-sampling all-three-control validation. For generic/integer/in-place fixtures without an output-refresh contract, preserve reference comparison and report output-refresh validation unavailable instead of blind poisoning.']}
output=arguments.output;output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({'status':'success','accepted':[row['accepted']for row in rows],'report':str(output),'report_sha256':sha(output)}))
