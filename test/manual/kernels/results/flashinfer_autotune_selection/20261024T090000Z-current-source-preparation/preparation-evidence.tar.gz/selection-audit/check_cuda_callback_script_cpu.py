"""Admit the standalone CUDA gate's control flow at explicit CPU GPU boundaries."""
import contextlib
import hashlib
import importlib.util
import json
from pathlib import Path
from unittest.mock import patch

ROOT=Path('/private/tmp/fi-next-steps-20261024')
loader=ROOT/'fixture-validation-callback/check_callback.py'
namespace={'__file__':str(loader),'__name__':'callback_cpu_boundaries'}
exec(compile(loader.read_text().split('with contextlib.ExitStack() as boundaries:',1)[0],str(loader),'exec'),namespace)
torch,state=namespace['torch'],namespace['state']
worker=ROOT/'current-source-coordinator/test_output_refresh.py'
spec=importlib.util.spec_from_file_location('cuda_gate_under_cpu_boundaries',worker)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
real_add,real_empty,real_ones=torch.add,torch.empty,torch.ones

def add(*args,**kwargs):
    if state.active is not None:
        state.active.actions.append(lambda:real_add(*args,**kwargs))
        return kwargs['out']
    return real_add(*args,**kwargs)

def cpu(function):
    def construct(*args,**kwargs):
        if kwargs.get('device')=='cuda':kwargs['device']='cpu'
        return function(*args,**kwargs)
    return construct

with contextlib.ExitStack()as stack:
    for name,value in [('is_available',lambda:True),('get_device_name',lambda:'CPU boundary control; actual CUDA pending'),('CUDAGraph',namespace['Graph']),('graph',namespace['capture']),('Event',namespace['Event']),('synchronize',lambda:None),('_sleep',lambda _:None),('is_current_stream_capturing',lambda:state.active is not None)]:stack.enter_context(patch.object(torch.cuda,name,value))
    for name,value in [('add',add),('empty',cpu(real_empty)),('ones',cpu(real_ones))]:stack.enter_context(patch.object(torch,name,value))
    result=module.run(ROOT/'current-source-qualification/fp8-runtime-callback/benchmarks/bench_autotuner_accuracy.py')
assert result['status']=='success'
assert [case['accepted']for case in result['cases']]==[True,False,True,True,False,False]
assert len(result['unsafe_roles'])==4
report={'status':'CPU_admission_passed_actual_CUDA_pending','worker_sha256':hashlib.sha256(worker.read_bytes()).hexdigest(),'admission_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'actual_harness_source_sha256':result['harness_sha256'],'cases':[{'kind':row['kind'],'callback':row['callback_enabled'],'accepted':row['accepted'],'final_assertions':row['final_assertions'],'callback_calls':row['callback_calls']}for row in result['cases']],'unsafe_role_rejections':4,'boundaries':['Real complete standalone worker, current harness and tuner/cache/policy execute; profiler durations remain the intended controlled values.','CUDA allocations, graph capture/replay, events, device query and torch.add recording are CPU boundaries for this admission only. No actual CUDA, native provider or device numerics pass is reported.']}
(ROOT/'selection-audit/cuda-callback-script-cpu-admission.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'worker_sha256':report['worker_sha256'],'cases':len(report['cases']),'unsafe_roles':4}))
