#!/usr/bin/env python3
"""Execute exact ported FP8 Python source with current tuner and fake native CUDA."""

import ast
import contextlib
import copy
import functools
import hashlib
import json
from pathlib import Path
import struct
import sys
import types
from typing import List, Literal, Optional, Tuple

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "cpu-deps"))
SOURCE = ROOT / "fp8-candidate/flashinfer/gemm/gemm_base.py"
BASE_LOADER = ROOT.parent / "upstream/prove_distributed_objective_guard.py"
assert hashlib.sha256(BASE_LOADER.read_bytes()).hexdigest() == "4e8215a2fa9d49edff10ed8a06c8a8cd87793298b9f66a9a2576cb4aa66cf8f8"
loader = types.ModuleType("whole_current_tuner_loader")
loader.__file__ = str(BASE_LOADER)
exec(compile(BASE_LOADER.read_bytes(), str(BASE_LOADER), "exec"), loader.__dict__)
api, engine, cache, torch, cuda_fixture, tuner_sources = loader.load_whole_modules(ROOT.parent / "upstream/flashinfer-main")
import numpy


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


checks = []


def check(condition, name):
    if not condition:
        raise AssertionError(name)
    checks.append(name)


class NativeBoundary:
    """No native CUDA is simulated as real; return flags are explicit fixtures."""

    def __init__(self):
        self.calls = []
        self.used = 1
        self.descriptors = (tuple(range(1, 9)), tuple(range(9, 17)))

    def bmm_fp8_get_algos(self, a, b, out, sa, sb, workspace, buffer, bucket_m):
        self.calls.append({"kind": "enumerate", "actual_m": a.shape[-2], "bucket_m": bucket_m,
                           "workspace_bytes": workspace.numel()})
        raw = b"".join(struct.pack("8Q", *descriptor) for descriptor in self.descriptors)
        buffer[:len(raw)].copy_(torch.tensor(list(raw), dtype=torch.uint8))
        return len(self.descriptors)

    def write(self, a, b, out, sa, sb):
        out.copy_((a.float() @ b.float() * sa * sb).to(out.dtype))

    def bmm_fp8(self, a, b, out, sa, sb, workspace):
        self.calls.append({"kind": "default", "actual_m": a.shape[-2]})
        self.write(a, b, out, sa, sb)

    def bmm_fp8_run_with_descriptor(self, a, b, out, sa, sb, workspace, descriptor):
        tactic = struct.unpack("8Q", bytes(descriptor.tolist()))
        self.calls.append({"kind": "descriptor", "actual_m": a.shape[-2], "tactic": list(tactic), "used_fixture": self.used})
        self.write(a, b, out, sa, sb)
        return self.used


native = NativeBoundary()
namespace = {
    "__name__": "ported_fp8_source_fragment", "torch": torch, "functools": functools,
    "struct": struct, "SimpleNamespace": types.SimpleNamespace, "List": List,
    "Optional": Optional, "Tuple": Tuple, "Literal": Literal,
    "AutoTuner": api.AutoTuner, "TunableRunner": api.TunableRunner,
    "TuningConfig": api.TuningConfig, "DynamicTensorSpec": api.DynamicTensorSpec,
    "ConstraintSpec": api.ConstraintSpec, "OptimizationProfile": api.OptimizationProfile,
    "is_in_profile_measurement": api.is_in_profile_measurement,
    "gen_gemm_module": lambda: types.SimpleNamespace(build_and_load=lambda: native),
    "register_custom_op": lambda *a, **k: lambda function: function,
    "register_fake_op": lambda *a, **k: lambda function: function,
    "next_positive_power_of_2": lambda x: 1 << (x - 1).bit_length(),
}
mapping_path = ROOT / "reference-sources/flashinfer/fused_moe/utils.py"
mapping_tree = ast.parse(mapping_path.read_text())
mapping_names = {"_PHASE1_END", "_PHASE2_END", "_PHASE2_STEP", "_PHASE3_END", "_PHASE3_STEP"}
mapping_functions = {"_ceil_to_step", "get_hybrid_num_tokens_buckets", "map_to_hybrid_bucket_uncapped"}
mapping_nodes = [node for node in mapping_tree.body if
                 isinstance(node, ast.FunctionDef) and node.name in mapping_functions
                 or isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id in mapping_names for target in node.targets)]
exec(compile(ast.Module(body=mapping_nodes, type_ignores=[]), str(mapping_path), "exec"), namespace)

tree = ast.parse(SOURCE.read_text())
function_names = {"_cublaslt_algos_to_tactics", "_is_cublaslt_algo_tactic", "_cublaslt_algo_tensor",
                  "_cublaslt_algo_arg", "_check_cublaslt_descriptor_ran", "get_gemm_module",
                  "fp8_gemm_sm100", "bmm_fp8"}
assignment_names = {"_CUBLASLT_ALGO_BYTES", "_CUBLASLT_MAX_ALGOS", "_CUBLASLT_ALGO_FORMAT", "_FP8_GEMM_SM100_TUNING_CONFIG"}
nodes, extracted = [], []
for node in tree.body:
    selected = isinstance(node, ast.FunctionDef) and node.name in function_names or isinstance(node, ast.Assign) and any(
        isinstance(target, ast.Name) and target.id in assignment_names for target in node.targets)
    if selected:
        node = copy.deepcopy(node)
        if isinstance(node, ast.FunctionDef):
            extracted.append({"name": node.name, "line": node.lineno})
            if node.name == "bmm_fp8":
                node.decorator_list = []
        nodes.append(node)
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(SOURCE), "exec"), namespace)
workspace = torch.empty(1024, dtype=torch.uint8)
namespace.update(_get_cache_buf=lambda *args: workspace, DEFAULT_WORKSPACE_SIZE=workspace.numel(),
                 CUDNN_AVAILABLE=False,
                 _cudnn_gemm_fp8_runner=lambda: (_ for _ in ()).throw(RuntimeError("unselected backend")),
                 _cute_dsl_fp8_gemm_runner_sm107=lambda: (_ for _ in ()).throw(RuntimeError("unselected backend")))
api.AutoTuner._instance = api.AutoTuner()
module = namespace["get_gemm_module"]()


def operands(m, n=8, k=16, dtype=torch.bfloat16, workspace_bytes=1024):
    return [torch.ones(1, m, k, dtype=torch.float8_e4m3fn),
            torch.full((1, n, k), 2, dtype=torch.float8_e4m3fn).transpose(-2, -1),
            torch.tensor([0.5]), torch.tensor([0.25]),
            torch.empty(1, m, n, dtype=dtype), torch.empty(workspace_bytes, dtype=torch.uint8)]


r1, r2 = module.cublas_fp8_gemm_runner(), module.cublas_fp8_gemm_runner()
a129, a144 = operands(129), operands(144)
tactics = r1.get_valid_tactics(a129, None)
check(tactics == list(native.descriptors), "actual_helper_parses_two_native_descriptor_fixtures")
check(native.calls[-1]["bucket_m"] == 256, "actual_current_bucket_mapper_enumerates_M129_at256")
count = len(native.calls)
check(r2.get_valid_tactics(a144, None) == tactics and len(native.calls) == count,
      "M144_and_M129_share_bucket_enumeration_across_actual_runner_instances")
r1.get_valid_tactics(operands(257), None)
check(native.calls[-1]["bucket_m"] == 512, "next_bucket_uses_independent_native_enumeration")
for label, changed in (("workspace", operands(144, workspace_bytes=2048)),
                       ("output_dtype", operands(144, dtype=torch.float16)),
                       ("N", operands(144, n=16)), ("K", operands(144, k=32))):
    before = len(native.calls)
    r1.get_valid_tactics(changed, None)
    check(len(native.calls) == before + 1 and native.calls[-1]["kind"] == "enumerate", "cache_key_separates_" + label)
check(r1.get_cache_key_extras(a129) == r1.get_cache_key_extras(a144), "extras_remain_M_synthesis_invariant")

for tactic in tactics + [(2**64 - 1,) * 8]:
    tensor = namespace["_cublaslt_algo_arg"](tactic)
    check(bytes(tensor.tolist()) == struct.pack("8Q", *tactic), "actual_CPU_tensor_descriptor_roundtrip_" + str(tactic[0]))
    restored = engine._json_to_tactic(json.loads(json.dumps(engine._tactic_to_json(tactic))))
    check(restored == tactic, "actual_current_tuner_JSON_descriptor_roundtrip_" + str(tactic[0]))
check(namespace["_cublaslt_algo_arg"](-1) is None, "default_descriptor_argument_is_None")
for tactic in (0, 17, -2, (), (1,) * 7, (1,) * 9, (-1,) * 8, (2**64,) * 8, ("x",) * 8):
    try:
        namespace["_cublaslt_algo_arg"](tactic)
    except ValueError:
        check(True, "invalid_descriptor_rejected_" + repr(tactic))
    else:
        raise AssertionError("malformed tactic accepted")

before = len(native.calls)
check(r1(a144, tactic=-1) is a144[4], "default_runner_returns_callers_output")
check(len(native.calls) == before + 1 and native.calls[-1]["kind"] == "default", "default_avoids_descriptor_enumeration")
for used in (1, 0):
    native.used = used
    before = len(native.calls)
    r1(a144, tactic=tactics[0])
    check(len(native.calls) == before + 1 and native.calls[-1]["kind"] == "descriptor", "explicit_does_not_reenumerate_" + str(used))
    with engine._profile_measurement_scope():
        if used:
            r1(a144, tactic=tactics[0])
            check(True, "profile_accepts_native_used_descriptor_fixture1")
        else:
            try:
                r1(a144, tactic=tactics[0])
            except RuntimeError:
                check(True, "profile_rejects_native_fallback_fixture0")
            else:
                raise AssertionError("profile silently accepted fallback")
native.used = 1

tuner = api.AutoTuner.get()
config = namespace["_FP8_GEMM_SM100_TUNING_CONFIG"]
shape = tuple(tuple(tensor.shape) for tensor in a144)
key = tuner._get_cache_key("fp8_gemm", r1, shape, config, r1.get_cache_key_extras(a144))
tuner._winner_cache()[key] = (3, None)
check(tuner.search_cache("fp8_gemm", [r1], shape, config, inputs=a144)[0] is False,
      "actual_current_tuner_rejects_old_ordinal_memory_tactic")
tuner._winner_cache()[key] = (tactics[0], None)
check(tuner.search_cache("fp8_gemm", [r2], shape, config, inputs=a144)[0] is True,
      "actual_current_tuner_accepts_descriptor_across_runner_instances")
before = len(native.calls)
output = namespace["bmm_fp8"](a144[0], a144[1], a144[2], a144[3], a144[4].dtype, out=a144[4], backend="cublas")
check(output is a144[4] and native.calls[-1]["kind"] == "descriptor" and len(native.calls) == before + 1,
      "actual_public_BMM_body_and_dispatch_consume_current_tuner_descriptor")
torch.testing.assert_close(output.float(), a144[0].float() @ a144[1].float() * a144[2] * a144[3], rtol=0, atol=0)
check(True, "public_body_fixture_output_matches_CPU_reference")
check(sha(ROOT / "fp8-candidate/flashinfer/autotuner/autotuner.py") == tuner_sources["flashinfer/autotuner/autotuner.py"]["sha256"],
      "ported_candidate_keeps_entire_current_tuner_byte_identical")

result = {
    "status": "success", "base_commit": "27c62fdf0ab1cd4014df8a15b66a975541fda83c",
    "script_sha256": sha(Path(__file__)), "ported_gemm_sha256": sha(SOURCE),
    "torch": torch.__version__, "numpy": numpy.__version__, "cuda_available": torch.cuda.is_available(),
    "checks_passed": len(checks), "checks": checks, "extracted_actual_functions": extracted,
    "whole_current_tuner_sources": tuner_sources, "native_boundary_calls": native.calls,
    "boundaries": [
        "Exact ported descriptor helper, get_gemm_module, runner, FP8 dispatch and public BMM body source nodes are executed without changing function bodies.",
        "Whole unchanged current tuner/cache/protocol modules are imported from hash-checked official sources through the retained GPU import shells.",
        "Public BMM admission/logging decorators are omitted for CPU-only execution; this does not qualify actual decorated public CUDA execution.",
        "Custom-op registration and JIT native loading are explicit CPU fixtures. Native descriptor acceptance0/1 and CPU output writes are fixtures, not cuBLASLt results.",
        "Actual CPU Torch tensors and pinned NumPy2.3.4 implement descriptor byte conversion. GPU timing and native CUDA compilation are not executed.",
        "Real current bucket-generator/map source is extracted unchanged; its pure next-positive-power-of-two import is supplied by the retained fixture.",
    ],
    "limits": ["No CUDA compilation, real AlgoCheck, native descriptor-use, graph capture/replay or serving evidence.",
               "No disk persistence roundtrip or multi-device/native-cache lifetime qualification.",
               "This source-level proof does not replace explicit JitSpec.build/load and decorated public BMM CUDA qualification."],
}
(ROOT / "cpu-contract-result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"status": "success", "checks": len(checks), "result_sha256": sha(ROOT / "cpu-contract-result.json")}, indent=2))
