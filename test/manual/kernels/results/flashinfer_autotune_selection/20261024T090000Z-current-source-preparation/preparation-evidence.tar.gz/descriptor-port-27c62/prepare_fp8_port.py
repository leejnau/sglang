#!/usr/bin/env python3
"""Prepare FP8-only descriptor runtime changes on the pinned current base."""

import ast
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
BASE = ROOT / "baseline"
APPLIED_ORIGINAL = ROOT / "full-original-reject-attempt"
TARGET = ROOT / "fp8-candidate"
NATIVE = ("csrc/bmm_fp8.cu", "csrc/flashinfer_gemm_binding.cu", "include/flashinfer/gemm/bmm_fp8.cuh")
GEMM = "flashinfer/gemm/gemm_base.py"
HELPERS = (
    "_cublaslt_algos_to_tactics", "_is_cublaslt_algo_tactic", "_cublaslt_algo_tensor",
    "_cublaslt_algo_arg", "_check_cublaslt_descriptor_ran",
)


def sha(content):
    return hashlib.sha256(content).hexdigest()


def function(source, name):
    tree = ast.parse(source)
    node = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)
    lines = source.splitlines(True)
    first = min([node.lineno] + [d.lineno for d in node.decorator_list]) - 1
    return "".join(lines[first:node.end_lineno])


source_manifest = json.loads((ROOT / "source-manifest.json").read_text())
for row in source_manifest["files"]:
    assert sha((BASE / row["path"]).read_bytes()) == row["sha256"]
base = (BASE / GEMM).read_text()
applied = (APPLIED_ORIGINAL / GEMM).read_text()
text = base
old_import, new_import = "import os\nimport warnings\n", "import os\nimport struct\nimport warnings\n"
assert text.count(old_import) == 1
text = text.replace(old_import, new_import)
old_symbol, new_symbol = "    TuningConfig,\n)", "    TuningConfig,\n    is_in_profile_measurement,\n)"
assert text.count(old_symbol) == 1
text = text.replace(old_symbol, new_symbol)
first = applied.index('_CUBLASLT_ALGO_FORMAT = "8Q"')
last = applied.index("# Error messages", first)
addition = applied[first:last]
anchor = "_CUBLASLT_MAX_ALGOS = 100\n\n"
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + addition)
old_function = function(base, "get_gemm_module")
new_function = function(applied, "get_gemm_module")
assert text.count(old_function) == 1
text = text.replace(old_function, new_function)
compile(text, GEMM, "exec")

# Machine-check that every unrelated current-main Python AST node survives.
tree, old_tree = ast.parse(text), ast.parse(base)
tree.body = [node for node in tree.body if not (
    isinstance(node, ast.FunctionDef) and node.name in HELPERS
) and not (
    isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == "_CUBLASLT_ALGO_FORMAT" for target in node.targets)
) and not (
    isinstance(node, ast.Import) and len(node.names) == 1 and node.names[0].name == "struct"
)]
for index, node in enumerate(tree.body):
    if isinstance(node, ast.ImportFrom) and node.module == "autotuner":
        node.names = [name for name in node.names if name.name != "is_in_profile_measurement"]
    if isinstance(node, ast.FunctionDef) and node.name == "get_gemm_module":
        tree.body[index] = next(node for node in old_tree.body if isinstance(node, ast.FunctionDef) and node.name == "get_gemm_module")
assert ast.dump(tree) == ast.dump(old_tree), "unrelated current-main code changed"

shutil.copytree(BASE, TARGET)
(TARGET / GEMM).write_text(text)
for name in NATIVE:
    shutil.copyfile(APPLIED_ORIGINAL / name, TARGET / name)

changes = []
patches = []
for row in source_manifest["files"]:
    name = row["path"]
    before, after = (BASE / name).read_bytes(), (TARGET / name).read_bytes()
    changes.append({"path": name, "base_sha256": sha(before), "candidate_sha256": sha(after),
                    "base_size_bytes": len(before), "candidate_size_bytes": len(after), "changed": before != after})
    if before != after:
        patches.append("".join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), "a/" + name, "b/" + name)))
assert {row["path"] for row in changes if row["changed"]} == {GEMM, *NATIVE}
patch = "".join(patches)
patch_path = ROOT / "fp8-current-main.patch"
patch_path.write_text(patch)
check = subprocess.run(["git", "apply", "--check", str(patch_path)], cwd=BASE, text=True, capture_output=True)
assert check.returncode == 0, check.stderr
verification = ROOT / "apply-verification"
shutil.copytree(BASE, verification)
applied = subprocess.run(["git", "apply", str(patch_path)], cwd=verification, text=True, capture_output=True)
assert applied.returncode == 0, applied.stderr
assert all((verification / row["path"]).read_bytes() == (TARGET / row["path"]).read_bytes() for row in changes)
lines = patch.splitlines()
result = {
    "status": "FP8_only_source_port_prepared",
    "base_commit": source_manifest["commit"],
    "original_diff_sha256": sha((ROOT / "original-6148.diff").read_bytes()),
    "original_full_diff_clean_apply": False,
    "original_reject_reason": "Only first gemm_base import hunk rejects: current main inserted weakref. All remaining original hunks apply cleanly with offsets.",
    "port_scope": "Original6148 FP8 native implementation, descriptor helpers and FP8 runner only; preserve current-main imports/features and leave BF16, tuner/doc, persistence, distributed guard and original test files unchanged.",
    "source_derivation": "Extract exact helper and get_gemm_module source from the successful original hunks on current main, preserving decorators; add struct/profile-marker imports around current weakref import.",
    "unchanged_outside_FP8_AST": True,
    "git_apply_check_exit_code": check.returncode,
    "git_apply_result_exit_code": applied.returncode,
    "applied_result_byte_equal_to_candidate": True,
    "python_compile_passed": True,
    "patch_sha256": sha(patch.encode()),
    "patch_lines_added": sum(line.startswith("+") and not line.startswith("+++") for line in lines),
    "patch_lines_removed": sum(line.startswith("-") and not line.startswith("---") for line in lines),
    "files": changes,
    "limits": ["Source preparation only; no CUDA compilation or execution yet.", "No upstream production checkout or SGLang source changed.", "No integration of the separate configured-timer guard."],
}
(ROOT / "port-manifest.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({key: result[key] for key in ("status", "patch_sha256", "patch_lines_added", "patch_lines_removed", "applied_result_byte_equal_to_candidate")}, indent=2))
