"""CPU regression controls for a scratch-only official harness callback patch.

Real full AutoTuner/cache/policy and both whole benchmark modules execute.
Only GPU imports/capture/events and profiling times are controlled. No CUDA
kernel, timing, descriptor acceptance or production SGLang call is established.
"""

from __future__ import annotations

import contextlib
import hashlib
import importlib
import importlib.util
import io
import json
import logging
import math
import os
import sys
import tempfile
import types
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
SOURCE = Path("/private/tmp/fi-next-steps-20261024/upstream/flashinfer-main")
BASELINE = Path(
    "/private/tmp/fi-next-steps-20261024/measurement-source/benchmarks/bench_autotuner_accuracy.py"
)
CANDIDATE = HERE / "benchmarks/bench_autotuner_accuracy.py"
checks = []


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check(condition, label):
    if not condition:
        raise AssertionError(label)
    checks.append(label)


def package(name, path):
    module = types.ModuleType(name)
    module.__path__ = [str(path)]
    sys.modules[name] = module
    return module


def unavailable(*args, **kwargs):
    raise AssertionError("unexpected GPU-only import boundary")


os.environ["FLASHINFER_AUTOTUNER_LOAD_FROM_FILE"] = "0"
os.environ["FLASHINFER_AUTOTUNE_TIMER"] = "cuda_event"
fi = package("flashinfer", SOURCE / "flashinfer")
package("flashinfer.jit", SOURCE / "flashinfer/jit")
core = types.ModuleType("flashinfer.jit.core")
core.logger = logging.getLogger("fixture-callback-controls")
sys.modules[core.__name__] = core
utils = types.ModuleType("flashinfer.utils")
utils.next_positive_power_of_2 = lambda n: 1 << (n - 1).bit_length()
utils.is_confidential_compute = lambda: False
utils.get_globaltimer_kernel = unavailable
sys.modules[utils.__name__] = utils
tllm = types.ModuleType("flashinfer.tllm_utils")
tllm.delay_kernel = unavailable
tllm.get_trtllm_utils_module = unavailable
sys.modules[tllm.__name__] = tllm
package("tests", SOURCE / "tests")
fp8 = types.ModuleType("tests.utils_fp8")
fp8.to_float8 = unavailable
sys.modules[fp8.__name__] = fp8
import torch  # noqa: E402

api = importlib.import_module("flashinfer.autotuner")
fi.__version__ = importlib.import_module("flashinfer.version").__version__


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


baseline, candidate = (
    load(BASELINE, "baseline_harness"),
    load(CANDIDATE, "callback_harness"),
)
check(
    sha(BASELINE) == "7947647d266ec6a837bedd8e9c87d7d4dcbb4683bb9d16fef4b2d01c3f43b0dd",
    "original official harness source remains unchanged",
)
state = SimpleNamespace(active=None, clock=0, log=[], sampled=False, captures=[])


class Graph:
    def __init__(self):
        self.actions, self.tactics = [], []

    def replay(self):
        state.log.append(("replay", tuple(self.tactics)))
        for action in self.actions:
            action()
        state.clock += 1


@contextlib.contextmanager
def capture(graph):
    if state.active is not None:
        raise AssertionError("nested GPU boundary stub")
    state.active = graph
    try:
        yield
    finally:
        state.active = None
        state.captures.append(graph)


class Event:
    def __init__(self, **kwargs):
        self.value = None

    def record(self):
        self.value = state.clock

    def synchronize(self):
        pass

    def elapsed_time(self, other):
        return float(other.value - self.value)


def controlled_profile(self, runner, inputs, tactic, config, **kwargs):
    return 1.0 if tactic == 0 else 2.0


def reset():
    state.active, state.clock, state.log = None, 0, []
    state.sampled, state.captures = False, []


def problem(kind):
    output = torch.empty(4)
    inputs = [
        torch.ones(4),
        torch.ones(4),
        torch.ones(1),
        torch.ones(1),
        output,
        torch.empty(8, dtype=torch.uint8),
    ]

    class Runner(api.TunableRunner):
        def get_valid_tactics(self, inputs, profile):
            return [0]

        def forward(self, inputs, tactic=-1, **kwargs):
            def action():
                if tactic == -1 or kind == "correct":
                    torch.add(inputs[0], 1, out=output)
                elif kind == "wrong":
                    torch.add(inputs[0], 2, out=output)
                # Explicit no-write deliberately leaves shared output unchanged.

            if state.active is not None:
                state.active.actions.append(action)
                state.active.tactics.append(tactic)
            else:
                action()
            return output

    return Runner(), inputs


ARGS = SimpleNamespace(
    cold_l2=None,
    profile_inputs="retained",
    seeds=1,
    graph_policies=["auto"],
    seed=19,
    warmup=1,
    tuner_repeat=2,
    oracle_rounds=3,
    validation_replays=2,
    prequeue_cycles=1,
    rtol=0,
    atol=0,
)


def run_case(module, kind, callback):
    reset()
    runner, inputs = problem(kind)
    previous = api.AutoTuner._instance
    numerical, refreshes = [], []
    original_assert, sample = (
        torch.testing.assert_close,
        module.interleaved_graph_samples,
    )

    def sampled(*args, **kwargs):
        values = sample(*args, **kwargs)
        state.sampled = True
        state.log.append(("sampling_finished",))
        return values

    def refresh(output, actual_inputs):
        check(
            state.sampled and state.active is None,
            "refresh only after timing and outside capture",
        )
        check(
            actual_inputs is inputs and output is inputs[4],
            "refresh receives original output and retained inputs",
        )
        reads = [tensor.clone() for tensor in inputs[:4]]
        module.prepare_fp8_validation(output, actual_inputs)
        check(
            all(torch.equal(a, b) for a, b in zip(reads, inputs[:4])),
            "refresh preserves declared read operands",
        )
        refreshes.append(output.data_ptr())
        state.log.append(("refresh",))

    def assert_close(actual, expected, **kwargs):
        numerical.append(
            {
                "actual": [
                    value if math.isfinite(value) else str(value)
                    for value in actual.tolist()
                ],
                "expected": expected.tolist(),
            }
        )
        return original_assert(actual, expected, **kwargs)

    with (
        patch.object(module, "interleaved_graph_samples", sampled),
        patch.object(module, "sm_clock_mhz", lambda: None),
        patch.object(torch.testing, "assert_close", assert_close),
    ):
        try:
            kwargs = {"prepare_validation": refresh} if callback else {}
            report = module.graph_selection_study(
                "test.fixture_callback",
                [runner],
                api.TuningConfig(),
                inputs,
                {},
                ARGS,
                **kwargs,
            )
        except AssertionError as error:
            row = {"accepted": False, "error": str(error).splitlines()[0]}
        else:
            trial = report["trials"][0]
            row = {
                "accepted": True,
                "winner": trial["tactic"],
                "cache_hit": trial["cache_hit"],
                "profiles": trial["profile_count"],
                "output_refresh": report["validation"].get(
                    "output_refresh", "not_reported"
                ),
            }
    check(
        api.AutoTuner._instance is previous, "real singleton restored after graph study"
    )
    if callback:
        for index, event in enumerate(state.log):
            if event == ("refresh",):
                check(
                    state.log[index + 1][0] == "replay",
                    "each refresh immediately precedes independent replay",
                )
        check(
            len(refreshes) == (3 if kind == "correct" else 2),
            "exact final validation callback count",
        )
    row.update(
        kind=kind,
        callback=callback,
        numeric_assertions=numerical,
        final_refreshes=len(refreshes),
        original_shared_output_ptr=inputs[4].data_ptr(),
        capture_tactics=[graph.tactics for graph in state.captures],
    )
    return row


with contextlib.ExitStack() as boundaries:
    for name, value in [
        ("CUDAGraph", Graph),
        ("graph", capture),
        ("Event", Event),
        ("synchronize", lambda: None),
        ("_sleep", lambda _: None),
        ("is_current_stream_capturing", lambda: state.active is not None),
        ("get_device_name", lambda: "CPU boundary control; no CUDA device"),
    ]:
        boundaries.enter_context(patch.object(torch.cuda, name, value))
    boundaries.enter_context(
        patch.object(api.AutoTuner, "_profile_single_kernel", controlled_profile)
    )
    before = [
        run_case(baseline, kind, False) for kind in ("correct", "wrong", "no_write")
    ]
    compatible = [
        run_case(candidate, kind, False) for kind in ("correct", "wrong", "no_write")
    ]
    after = [
        run_case(candidate, kind, True) for kind in ("correct", "wrong", "no_write")
    ]
    check(
        [row["accepted"] for row in before] == [True, False, True],
        "original source reproduces shared-output no-write gap",
    )
    check(
        [row["accepted"] for row in compatible] == [True, False, True],
        "no-callback callers retain original behavior",
    )
    check(
        all(
            row.get("output_refresh", "unavailable") == "unavailable"
            for row in compatible
        ),
        "no-callback refresh coverage explicitly unavailable",
    )
    check(
        [row["accepted"] for row in after] == [True, False, False],
        "callback passes correct and rejects destructive-wrong and no-write",
    )
    check(
        after[0]["winner"] == "0"
        and after[0]["cache_hit"]
        and after[0]["profiles"] == 2
        and after[0]["output_refresh"] == "fixture_callback",
        "actual selected explicit cache winner and enabled coverage",
    )

# Built-in FP8 opts in explicitly; its construction runs at the GPU boundary only.
original_randn = torch.randn
with (
    patch.object(
        torch,
        "randn",
        lambda *shape, **kwargs: original_randn(*shape, dtype=kwargs["dtype"]),
    ),
    patch.object(
        candidate,
        "to_float8",
        lambda tensor: (tensor.to(torch.float8_e4m3fn), torch.ones(1)),
    ),
):
    builtin = candidate.build_bmm_fp8(4, 4, 4)
check(
    builtin.prepare_validation is candidate.prepare_fp8_validation,
    "built-in FP8 fixture explicitly declares the refresh callback",
)
check(
    callable(builtin.reference),
    "built-in FP8 fixture retains its existing reference API",
)

# All alias/type checks precede mutation, including partial storage aliases.
role_cases = []
for kind in (
    "read_alias",
    "partial_read_alias",
    "scratch_alias",
    "integer",
    "wrong_role",
    "strided_output",
):
    output = torch.ones(4, dtype=torch.int64 if kind == "integer" else torch.float32)
    inputs = [
        torch.ones(4),
        torch.ones(4),
        torch.ones(1),
        torch.ones(1),
        output,
        torch.empty(8, dtype=torch.uint8),
    ]
    if kind == "read_alias":
        inputs[0] = output
    elif kind == "partial_read_alias":
        inputs[0] = output[1:]
    elif kind == "scratch_alias":
        inputs[5] = output
    elif kind == "wrong_role":
        inputs[4] = torch.ones_like(output)
    elif kind == "strided_output":
        output = torch.ones(8)[::2]
        inputs[4] = output
    previous = output.clone()
    try:
        candidate.prepare_fp8_validation(output, inputs)
    except ValueError as error:
        role_cases.append({"kind": kind, "error": str(error)})
    else:
        raise AssertionError("unsafe callback admitted: " + kind)
    check(
        torch.equal(output, previous),
        kind + " rejected before any output/read mutation",
    )
output = torch.ones(4)
inputs = [
    torch.ones(4),
    torch.ones(4),
    torch.ones(1),
    torch.ones(1),
    output,
    torch.empty(8, dtype=torch.uint8),
]
reads = [tensor.clone() for tensor in inputs[:4]]
candidate.prepare_fp8_validation(output.view(2, 2), inputs)
check(
    bool(torch.isnan(output).all())
    and all(torch.equal(a, b) for a, b in zip(reads, inputs[:4])),
    "contiguous output view sharing declared output role is admitted safely",
)
try:
    candidate.graph_selection_study(
        "test", [], api.TuningConfig(), [], {}, ARGS, prepare_validation=object()
    )
except TypeError:
    check(True, "noncallable hook rejected before capture/tuning")
else:
    raise AssertionError("noncallable callback accepted")

# Exercise real main() fixture plumbing, including unchanged old fixture objects.
main_rows = []
for enabled in (False, True):
    reset()
    runner, inputs = problem("correct")
    factory = types.ModuleType("fixture_callback_cpu")
    callback_calls = []

    def build(args):
        def call():
            chosen, tactic = api.AutoTuner.get().choose_one(
                "test.main_callback", [runner], api.TuningConfig(), inputs
            )
            return chosen(inputs, tactic=tactic)

        if enabled:

            def prepare(output, actual_inputs):
                callback_calls.append(output.data_ptr())
                candidate.prepare_fp8_validation(output, actual_inputs)

            call.prepare_validation = prepare
        return call

    factory.build = build
    with (
        tempfile.TemporaryDirectory() as directory,
        contextlib.ExitStack() as boundaries,
    ):
        out = Path(directory) / "report.json"
        boundaries.enter_context(
            patch.dict(sys.modules, {"fixture_callback_cpu": factory})
        )
        boundaries.enter_context(
            patch.object(
                sys,
                "argv",
                [
                    "harness",
                    "--graph-selection-study",
                    "--fixture",
                    "fixture_callback_cpu:build",
                    "--graph-policies",
                    "auto",
                    "--profile-inputs",
                    "retained",
                    "--seeds",
                    "1",
                    "--seed",
                    "19",
                    "--warmup",
                    "1",
                    "--tuner-repeat",
                    "2",
                    "--oracle-rounds",
                    "3",
                    "--validation-replays",
                    "2",
                    "--prequeue-cycles",
                    "1",
                    "--rtol",
                    "0",
                    "--atol",
                    "0",
                    "--out",
                    str(out),
                ],
            )
        )
        for name, value in [
            ("CUDAGraph", Graph),
            ("graph", capture),
            ("Event", Event),
            ("synchronize", lambda: None),
            ("_sleep", lambda _: None),
            ("is_current_stream_capturing", lambda: state.active is not None),
            ("get_device_name", lambda: "CPU boundary control; no CUDA device"),
        ]:
            boundaries.enter_context(patch.object(torch.cuda, name, value))
        boundaries.enter_context(
            patch.object(api.AutoTuner, "_profile_single_kernel", controlled_profile)
        )
        boundaries.enter_context(patch.object(candidate, "sm_clock_mhz", lambda: None))
        with (
            contextlib.redirect_stdout(io.StringIO()),
            contextlib.redirect_stderr(io.StringIO()),
        ):
            candidate.main()
        report = json.loads(out.read_text())
        check(
            report["validation"]["output_refresh"]
            == ("fixture_callback" if enabled else "unavailable"),
            "real main forwards optional hook and reports coverage",
        )
        check(
            len(callback_calls) == (3 if enabled else 0),
            "real main calls callback only for opted-in fixture",
        )
        main_rows.append(
            {
                "enabled": enabled,
                "callback_calls": len(callback_calls),
                "coverage": report["validation"]["output_refresh"],
            }
        )

sources = [
    Path(__file__),
    BASELINE,
    CANDIDATE,
    *[
        SOURCE / "flashinfer" / name
        for name in [
            "autotuner/autotuner.py",
            "autotuner/__init__.py",
            "autotuner/protocol.py",
            "autotune_cache.py",
            "tactics_blocklist.py",
        ]
    ],
]
report = {
    "status": "success",
    "checks": len(checks),
    "passed_checks": checks,
    "source_sha256": {str(path): sha(path) for path in sources},
    "torch": torch.__version__,
    "baseline": before,
    "candidate_no_callback": compatible,
    "candidate_with_callback": after,
    "unsafe_roles": role_cases,
    "real_main_cases": main_rows,
    "boundaries": [
        "Whole pinned benchmark modules, production AutoTuner.choose_one/cache/policy and actual CPU Tensor writes/assertions execute.",
        "GPU-only imports, CUDA capture/events/streams and measured profiling times are controlled; no CUDA kernel, device timing, native descriptor or production SGLang accuracy claim.",
        "The optional callback is invoked outside all sampled/captured windows; generic callers without ownership remain unchanged and report unavailable coverage.",
    ],
    "pending": [
        "CUDA execution of focused upstream-style regressions",
        "Current-source descriptor port and native build/acceptance qualification",
    ],
}
path = HERE / "cpu-controls.json"
path.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
print(json.dumps({"status": "success", "checks": len(checks), "report": str(path)}))
