"""Publish bounded CPU/source preparation evidence without dependency source trees."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path


DEFAULT_SOURCE = Path("/private/tmp/fi-next-steps-20261024")
DEFAULT_OUTPUT = Path(
    "/private/tmp/sglang-autotune-selection-study/test/manual/kernels/results/"
    "flashinfer_autotune_selection/20261024T090000Z-current-source-preparation"
)
TOKEN = bytes([118, 108, 108, 109])
GROUPS = {
    "upstream/configured-timer-guard": [
        "readiness-report.json",
        "candidate-manifest.json",
        "configured-timer-guard.patch",
        "run_regression.py",
        "prepare_candidate.py",
        "baseline-attempt01/result.json",
        "baseline-attempt01/rank0.json",
        "baseline-attempt01/rank1.json",
        "baseline-attempt01/exit-codes.json",
        "candidate-attempt01/result.json",
        "candidate-attempt01/rank0.json",
        "candidate-attempt01/rank1.json",
        "candidate-attempt01/exit-codes.json",
    ],
    "descriptor-port-27c62": [
        "port-manifest.json",
        "source-manifest.json",
        "reference-source-manifest.json",
        "readiness-report.json",
        "fp8-current-main.patch",
        "prepare_fp8_port.py",
        "check_fp8_port.py",
        "cpu-contract-result.json",
        "original-apply-check.json",
    ],
    "fixture-validation-callback": [
        "proposed.patch",
        "harness-only.patch",
        "adapter-integration.patch",
        "check_callback.py",
        "cpu-controls.json",
        "proposal.json",
    ],
    "fixture-adapter": [
        "sglang_captured_fixture.py",
        "adapter-contract.json",
        "check_adapter.py",
        "cpu-controls.json",
        "prepare_validation_proposal.py",
        "qualification-plan.json",
    ],
    "activation-values-design": [
        "design.json",
        "prove_profile_invariance.py",
        "cpu-proof.json",
        "synthetic_matched_copy.json",
        "captured_m144.json",
    ],
    "review-public": [
        "reproduce_no_write_roles.py",
        "portable-no-write-result.json",
        "fixture-adapter-review.json",
    ],
    "routing-source": [
        "routing-review.json",
        "manifest.json",
        "additional-manifest.json",
        "additional-manifest-2.json",
        "additional-manifest-3.json",
    ],
}
EXTRAS = [
    "upstream/prove_distributed_objective_guard.py",
    "review-public/distributed-proof-result.json",
    "review-public/distributed-objective-guard-proof.json",
    "current-source-coordinator/test_output_refresh.py",
    "selection-audit/check_cuda_callback_script_cpu.py",
    "selection-audit/cuda-callback-script-cpu-admission.json",
]


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (
        json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n"
    ).encode()


def load(root, relative):
    return json.loads((root / relative).read_bytes())


def safe_bytes(data, label):
    if TOKEN in data.lower():
        raise AssertionError(f"Disallowed project token in {label}")


def source_member(root, relative):
    path = root / relative
    assert path.is_file() and not path.is_symlink(), relative
    assert path.suffix in {".json", ".py", ".patch"}, relative
    data = path.read_bytes()
    safe_bytes(data, relative)
    return data


def sanitized_upstream(root):
    name = "review-public/upstream-review.json"
    review = load(root, name)
    fields = (
        "number",
        "state",
        "merged",
        "merged_at",
        "merge_commit_sha",
        "html_url",
        "head_sha",
    )
    return {
        "status": "Historical pinned public metadata; no refresh performed during packaging.",
        "observed_at_utc": review["reviewed_at_utc"],
        "source_report": {
            "relative_path": name,
            "sha256": digest((root / name).read_bytes()),
        },
        "pins": review["pins"],
        "pull_requests": {
            number: {key: row[key] for key in fields}
            for number, row in review["pull_requests"].items()
        },
        "release_boundary": review["release_boundary"],
        "conclusions": [
            "The reviewed current main contains the scoped-cache ownership, replay-coverage, distributed-phase and selection-study APIs. The earlier private scoped prototype stays parked.",
            "The reviewed stable tag lacks those newer APIs; source qualification does not authorize changing SGLang's dependency or policy.",
            "The descriptor change remains an open upstream proposal at the recorded head. A separately reviewed FP8-only source port is prepared, not a claim that the original diff applies cleanly.",
            "Delay-helper initialization is fixed upstream; this alone does not identify the cause of the earlier fixed-provider selection failures.",
        ],
        "excluded": "Raw PR titles, bodies, private conversations and whole upstream source files are not copied.",
    }


def status(root, members):
    timer = load(root, "upstream/configured-timer-guard/readiness-report.json")
    port = load(root, "descriptor-port-27c62/cpu-contract-result.json")
    callback = load(root, "fixture-validation-callback/cpu-controls.json")
    adapter = load(root, "fixture-adapter/cpu-controls.json")
    values = load(root, "activation-values-design/cpu-proof.json")
    no_write = load(root, "review-public/portable-no-write-result.json")
    assert [row["accepted"] for row in no_write["cases"]] == [
        True,
        False,
        True,
        True,
        False,
        False,
    ]
    assert callback["checks"] == 60 and adapter["controls"] == 38
    assert values["controls"] == 216 and port["checks_passed"] == 36
    for phase in ("baseline", "candidate"):
        assert timer[phase]["cases"] == 20
    return {
        "schema_version": 1,
        "status": "CPU and source preparation complete; current-source CUDA qualification is separate.",
        "scope": "Manual research evidence only. No production change, GPU execution, CI trigger, commit, push or PR was performed by this packaging task.",
        "flashinfer_base_commit": timer["base_commit"],
        "components": {
            "configured_timer_guard": {
                "status": "Scratch candidate with actual two-process CPU Gloo agreement.",
                "baseline": timer["baseline"],
                "candidate": timer["candidate"],
                "new_coherent_rejections": len(
                    timer["new_coherent_rejections_before_profiles_or_runner_calls"]
                ),
                "retained_accepted_cases": len(timer["retained_acceptance"]),
                "patch_sha256": timer["patch_sha256"],
                "limits": timer["limits"],
            },
            "no_write_proof": {
                "cases": len(no_write["cases"]),
                "before_correct_wrong_no_write": [True, False, True],
                "role_refresh_correct_wrong_no_write": [True, False, False],
                "role_controls": len(no_write["role_controls"]),
                "boundary": "Full unchanged harness/tuner with real CPU tensor writes; controlled GPU boundaries and times. This proves a validation gap, not an actual backend defect.",
            },
            "fixture_validation_callback": {
                "cpu_controls": callback["checks"],
                "status": callback["status"],
                "boundary": "Optional fixture-owned output refresh after timing and before final replays. Declared floating output ownership and storage disjointness are validated before mutation; generic/in-place/integer fixtures stay unchanged.",
                "cuda_regressions": "Prepared; not executed in this CPU/source preparation package.",
            },
            "fp8_descriptor_port": {
                "cpu_controls": port["checks_passed"],
                "status": port["status"],
                "original_diff_clean_apply": False,
                "changed_files": 4,
                "boundary": "Actual extracted ported Python bodies and unchanged full tuner/cache with native acceptance fixtures. CUDA build, actual decorated facade, AlgoCheck and descriptor execution are not qualified here.",
            },
            "captured_fixture_adapter": {
                "cpu_controls": adapter["controls"],
                "status": adapter["status"],
                "original_adapter_refresh_enabled": False,
                "boundary": "Actual official capture hook and real tuner paths on CPU with disclosed import/kernel stand-ins. Separate integration patch is proposed; GPU execution remains a distinct gate.",
            },
            "activation_values_design": {
                "cpu_controls": values["controls"],
                "status": values["status"],
                "boundary": "Preserves nine profiles, runtime bucket256, keys and random draws while replacing only exact M144 activation values through the existing initializer contract. Physical GPU preparation history and performance remain unqualified.",
            },
            "routing_and_upstream_status": {
                "status": "Pinned public source review only.",
                "recommendation": "Keep production policy changes separate. Any report-only replay-coverage integration requires a supported released dependency containing that API and actual release validation.",
            },
        },
        "archive_member_count": len(members),
        "reproduction": {
            "layout": "Archive paths retain the scratch-relative layout. Scripts preserve original source hashes and local defaults; use recorded source revisions/manifests and relocate paths explicitly when reproducing.",
            "dependencies": "Fetch exact public upstream revisions separately. Full dependency source trees, private fixture tensors, native binaries and environment packages are intentionally omitted. Torch and NumPy versions are recorded per proof.",
            "evidence": "Selected scripts, patches and final reports are exact original bytes. Only the explicitly derived upstream-status JSON is reconstructed from allowed public fields.",
            "counts": "Control counts belong to their individual proofs and overlap; they are not summed as independent tests.",
        },
        "limits": [
            "This package contains no new GPU measurements or serving-performance claim.",
            "Current-source CUDA/native/adapter qualification is forthcoming in a separate batch and is not inferred from CPU admissions.",
            "No scoped-cache production rollout, general v1 persistence migration, model matrix or distributed GPU qualification is approved by these proofs.",
        ],
    }


def desired_members(root):
    names = [
        str(Path(group) / name) for group, items in GROUPS.items() for name in items
    ] + EXTRAS
    members = {name: source_member(root, name) for name in names}
    self_name = "coordinator/package_preparation_results.py"
    members[self_name] = Path(__file__).read_bytes()
    members["derived/upstream-status.json"] = encoded(sanitized_upstream(root))
    for name, data in members.items():
        safe_bytes(data, name)
    return members


def verify_proof_sources(root):
    checks = 0
    for relative in (
        "fixture-adapter/cpu-controls.json",
        "fixture-validation-callback/cpu-controls.json",
    ):
        for path, expected in load(root, relative)["source_sha256"].items():
            assert digest(Path(path).read_bytes()) == expected, path
            checks += 1
    values = load(root, "activation-values-design/cpu-proof.json")["source"]
    for key, relative in (
        ("proof_sha256", "activation-values-design/prove_profile_invariance.py"),
        ("loader_sha256", "fixture-adapter/check_adapter.py"),
    ):
        assert digest((root / relative).read_bytes()) == values[key], relative
        checks += 1
    timer = load(root, "upstream/configured-timer-guard/readiness-report.json")
    for variant in ("baseline", "candidate"):
        relative = f"upstream/configured-timer-guard/{variant}-attempt01/result.json"
        assert digest((root / relative).read_bytes()) == timer[variant]["result_sha256"]
        checks += 1
    return checks


def write_archive(path, members):
    with (
        path.open("wb") as raw,
        gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0) as zipped,
    ):
        with tarfile.open(fileobj=zipped, mode="w") as archive:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(data))


def verify(root, output, expected):
    checks = verify_proof_sources(root)
    index = load(output, "preparation-evidence-member-index.json")
    with tarfile.open(output / "preparation-evidence.tar.gz", "r:gz") as archive:
        actual = {}
        for member in archive.getmembers():
            assert member.isfile() and not member.issym()
            path = Path(member.name)
            assert not path.is_absolute() and ".." not in path.parts
            data = archive.extractfile(member).read()
            safe_bytes(data, member.name)
            assert member.name not in actual
            actual[member.name] = data
            assert data == expected[member.name]
            assert index["members"][member.name] == {
                "sha256": digest(data),
                "size_bytes": len(data),
            }
            checks += 6
    assert actual == expected
    assert len(actual) == index["member_count"]
    checks += 2
    artifacts = load(output, "artifact-index.json")
    for name, metadata in artifacts["files"].items():
        data = (output / name).read_bytes()
        assert metadata == {"sha256": digest(data), "size_bytes": len(data)}
        checks += 1
    for path in output.iterdir():
        assert path.is_file() and not path.is_symlink()
        safe_bytes(path.read_bytes(), path.name)
        checks += 2
    assert load(output, "status.json") == status(root, expected)
    checks += 1
    return {"status": "success", "checks": checks, "members": len(actual)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--verify-only", action="store_true")
    args = parser.parse_args()
    members = desired_members(args.source_root)
    proof_source_checks = verify_proof_sources(args.source_root)
    if not args.verify_only:
        args.output.mkdir(parents=True, exist_ok=True)
        assert not list(args.output.iterdir()), "Refuse to overwrite existing evidence."
        write_archive(args.output / "preparation-evidence.tar.gz", members)
        index = {
            "schema_version": 1,
            "member_count": len(members),
            "members": {
                name: {"sha256": digest(data), "size_bytes": len(data)}
                for name, data in sorted(members.items())
            },
            "derived_members": ["derived/upstream-status.json"],
            "excluded": [
                "Private fixture tensors",
                "Native binaries",
                "Whole upstream source trees",
                "Raw upstream PR payloads",
                "Private conversation notes",
                "Transient attempts",
            ],
        }
        (args.output / "preparation-evidence-member-index.json").write_bytes(
            encoded(index)
        )
        (args.output / "status.json").write_bytes(
            encoded(status(args.source_root, members))
        )
        validation = {
            "status": "success",
            "scope": "Publication packaging and existing CPU/source evidence; no proof rerun or GPU execution.",
            "member_bytes": "All selected original members are byte-identical; derived upstream metadata is separately identified.",
            "archive_safety": "Only regular .py/.json/.patch members. No model/native binaries or raw dependency source trees.",
            "token_scan": "Case-insensitive required byte-pattern check of every output file and decompressed member passes.",
            "package_source_sha256": digest(Path(__file__).read_bytes()),
            "proof_source_and_timer_result_hash_checks": proof_source_checks,
            "note": "CPU proof counts and limits are taken from the original retained reports, not from packaging assertions.",
        }
        (args.output / "validation.json").write_bytes(encoded(validation))
        files = {
            path.name: {
                "sha256": digest(path.read_bytes()),
                "size_bytes": path.stat().st_size,
            }
            for path in sorted(args.output.iterdir())
        }
        (args.output / "artifact-index.json").write_bytes(
            encoded({"schema_version": 1, "files": files})
        )
    print(json.dumps(verify(args.source_root, args.output, members), sort_keys=True))


if __name__ == "__main__":
    main()
