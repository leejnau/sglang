#!/usr/bin/env python3
"""CPU mechanism proof with exact official tuner/config code and controlled times.

The CUDA facade, native candidate enumeration and latency are not qualified here.
GPU-only import leaves use the disclosed existing admission-control shims.
"""
from __future__ import annotations
import ast
import dataclasses
import hashlib
import json
import os
import struct
import sys
from pathlib import Path
from unittest.mock import patch

HERE = Path(__file__).resolve().parent
ADAPTER = Path('/private/tmp/fi-next-steps-20261024/fixture-adapter')
CURRENT = Path('/private/tmp/fi-next-steps-20261024/upstream/flashinfer-main')
UTIL = Path('/private/tmp/fi-next-steps-20261024/descriptor-port-27c62/reference-sources/flashinfer/fused_moe/utils.py')
FIXTURE = Path('/private/tmp/fi-next-steps-20261024/coordinator/raw/attempt02/fixture')
os.environ['FLASHINFER_AUTOTUNER_LOAD_FROM_FILE'] = '0'
os.environ['FLASHINFER_AUTOTUNE_TIMER'] = 'cuda_event'
sys.path.insert(0, str(ADAPTER))
loader = (ADAPTER/'check_adapter.py').read_text().split('contract = json.loads(', 1)[0]
ns = {'__file__': str(ADAPTER/'check_adapter.py'), '__name__': 'official_cpu_loader'}
exec(compile(loader, str(ADAPTER/'check_adapter.py'), 'exec'), ns)
torch, api, harness = ns['torch'], ns['api'], ns['harness']
from flashinfer.autotuner.initializers import autotuner_initializer_rand_scaled
checks = []
def check(condition, label):
    if not condition: raise AssertionError(label)
    checks.append(label)
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def tsha(t):
    return hashlib.sha256(bytes(t.detach().contiguous().view(torch.uint8).reshape(-1).tolist())).hexdigest()

# Execute exact AST nodes, not a handwritten copy of the config/bucket functions.
utils_ns = {'Tuple': tuple, 'List': list, 'next_positive_power_of_2': lambda n: 1 << (n-1).bit_length()}
util_tree = ast.parse(UTIL.read_text())
keep = []
for node in util_tree.body:
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id.startswith('_PHASE') for t in node.targets): keep.append(node)
    if isinstance(node, ast.FunctionDef) and node.name in ('_ceil_to_step','get_hybrid_num_tokens_buckets','map_to_hybrid_bucket_uncapped'): keep.append(node)
exec(compile(ast.Module(body=keep, type_ignores=[]),str(UTIL),'exec'),utils_ns)
gemm_path = CURRENT/'flashinfer/gemm/gemm_base.py'
gemm_node = next(node for node in ast.parse(gemm_path.read_text()).body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='_FP8_GEMM_SM100_TUNING_CONFIG' for t in node.targets))
gemm_ns = {name:getattr(api,name) for name in ('TuningConfig','DynamicTensorSpec','ConstraintSpec')}
gemm_ns.update({key:utils_ns[key] for key in ('get_hybrid_num_tokens_buckets','map_to_hybrid_bucket_uncapped')})
exec(compile(ast.Module(body=[gemm_node],type_ignores=[]),str(gemm_path),'exec'),gemm_ns)
original = gemm_ns['_FP8_GEMM_SM100_TUNING_CONFIG']
check(original.tensor_initializers == () and original.inputs_pre_hook is None, 'pinned GEMM config has no existing initializer or pre-hook to replace')
check(original.use_cuda_graph is False and original.use_cold_l2_cache is False, 'operation measurement flags remain unchanged')

blob=(FIXTURE/'fixture.safetensors').read_bytes(); size=struct.unpack_from('<Q',blob)[0]
header=json.loads(blob[8:8+size]); payload=blob[8+size:]
dtypes={'BF16':torch.bfloat16,'F8_E4M3':torch.float8_e4m3fn,'F32':torch.float32,'I64':torch.int64}
tensors={}
for name,meta in header.items():
    if name=='__metadata__':continue
    first,last=meta['data_offsets']
    tensors[name]=torch.frombuffer(bytearray(payload[first:last]),dtype=dtypes[meta['dtype']]).clone().reshape(meta['shape'])
manifest=json.loads((FIXTURE/'manifest.json').read_text())
q=(tensors['input_bf16'].float()*tensors['input_scale'].reciprocal()).clamp(-448,448).to(torch.float8_e4m3fn).unsqueeze(0)
check(tsha(q)==manifest['quantization']['independent_input_fp8_sha256'],'CPU quantized actual activation bytes match immutable manifest')
inputs=[q,tensors['weight_fp8_rowmajor'].t().unsqueeze(0),tensors['input_scale'],tensors['weight_scale'],torch.empty((1,144,4096),dtype=torch.bfloat16),torch.empty(1024,dtype=torch.uint8)]
original_read_hashes=[tsha(t) for t in inputs[:4]]

class ControlledRunner(api.TunableRunner):
    def get_cache_key_extras(self, values): return (values[0].dtype,values[1].dtype,values[4].dtype)
    def get_valid_tactics(self, values, profile):
        self.events_cache.append((values[0].shape[-2],[0,1]))
        return [0,1]
    def forward(self, inputs, tactic=-1, **kwargs):
        inputs[4].fill_(1)
        return inputs[4]

runner=ControlledRunner(); runner.events_cache=[]
pool=[runner]

def make_config(arm, initializer_calls):
    def initialize(shapes,dtype,device):
        # Always consume the identical default RNG draw before the intervention.
        generated=autotuner_initializer_rand_scaled(shapes,dtype,device)
        row={'shape':list(shapes),'generated_sha256':tsha(generated),'targeted':shapes==tuple(q.shape)}
        if shapes==tuple(q.shape):
            if dtype!=q.dtype or device!=q.device or not generated.is_contiguous(): raise ValueError('actual activation contract changed')
            # Same clone and in-place copy in both arms. Nothing is retained.
            shadow=generated.clone()
            generated.copy_(q if arm=='captured_m144' else shadow)
        row['returned_sha256']=tsha(generated)
        initializer_calls.append(row)
        return generated
    return dataclasses.replace(original,tensor_initializers=((0,initialize),))

def run(arm):
    records=[]; calls=[]; runner.events_cache=[]
    config=make_config(arm,calls)
    for field in dataclasses.fields(original):
        if field.name!='tensor_initializers':check(getattr(config,field.name) is getattr(original,field.name),'unchanged config object field '+arm+':'+field.name)
    tuner=api.AutoTuner(); tuner._profile_single_kernel=lambda r,values,tactic,effective_config,**kwargs: profile(values,tactic,effective_config)
    def profile(values,tactic,effective_config):
        check(effective_config.dynamic_tensor_specs is original.dynamic_tensor_specs and effective_config.constraint_specs is original.constraint_specs,'profiling preserves original specs')
        check(all(values[i] is inputs[i] for i in (1,2,3)), 'static weight and both scales retain original allocation')
        records.append({'m':values[0].shape[-2],'tactic':tactic,'hashes':[tsha(t) for t in values],
                        'metadata':[[list(t.shape),list(t.stride()),str(t.dtype)] for t in values]})
        return {-1:3.0,0:1.0,1:2.0}[tactic]
    def public_call():
        selected,tactic=api.AutoTuner.get().choose_one('fp8_gemm',pool,config,inputs)
        return selected(inputs,tactic=tactic),tactic
    torch.manual_seed(19)
    before=tsha(torch.get_rng_state())
    with patch.object(torch.cuda,'is_current_stream_capturing',lambda:False), harness.use_isolated_tuner(tuner):
        with harness.autotune_v2(mode='tune',persistent_cache=False):
            _,winner=public_call()
        after=tsha(torch.get_rng_state())
        keys=[api.AutoTuner._get_cache_key('fp8_gemm',runner,p.get_opt_shapes(),config,runner.get_cache_key_extras(inputs)).file_key for p in tuner._generate_optimization_profiles(config,inputs)]
        check(winner==0,'controlled timing minimum really selected '+arm)
        hit=bool(tuner.search_cache('fp8_gemm',pool,tuple(tuple(t.shape) for t in inputs),config,inputs=inputs)[0])
        check(hit,'bare runtime lookup is a real hit '+arm)
        count=len(records); init_count=len(calls)
        _,bare=public_call()
        with harness.autotune_v2(mode='tune',persistent_cache=False): _,warm=public_call()
        check(len(records)==count and len(calls)==init_count,'bare and warm use winner without new input synthesis/profiling '+arm)
        check(bare==warm==0,'bare and warm consume real cached winner '+arm)
        cache_path=HERE/(arm+'.json')
        tuner.save_configs(str(cache_path))
    raw_cache=json.loads(cache_path.read_text())
    return {'arm':arm,'config':config,'records':records,'initializer_calls':calls,'enumeration':list(runner.events_cache),'keys':keys,
            'rng_before':before,'rng_after':after,'runtime_key':api.AutoTuner._get_cache_key('fp8_gemm',runner,tuple(tuple(t.shape) for t in inputs),config,runner.get_cache_key_extras(inputs)).file_key,
            'saved_file':str(cache_path),'saved_file_sha256':sha(cache_path),'saved_key_names':sorted(k for k in raw_cache if k!='_metadata')}

control=run('synthetic_matched_copy');actual=run('captured_m144')
check(control['enumeration']==actual['enumeration']==[(m,[0,1]) for m in (1,2,4,8,16,32,64,128,144)],'nine profile endpoints and controlled enumeration order preserved')
check(control['keys']==actual['keys'] and control['runtime_key']==actual['runtime_key'],'all profile and runtime cache identities identical across values arms')
check(control['runtime_key'].count('256')==1,'runtime M144 maps to original canonical bucket256')
check(control['saved_key_names']==actual['saved_key_names'],'v1 serialized cache key names preserved')
check(control['rng_before']==actual['rng_before'] and control['rng_after']==actual['rng_after'],'CPU RNG before/after identical with default draws consumed')
check(len(control['records'])==len(actual['records'])==27,'all nine profiles race default plus two controlled tactics')
check([tsha(t) for t in inputs[:4]]==original_read_hashes,'original serving input, weight and scalar bytes unchanged')
for a,b in zip(control['records'],actual['records'],strict=True):
    check(a['m']==b['m'] and a['tactic']==b['tactic'] and a['metadata']==b['metadata'],'matching per-candidate profile order and layouts')
    if a['m']==144:
        check(a['hashes'][0]!=b['hashes'][0] and b['hashes'][0]==tsha(q),'only runtime-profile activation changed to actual bytes')
        check(a['hashes'][1:]==b['hashes'][1:],'runtime-profile weight/scales/output/workspace values unchanged')
    else:check(a['hashes']==b['hashes'],'all non-runtime-profile inputs unchanged')
for a,b in zip(control['initializer_calls'],actual['initializer_calls'],strict=True):
    check(a['shape']==b['shape'] and a['generated_sha256']==b['generated_sha256'],'identical pre-intervention draws per profile')
result={'status':'success','controls':len(checks),'checks':checks,
        'source':{'commit':'27c62fdf0ab1cd4014df8a15b66a975541fda83c','tuner_sha256':sha(CURRENT/'flashinfer/autotuner/autotuner.py'),
                  'gemm_sha256':sha(gemm_path),'bucket_source_sha256':sha(UTIL),'proof_sha256':sha(__file__),
                  'loader_sha256':sha(ADAPTER/'check_adapter.py'),'fixture_sha256':sha(FIXTURE/'fixture.safetensors')},
        'arms':[{k:v for k,v in row.items() if k!='config'} for row in (control,actual)],
        'limits':['Complete pinned choose_one, profile generation, synthesis, key construction and save paths execute; only profiling times/runner execution are controlled CPU stand-ins.',
                  'GPU-only import leaves and stream-capture query are disclosed shims. This does not qualify actual SGLang CUDA facade, candidate descriptors, native enumeration or performance.',
                  'Source AST extraction preserves exact config and bucket functions; next-positive-power helper is a disclosed equivalent integer shim.',
                  'Inline byte hashes are CPU proof instrumentation only; a later timing experiment must not carry these hashes into profiling windows.']}
(HERE/'cpu-proof.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'success','controls':len(checks),'output':str(HERE/'cpu-proof.json'),'sha256':sha(HERE/'cpu-proof.json')}))
