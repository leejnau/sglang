#!/usr/bin/env python3
"""Run baseline/candidate whole-module CPU/Gloo controls, without GPU timing."""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import traceback
import types

ROOT = Path(__file__).resolve().parent
BASE_SCRIPT = ROOT.parent / "prove_distributed_objective_guard.py"
BASE_SCRIPT_SHA = "4e8215a2fa9d49edff10ed8a06c8a8cd87793298b9f66a9a2576cb4aa66cf8f8"
BASE_TUNER_SHA = "0db42ad90d1a3fec6f81509a2c520c1892cea0a433f5dbd7f43468a2a10243ca"
CANDIDATE_TUNER_SHA = "bc9952191f66606e7035a72ac6c16bfe02dda270a97a9af9b28f4088e08c3c24"
PATCH_SHA = "b9f96954f1db4c3b2f034dd29673a489202f49343d6a2020f616d74e341c6212"
TUNER = "flashinfer/autotuner/autotuner.py"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


assert sha(BASE_SCRIPT) == BASE_SCRIPT_SHA
base = types.ModuleType("retained_distributed_guard_proof")
base.__file__ = str(BASE_SCRIPT)
exec(compile(BASE_SCRIPT.read_bytes(), str(BASE_SCRIPT), "exec"), base.__dict__)


def configure(source_root):
    actual = sha(source_root / TUNER)
    assert actual in (BASE_TUNER_SHA, CANDIDATE_TUNER_SHA), "unknown tuner source"
    candidate = actual == CANDIDATE_TUNER_SHA
    if candidate:
        assert sha(ROOT / "configured-timer-guard.patch") == PATCH_SHA
    base.EXPECTED[TUNER] = actual
    cases = []
    for method in ("choose", "rank"):
        for label, left, right, rejects in (
            ("matching_auto", "auto", "auto", False),
            ("matching_eager", "eager", "eager", False),
            ("matching_no_delay", "no_delay", "no_delay", False),
            ("matching_cupti_unavailable", "cupti", "cupti", False),
            ("auto_vs_explicit_events", "auto", "events", False),
            ("auto_vs_eager", "auto", "eager", candidate),
            ("events_vs_no_delay", "events", "no_delay", candidate),
            ("auto_vs_unavailable_cupti", "auto", "cupti", candidate),
            ("graph_mismatch", "auto", "graph", True),
            ("l2_mismatch", "auto", "cold", True),
        ):
            cases.append((method + "_" + label, method, left, right, rejects))
    base.CASES = tuple(cases)
    return "candidate" if candidate else "baseline"


def worker(args, variant):
    # This retained function delegates the actual profiler and every phase gate
    # unchanged. Only the source file being imported differs between variants.
    base.worker(args)
    result = json.loads(args.result.read_text())
    result["source_variant"] = variant
    for row in result["records"]:
        if row["expected_rejection"]:
            expected = "profiles" if row["method"] == "choose" else "ranking_profile"
            assert row["phase_gates"][-1]["phase"] == [expected, "proof::objective_guard"]
    api = sys.modules["flashinfer.autotuner"]
    engine = sys.modules["flashinfer.autotuner.autotuner"]
    cache = sys.modules["flashinfer.autotune_cache"]
    assert engine._tune_process_group is None
    single = []
    for kind in ("auto", "events", "eager", "no_delay", "cupti"):
        tuner = api.AutoTuner()
        api.AutoTuner._instance = tuner
        config = api.TuningConfig(use_cuda_graph=False, use_cold_l2_cache=False)
        with cache.autotune_v2(persistent_cache=False, measurement_policy=base.policy(cache, kind)):
            original = tuner._profiling_policy(config)
            guarded = tuner._tuning_group_profiling_policy(config) if variant == "candidate" else original
            assert guarded == original
            single.append({"policy": kind, "profiling_policy": list(original),
                           "guard_payload_without_tuning_group": list(guarded),
                           "identity": repr(tuner._winner_cache_identity())})
        assert not tuner.is_tuning_mode and tuner._active_tuning_contexts == 0 and not tuner._v2_local.active
    result["no_tuning_group_controls"] = single
    result["post_controls_sources"] = base.source_manifest(args.source_root)
    assert result["post_controls_sources"] == result["source_sha256"]
    write(args.result, result)


def coordinator(args, variant):
    args.output.mkdir(parents=True, exist_ok=False)
    source = base.source_manifest(args.source_root)
    processes = []
    deadline = time.monotonic() + 180
    for rank in range(2):
        log = (args.output / f"rank{rank}.log").open("w")
        command = [sys.executable, str(Path(__file__).resolve()), "--worker", "--source-root", str(args.source_root),
                   "--rank", str(rank), "--rendezvous", str(args.output / "rendezvous"),
                   "--result", str(args.output / f"rank{rank}.json")]
        environment = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "CUDA_VISIBLE_DEVICES": "",
                       "GLOO_SOCKET_IFNAME": os.environ.get("GLOO_SOCKET_IFNAME", "lo0" if sys.platform == "darwin" else "lo")}
        processes.append((subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=environment), log))
    exits = []
    try:
        for process, _ in processes:
            exits.append(process.wait(timeout=max(1, deadline - time.monotonic())))
    finally:
        for process, log in processes:
            if process.poll() is None:
                process.kill()
                process.wait()
            log.close()
    write(args.output / "exit-codes.json", exits)
    assert exits == [0, 0], "inspect preserved rank logs"
    ranks = [json.loads((args.output / f"rank{rank}.json").read_text()) for rank in range(2)]
    comparisons = []
    for index, case in enumerate(base.CASES):
        sides = [rank["records"][index] for rank in ranks]
        assert all(row["case"] == case[0] for row in sides)
        payloads = [[{key: row[key] for key in ("phase", "selection", "status", "error")}
                     for row in side["phase_gates"]] for side in sides]
        accepted = all(row["outcome"] == "accepted" for row in sides)
        assert all((row["outcome"] == "rejected") is case[-1] for row in sides)
        assert not accepted or payloads[0] == payloads[1]
        comparisons.append({
            "case": case[0], "method": case[1], "policy_kinds": [row["policy_kind"] for row in sides],
            "outcomes": [row["outcome"] for row in sides], "expected_rejection": case[-1],
            "profiles_per_rank": [len(row["profiles"]) for row in sides],
            "runner_calls_per_rank": [row["runner_calls"] for row in sides],
            "delay_calls_per_rank": [sum(call["event"] == "delay_kernel" for profile in row["profiles"]
                                         for call in profile["cuda_calls"]) for row in sides],
            "final_gate_payloads": [row["phase_gates"][-1] for row in sides],
            "returned": [row.get("returned") for row in sides],
            "both_subsequent_barriers_reached": all(row["subsequent_barrier_reached"] for row in sides),
        })
    assert base.source_manifest(args.source_root) == source
    result = {
        "status": "success", "source_variant": variant, "base_commit": base.PIN,
        "script_sha256": sha(Path(__file__)), "retained_reproducer_sha256": BASE_SCRIPT_SHA,
        "candidate_patch_sha256": PATCH_SHA if variant == "candidate" else None,
        "source_sha256": source, "world_size": 2, "worker_pids": [row["pid"] for row in ranks],
        "exit_codes": exits, "cases": comparisons, "cases_passed": len(comparisons),
        "no_tuning_group_controls_per_rank": [len(row["no_tuning_group_controls"]) for row in ranks],
        "accepted_cases": sum(row["outcomes"] == ["accepted", "accepted"] for row in comparisons),
        "rejected_cases": sum(row["outcomes"] == ["rejected", "rejected"] for row in comparisons),
        "evidence_scope": "Whole source modules and original profiler with deterministic CPU CUDA boundaries; actual two-process Gloo gates and per-tactic reductions. No GPU timing, model or NCCL qualification.",
        "contract": "Coordinate configured policy.timer with None normalized to events; no persistent provenance/identity change. Single-process and no-tuning-group payloads remain unchanged.",
        "limits": ["Different configured timers are conservatively rejected even if some actual paths could converge.",
                   "Dynamic CUPTI availability/infra fallback remains outside this guard; availability is forced unavailable in these fixtures.",
                   "Delegated protocols and private globaltimer settings are not coordinated by this change.",
                   "Current SGLang's matching unspecified policies already agree; no current serving regression or speedup is claimed."],
    }
    write(args.output / "result.json", result)
    print(json.dumps({"status": "success", "variant": variant, "result": str(args.output / "result.json"),
                      "sha256": sha(args.output / "result.json"), "cases": len(comparisons)}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=ROOT.parent / "flashinfer-main")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--rank", type=int, choices=(0, 1))
    parser.add_argument("--rendezvous", type=Path)
    parser.add_argument("--result", type=Path)
    args = parser.parse_args()
    variant = configure(args.source_root)
    if args.worker:
        try:
            worker(args, variant)
        except BaseException:
            traceback.print_exc()
            raise
    else:
        if args.output is None:
            parser.error("--output is required")
        coordinator(args, variant)


if __name__ == "__main__":
    main()
