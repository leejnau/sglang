#!/usr/bin/env python3
"""Run pinned whole production modules with real CPU/Gloo and fake CUDA events.

The CUDA event/stream boundary supplies deterministic timing fixtures. The
production policy, configuration, choose/rank methods, every phase gate, and
the production per-tactic Gloo reduction run unchanged. This is not a latency
measurement or GPU/distributed-model qualification.
"""
from __future__ import annotations

import argparse
import ast
import contextlib
import dataclasses
import datetime
import hashlib
import importlib
import json
import logging
import os
import subprocess
import sys
import time
import traceback
import types
from pathlib import Path

PIN = "27c62fdf0ab1cd4014df8a15b66a975541fda83c"
EXPECTED = {
    "flashinfer/autotuner/autotuner.py": "0db42ad90d1a3fec6f81509a2c520c1892cea0a433f5dbd7f43468a2a10243ca",
    "flashinfer/autotune_cache.py": "1ab2ed7208ed1bf1007b1f74de29fc818c93a5ab091beea0833474177fbb29ad",
}
SOURCE_FILES = (
    "flashinfer/autotuner/autotuner.py", "flashinfer/autotuner/__init__.py",
    "flashinfer/autotuner/initializers.py", "flashinfer/autotuner/protocol.py",
    "flashinfer/autotune_cache.py", "flashinfer/tactics_blocklist.py", "flashinfer/version.py",
)
CASES = (
    ("choose_matching_auto", "choose", "auto", "auto", False),
    ("choose_matching_eager", "choose", "eager", "eager", False),
    ("choose_auto_vs_eager", "choose", "auto", "eager", False),
    ("choose_events_vs_no_delay", "choose", "events", "no_delay", False),
    ("choose_auto_vs_unavailable_cupti", "choose", "auto", "cupti", False),
    ("choose_graph_mismatch_rejected", "choose", "auto", "graph", True),
    ("choose_l2_mismatch_rejected", "choose", "auto", "cold", True),
    ("rank_matching_auto", "rank", "auto", "auto", False),
    ("rank_auto_vs_eager", "rank", "auto", "eager", False),
    ("rank_events_vs_no_delay", "rank", "events", "no_delay", False),
    ("rank_auto_vs_unavailable_cupti", "rank", "auto", "cupti", False),
    ("rank_graph_mismatch_rejected", "rank", "auto", "graph", True),
    ("rank_l2_mismatch_rejected", "rank", "auto", "cold", True),
)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def source_manifest(root):
    result = {name: {"sha256": sha(root / name), "size_bytes": (root / name).stat().st_size}
              for name in SOURCE_FILES}
    for name, digest in EXPECTED.items():
        require(result[name]["sha256"] == digest, "pinned source changed: " + name)
    return result


class CudaFixture:
    """Record actual profiler routing with CPU-only deterministic event values."""
    def __init__(self):
        self.calls = []
        self.tactic = None
        self.repeat = 10

    def unavailable(self, *args, **kwargs):
        raise RuntimeError("unexpected unsupported GPU boundary")

    def helper(self):
        self.calls.append({"event": "delay_helper_request"})
        return self

    def delay(self, microseconds):
        self.calls.append({"event": "delay_kernel", "microseconds": microseconds})

    def stream(self):
        fixture = self
        class Stream:
            def synchronize(self):
                fixture.calls.append({"event": "stream_synchronize"})
        return Stream()

    def event(self, *args, **kwargs):
        fixture = self
        class Event:
            def record(self, *args):
                fixture.calls.append({"event": "event_record"})

            def elapsed_time(self, end):
                cost = {-1: 4.0, 0: 1.0, 1: 3.0}[fixture.tactic]
                value = cost * fixture.repeat
                fixture.calls.append({"event": "event_elapsed_fixture", "batch_ms": value})
                return value
        return Event()

    def graph(self):
        class Graph:
            def replay(self):
                raise RuntimeError("graph replay is not part of accepted eager cases")
        return Graph()


def load_whole_modules(root):
    require(not any(name == "flashinfer" or name.startswith("flashinfer.") for name in sys.modules),
            "worker requires a fresh interpreter")
    initial = source_manifest(root)
    os.environ["FLASHINFER_AUTOTUNE_TIMER"] = "cuda_event"
    os.environ["FLASHINFER_AUTOTUNER_LOAD_FROM_FILE"] = "0"
    os.environ.pop("FLASHINFER_TACTICS_BLOCKLIST", None)
    fixture = CudaFixture()

    def package(name, path):
        module = types.ModuleType(name)
        module.__path__ = [str(path)]
        sys.modules[name] = module
        return module

    top = package("flashinfer", root / "flashinfer")
    package("flashinfer.jit", root / "flashinfer/jit")
    core = types.ModuleType("flashinfer.jit.core")
    core.logger = logging.getLogger("objective-guard-proof")
    sys.modules[core.__name__] = core
    tllm = types.ModuleType("flashinfer.tllm_utils")
    tllm.delay_kernel = fixture.delay
    tllm.get_trtllm_utils_module = fixture.helper
    sys.modules[tllm.__name__] = tllm
    utilities = types.ModuleType("flashinfer.utils")
    utilities.next_positive_power_of_2 = lambda value: 1 << (value - 1).bit_length()
    utilities.is_confidential_compute = lambda: False
    utilities.get_globaltimer_kernel = fixture.unavailable
    sys.modules[utilities.__name__] = utilities
    api = importlib.import_module("flashinfer.autotuner")
    engine = importlib.import_module("flashinfer.autotuner.autotuner")
    cache = importlib.import_module("flashinfer.autotune_cache")
    top.autotune_v2, top.MeasurementPolicy = cache.autotune_v2, cache.MeasurementPolicy
    import torch
    require(torch.__version__.split("+")[0] == "2.14.1" and not torch.cuda.is_available(), "expected existing CPU Torch2.14.1")
    torch.cuda.is_current_stream_capturing = lambda: False
    torch.cuda.current_stream = fixture.stream
    torch.cuda.stream = lambda stream: contextlib.nullcontext()
    torch.cuda.Event = fixture.event
    torch.cuda.CUDAGraph = fixture.graph
    torch.cuda.synchronize = lambda: None
    torch.cuda.empty_cache = lambda: None
    engine._load_cupti = lambda: None
    return api, engine, cache, torch, fixture, initial


def policy(cache, kind):
    if kind == "auto":
        return None
    return cache.MeasurementPolicy(**{
        "eager": {"execution_mode": "eager"},
        "events": {"_timer": "events"},
        "no_delay": {"_timer": "events_no_delay"},
        "cupti": {"_timer": "cupti"},
        "graph": {"execution_mode": "cuda_graph"},
        "cold": {"cold_l2": True},
    }[kind])


def worker(args):
    api, engine, cache, torch, fixture, initial_sources = load_whole_modules(args.source_root)
    import torch.distributed as dist
    require(dist.is_gloo_available(), "Gloo unavailable")
    dist.init_process_group("gloo", init_method="file://" + str(args.rendezvous),
                            rank=args.rank, world_size=2, timeout=datetime.timedelta(seconds=45))
    api.set_autotune_process_group(dist.group.WORLD)
    records, active = [], {}
    original_agreement = engine._tuning_group_agreement
    original_reduce = dist.all_reduce
    original_profile = engine.AutoTuner._profile_single_kernel

    def agreement(phase, selection, status=0, error=None):
        row = {"phase": engine._tactic_to_json(phase), "selection": engine._tactic_to_json(selection),
               "status": status, "error": error}
        active["phase_gates"].append(row)
        try:
            result = original_agreement(phase, selection, status, error)
            row.update(return_status=result[0], return_agreed=result[1], accepted=True)
            return result
        except BaseException as exc:
            row.update(accepted=False, exception=f"{type(exc).__name__}: {exc}")
            raise

    def reduction(tensor, *args, **kwargs):
        active["reductions"].append({"elements": tensor.numel(), "dtype": str(tensor.dtype),
                                     "op": str(kwargs.get("op", "SUM")), "before": tensor.tolist()})
        result = original_reduce(tensor, *args, **kwargs)
        active["reductions"][-1]["after"] = tensor.tolist()
        return result

    def profile(tuner, runner, inputs, tactic, config, *more, **kwargs):
        current = tuner._effective_measure_policy
        row = {"tactic": tactic, "policy": dataclasses.asdict(current) if current else None,
               "policy_timer_property": current.timer if current else None,
               "identity": repr(tuner._winner_cache_identity()),
               "profiling_policy": engine._tactic_to_json(tuner._profiling_policy(config)),
               "configuration": dataclasses.asdict(config), "cuda_calls": []}
        # Configuration contains callable/shape objects only for dynamic specs;
        # this fixed CPU case uses empty tuples and no callbacks.
        active["profiles"].append(row)
        first = len(fixture.calls)
        fixture.repeat = tuner._get_profiling_repeat(config)
        try:
            result = original_profile(tuner, runner, inputs, tactic, config, *more, **kwargs)
            row["returned_reduced_ms_fixture"] = result
            return result
        except BaseException as exc:
            row["exception"] = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            row["cuda_calls"] = fixture.calls[first:]

    engine._tuning_group_agreement = agreement
    dist.all_reduce = reduction
    engine.AutoTuner._profile_single_kernel = profile

    class Runner(api.TunableRunner):
        def get_valid_tactics(self, inputs, profile):
            return [0, 1]

        def forward(self, inputs, tactic=-1, **kwargs):
            fixture.tactic = tactic
            active["runner_calls"] += 1
            return inputs[0] + tactic

    try:
        for name, method, left, right, expected_rejection in CASES:
            active = {"case": name, "method": method, "rank": args.rank, "pid": os.getpid(),
                      "policy_kind": (left, right)[args.rank], "expected_rejection": expected_rejection,
                      "phase_gates": [], "reductions": [], "profiles": [], "runner_calls": 0}
            records.append(active)
            tuner = api.AutoTuner()
            api.AutoTuner._instance = tuner
            config = api.TuningConfig(use_cuda_graph=False, use_cold_l2_cache=False)
            inputs, runner = [torch.ones(2, 3)], Runner()
            requested = policy(cache, active["policy_kind"])
            active["requested_policy"] = dataclasses.asdict(requested) if requested else None
            active["requested_timer_property"] = requested.timer if requested else None
            active["base_config"] = dataclasses.asdict(config)
            try:
                with cache.autotune_v2(mode="tune", persistent_cache=False, measurement_policy=requested):
                    active["identity"] = repr(tuner._winner_cache_identity())
                    if method == "choose":
                        selected, tactic = tuner.choose_one("proof::objective_guard", [runner], config, inputs)
                        require(selected is runner, "unexpected runner")
                        active["returned"] = tactic
                    else:
                        active["returned"] = tuner.rank_tactics("proof::objective_guard", [runner], config, inputs, k=2)
                active["outcome"] = "accepted"
            except engine._TuningGroupError as exc:
                active["outcome"] = "rejected"
                active["exception"] = f"{type(exc).__name__}: {exc}"
            require((active["outcome"] == "rejected") is expected_rejection, "unexpected outcome: " + name)
            if expected_rejection:
                require(not active["profiles"] and active["runner_calls"] == 0, "mismatch profiled before rejection")
            else:
                expected_tactics = [-1, 0, 1] if method == "choose" else [0, 1]
                require([row["tactic"] for row in active["profiles"]] == expected_tactics, "missing actual production profiles")
                require(all("exception" not in row for row in active["profiles"]), "unexpected profiler exception")
                require(active["returned"] == (0 if method == "choose" else [0, 1]), "unexpected fixture minimum")
                require(all(row["accepted"] and row["return_agreed"] for row in active["phase_gates"]), "gate disagreement escaped")
            require(not tuner.is_tuning_mode and tuner._active_tuning_contexts == 0 and not tuner._v2_local.active,
                    "context leaked")
            dist.barrier()
            active["subsequent_barrier_reached"] = True
            write(args.result, {"status": "running", "rank": args.rank, "records": records})
        require(source_manifest(args.source_root) == initial_sources, "source changed during proof")
        result = {"status": "success", "rank": args.rank, "pid": os.getpid(), "torch": torch.__version__,
                  "cuda_available": torch.cuda.is_available(), "gloo": dist.is_gloo_available(),
                  "source_commit": PIN, "source_sha256": initial_sources, "records": records}
        write(args.result, result)
    finally:
        api.set_autotune_process_group(None)
        dist.destroy_process_group()


def static_gate_sites(source):
    tree = ast.parse(source.read_text())
    gate_names = {"_check_tuning_group_phase", "_sync_oom_across_tune_group", "_all_ranks_hit_cache"}
    rows = []
    for function in ast.walk(tree):
        if not isinstance(function, ast.FunctionDef) or function.name not in ("choose_one", "rank_tactics", "_profile_single_kernel"):
            continue
        for node in ast.walk(function):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in gate_names:
                rows.append({"method": function.name, "line": node.lineno, "gate": node.func.id,
                             "source": ast.get_source_segment(source.read_text(), node)})
    return sorted(rows, key=lambda row: row["line"])


def coordinator(args):
    args.output.mkdir(parents=True, exist_ok=False)
    source = source_manifest(args.source_root)
    processes = []
    deadline = time.monotonic() + 180
    for rank in range(2):
        log = (args.output / f"rank{rank}.log").open("w")
        command = [sys.executable, str(Path(__file__).resolve()), "--worker", "--source-root", str(args.source_root),
                   "--rank", str(rank), "--rendezvous", str(args.output / "rendezvous"),
                   "--result", str(args.output / f"rank{rank}.json")]
        interface = os.environ.get("GLOO_SOCKET_IFNAME", "lo0" if sys.platform == "darwin" else "lo")
        environment = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1", "CUDA_VISIBLE_DEVICES": "", "GLOO_SOCKET_IFNAME": interface}
        processes.append((subprocess.Popen(command, stdout=log, stderr=subprocess.STDOUT, env=environment), log))
    exits = []
    try:
        for process, _ in processes:
            exits.append(process.wait(timeout=max(1, deadline - time.monotonic())))
    finally:
        for process, log in processes:
            if process.poll() is None:
                process.kill()
                process.wait()
            log.close()
    write(args.output / "exit-codes.json", exits)
    require(exits == [0, 0], "CPU workers failed; inspect retained logs")
    ranks = [json.loads((args.output / f"rank{rank}.json").read_text()) for rank in range(2)]
    comparisons = []
    for index, case in enumerate(CASES):
        left, right = (rank["records"][index] for rank in ranks)
        require(left["case"] == right["case"] == case[0], "rank case order")
        payloads = [[{key: row[key] for key in ("phase", "selection", "status", "error")} for row in side["phase_gates"]]
                    for side in (left, right)]
        accepted = left["outcome"] == right["outcome"] == "accepted"
        if accepted:
            require(payloads[0] == payloads[1], "accepted case had different phase payloads")
        delay_counts = [sum(call["event"] == "delay_kernel" for row in side["profiles"] for call in row["cuda_calls"])
                        for side in (left, right)]
        comparisons.append({"case": case[0], "method": case[1], "outcomes": [left["outcome"], right["outcome"]],
                            "policy_kinds": [left["policy_kind"], right["policy_kind"]],
                            "requested_timer_properties": [left["requested_timer_property"], right["requested_timer_property"]],
                            "phase_payloads_equal": payloads[0] == payloads[1], "phase_gates_per_rank": [len(x) for x in payloads],
                            "profiles_per_rank": [len(left["profiles"]), len(right["profiles"])],
                            "actual_profiler_delay_calls": delay_counts,
                            "returned": [left.get("returned"), right.get("returned")],
                            "barrier_after_case": left["subsequent_barrier_reached"] and right["subsequent_barrier_reached"]})
    result = {"schema_version": 1, "status": "success", "source_commit": PIN,
              "script_sha256": sha(Path(__file__)), "python": sys.executable, "source_sha256": source,
              "world_size": 2, "worker_pids": [row["pid"] for row in ranks], "exit_codes": exits,
              "whole_production_modules": True, "original_methods_executed": ["MeasurementPolicy", "autotune_v2", "autotune",
                  "AutoTuner.choose_one", "AutoTuner.rank_tactics", "AutoTuner._apply_measure_policy", "AutoTuner._profiling_policy",
                  "AutoTuner._profile_single_kernel", "_tuning_group_agreement", "_all_ranks_hit_cache", "_check_tuning_group_phase", "_sync_oom_across_tune_group"],
              "cases": comparisons, "all_early_gate_call_sites": static_gate_sites(args.source_root / "flashinfer/autotuner/autotuner.py"),
              "boundaries": ["GPU package initialization bypassed with explicit module shells.",
                  "CUDA current-stream/capture query, stream/event/graph primitives and delay-helper/kernel calls use recorded CPU fixtures.",
                  "Event elapsed values are deterministic fixtures; no GPU timing or performance inference.",
                  "CUPTI availability is forced unavailable to exercise the actual event fallback. No CUPTI tracing is simulated as real.",
                  "Production phase gates and per-tactic timing reductions use actual two-process Torch Gloo on loopback.",
                  "No production source was patched; observers wrap and delegate original methods unchanged."],
              "conclusion": "Production gates accept None-vs-eager and events-vs-events_no_delay objectives with identical config provenance while actual profiler branches issue different delay calls. Graph/L2 config mismatches are rejected before profiling. Current SGLang's matching unspecified policies are unaffected.",
              "scope": "Defensive future distributed policy agreement, not demonstrated current SGLang regression; not GPU/NCCL/model/TP/EP qualification."}
    write(args.output / "result.json", result)
    print(json.dumps({"status": result["status"], "result": str(args.output / "result.json"),
                      "result_sha256": sha(args.output / "result.json"), "cases": len(CASES)}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, default=Path(__file__).resolve().parent / "flashinfer-main")
    parser.add_argument("--output", type=Path)
    parser.add_argument("--worker", action="store_true")
    parser.add_argument("--rank", type=int, choices=(0, 1))
    parser.add_argument("--rendezvous", type=Path)
    parser.add_argument("--result", type=Path)
    args = parser.parse_args()
    if args.worker:
        try:
            worker(args)
        except BaseException:
            traceback.print_exc()
            raise
    else:
        if args.output is None:
            parser.error("--output is required")
        coordinator(args)


if __name__ == "__main__":
    main()
