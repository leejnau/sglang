#!/usr/bin/env python3
"""Make a small standalone upstream research candidate from pinned sources."""

import ast
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent / "flashinfer-main"
PIN = "27c62fdf0ab1cd4014df8a15b66a975541fda83c"
TUNER = "flashinfer/autotuner/autotuner.py"
BASE_SHA = "0db42ad90d1a3fec6f81509a2c520c1892cea0a433f5dbd7f43468a2a10243ca"
FILES = (
    TUNER, "flashinfer/autotuner/__init__.py",
    "flashinfer/autotuner/initializers.py", "flashinfer/autotuner/protocol.py",
    "flashinfer/autotune_cache.py", "flashinfer/tactics_blocklist.py",
    "flashinfer/version.py",
)


def sha(content):
    return hashlib.sha256(content).hexdigest()


original = (BASE / TUNER).read_bytes()
assert sha(original) == BASE_SHA
text = original.decode()
choose_old = '(len(profiles), self._profiling_policy(tuning_config)),'
choose_new = '(len(profiles), self._tuning_group_profiling_policy(tuning_config)),'
rank_old = '''                ("ranking_profile", custom_op),
                self._profiling_policy(tuning_config),'''
rank_new = '''                ("ranking_profile", custom_op),
                self._tuning_group_profiling_policy(tuning_config),'''
anchor = '''    @staticmethod
    def _default_profiling_policy(tuning_config: TuningConfig) -> tuple:'''
helper = '''    def _tuning_group_profiling_policy(self, tuning_config: TuningConfig) -> tuple:
        """Coordinate configured timers without changing persisted provenance."""
        policy = self._profiling_policy(tuning_config)
        if _tune_process_group is not None:
            measure = self._effective_measure_policy
            policy += ("configured_timer", measure.timer if measure else "events")
        return policy

'''
assert text.count(choose_old) == text.count(rank_old) == text.count(anchor) == 1
candidate = text.replace(choose_old, choose_new).replace(rank_old, rank_new).replace(anchor, helper + anchor)
compile(candidate, TUNER, "exec")


def methods(source):
    tree = ast.parse(source)
    cls = next(row for row in tree.body if isinstance(row, ast.ClassDef) and row.name == "AutoTuner")
    return {row.name: row for row in cls.body if isinstance(row, ast.FunctionDef)}


before, after = methods(text), methods(candidate)
unchanged = [
    "_profiling_policy", "_default_profiling_policy", "_winner_cache_identity",
    "_profile_single_kernel", "save_configs", "load_configs", "search_cache",
]
for name in unchanged:
    assert ast.dump(before[name]) == ast.dump(after[name]), name
for name in ("choose_one", "rank_tactics"):
    revised = ast.parse(ast.unparse(after[name]))
    for row in ast.walk(revised):
        if isinstance(row, ast.Attribute) and row.attr == "_tuning_group_profiling_policy":
            row.attr = "_profiling_policy"
    assert ast.dump(ast.parse(ast.unparse(before[name]))) == ast.dump(revised), name

source_root = ROOT / "candidate"
source_root.mkdir(exist_ok=False)
manifest = []
for name in FILES:
    old = (BASE / name).read_bytes()
    new = candidate.encode() if name == TUNER else old
    target = source_root / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(new)
    manifest.append({"path": name, "base_sha256": sha(old), "candidate_sha256": sha(new), "changed": old != new})
patch = "".join(difflib.unified_diff(text.splitlines(True), candidate.splitlines(True), "a/" + TUNER, "b/" + TUNER))
patch_path = ROOT / "configured-timer-guard.patch"
patch_path.write_text(patch)
lines = patch.splitlines()
added = sum(line.startswith("+") and not line.startswith("+++") for line in lines)
removed = sum(line.startswith("-") and not line.startswith("---") for line in lines)
result = {
    "scope": "Scratch-only standalone upstream configured-timer agreement proposal; no production integration, PR, GPU or performance evidence.",
    "base_commit": PIN,
    "source_root": str(source_root),
    "files": manifest,
    "patch_sha256": sha(patch.encode()),
    "patch_lines_added": added,
    "patch_lines_removed": removed,
    "persistent_format_changed": False,
    "structurally_unchanged_methods": unchanged,
    "choose_rank_changes": "Exactly one existing distributed phase-gate payload call per method, plus one shared helper; AST equal after restoring the two helper names.",
    "configured_timer_contract": "None normalizes to events. Explicit events agrees with None; eager defaults to events_no_delay. All ranks must request the same normalized timer when a tuning process group is set.",
    "conservative_scope": "Different configured timers may be rejected even when some cold-L2/individual/fallback branches would converge. No claim of universal effective-backend equivalence.",
    "out_of_scope": ["Dynamic CUPTI availability/infra fallback", "Delegated protocol coordination", "Private globaltimer settings", "GPU/NCCL/model qualification"],
}
(ROOT / "candidate-manifest.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"candidate_tuner_sha256": sha(candidate.encode()), "patch_sha256": result["patch_sha256"], "added": added, "removed": removed}, indent=2))
