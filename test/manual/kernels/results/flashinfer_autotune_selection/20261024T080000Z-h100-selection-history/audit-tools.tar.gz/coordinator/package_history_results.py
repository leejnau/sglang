from pathlib import Path
import hashlib,json,math,shutil,tarfile
root=Path('/private/tmp/fi-next-steps-20261024');batch=Path('/private/tmp/sglang-autotune-selection-study/test/manual/kernels/results/flashinfer_autotune_selection/20261024T080000Z-h100-selection-history');raw=root/'coordinator/raw/attempt02'
a=json.loads((raw/'final-analysis.json').read_text());b=json.loads((root/'coordinator/history-analysis-local.json').read_text());differences=[]
def compare(x,y,path=''):
    assert type(x)==type(y),path
    if isinstance(x,dict):
        assert x.keys()==y.keys(),path
        for k in x:compare(x[k],y[k],path+'.'+str(k))
    elif isinstance(x,list):
        assert len(x)==len(y),path
        for i,(v,w) in enumerate(zip(x,y)):compare(v,w,path+f'[{i}]')
    elif x!=y:
        if path.endswith('.trace.file'):assert Path(x).name==Path(y).name
        else:assert isinstance(x,float) and math.isclose(x,y,rel_tol=1e-14,abs_tol=1e-15),path
        differences.append({'path':path,'cluster':x,'local':y})
compare(a['analysis'],b['analysis'])
files=[root/'history-statistics-audit/audit.py',root/'history-statistics-audit/summarize.py',root/'selection-audit/audit_history_raw.py',root/'coordinator/package_public.py',root/'coordinator/preserve.py',root/'coordinator/check_launcher.py',root/'coordinator/launcher-controls.json',Path(__file__)]
index=[]
with tarfile.open(batch/'audit-tools.tar.gz','w:gz') as t:
    for p in files:
        data=p.read_bytes();assert bytes([118,108,108,109]) not in data.lower(),p
        rel=str(p.relative_to(root));t.add(p,arcname=rel,recursive=False);index.append({'path':rel,'sha256':hashlib.sha256(data).hexdigest(),'size_bytes':len(data)})
validation={'status':'passed','execution_source_commit':'bdcd1d9bf844022bae45652c1a7979f3fe8477bd','all32_workers_succeeded':True,'final_integrity_gate_exit':0,'independent_controls':{'checks':50697,'workers':32,'startup_profiles':2592,'default_profiles':288,'forbidden_profiles':0,'numeric_guards':2208,'exact_zero_guards':128,'primary_graphs':64,'retained_history_graphs':16,'trace_kernels':384,'graph_launches':192},'independent_math_comparisons':337,'local_frozen_analyzer_replay':{'passed':True,'differences_only_relocated_trace_paths_and_double_roundoff':differences},'successful_full_raw':{'sha256':'0eeedb2912c10089c743f1249701e8c65347a8a585e734023a2fbedb2404448b','size_bytes':11636498,'manifest_files_verified':238,'durable_path':'/home/lnau/flashinfer-autotune-study/20261024T080000Z-h100-selection-history-attempt02-full-raw.tgz'},'failed_attempt01':{'execution_source_commit':'fb6655b8775f0fb81915800fd8f2a0e3934f6136','workers_started':1,'stage':'post-timing trace parsing','cause':'CPU user_annotation and GPU gpu_user_annotation share a name; original reader required only one name match.','fix_commit':'a15130a52ebdd4a85281df319170ec572e33583b','fix_scope':'Filter CPU user_annotation only; candidate/timing/capture/policy unchanged. Full32process retry; failed process not mixed into cohort.','full_raw_sha256':'7f1be8f20e678b3e530e4eb74d473e47d87bf8e969824fa3ed00b2155cbbd5e8','native_supplement_sha256':'d3b45d8f01141d4e8043de3701607bd35543eaa0412798e9385813258397780b','preserved':True},'audit_tools':index,'limitations':a['limitations'],'allocation':{'job_id':2792066,'state':'released','released_at_utc':'2026-10-24T08:36:29Z','history_worker_step':'2792066.5 COMPLETED 0:0','calibration_worker_step':'2792066.14 COMPLETED 0:0','hold_allocation':'CANCELLED by owner after preservation; not a failed study','final_resource_check':'No experiment containers or GPU compute processes; 0MiB GPU memory. Only preexisting DCGM container remains.','final_scheduler':'No longer in active queue; sacct final record preserved.'}}
(batch/'validation.json').write_text(json.dumps(validation,indent=2)+'\n')
for p in batch.iterdir():
    if p.is_file() and not p.name.endswith('.gz'):assert bytes([118,108,108,109]) not in p.read_bytes().lower(),p
print('Frozen analyzer reproduced within double roundoff; source, audits and failure preserved')
