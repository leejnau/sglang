"""Independent raw controls audit; imports neither workers nor their analyzers."""
from __future__ import annotations

import argparse
import ast
import base64
import collections
import csv
import hashlib
import itertools
import json
import math
from pathlib import Path
import random
import re
import statistics
import struct
import subprocess

BATCH = 'test/manual/kernels/results/flashinfer_autotune_selection/20261024T080000Z-h100-selection-history'
SOURCE_MANIFEST = 'test/manual/kernels/results/flashinfer_autotune_selection/20261019T232945Z-h100-descriptor-qualification/source-manifest.json'
MS = [1,2,4,8,16,32,64,128,144]
COUNTS = collections.Counter()
ERRORS = []

def sha_bytes(data):return hashlib.sha256(data).hexdigest()
def sha(path):return sha_bytes(Path(path).read_bytes())
def load(path):return json.loads(Path(path).read_text())
def normalized(value):return json.dumps(value,sort_keys=True,separators=(',',':'))
def gate(condition,label):
    COUNTS[label.split(':',1)[0]] += 1
    if not condition:raise AssertionError(label)
def finite(value):return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value)
def close(a,b):return math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-14)
def frozen_blob(path):
    return subprocess.run(['git','-C',str(ARGS.source_root),'show',ARGS.commit+':'+path],check=True,capture_output=True).stdout

def tensor_payloads(path):
    data=path.read_bytes();size=struct.unpack_from('<Q',data)[0];header=json.loads(data[8:8+size]);payload=memoryview(data)[8+size:]
    return {key:(value,bytes(payload[value['data_offsets'][0]:value['data_offsets'][1]]))for key,value in header.items()if key!='__metadata__'}

def trace_audit(result,graphs,root):
    history=result['selection_history'];trace=history['post_timing_trace'];path=root/Path(trace['path']).name
    gate(path.is_file() and sha(path)==trace['sha256'],'trace: original file hash')
    gate(result['observer']['trace']==trace and not result['observer']['enabled'],'trace: post-timing metadata')
    gate(trace['started_ns']>history['pre_trace_checks']['ended_ns'],'trace: follows final checks')
    gate(trace['ended_ns']<history['post_trace_checks']['ended_ns'],'trace: finishes before post checks')
    gate(trace['started_ns']>max(row['ended_ns']for block in result['graph_controls']['blocks']for row in block['measurements']),'trace: follows all primary batches')
    events=load(path)['traceEvents'];kernels=[event for event in events if event.get('cat')=='kernel']
    gate(len(kernels)==trace['kernel_events']==12,'trace: twelve actual CUDA launches')
    summaries={row['graph_id']:row for row in trace['graphs']};sequences={}
    for name in ['winner','default']:
        markers=[event for event in events if event.get('cat')=='user_annotation' and event.get('ph')=='X' and event.get('name')=='retained_'+name]
        gate(len(markers)==1,'trace: unique graph label')
        marker=markers[0];inside=[event for event in events if marker['ts']<=event.get('ts',-1)<=marker['ts']+marker['dur']]
        launches=[event for event in inside if 'cudaGraphLaunch' in event.get('name','')]
        selected=sorted([event for event in inside if event.get('cat')=='kernel'],key=lambda event:event['ts'])
        gate(len(launches)==3 and len(selected)==6,'trace: graph launches and two kernels per replay')
        correlations=[event.get('args',{}).get('correlation')for event in launches]
        gate(None not in correlations and len(set(correlations))==3,'trace: three independent launch correlations')
        gate(collections.Counter(event.get('args',{}).get('correlation')for event in selected)==collections.Counter({key:2 for key in correlations}),'trace: kernel-to-launch correlation')
        signatures=[];indices=[]
        for event in selected:
            values=event['args'];signature={'name':event['name'],**{key:values.get(key)for key in ['device','grid','block','registers per thread','shared memory']}}
            gate(bool(signature['name']) and all(isinstance(signature[key],list) and len(signature[key])==3 for key in ['grid','block']),'trace: actual kernel launch metadata')
            if signature not in signatures:signatures.append(signature)
            indices.append(signatures.index(signature))
        summary=summaries[name]
        gate(summary['signatures']==signatures and summary['kernel_sequence']==indices,'trace: independently reconstructed signatures')
        gate(summary['graph_object_id']==graphs[name]['graph_object_id'] and summary['output_data_ptr']==graphs[name]['output']['data_ptr'],'trace: original graph object and output ownership')
        gate(summary['kernel_events']==6 and summary['graph_launch_events']==3,'trace: summary counts')
        sequences[name]=[signatures[index]for index in indices]
        gate(all(selected[index]['name']=='_static_quant_fp8' for index in [0,2,4]),'trace: real quantizer precedes BMM')
    return {'same_primary_signature_sequence':sequences['winner']==sequences['default'],'winner_kernel_sequence':[x['name']for x in sequences['winner']],'default_kernel_sequence':[x['name']for x in sequences['default']]}

def numeric_audit(result,graphs):
    checks=result['correctness']['checks'];history=result['selection_history']['history_enabled']
    gate(result['correctness']['passed'] and result['correctness']['rtol']==.02 and result['correctness']['atol']==.125,'numerics: fixed quantized reference threshold')
    labels=[row['check']for row in checks]
    gate(len(labels)==len(set(labels))==(72 if history else 66),'numerics: complete unique checks')
    gate(set(labels)>={'natural_eager_changed_input','natural_eager_restored_input','winner_changed_input','winner_restored_input','default_changed_input','default_restored_input','traced_winner','traced_default'},'numerics: changed/restored and trace guards')
    by_label={row['check']:row for row in checks};zeros=0;zero_sha=sha_bytes(bytes(144*4096*2));zero_hashes=0;outputs=collections.defaultdict(set)
    for row in checks:
        q=row['quantized_reference'];dense=row['bf16_reference']
        gate(q['passed'] and dense['diagnostic_only'],'numerics: reference roles')
        gate(all(finite(value)for key,value in q.items()if key!='passed') and all(finite(value)for key,value in dense.items()if key!='diagnostic_only'),'numerics: finite metrics')
        gate(q['max_normalized_error']<=1 and q['max_abs_error']==row['max_abs_error'],'numerics: actual error gate')
        if row['exact_zero_required']:
            zeros+=1
            gate(all(q[key]==0 for key in ['max_abs_error','max_normalized_error','rmse','relative_l2']),'numerics: zero input exactly zero')
            zero_hashes+=row['output_sha256']==zero_sha
        name=row['graph_id']
        if name is not None:
            gate(name in graphs and row['output_data_ptr']==graphs[name]['output']['data_ptr'],'numerics: actual retained allocation')
            if not row['exact_zero_required']:outputs[name].add(row['output_sha256'])
    gate(zeros==(5 if history else 3),'numerics: complete zero checks')
    for block in result['graph_controls']['blocks']:
        for row in block['measurements']:
            gate(by_label[row['correctness_check']]['graph_id']==row['graph_id'],'numerics: timed allocation checked')
    for row in result['binding_acceptance_checks']:
        gate(row['accepted'] and (row['used_descriptor']==[] if row['tactic']==-1 else row['used_descriptor']==[1]),'native: no explicit descriptor fallback')
    poison=result['actual_layer']['native_output_poison_checks']
    gate(len(poison)==len(result['binding_acceptance_checks'])==(11 if history else 9),'numerics: actual native poisoning coverage')
    gate(all(row['poisoned_actual_allocation'] is (not row['capturing'])for row in poison),'numerics: poison outside actual capture')
    return {'checks':len(checks),'zero_checks':zeros,'positive_zero_byte_hashes':zero_hashes,'nonzero_output_hashes_by_graph':{key:len(value)for key,value in outputs.items()}}

def one_worker(root,record,manifest,plan,fixture,expected_native):
    path=root/record['raw_name'];result=load(path);env=result['environment'];extra=result['selection_history'];controls=result['graph_controls']
    raw_name=path.stem;gate(result['status']=='success' and result['arm']=='auto' and result['mode']=='timing','worker: successful fixed-auto process')
    gate(result['trial']==record['trial'] and result['seed']==19 and result['shape']==[144,4096,1024],'worker: fixed fixture geometry')
    gate(extra['history_enabled']==bool(record['history']) and extra['inline_fingerprinting']==bool(record['fingerprint']),'worker: scheduled factors')
    gate(result['worker_sha256']==manifest['source_sha256'][plan['protocol']['worker']],'source: worker frozen blob')
    gate(env['sglang_commit']==ARGS.commit and env['sglang_wrapper_sha256']==plan['environment']['sglang_wrapper_sha256'],'source: actual execution commit and wrapper')
    gate(env['torch']==plan['environment']['torch'] and env['torch_cuda']==plan['environment']['torch_cuda'] and env['physical_gpu_uuid']==plan['environment']['physical_gpu_uuid'],'source: same software and physical GPU')
    gate(env['flashinfer']=='0.7.2' and env['measurement_policy'] is None and env['LD_PRELOAD'] in (None,'') and not env['managed_store'],'source: old-source auto without managed store or preload')
    gate(env['flashinfer_autotune_cache_sha256']==plan['flashinfer_source']['autotune_cache_sha256'],'source: exact policy module')
    gate(env['native_artifact']['source_sha256']==expected_native and env['flashinfer_tuner_sha256']==expected_native['flashinfer/autotuner/autotuner.py'],'native: exact seven source files')
    for filename,value in env['helper_sha256'].items():
        gate(manifest['source_sha256'].get('test/manual/kernels/'+filename)==value,'source: helper frozen blob')
    gate(result['manifest_sha256']==plan['flashinfer_source']['source_manifest_sha256'],'source: overlay manifest')
    gate(result['fixture']['manifest_sha256']==plan['fixture']['manifest_sha256'] and result['fixture']['tensor_file_sha256']==plan['fixture']['tensor_file_sha256'],'fixture: file identities')
    gate(env['operand_sha256']=={key:value['sha256']for key,value in fixture['tensors'].items()},'fixture: exact public operand bytes')
    gate(result['actual_layer']['quantization_reference']['byte_match'] and result['actual_layer']['quantization_reference']['actual_input_fp8_sha256']==fixture['quantization']['independent_input_fp8_sha256'],'fixture: actual quantizer bytes')
    gate(result['actual_layer']['inference_mode'] and not result['actual_layer']['grad_enabled'] and not result['actual_layer']['allow_tf32'] and not result['actual_layer']['torch_profiler_enabled'],'source: actual normal inference path')
    for row in result['actual_layer']['observed_public_inputs']:
        gate(row['backend']=='cublas' and row['inputs'][0]['shape']==[1,144,1024] and row['inputs'][1]['stride']==[1024,1,1024],'fixture: actual public BMM facade')
        if 'quantized_input_sha256'in row:
            gate(row['quantized_input_sha256']==fixture['quantization']['independent_input_fp8_sha256'] and row['weight_rowmajor_sha256']==fixture['tensors']['weight_fp8_rowmajor']['sha256'],'fixture: observed public activation and weight hashes')
    profiles=result['profiles'];gate(result['profile_attempts']==len(profiles)==81 and result['forbidden_profile_attempts']==[],'profile: all attempts confined to81 startup rows')
    grouped=collections.OrderedDict()
    for row in profiles:
        gate(row['stage']=='startup' and row.get('error')is None and finite(row['profiler_ms']) and row['profiler_ms']>0,'profile: real finite startup timing')
        grouped.setdefault(normalized(row['normalized_profile']),[]).append(row)
        settings=row['autotuner_settings'];config=settings['config']
        gate(all(settings[key]==value for key,value in [('warmup',3),('repeat',10),('stream_delay_micro_secs',5000),('cuda_graph_delay_micro_secs',100),('use_global_timer',False),('effective_measure_policy',None),('effective_policy_timer',None)]),'profile: unchanged timer settings')
        gate(config=={'use_cuda_graph':False,'use_cold_l2_cache':False,'cuda_graph_profile_replays':1,'profiling_repeat':None,'effective_profiling_repeat':10} and row['default_race_enabled'],'profile: actual auto/hot default race')
        gate(row['fingerprinted']==bool(record['fingerprint']),'fingerprint: honest row coverage')
        values=result['profiling_input_groups'][row['profiling_input_group']]
        gate(sha_bytes(normalized(values).encode())==row['profiling_input_group'],'fingerprint: metadata/full-hash group identity')
        for operand,value in values.items():
            gate(set(value)==({'shape','stride','dtype','sha256'}if record['fingerprint']else{'shape','stride','dtype'}),'fingerprint: no fabricated F0 byte proof')
            if record['fingerprint']:gate(len(value['sha256'])==64,'fingerprint: exact full SHA representation')
    gate(len(grouped)==9 and [rows[0]['input_shapes'][0][1]for rows in grouped.values()]==MS,'profile: nine actual measured M values')
    gate(sum(row['tactic']==-1 for row in profiles)==9,'profile: default in every bucket')
    orders=[]
    for rows in grouped.values():
        gate(len(rows)==9 and rows[0]['tactic']==-1 and len({normalized(row['tactic'])for row in rows})==9,'profile: default-first eight-descriptor race')
        orders.append([row['tactic']for row in rows])
    summary=result['runtime_profile_summary'];runtime=[row for row in profiles if row['normalized_profile']==summary['normalized_profile']]
    gate(runtime[0]['input_shapes'][0]==[1,144,1024] and summary['normalized_profile'][0]==[1,256,1024],'profile: measured endpoint distinct from cache bucket')
    minimum=min(row['profiler_ms']for row in runtime);default=runtime[0]['profiler_ms'];best=min(row['profiler_ms']for row in runtime[1:]);winner=result['natural']['tactic']
    gate(any(row['tactic']==winner and row['profiler_ms']==minimum for row in runtime),'profile: actual natural finite minimum')
    gate(summary['minimum_ms']==minimum and close(summary['best_explicit_over_default'],best/default) and close(extra['runtime_best_explicit_over_default_profile'],best/default),'profile: independently reconstructed margin')
    cache=result['cache'];cache_path=root/'caches'/Path(cache['path']).name;saved=load(cache_path)
    gate(sha(cache_path)==cache['after_startup_sha256']==cache['after_controls_sha256'],'cache: unchanged incidental v1 file bytes')
    gate(cache['before_sha256']is None and cache['incidental_legacy_entries']==9 and not cache['persistence_under_test'],'cache: fresh state and bounded save-only claim')
    generation=saved.pop('_generation')
    gate(generation==sha_bytes(normalized(saved).encode()),'cache: real file generation')
    entries={key:value for key,value in saved.items()if key.startswith('(')};gate(len(entries)==9,'cache: nine real saved winners')
    for key,value in entries.items():
        clean=key.replace('torch.float8_e4m3fn',repr('float8')).replace('torch.bfloat16',repr('bf16'))
        shapes=ast.literal_eval(clean)[2];rows=grouped[normalized(shapes)]
        gate(value[0]=='CublasFp8GemmRunner' and any(value[1]==row['tactic'] and row['profiler_ms']==min(item['profiler_ms']for item in rows)for row in rows),'cache: every saved tactic is measured minimum')
    gate(entries[cache['runtime_file_key']][1]==winner and result['natural']['cache_hit'] and result['natural']['lookup_tier']=='memory','cache: natural winner matches memory hit and save')
    for scope in controls['miss_scope']:
        gate(scope['restored'] and scope['all_cache_state_restored'] and scope['winner_entries_after_removal']==scope['file_entries_after_removal']==0,'cache: genuine miss and full restoration')
        gate(scope['cache_sha256_before']==scope['cache_sha256_after']==cache['after_startup_sha256'] and scope['winner_contents_sha256_before']==scope['winner_contents_sha256_after'] and scope['file_contents_sha256_before']==scope['file_contents_sha256_after'],'cache: state and file hashes restored')
    gate(len(controls['miss_scope'])==1 and cache['miss_scopes_restored'],'cache: exactly one default control scope')
    order=['winner','default']if record['capture_order']=='winner-first'else['default','winner']
    gate(controls['capture_order']==extra['requested_capture_order']==order,'capture: independent scheduled order')
    graphs={row['id']:row for row in controls['graphs']};gate(set(graphs)=={'winner','default'},'capture: primary graph counters isolated')
    if record['history']:
        hist=extra['history'];graphs['pre_default']=hist['graph']
        gate(hist['retained_through_end'] and hist['profile_attempts_before']==hist['profile_attempts_after']==0 and hist['cache_before']==hist['cache_after'],'history: no tuning or cache mutation')
        gate(hist['measurement']['ended_ns']<controls['startup_started_ns'],'history: exact recipe precedes startup')
        gate(len(hist['measurement']['measurement']['samples_ms'])==15 and hist['measurement']['measurement']['warmup_actual_ms']>=500,'history: actual old warmup and15 samples')
    else:gate(extra['history']is None,'history: H0 owns no history graph')
    gate(len({row['output']['data_ptr']for row in graphs.values()})==len(graphs) and len({row['graph_object_id']for row in graphs.values()})==len(graphs),'capture: distinct live objects and owned outputs')
    for name,row in graphs.items():
        expected=winner if name=='winner'else-1;tier='memory'if name=='winner'else'miss'
        gate(row['tactic']==expected and row['lookup_tier']==tier and row['selection']['cache_hit']==(tier=='memory'),'capture: actual matching hit or genuine miss')
        gate(row['selection']['capturing'] and not row['selection']['is_tuning_mode'],'capture: no tuning during graph capture')
        gate(row['inputs'][4]['data_ptr']==row['output']['data_ptr'] and row['quantized_input_sha256']==fixture['quantization']['independent_input_fp8_sha256'],'capture: actual output view and quantized fixture')
    for scope in result['objective']['scope_records']:
        gate(scope['measurement_policy']is None and scope['winner_identity']=='None' and not scope['managed_store'],'scope: unspecified policy throughout')
        if scope['stage']!='startup':gate(not scope['is_tuning_mode']and scope['tuning_contexts']==0,'scope: replay cannot profile')
    final=result['objective']['final_state'];gate(not any(final[key]for key in ['active_v2','measurement_policy','is_tuning_mode','tuning_contexts','managed_store']) and final['caller_stream_restored'],'scope: final policy/stream restoration')
    gate(extra['synthetic_input_references_retained']is False and extra['profiling_byte_attestation']==('inline_full_hashes'if record['fingerprint']else'metadata_only_no_synthetic_byte_attestation'),'fingerprint: disclosed F0 limitation')
    rng=extra['rng_states'];gate([row['stage']for row in rng]==['before_history','before_startup','after_startup'],'RNG: three actual boundaries')
    for row in rng:
        for key in ['cpu','cuda']:
            raw=base64.b64decode(row[key]['base64'],validate=True)
            gate(len(raw)==row[key]['nbytes']and sha_bytes(raw)==row[key]['sha256'],'RNG: independent byte/hash validation')
    gate(all(rng[0][key]==rng[1][key]for key in ['cpu','cuda']),'RNG: history does not consume generator state')
    schedule=[list(pair)for _ in range(12)for pair in itertools.permutations(['winner','default'])];random.Random(6100+record['trial']).shuffle(schedule)
    gate(controls['schedule']==schedule and controls['schedule_seed']==6100+record['trial'],'timing: paired replay schedule')
    ratios=[];wall=[]
    for index,block in enumerate(controls['blocks']):
        gate(block['index']==index and block['order']==schedule[index],'timing: actual balanced block order')
        measurements={row['graph_id']:row for row in block['measurements']}
        gate([row['graph_id']for row in block['measurements']]==schedule[index],'timing: actual execution order')
        for row in block['measurements']:
            gate(row['iterations']==5120 and row['rewarm_actual_ms']>=20 and not row['policy_scope_active']and not row['tuning_mode'],'timing: raw replay count/rewarm/no tuning')
            gate(row['ended_ns']>row['started_ns']and close(row['wall_batch_ms']/5120,row['wall_per_call_ms'])and close(row['gpu_event_batch_ms']/5120,row['gpu_event_per_call_ms']),'timing: independently normalized intervals')
            gate(all(finite(row[key])and row[key]>0 for key in ['wall_batch_ms','gpu_event_batch_ms']),'timing: positive samples')
        ratios.append(measurements['winner']['gpu_event_per_call_ms']/measurements['default']['gpu_event_per_call_ms'])
        wall.append(measurements['winner']['wall_per_call_ms']/measurements['default']['wall_per_call_ms'])
    gate(len(ratios)==24 and close(statistics.median(ratios),extra['selected_over_default_graph_event_median']),'timing: reconstructed selected/default ratio')
    gate(extra['pre_trace_checks']['profile_attempts']==extra['post_trace_checks']['profile_attempts']==81,'profile: no attempts after startup or during trace')
    gate(all(extra['pre_trace_checks'][key]==extra['post_trace_checks'][key]for key in ['file_sha256','winner_sha256','loaded_file_sha256']),'cache: posttrace state unchanged')
    numeric=numeric_audit(result,graphs);trace=trace_audit(result,graphs,root)
    container=(root/(raw_name+'.container-id')).read_text().strip();gate(len(container)==64,'worker: real fresh container identity')
    return {'name':raw_name,'trial':record['trial'],'cell':record['cell'],'container_id':container,'tactic':winner,'profile_margin':best/default,'graph_event_ratio':statistics.median(ratios),'graph_wall_ratio':statistics.median(wall),'numeric':numeric,'trace':trace,'rng_sha256':{row['stage']:{key:row[key]['sha256']for key in ['cpu','cuda']}for row in rng},'profiling_input_groups':result['profiling_input_groups'],'profiling_metadata_domain':sorted(normalized({name:{key:value for key,value in values.items()if key!='sha256'}for name,values in group.items()})for group in result['profiling_input_groups'].values()),'candidate_orders':orders,'native_sha256':env['native_artifact']['library_sha256'],'ninja_sha256':env['native_artifact']['ninja_sha256'],'raw_sha256':sha(path)}

def main():
    global ARGS
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--root',type=Path,required=True);parser.add_argument('--source-root',type=Path,default=Path('/private/tmp/sglang-autotune-selection-study'));parser.add_argument('--commit',required=True);parser.add_argument('--trials',nargs='+',type=int,default=list(range(8)));parser.add_argument('--output',type=Path,required=True);ARGS=parser.parse_args()
    root=ARGS.root;plan=json.loads(frozen_blob(BATCH+'/plan.json'));fixture=load(root/'fixture/manifest.json');manifest=load(root/'manifest.json')
    gate((root/'execution-commit.txt').read_text().strip()==ARGS.commit,'source: outer execution commit')
    gate(manifest['plan_sha256']==sha_bytes(frozen_blob(BATCH+'/plan.json')),'source: frozen plan')
    gate(plan['container_image']in load(root/'image.json')['RepoDigests']and load(root/'image.json')['Architecture']=='amd64','source: exact container image')
    for path,value in manifest['source_sha256'].items():gate(sha_bytes(frozen_blob(path))==value,'source: every outer manifest blob')
    source_manifest=json.loads(frozen_blob(SOURCE_MANIFEST));expected={row['installed_package_path']:row['candidate_sha256']for row in source_manifest['files']if row['runtime_overlay']}
    gate(sha(root/'fixture/manifest.json')==plan['fixture']['manifest_sha256'],'fixture: original capture manifest')
    fixture_path=root/'fixture/fixture.safetensors';gate(sha(fixture_path)==plan['fixture']['tensor_file_sha256'],'fixture: original private tensor file')
    payloads=tensor_payloads(fixture_path)
    for name,(meta,data)in payloads.items():gate(sha_bytes(data)==fixture['tensors'][name]['sha256'],'fixture: each original tensor payload')
    weight=payloads['weight_fp8_rowmajor'][1];transposed=b''.join(weight[index::1024]for index in range(1024));weight_profile_sha=sha_bytes(transposed)
    rows=[]
    for record in plan['protocol']['worker_schedule']:
        if record['trial']not in ARGS.trials:continue
        try:rows.append(one_worker(root,record,manifest,plan,fixture,expected))
        except Exception as error:ERRORS.append({'worker':record['raw_name'],'error_type':type(error).__name__,'error':str(error)})
    gate(len(rows)==4*len(ARGS.trials),'worker: complete successful scheduled set')
    gate(len({row['container_id']for row in rows})==len(rows),'worker: fresh container per cell')
    gate(all(row['candidate_orders']==rows[0]['candidate_orders']for row in rows),'profile: identical candidate identity and order across cells')
    gate(all(row['profiling_metadata_domain']==rows[0]['profiling_metadata_domain']for row in rows),'profile: identical defined operand shapes/strides/dtypes across cells')
    gate(all(row['rng_sha256']==rows[0]['rng_sha256']for row in rows),'RNG: identical full generator footprint across cells/trials')
    f1=[row for row in rows if 'f1'in row['cell']]
    gate(all(row['profiling_input_groups']==f1[0]['profiling_input_groups']for row in f1),'fingerprint: actual synthetic bytes equal across F1 cells')
    for row in f1:
        for values in row['profiling_input_groups'].values():gate(values['weight']['sha256']==weight_profile_sha and values['input_scale']['sha256']==fixture['tensors']['input_scale']['sha256']and values['weight_scale']['sha256']==fixture['tensors']['weight_scale']['sha256'],'fingerprint: actual profiling static operand bytes')
    library=root/'native-builds/candidate/gemm.so';ninja=root/'native-builds/candidate/build.ninja'
    gate(all(row['native_sha256']==sha(library)and row['ninja_sha256']==sha(ninja)for row in rows),'native: actual private ELF and ninja bytes')
    ninja_text=ninja.read_text();translation_units=re.findall(r'^build .+: (?:cuda_compile|compile) (.+)$',ninja_text,re.M)
    gate(len(translation_units)==3 and {Path(path).name for path in translation_units}=={'bmm_fp8.cu','group_gemm.cu','flashinfer_gemm_binding.cu'},'native: exactly three FP8 translation units')
    gate('-gencode=arch=compute_90a,code=sm_90a' in ninja_text,'native: correct compiled architecture')

    cell_summary={}
    for cell in plan['protocol']['cells']:
        own=[row for row in rows if row['cell']==cell]
        cell_summary[cell]={'workers':len(own),'default_winners':sum(row['tactic']==-1 for row in own),'explicit_winners':sum(row['tactic']!=-1 for row in own),'profile_margins':[row['profile_margin']for row in own],'graph_event_ratios':[row['graph_event_ratio']for row in own],'same_primary_signature_sequence':sum(row['trace']['same_primary_signature_sequence']for row in own)}
    output={'status':'success'if not ERRORS else'error','source_commit':ARGS.commit,'audit_script_sha256':sha(__file__),'raw_root':str(root),'trials':ARGS.trials,'workers':len(rows),'profiles':81*len(rows),'default_profiles':9*len(rows),'forbidden_profile_attempts':0,'numeric_checks':sum(row['numeric']['checks']for row in rows),'zero_checks':sum(row['numeric']['zero_checks']for row in rows),'positive_zero_hashes':sum(row['numeric']['positive_zero_byte_hashes']for row in rows),'check_categories':dict(COUNTS),'errors':ERRORS,'cells':cell_summary,'workers_detail':[{key:value for key,value in row.items()if key not in ['profiling_input_groups','profiling_metadata_domain','candidate_orders','container_id']}for row in rows],'limits':['Independent standard-library audit of preserved metadata, raw trace events, fixture payloads and cache/native bytes. GPU output arrays are not retained, so general error metrics are not rederived from output tensors.','F0 has metadata and generator-state consistency, not direct synthetic operand-byte attestation.','Trace durations do not enter latency ratios; same/different valid kernel signatures are outcomes, not integrity gates.','Incidental v1 save is checked, but no fresh-process persistence behavior is claimed.']}
    ARGS.output.write_text(json.dumps(output,indent=2,allow_nan=False)+'\n');print(json.dumps({key:output[key]for key in ['status','workers','profiles','numeric_checks','zero_checks','errors']}));return 0 if output['status']=='success' else 1

if __name__=='__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        if 'ARGS' in globals():
            ARGS.output.write_text(json.dumps({'status':'error','source_commit':ARGS.commit,'audit_script_sha256':sha(__file__),'check_categories':dict(COUNTS),'errors':ERRORS,'fatal_error':{'type':type(error).__name__,'message':str(error)}},indent=2)+'\n')
        raise

