"""Derive a compact working summary from the independently audited raw study."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
audit = json.loads((ROOT / "final-audit.json").read_text())
selected = [row for row in audit["workers"] if row["winner"] != -1]
summary = {
    "status": "FINAL_immutable_derived_summary",
    "source_commit": audit["source_commit"],
    "scope": "32 fresh workers,8 complete H0/H1 by F0/F1 blocks, fixed source/auto objective and captured144x4096x1024 QKV fixture on the same H100 NVL.",
    "independent_audit": {"path": str(ROOT / "final-audit.json"),
                          "sha256": hashlib.sha256((ROOT / "final-audit.json").read_bytes()).hexdigest(),
                          "official_numeric_comparisons": audit["official_comparison"]["independent_numeric_comparisons"]},
    "totals": audit["totals"],
    "selection_counts": [
        {"cell": cell, "default": sum(row["winner"] == -1 for row in audit["workers"] if row["cell"] == cell),
         "explicit": sum(row["winner"] != -1 for row in audit["workers"] if row["cell"] == cell)}
        for cell in ("h0f0", "h0f1", "h1f0", "h1f1")
    ],
    "explicit_cases": [
        {"trial": row["trial"], "cell": row["cell"],
         "profile_explicit_advantage_percent": -row["profile_margin_percent"],
         "actual_graph_selected_over_default": row["scores"]["gpu_event"]["median_pair_ratio"],
         "actual_GEMM_signature_differs": not row["trace"]["same_ordered_kernel_signatures"]}
        for row in selected
    ],
    "primary_factorial_estimates": [row for row in audit["factorial_effects"] if row["measure"] != "serving_wall"],
    "same_default_same_kernel_capture_association": audit["capture_order_association"],
    "findings": [
        "All natural choices equal actual finite profile minima; the selection loop and cache-hit consumption behaved correctly.",
        "Default won29of32; three naturally chosen explicit candidates measured18.90–21.99percent slower in the retained serving graph than their own default. These are runtime comparisons, not startup cost.",
        "The continuous profiler-margin H/F/interaction intervals all include1; this fixed sample does not isolate a stable explanation for the sporadic explicit wins.",
        "The serving fingerprint-main contrast is1.00133 with exploratory unadjusted interval[1.00038,1.00776]. Preserve this estimate, without a significance/equivalence claim or treating it as a pure profiling-observer cost.",
        "Among natural-default cases with equal actual same-worker launch signatures, H0 first-capture medians are about0.92–0.94percent slower, all7cases per H0cell. H1 patterns are mixed. This is a posthoc subgroup, not an independent causal test.",
        "Same-worker post-timing traces now establish actual launch signatures for these retained objects; equal signatures still do not equate memory mapping, GPU state or host submission gaps.",
    ],
    "interpretation": "No uniform selection-quality improvement or clean H/F attribution established. Large explicit-candidate runtime regressions remain alongside subpercent retained-graph measurement sensitivity.",
    "next_bounded_decision": "Complete the separately preregistered six-process replay-method calibration before interpreting subpercent effects or changing policy/upstream preparation. No new experiment was launched by this summary.",
    "limits": audit["limits"] + [
        "F0 has metadata/RNG evidence without direct synthetic profiling tensor-byte hashes.",
        "Full-model serving, trained-FP8 calibration, TP/EP and workload generalization remain unqualified.",
        "Attempt01 failed in the post-timing trace reader and remains preserved as an error; this32worker result uses the full fresh attempt02 after the CPU annotation-category fix.",
        "The factorial includes any resulting candidate-identity change; it is not an isolated host-cost measurement.",
    ],
    "summary_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
path = ROOT / "final-summary.json"
path.write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({"path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest()}))
