#!/usr/bin/env python3
"""Independent raw arithmetic/evidence audit; imports no experiment analyzer."""

from __future__ import annotations

import argparse
import collections
import functools
import hashlib
import itertools
import json
import math
import statistics
from pathlib import Path

SOURCE_COMMIT = "bdcd1d9bf844022bae45652c1a7979f3fe8477bd"
PLAN_SHA = "44aed74be70eae283dab2fd4e2bcbefca5d906fc15eb35fbda775337ec9f4544"
SOURCE_ROOT = Path("/private/tmp/sglang-autotune-selection-study")
BATCH = "test/manual/kernels/results/flashinfer_autotune_selection/20261024T080000Z-h100-selection-history"
CELLS = ("h0f0", "h0f1", "h1f0", "h1f1")


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check(condition, reason):
    if not condition:
        raise ValueError(reason)


def close(a, b, reason):
    check(math.isfinite(a) and math.isfinite(b)
          and math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-14), reason)


def median(values):
    values = sorted(values)
    check(bool(values), "empty median")
    middle = len(values) // 2
    return values[middle] if len(values) % 2 else (values[middle - 1] + values[middle]) / 2


def positive(value):
    return type(value) in (int, float) and math.isfinite(value) and value > 0


def compositions(total, bins):
    """Enumerate integer occupancy vectors, not analyzer index multisets."""
    if bins == 1:
        yield (total,)
    else:
        for first in range(total + 1):
            for suffix in compositions(total - first, bins - 1):
                yield (first,) + suffix


@functools.lru_cache(None)
def resampling_occupancies(n):
    factorial = math.factorial(n)
    rows = []
    for counts in compositions(n, n):
        multiplicity = factorial
        for count in counts:
            multiplicity //= math.factorial(count)
        rows.append((counts, multiplicity))
    check(sum(weight for _, weight in rows) == n**n, "occupancy resampling total")
    return tuple(rows)


def bootstrap_distribution(values):
    mass = collections.Counter()
    for counts, weight in resampling_occupancies(len(values)):
        sample = []
        for value, count in zip(values, counts):
            sample.extend([value] * count)
        mass[median(sample)] += weight
    return mass


def percentile_mass(mass, q):
    total = sum(mass.values())
    position = (total - 1) * q
    left, right = math.floor(position), math.ceil(position)

    def value_at(index):
        cumulative = 0
        for value, weight in sorted(mass.items()):
            cumulative += weight
            if index < cumulative:
                return value
        raise ValueError("bootstrap order statistic outside population")
    return value_at(left) * (right - position) + value_at(right) * (position - left) if right > left else value_at(left)


def describe_trials(trial_values):
    check(len({trial for trial, _ in trial_values}) == len(trial_values), "trial IDs repeated")
    values = [value for _, value in trial_values]
    check(all(positive(value) for value in values), "nonpositive trial ratio")
    uncertainty = None
    if len(values) > 1:
        mass = bootstrap_distribution(values)
        uncertainty = [percentile_mass(mass, 0.025), percentile_mass(mass, 0.975)]
    return {
        "n_complete_repetitions": len(values), "trial_values": trial_values,
        "median": median(values), "range": [min(values), max(values)],
        "below_one": sum(value < 1 for value in values), "above_one": sum(value > 1 for value in values),
        "exploratory_block_bootstrap95": uncertainty,
    }


def independent_factor_effects(values):
    """Multiply the two conditional effects, then take their geometric mean."""
    history_when_unobserved = values["h1f0"] / values["h0f0"]
    history_when_observed = values["h1f1"] / values["h0f1"]
    observation_without_history = values["h0f1"] / values["h0f0"]
    observation_with_history = values["h1f1"] / values["h1f0"]
    return {
        "history_main": math.sqrt(history_when_unobserved * history_when_observed),
        "fingerprint_main": math.sqrt(observation_without_history * observation_with_history),
        "interaction": observation_with_history / observation_without_history,
    }


def paired_scores(blocks, channel):
    key = "gpu_event_per_call_ms" if channel == "gpu_event" else "wall_per_call_ms"
    ratios, absolute, by_position = [], collections.defaultdict(list), collections.defaultdict(list)
    for block in blocks:
        rows = {row["graph_id"]: row for row in block["measurements"]}
        check(set(rows) == {"winner", "default"}, "paired batch lost an arm")
        ratio = rows["winner"][key] / rows["default"][key]
        check(positive(ratio), "invalid same-block ratio")
        ratios.append(ratio)
        for graph_id in ("winner", "default"):
            absolute[graph_id].append(rows[graph_id][key])
            by_position[graph_id, block["order"].index(graph_id)].append(rows[graph_id][key])
    return {
        "paired_ratios": ratios, "median_pair_ratio": median(ratios),
        "graph_medians_ms": {name: median(values) for name, values in absolute.items()},
        "same_graph_first_replay_over_second": {
            name: median(by_position[name, 0]) / median(by_position[name, 1])
            for name in ("winner", "default") if by_position[name, 0] and by_position[name, 1]
        },
    }


def native_signature(event):
    args = event["args"]
    return [event["name"], args["device"], args["grid"], args["block"],
            args["registers per thread"], args["shared memory"]]


def actual_trace(data, raw):
    evidence = data["selection_history"]
    trace = evidence["post_timing_trace"]
    path = raw / Path(trace["path"]).name
    check(digest(path) == trace["sha256"], "actual trace digest mismatch")
    latest_batch = max(row["ended_ns"] for group in data["graph_controls"]["blocks"] for row in group["measurements"])
    check(latest_batch < evidence["pre_trace_checks"]["ended_ns"] < trace["started_ns"]
          < trace["ended_ns"] < evidence["post_trace_checks"]["ended_ns"], "trace predates primary latency completion")
    captures = {row["id"]: row for row in data["graph_controls"]["graphs"]}
    trace_rows = {row["graph_id"]: row for row in trace["graphs"]}
    events = read(path)["traceEvents"]
    results, all_correlations = {}, set()
    for name in ("winner", "default"):
        row, capture = trace_rows[name], captures[name]
        check(row["graph_object_id"] == capture["graph_object_id"]
              and row["output_data_ptr"] == capture["output"]["data_ptr"],
              "post-timing observation used a substituted graph/output")
        scope = [event for event in events if event.get("cat") == "user_annotation"
                 and event.get("name") == "retained_" + name]
        check(len(scope) == 1, "missing original graph label")
        begin, end = scope[0]["ts"], scope[0]["ts"] + scope[0]["dur"]
        launches = sorted([event for event in events if event.get("cat") == "cuda_runtime"
                           and "cudaGraphLaunch" in event.get("name", "")
                           and begin <= event["ts"] <= end], key=lambda event: event["ts"])
        check(len(launches) == 3, "retained graph replay count")
        cycles, identities = [], set()
        for launch in launches:
            correlation = launch["args"]["correlation"]
            check(correlation not in all_correlations, "launch correlation reused")
            all_correlations.add(correlation)
            kernels = sorted([event for event in events if event.get("cat") == "kernel"
                              and event.get("args", {}).get("correlation") == correlation],
                             key=lambda event: event["ts"])
            check(len(kernels) == 2, "quantizer/GEMM pair not present")
            check(all(begin <= event["ts"] < event["ts"] + event["dur"] <= end + 1 for event in kernels),
                  "GPU launch escapes its graph annotation")
            identities.update(event["args"]["graph id"] for event in kernels)
            cycles.append([native_signature(event) for event in kernels])
        check(len(identities) == 1 and next(iter(identities)) > 0, "unstable actual CUDA graph identity")
        check(cycles[0] == cycles[1] == cycles[2], "retained graph launches differ between trace cycles")
        check("static_quant_fp8" in cycles[0][0][0], "actual serving quantizer missing")
        results[name] = {"cuda_graph_id": next(iter(identities)), "signature": cycles[0],
                         "python_graph_object_id": capture["graph_object_id"],
                         "output_ptr": capture["output"]["data_ptr"]}
    check(results["winner"]["cuda_graph_id"] != results["default"]["cuda_graph_id"], "same CUDA graph relabeled as both")
    check(results["winner"]["output_ptr"] != results["default"]["output_ptr"], "shared primary output")
    check(len([event for event in events if event.get("cat") == "kernel"]) == 12, "unexpected trace kernel workload")
    return {
        "path": str(path), "sha256": digest(path), "graphs": results,
        "same_ordered_kernel_signatures": results["winner"]["signature"] == results["default"]["signature"],
        "scope": "Same retained graphs after timing; instrumented durations are not performance estimates.",
    }


def audit_worker(path, scheduled, raw, source_commit):
    data = read(path)
    check(data["status"] == "success", f"worker failure: {path.name}")
    check(path.with_suffix(".exit-code").read_text().strip() == "0", "worker exit failure")
    check(data["environment"]["sglang_commit"] == source_commit, "wrong source execution")
    check(data["trial"] == scheduled["trial"] and data["arm"] == "auto", "wrong trial/objective")
    evidence = data["selection_history"]
    check(evidence["history_enabled"] == bool(scheduled["history"])
          and evidence["inline_fingerprinting"] == bool(scheduled["fingerprint"]), "wrong factorial cell")
    check((evidence["history"] is not None) == bool(scheduled["history"]), "history factor not executed")
    check(evidence["synthetic_input_references_retained"] is False, "input refs retained")
    for operands in data["profiling_input_groups"].values():
        for tensor in operands.values():
            check(("sha256" in tensor) == bool(scheduled["fingerprint"]), "fabricated/missing byte attestation")
    check(data["profile_attempts"] == len(data["profiles"]) and not data["forbidden_profile_attempts"],
          "post-startup or unrecorded profiler attempts")
    for generator in ("cpu", "cuda"):
        check(evidence["rng_states"][0][generator] == evidence["rng_states"][1][generator], "history consumed RNG")
    check(data["natural"]["cache_hit"] is True and data["natural"]["lookup_tier"] == "memory", "natural fallback accepted as hit")
    if data["natural"]["tactic"] != -1:
        check(data["natural"]["acceptance"]["used_descriptor"] == [1], "descriptor silently fell back")
    expected_key = [[1, 256, 1024], [1, 1024, 4096], [1], [1], [1, -1, 4096], [-1]]
    runtime = [row for row in data["profiles"] if row["normalized_profile"] == expected_key]
    check(runtime and runtime[0]["tactic"] == -1, "default did not participate first")
    finite = [row for row in runtime if row.get("profiler_ms") is not None]
    check(all(positive(row["profiler_ms"]) for row in finite), "nonfinite profile")
    default = next(row["profiler_ms"] for row in finite if row["tactic"] == -1)
    explicit = min(row["profiler_ms"] for row in finite if row["tactic"] != -1)
    winner = min(finite, key=lambda row: row["profiler_ms"])["tactic"]
    check(winner == data["natural"]["tactic"], "natural winner not first finite minimum")
    profile_ratio = explicit / default
    close(profile_ratio, evidence["runtime_best_explicit_over_default_profile"], "producer profile ratio")
    blocks = data["graph_controls"]["blocks"]
    check(len(blocks) == 24, "wrong replay block count")
    check(collections.Counter(tuple(group["order"]) for group in blocks) ==
          collections.Counter({("winner", "default"): 12, ("default", "winner"): 12}), "replay orders not balanced")
    scores = {}
    for channel in ("gpu_event", "wall"):
        for group in blocks:
            for row in group["measurements"]:
                check(row["iterations"] == 5120, "replay iterations changed")
                batch_key = "gpu_event_batch_ms" if channel == "gpu_event" else "wall_batch_ms"
                per_key = "gpu_event_per_call_ms" if channel == "gpu_event" else "wall_per_call_ms"
                close(row[batch_key] / 5120, row[per_key], "raw replay normalization")
        scores[channel] = paired_scores(blocks, channel)
    close(scores["gpu_event"]["median_pair_ratio"], evidence["selected_over_default_graph_event_median"],
          "producer serving ratio")
    trace = actual_trace(data, raw)
    check(data["cache"]["after_startup_sha256"] == data["cache"]["after_controls_sha256"], "cache changed during controls")
    check(evidence["pre_trace_checks"]["profile_attempts"] == evidence["post_trace_checks"]["profile_attempts"] ==
          data["profile_attempts"], "trace started profiling")
    checks = data["correctness"]["checks"]
    check(data["correctness"]["passed"] is True, "numerical failure")
    check(all(row["quantized_reference"]["passed"] and row["quantized_reference"]["max_normalized_error"] <= 1 for row in checks),
          "invalid numerical reference")
    for row in checks:
        if row["check"].endswith("_changed_input"):
            check(row["exact_zero_required"] and row["quantized_reference"]["max_abs_error"] == 0,
                  "changed-input replay did not produce exact zero")
    capture_order = data["graph_controls"]["capture_order"]
    expected_order = ["winner", "default"] if scheduled["capture_order"] == "winner-first" else ["default", "winner"]
    check(capture_order == expected_order, "capture order deviated")
    ratio = scores["gpu_event"]["median_pair_ratio"]
    first_capture_score = ratio if capture_order[0] == "winner" else 1 / ratio
    return {
        "trial": scheduled["trial"], "cell": scheduled["cell"], "worker": str(path), "sha256": digest(path),
        "container_id": path.with_suffix(".container-id").read_text().strip(),
        "winner": winner, "default_profile_ms": default, "best_explicit_profile_ms": explicit,
        "profile_ratio": profile_ratio, "profile_margin_percent": 100 * (profile_ratio - 1),
        "scores": scores, "capture_order": capture_order,
        "same_default_first_capture_over_second": first_capture_score if winner == -1 and trace["same_ordered_kernel_signatures"] else None,
        "trace": trace, "numeric_checks": len(checks), "candidate_failures": [row for row in data["profiles"] if row.get("profiler_ms") is None],
        "initial_public_call_ms": data["initial_public_call_ms"], "startup_ms": data["startup_ms"],
        "native_library_sha256": data["environment"]["native_artifact"]["library_sha256"],
        "native_ninja_sha256": data["environment"]["native_artifact"]["ninja_sha256"],
        "fixture_sha256": data["fixture"]["tensor_file_sha256"],
        "profile_count": len(data["profiles"]),
    }


def audit(args):
    check(args.source_commit == SOURCE_COMMIT, "exact frozen execution commit")
    check(digest(args.plan) == PLAN_SHA, "preregistered plan digest")
    plan = read(args.plan)
    schedule = [row for row in plan["protocol"]["worker_schedule"] if row["trial"] in args.trials]
    check(len(schedule) == len(args.trials) * 4 and len({row["raw_name"] for row in schedule}) == len(schedule), "incomplete blocked schedule")
    rows = [audit_worker(args.raw_root / scheduled["raw_name"], scheduled, args.raw_root, args.source_commit)
            for scheduled in schedule]
    check(len({row["container_id"] for row in rows}) == len(rows), "worker container reused")
    for field in ("native_library_sha256", "native_ninja_sha256", "fixture_sha256"):
        check(len({row[field] for row in rows}) == 1, "cohort provenance changed: " + field)
    by_trial = collections.defaultdict(dict)
    for row in rows:
        by_trial[row["trial"]][row["cell"]] = row
    check(all(set(cells) == set(CELLS) for cells in by_trial.values()), "partial trial treated as complete")
    cells, factors = [], []
    for measure in ("profile_margin", "serving_gpu_event", "serving_wall"):
        get_score = lambda row: row["profile_ratio"] if measure == "profile_margin" else row["scores"][measure.removeprefix("serving_")]["median_pair_ratio"]
        for cell in CELLS:
            selected = [(trial, get_score(group[cell])) for trial, group in sorted(by_trial.items())]
            cells.append({"cell": cell, "measure": measure, **describe_trials(selected),
                          "default_winners": sum(group[cell]["winner"] == -1 for group in by_trial.values())})
        per_trial = {trial: independent_factor_effects({cell: get_score(row) for cell, row in group.items()})
                     for trial, group in sorted(by_trial.items())}
        for contrast in ("history_main", "fingerprint_main", "interaction"):
            factors.append({"measure": measure, "contrast": contrast,
                            **describe_trials([(trial, values[contrast]) for trial, values in per_trial.items()])})
    capture = []
    for cell in CELLS:
        subset = [row for row in rows if row["cell"] == cell and row["same_default_first_capture_over_second"] is not None]
        capture.append({"cell": cell, "n": len(subset),
                        "trial_values": [[row["trial"], row["same_default_first_capture_over_second"]] for row in subset],
                        "median": median([row["same_default_first_capture_over_second"] for row in subset]) if subset else None,
                        "scope": "Post hoc descriptive default-winner AND equal observed launch signatures subgroup; not an independent causal estimate."})
    result = {
        "status": "success", "source_commit": args.source_commit, "script_sha256": digest(__file__),
        "plan_sha256": digest(args.plan), "trials": args.trials, "n_complete_repetitions": len(args.trials),
        "workers": rows, "cell_summaries": cells, "factorial_effects": factors,
        "capture_order_association": capture,
        "totals": {"workers": len(rows), "primary_paired_batches": len(rows) * 24,
                   "trace_launches": len(rows) * 6, "numeric_checks": sum(row["numeric_checks"] for row in rows),
                   "profiles": sum(row["profile_count"] for row in rows)},
        "derivation": "Raw same-block division then median. Factor main effects multiply conditional ratios and take square roots; interaction divides conditional observation effects. Bootstrap enumerates integer occupancy compositions with multinomial multiplicities, not analyzer index multisets.",
        "limits": [
            "Eight complete blocked repetitions are inferential units.24blocks/15samples are dependent observations.",
            "Exploratory, unadjusted intervals; no significance/equivalence claim or performance acceptance threshold.",
            "H bundles startup capture, allocations, work and time. F0 does not attest synthetic operand bytes.",
            "Post-timing trace observes actual retained graph signatures; its instrumented durations are not performance.",
            "Same CUDA kernel signatures do not imply identical memory mapping, cache/device state or launch gaps.",
        ],
    }
    if args.official_analysis:
        result["official_comparison"] = compare_official(result, read(args.official_analysis))
    return result


def compare_official(ours, official):
    checks = 0
    check(official["status"] == "success" and official["trials"] == ours["trials"], "official cohort mismatch")
    for table, keys in (("cell_summaries", ("cell", "measure")), ("factorial_effects", ("measure", "contrast"))):
        reference = {tuple(row[key] for key in keys): row for row in official["analysis"][table]}
        for row in ours[table]:
            other = reference[tuple(row[key] for key in keys)]
            check(other["independent_trials"] == row["n_complete_repetitions"], "official trial units")
            own_trials = dict(row["trial_values"])
            for trial in other["trial_estimates"]:
                close(trial["ratio"], own_trials[trial["trial"]], "official per-trial arithmetic")
                checks += 1
            for field, value in (("median_ratio", row["median"]), ("min_ratio", row["range"][0]), ("max_ratio", row["range"][1])):
                close(other[field], value, "official summary arithmetic")
                checks += 1
            interval = other["exploratory_cluster_bootstrap_95_percent"]
            if row["exploratory_block_bootstrap95"] is None:
                check(interval is None, "official n1 interval")
            else:
                close(interval["lower"], row["exploratory_block_bootstrap95"][0], "official exact lower CI")
                close(interval["upper"], row["exploratory_block_bootstrap95"][1], "official exact upper CI")
                checks += 2
    reference_workers = {(row["trial"], row["cell"]): row for row in official["analysis"]["workers"]}
    for row in ours["workers"]:
        other = reference_workers[row["trial"], row["cell"]]
        check(other["winner"] == row["winner"], "official winner mismatch")
        close(other["best_explicit_over_default_profile"], row["profile_ratio"], "official profile score")
        for channel in ("gpu_event", "wall"):
            close(other["serving"][channel]["ratio"], row["scores"][channel]["median_pair_ratio"], "official serving score")
            checks += 1
    return {"status": "pass", "independent_numeric_comparisons": checks,
            "same_defined_estimands_different_factorial_and_bootstrap_derivations": True}


def self_test():
    tests = []
    check(len(resampling_occupancies(8)) == 6435, "count-vector coverage")
    check(sum(weight for _, weight in resampling_occupancies(8)) == 8**8, "8^8 total probability mass")
    tests.append("8trial_occupancy_count_and_mass")
    binary = bootstrap_distribution([1] * 4 + [2] * 4)
    expected = {1: sum(math.comb(8, k) for k in range(4)) * 4**8,
                1.5: math.comb(8, 4) * 4**8,
                2: sum(math.comb(8, k) for k in range(5, 9)) * 4**8}
    check(binary == expected, "independent binomial formula disagrees with8trial weights")
    tests.append("8trial_distribution_matches_closed_form_binomial")
    for n in (3, 4):
        values = [0.8, 1.1, 1.5, 1.7][:n]
        brute = collections.Counter(median([values[index] for index in indices])
                                    for indices in itertools.product(range(n), repeat=n))
        check(bootstrap_distribution(values) == brute, "occupancy vs exhaustive bootstrap")
    tests.append("3_and4trial_bootstrap_matches_ordered_enumeration")
    effects = independent_factor_effects({"h0f0": 1.1, "h0f1": 1.1 * 0.8,
                                          "h1f0": 1.1 * 1.2, "h1f1": 1.1 * 1.2 * 0.8 * 1.3})
    close(effects["history_main"], 1.2 * math.sqrt(1.3), "known history effect")
    close(effects["fingerprint_main"], 0.8 * math.sqrt(1.3), "known observation effect")
    close(effects["interaction"], 1.3, "known interaction")
    tests.append("multiplicative_factorial_effects_known_truth")
    pairs = []
    for index, (winner, default) in enumerate(((1, 1), (100, 1), (100, 100))):
        order = ["winner", "default"] if index % 2 == 0 else ["default", "winner"]
        values = {"winner": winner, "default": default}
        pairs.append({"order": order, "measurements": [
            {"graph_id": name, "gpu_event_per_call_ms": values[name]} for name in order]})
    controlled = paired_scores(pairs, "gpu_event")
    check(controlled["median_pair_ratio"] == 1
          and controlled["graph_medians_ms"]["winner"] / controlled["graph_medians_ms"]["default"] == 100,
          "median of paired ratios was replaced with ratio of medians")
    tests.append("median_paired_ratios_differs_from_ratio_of_medians")
    check(describe_trials([(0, 1)])["exploratory_block_bootstrap95"] is None, "n1 invented CI")
    tests.append("first4_checkpoint_n1_has_no_CI")
    return {"status": "success", "scope": "independent CPU arithmetic controls only",
            "passed": tests, "script_sha256": digest(__file__)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-root", type=Path)
    parser.add_argument("--plan", type=Path, default=SOURCE_ROOT / BATCH / "plan.json")
    parser.add_argument("--source-commit", default=SOURCE_COMMIT)
    parser.add_argument("--official-analysis", type=Path)
    parser.add_argument("--trials", type=int, nargs="+", default=list(range(8)))
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if not args.self_test and args.raw_root is None:
        parser.error("--raw-root is required")
    try:
        result = self_test() if args.self_test else audit(args)
        code = 0
    except Exception as error:
        result = {"status": "error", "error": f"{type(error).__name__}: {error}", "script_sha256": digest(__file__)}
        code = 1
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"status": result["status"], "output": str(args.output), "sha256": digest(args.output)}))
    return code


if __name__ == "__main__":
    raise SystemExit(main())
