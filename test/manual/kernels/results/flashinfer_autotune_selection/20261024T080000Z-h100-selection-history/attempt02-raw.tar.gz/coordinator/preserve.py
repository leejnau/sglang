"""Preserve exact selection-history raw evidence including private native/fixture bytes."""
import argparse,hashlib,json,shutil,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--study',type=Path,required=True);p.add_argument('--batch',required=True);p.add_argument('--attempt',required=True);p.add_argument('--durable',type=Path,required=True)
a=p.parse_args();study=a.study.resolve();raw=study/'results'/a.batch/a.attempt
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
records=[json.loads(f.read_text()) for f in sorted(raw.glob('trial*-*-*.json')) if not f.name.endswith('.trace.json')]
success=[r for r in records if r.get('status')=='success' and r.get('environment',{}).get('native_artifact')]
if success:
 n=success[0]['environment']['native_artifact']
 lib=study/Path(n['library_path']).relative_to('/study')
 assert sha(lib)==n['library_sha256']
 dst=raw/'native-builds/candidate/gemm.so';dst.parent.mkdir(parents=True,exist_ok=True)
 if dst.exists(): assert sha(dst)==sha(lib)
 else: shutil.copyfile(lib,dst)
 (raw/'native-builds/candidate/gemm.so.sha256').write_text(sha(dst)+'\n')
 (raw/'native-builds/candidate/library-provenance.json').write_text(json.dumps(n,indent=2)+'\n')
manifest={str(f.relative_to(raw)):{'sha256':sha(f),'size_bytes':f.stat().st_size} for f in sorted(raw.rglob('*')) if f.is_file() and f.name!='preservation-manifest.json'}
(raw/'preservation-manifest.json').write_text(json.dumps({'schema_version':1,'files':manifest},indent=2)+'\n')
archive=study/(a.batch+'-'+a.attempt+'-full-raw.tgz')
assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:t.add(raw,arcname=a.attempt)
a.durable.mkdir(parents=True,exist_ok=True);durable=a.durable/archive.name;assert not durable.exists();shutil.copyfile(archive,durable)
assert sha(archive)==sha(durable)
print(json.dumps({'node_archive':str(archive),'durable_archive':str(durable),'sha256':sha(archive),'size_bytes':archive.stat().st_size,'members':len(manifest)+1,'worker_records':len(records),'successful_worker_records':len(success)},indent=2))
