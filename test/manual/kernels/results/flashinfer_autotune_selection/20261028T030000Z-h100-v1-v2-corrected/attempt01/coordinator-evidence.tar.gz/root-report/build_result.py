"""Build the bounded research summary from the unchanged canonical analysis."""

import argparse
import hashlib
import json
from pathlib import Path


def build(analysis):
    assert analysis["status"] == "passed"
    assert analysis["execution_commit"] == "1e3056eac034ffdcce288b2f4257c232af379a8c"
    assert analysis["processes"] == 21 and analysis["correctness_checks"] == 4140
    assert analysis["fresh_warm_persistence_verified"]
    metrics = analysis["metrics"]
    primary = metrics[analysis["primary"]]
    cold = analysis["startup_host_cost_ms"]
    default_wins = []
    for row in analysis["results"]:
        if row["mode"] != "timing" or row["natural_tactic"] != -1:
            continue
        ranked = row["target_candidate_ranking"]
        default = next(item for item in ranked if item["tactic"] == -1)
        explicit = next(item for item in ranked if item["tactic"] != -1)
        default_wins.append(
            {
                "block": row["trial"],
                "arm": row["arm"],
                "default_profile_ms": default["profiler_ms"],
                "fastest_explicit_profile_ms": explicit["profiler_ms"],
                "margin_ns": (explicit["profiler_ms"] - default["profiler_ms"]) * 1e6,
                "margin_percent_of_explicit": (
                    1 - default["profiler_ms"] / explicit["profiler_ms"]
                )
                * 100,
            }
        )
    assert len(default_wins) == 2
    return {
        "schema_version": 1,
        "status": "completed",
        "batch": "20261028T030000Z-h100-v1-v2-corrected",
        "execution_commit": analysis["execution_commit"],
        "plan_sha256": analysis["plan_sha256"],
        "schedule_sha256": analysis["schedule_sha256"],
        "question": "Does v2 add candidate-selection value when both actual APIs use the corrected shared delay helper?",
        "conclusion": "No demonstrated incremental v2 benefit on this fixture; no equivalence or general regression claim.",
        "scope": {
            "fixture_m_n_k": [144, 1024, 3072],
            "layer": "Qwen3-0.6B first MLP down projection",
            "physical_gpus": 1,
            "gpu": "NVIDIA H100 NVL",
            "driver": "580.196.07",
            "paired_timing_blocks": 8,
            "fresh_timing_processes": 16,
            "total_processes": 21,
            "measurement_policy": "unspecified",
            "persistence": "existing v1 save/load",
            "confirmation_performed": False,
            "profiling_inputs": "Original synthetic activations; target tensors have M144, while the normalized cache key uses bucket256.",
            "serving_inputs": "Captured real model activations and weights through the actual SGLang FP8 layer facade.",
            "hardware_amendment": "Original GPU under administrator maintenance; replacement H100 NVL and newer driver declared before source freeze and measurements. Exact image/source/native providers retained; fresh ordering gate passed. No historical pooling.",
        },
        "selection_counts": analysis["counts"],
        "same_tactic_pairs": analysis["same_tactic_pairs"],
        "same_natural_native_trace_pairs": analysis[
            "same_natural_trace_signature_pairs"
        ],
        "default_winning_profile_margins": default_wins,
        "primary": {
            "metric": analysis["primary"],
            **primary,
            "percent_change": 100 * (primary["geometric_mean"] - 1),
            "interpretation": "A ratio above1 means longer v2 graph time after normalization to each process's independently measured default. All measured ratios retained, including default/default controls.",
        },
        "secondary": {
            key: metrics[key]
            for key in (
                "v2_over_v1.eager.measured_normalized",
                "v1.cuda_graph.absolute_natural_ms",
                "v2.cuda_graph.absolute_natural_ms",
                "v1.cuda_graph.measured_natural_over_default",
                "v2.cuda_graph.measured_natural_over_default",
            )
        },
        "cold_tuning_cost": {
            "v1_profiles": 72,
            "v2_profiles": 81,
            "v1_median_ms": cold["v1"]["median"],
            "v2_median_ms": cold["v2"]["median"],
            "median_difference_ms": cold["v2"]["median"] - cold["v1"]["median"],
            "ratio_of_medians": cold["v2"]["median"] / cold["v1"]["median"],
            "scope": "Instrumented cold startup-tuning slice; neither full-model startup nor recurring serving cost.",
        },
        "validation": {
            "mlp_numerical_checks": analysis["correctness_checks"],
            "ordering_numerical_checks": analysis["ordering_qualification"][
                "correctness_checks"
            ],
            "total_numerical_checks": 4147,
            "warm_restarts": 2,
            "warm_profiles": 0,
            "post_startup_profiles": 0,
            "warm_persistence": "Fresh processes loaded byte-identical saved explicit winners through real file hits. Both admission winners were explicit; this cohort does not newly establish default-winner reload.",
            "independent_raw_checks": 17155,
            "independent_metrics": 21,
            "independent_scalar_comparisons": 231,
            "bit_exact_scalar_comparisons": 230,
            "rounding_disclosure": {
                "field": "metrics.v2_over_v1.eager.measured_normalized.exploratory_paired_block_bootstrap_95pct[0]",
                "canonical_linux": 0.9899938529895332,
                "macos_python312_and314": 0.9899938529895334,
                "ulp_difference": 1,
                "primary_exact": True,
                "explanation": "One endpoint difference consistent with platform exponentiation rounding; no direct per-draw Linux witness. Canonical report unchanged; strict failures and numerical witnesses preserved. Public reanalysis permits only this exact leaf/value pair, not general tolerances.",
            },
        },
        "resources": {
            "allocation": "2888333",
            "start_utc": "2026-10-28T03:01:37Z",
            "released_utc": "2026-10-28T03:16:46Z",
            "elapsed_seconds": 909,
            "containers_exited_and_cleaned": 21,
            "final_queue_empty": True,
            "final_gpu_processes_empty": True,
            "release_receipts": "Initial scheduler teardown observation and subsequent empty-queue confirmation both preserved.",
        },
        "evidence": {
            "private_final_archive_sha256": "b2a2a74e702d3f6fc9e28ae05c1c6b1f9d5cd2060ecaff7a82012dc968cf7cbc",
            "private_final_archive_members": 330,
            "private_final_archive_regular_files": 285,
            "private_final_archive_indexed_payload_files": 284,
            "operational_archive_sha256": "b7f5cea4d75f91360e6d65bdb07b6dedf3207d22869cc64c7e108187c0d4c2b1",
            "preservation": "All four phase archives and operational evidence durably copied and hash-verified locally. Public scientific results, traces, logs and caches remain byte-exact; inventory-only derivatives and private payload exclusions have explicit original hashes.",
        },
        "interpretation_and_next_action": [
            "Six same-choice pairs use identical selected descriptors and native kernel signatures; small timing differences there are not improved candidate selection.",
            "Two default choices won near-tie synthetic profiles. No repeat-level profiling uncertainty or same-process forced-explicit serving counterfactual was measured; no wrong-choice or confirmation-heuristic conclusion follows.",
            "Eager wall time includes host and cache-lookup behavior; it does not isolate GPU tactic execution.",
            "This comparison is separate from the earlier delay-correction study. That study's 1.17% estimate must not be attributed to v2 over v1.",
            "Present both bounded findings to the owner. Keep production policy and v1 persistence unchanged, the scoped prototype parked, and do not automatically expand the matrix or open a PR.",
        ],
        "additional_limits": analysis["limits"],
        "external_message_sent": False,
        "new_pr_opened": False,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--analysis", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    raw = args.analysis.read_bytes()
    result = build(json.loads(raw))
    result["canonical_analysis_sha256"] = hashlib.sha256(raw).hexdigest()
    result["summary_generator_sha256"] = hashlib.sha256(
        Path(__file__).read_bytes()
    ).hexdigest()
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")


if __name__ == "__main__":
    main()
