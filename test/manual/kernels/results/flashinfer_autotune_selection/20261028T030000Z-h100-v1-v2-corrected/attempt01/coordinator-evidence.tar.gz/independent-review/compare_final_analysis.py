"""Compare separately computed raw metrics and inspect full-run provenance."""

import argparse
import csv
import hashlib
import json
import math
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def compare(root, independent_path, plan_path):
    independent = read(independent_path)
    frozen = read(root / "paired-analysis.json")
    plan = read(plan_path)
    assert independent["status"] == frozen["status"] == "passed"
    assert set(independent["estimates"]) == set(frozen["metrics"])
    checks, differences = 0, []
    for key, expected in independent["estimates"].items():
        reported = frozen["metrics"][key]
        assert reported["paired_blocks"] == 8
        pairs = [(reported["geometric_mean"], expected["geometric_mean"])]
        pairs += list(zip(reported["values_by_block"], expected["values_by_block"], strict=True))
        pairs += list(zip(reported["exploratory_paired_block_bootstrap_95pct"], expected["percentile95"], strict=True))
        labels = ["geometric_mean"] + [f"values_by_block[{i}]" for i in range(8)] + [f"interval[{i}]" for i in range(2)]
        for label, (a, b) in zip(labels, pairs, strict=True):
            assert math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-15), key
            checks += 1
            if a != b:
                differences.append({"metric": key, "field": label, "canonical_linux": a, "independent_macos": b, "ulps": (b - a) / math.ulp(a)})
    assert frozen["mlp_processes"] == independent["processes"] == 20
    assert frozen["processes"] == 21
    assert frozen["correctness_checks"] == independent["numerical_checks"]
    ledger = read(root / "launch-ledger.json")["entries"]
    expected = [("ordering", "patched", None)] + [(phase, arm, None) for phase in ("admission", "warm") for arm in ("v1", "v2")]
    expected += [("timing", arm, i) for i in range(8) for arm in (("v1", "v2") if i % 2 == 0 else ("v2", "v1"))]
    assert [(r["phase"], r["arm"], r["block"]) for r in ledger] == expected
    assert len({r["container_id"] for r in ledger}) == 21
    assert all(a["ended_ns"] < b["started_ns"] for a, b in zip(ledger, ledger[1:]))
    for row in ledger:
        path = root / row["result_relative_path"]
        assert row["returncode"] == 0 and row["cleanup_error"] is None
        assert row["result_sha256"] == sha(path) and row["bootstrap_sha256"] == sha(path.with_suffix(".bootstrap.json"))
        assert path.with_suffix(".container-id").read_text().strip() == row["container_id"]
        boot = read(path.with_suffix(".bootstrap.json"))
        for field in ("before", "after_build", "after_worker"):
            assert boot["native_reuse"][field]["status"] == "passed"
            assert boot["native_reuse"][field]["elf_sha256"] == plan["native_reuse"]["required_library_sha256"]
        assert all(r["returncode"] == 0 and r["stdout"].endswith("ninja: no work to do.\n") for r in boot["native_reuse"]["ninja_dry_runs"])
    signatures = {}
    for row in frozen["results"]:
        key = json.dumps(row["natural_tactic"])
        assert row["trace_signatures"]["natural"]["ordered_launch_signature"] in independent["native_signatures_by_tactic"][key]
        assert row["trace_signatures"]["default"]["ordered_launch_signature"] in independent["native_signatures_by_tactic"]["-1"]
        signatures.setdefault(row["arm"], set()).add(row["trace_signatures"]["natural"]["ordered_launch_signature"][-1]["name"])
    environment = plan["environment"]
    for phase in ("ordering", "admission", "warm", "timing"):
        for point in ("before", "after"):
            rows = list(csv.reader((root / f"gpu-{point}-{phase}.csv").read_text().splitlines()))
            assert len(rows) == 1
            fields = [s.strip() for s in rows[0]]
            assert fields[1] == environment["gpu"] and fields[2].removeprefix("GPU-") == environment["uuid"] and fields[3] == environment["driver"]
            assert float(fields[4]) == environment["power_limit_watts"]
            if point == "before":
                assert int(fields[5]) == 0
        assert not (root / f"gpu-processes-after-{phase}.csv").read_text().strip()
        image = read(root / f"image-{phase}.json")
        assert image["Id"] == environment["image_id"] and image["Architecture"] == "amd64"
        assert (root / f"launcher-{phase}.exit-code").read_text().strip() == "0"
    return {"status": "passed", "execution_commit": frozen["execution_commit"], "metrics_compared": len(frozen["metrics"]), "numeric_fields_compared": checks, "arithmetic_comparison": {"relative_tolerance": 1e-12, "absolute_tolerance": 1e-15, "bit_exact_fields": checks - len(differences), "differences": differences, "canonical": "Original Linux result is preserved; independent macOS arithmetic is compared with explicitly stated tolerance."}, "complete_fresh_processes": 21, "mlp_numerical_checks": independent["numerical_checks"], "native_kernel_names_by_arm": {k: sorted(v) for k, v in signatures.items()}, "input_sha256": {"independent": sha(independent_path), "analysis": sha(root / "paired-analysis.json"), "plan": sha(plan_path)}, "limits": "Independent arithmetic agrees within stated tolerance, not universal bit equality; raw artifact/source/cache identities remain exact. Eight pairs on one fixture and amended GPU/driver. Same selected descriptor/signature does not show a v2 selection improvement even if timings differ."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-root", type=Path, required=True)
    parser.add_argument("--independent", type=Path, required=True)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = compare(args.raw_root, args.independent, args.plan)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))
