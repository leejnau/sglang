"""Independently check cold/warm admission without timing data or study imports."""

import argparse
import json
from pathlib import Path

import audit_matched_raw as audit


def run(root, contract):
    ledger = audit.read(root / "launch-ledger.json")["entries"]
    processes = [row for row in ledger if row["phase"] != "ordering"]
    audit.check([row["phase"] for row in processes] in (["admission"] * 2, ["admission"] * 2 + ["warm"] * 2), "only requested prerequisite processes")
    audit.check(len({row["container_id"] for row in ledger}) == len(ledger), "separate fresh containers")
    audit.check(all(a["ended_ns"] < b["started_ns"] for a, b in zip(ledger, ledger[1:])), "ordering then sequential admissions")
    ordering = audit.read(root / "ordering/patched.json")["attestation_before"]
    expected = {k: v for k, v in ordering.items() if k not in ("torch_stream", "ambient_ffi_stream")}
    results = []
    for entry in processes:
        path = root / entry["result_relative_path"]
        audit.check(entry["returncode"] == 0 and entry["cleanup_error"] is None, "successful clean launch")
        audit.check(entry["result_sha256"] == audit.sha(path) and entry["bootstrap_sha256"] == audit.sha(path.with_suffix(".bootstrap.json")), "ledger binds original files")
        audit.check(path.with_suffix(".container-id").read_text().strip() == entry["container_id"], "actual retained container identity")
        result = audit.cell(path, contract)
        audit.check(result["witness"] == expected, "same qualified source/native/FFI as prerequisite")
        results.append(result)
    cold = {r["arm"]: r for r in results if r["phase"] == "cold"}
    audit.check(set(cold) == {"v1", "v2"}, "one cold admission per arm")
    for m in audit.SHAPES:
        old, new = cold["v1"]["groups"][m], cold["v2"]["groups"][m]
        audit.check([r["tactic"] for r in old] == [r["tactic"] for r in new if r["tactic"] != -1], "identical actual explicit search pool")
        fingerprints = {tuple(r["fingerprints"]) for r in old + new}
        audit.check(len(fingerprints) == 1, "matching synthesized actual admission inputs")
    warm = {r["arm"]: r for r in results if r["phase"] == "warm"}
    if warm:
        audit.check(set(warm) == {"v1", "v2"}, "one fresh restart per arm")
        for arm in warm:
            audit.check(all(cold[arm][k] == warm[arm][k] for k in ("natural_tactic", "natural_key", "cache_sha256")), "actual winner survives exact file reuse")
    return {"status": "passed", "checks": audit.CHECKS, "processes": len(results), "warm_verified": bool(warm), "numerical_checks": sum(r["numerical_checks"] for r in results), "results": [{k: v for k, v in r.items() if k not in ("groups", "witness", "modes")} for r in results], "limits": "Admission and fresh cache correctness only; no performance windows or selection-quality comparison."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-root", type=Path, required=True)
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        report = run(args.raw_root, audit.read(args.contract))
    except Exception as error:
        report = {"status": "failed", "checks": audit.CHECKS, "error": repr(error)}
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps({k: v for k, v in report.items() if k != "results"}))
    raise SystemExit(report["status"] != "passed")
