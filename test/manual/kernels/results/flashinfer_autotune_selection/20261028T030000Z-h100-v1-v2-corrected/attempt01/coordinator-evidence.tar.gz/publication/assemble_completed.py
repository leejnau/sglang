"""Select exact current evidence for the completed bounded cohort."""
import hashlib
import json
import subprocess
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
STUDY=HERE.parent
RAW=STUDY/'coordinator/raw-timing/attempt01'
PUBLIC=HERE/'attempt01'
REVIEW=STUDY/'review'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

reports={
    'result.json':STUDY/'root-report/result.json',
    'admission-analysis.json':RAW/'admission-analysis.json',
    'warm-analysis.json':RAW/'warm-analysis.json',
    'paired-analysis.json':RAW/'paired-analysis.json',
    'public-manifest.json':PUBLIC/'public-manifest.json',
    'package-audit.json':PUBLIC/'package-audit.json',
    'publication-audit.json':PUBLIC/'publication-audit.json',
    'public-scientific-reanalysis-audit.json':HERE/'final-public-reanalysis-qualified/public-scientific-reanalysis-audit.json',
}
evidence={}
for name in ('source-design-review.json','frozen-launch-review.json','ordering-review.json','ordering-provenance-review.json','cold-admission-expanded-review.json','warm-admission-review.json','final-ordering-review.json','final-mlp-review.json','final-comparison-review.json','floating-point-comparison.json','final-integrity-review.json','interpretation-review.json','audit_matched_raw.py','compare_final_analysis.py','audit_fixed_ordering.py','audit_final_integrity.py','audit_admission_raw.py'):
    evidence['independent-review/'+name]=REVIEW/name
for name in ('package_base.py','assemble_public.py','prepare_public.py','check_publication.py','reproduce_public.py','reproduce_public_before_jsonroundtrip.py','reproduce_public_strict_json.py','check_reproduction_controls.py','inspect_bootstrap_rounding.py','assemble_completed.py','tooling-provenance.json','reproduction-controls-final.json','private-reanalysis-comparison.json','bootstrap-rounding-python312.json','bootstrap-rounding-python314.json'):
    evidence['publication/'+name]=HERE/name
for name in ('final-public-reanalysis','final-public-reanalysis-json'):
    evidence['publication/'+name+'-failure.json']=HERE/name/'scientific-comparison-failure.json'
evidence['publication/publication-policy.json']=PUBLIC/'publication-policy.json'
for name in ('attempt01-operational-evidence.tgz','attempt01-operational-manifest.json','attempt01-operational-receipt.json'):
    evidence['operations/'+name]=STUDY/name
for name in ('original-resource-audit.json','check_originals.py','public-master-audit.json','check_master.py'):
    evidence['resource-review/'+name]=STUDY/'independent-resource-review'/name
evidence['root-report/build_result.py']=STUDY/'root-report/build_result.py'
for name in ('analyzer-controls.json','worker-controls.json'):
    evidence['cpu-controls/'+name]=STUDY/name
for mapping in (reports,evidence):
    assert all(path.is_file() for path in mapping.values()),[str(p) for p in mapping.values() if not p.is_file()]
for name,mapping in (('reports',reports),('evidence',evidence)):
    path=HERE/(name+'-selection.json')
    assert not path.exists()
    path.write_text(json.dumps({k:str(v) for k,v in sorted(mapping.items())},indent=2)+'\n')
subprocess.run([sys.executable,str(HERE/'assemble_public.py'),'--public',str(PUBLIC),'--reports',str(HERE/'reports-selection.json'),'--evidence',str(HERE/'evidence-selection.json'),'--destination',str(HERE/'assembled/attempt01'),'--output',str(HERE/'assembly-audit.json')],check=True)
# Assembly's audit describes every byte it assembled; the audit itself remains
# an additional exact standalone report, as in earlier result directories.
out=HERE/'assembled/attempt01/assembly-audit.json';assert not out.exists();out.write_bytes((HERE/'assembly-audit.json').read_bytes())
print(json.dumps({'status':'passed','destination':str(out.parent),'result_sha256':sha(reports['result.json']),'assembly_sha256':sha(out),'files':len(list(out.parent.iterdir()))}))
