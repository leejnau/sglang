"""Independent read-only accounting of the public master against preserved originals."""
import copy,hashlib,io,json,tarfile
from pathlib import Path,PurePosixPath
ROOT=Path('/private/tmp/fi-v1-v2-corrected-20261028');PUB=ROOT/'publication/attempt01'
TOKEN=bytes.fromhex('766c6c6d')
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def read(data,prefix):
 out={}
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as t:
  for m in t:
   p=PurePosixPath(m.name);assert p.parts[0]==prefix and not p.is_absolute() and '..' not in p.parts
   if m.isdir():continue
   assert m.isfile();name=str(PurePosixPath(*p.parts[1:]));assert name not in out
   out[name]=t.extractfile(m).read()
 return out
original_path=ROOT/'coordinator/20261028T030000Z-h100-v1-v2-corrected-attempt01-timing-full-raw.tgz'
original_bytes=original_path.read_bytes();master=(PUB/'raw-public.tar.gz').read_bytes()
assert sha(original_bytes)=='b2a2a74e702d3f6fc9e28ae05c1c6b1f9d5cd2060ecaff7a82012dc968cf7cbc'
assert sha(master)=='66432cb1e2fe9c3032f8bb32b46aad645eba8ffe4ad575029b640b68257ad5a3'
assert TOKEN not in master.lower()
before=read(original_bytes,'attempt01');after=read(master,'raw');manifest=json.loads(after['public-manifest.json'])
assert manifest['private_archive_sha256']==sha(original_bytes) and manifest['private_archive_size_bytes']==len(original_bytes)
assert manifest['private_members_verified']==len(before)==285
assert after['public-manifest.json']==(PUB/'public-manifest.json').read_bytes()
rows={r['path']:r for r in manifest['files']};assert len(rows)==len(manifest['files'])
path_hashes={sha(p.encode()):p for p in before}
exclusions={r.get('path',path_hashes.get(r.get('path_sha256'))):r for r in manifest['excluded_private_files']}
assert None not in exclusions and len(exclusions)==len(manifest['excluded_private_files'])
assert set(rows).isdisjoint(exclusions) and set(rows)|set(exclusions)==set(before)
assert set(after)==set(rows)|{'public-manifest.json'}
exact=derived=removed=0
for name,row in rows.items():
 a,b=before[name],after[name]
 assert sha(a)==row['private_sha256'] and len(a)==row['private_size_bytes']
 assert sha(b)==row['public_sha256'] and len(b)==row['public_size_bytes']
 assert TOKEN not in name.encode().lower() and TOKEN not in b.lower()
 if row['mode']=='byte_exact':assert a==b;exact+=1;continue
 assert row['mode']=='derived_inventory_only' and name.endswith('.bootstrap.json')
 expected=json.loads(a);actual=json.loads(b);metadata=actual.pop('public_evidence_derivation')
 assert metadata==row['derivation'] and metadata['private_file_sha256']==sha(a) and metadata['private_file_size_bytes']==len(a)
 inventory=[]
 modules=expected['import'].get('source_modules',{})
 bad={k:v for k,v in modules.items() if TOKEN in canonical({k:v}).lower()}
 if bad:
  expected['import']['source_modules']={k:v for k,v in modules.items() if k not in bad}
  inventory.append({'path':'import.source_modules','original_count':len(modules),'omitted_count':len(bad),'original_inventory_sha256':sha(canonical(modules)),'omitted_entry_sha256':[sha(canonical({k:v})) for k,v in sorted(bad.items())]})
 for i,provider in enumerate(expected['import'].get('aot_providers',[])):
  modules=provider.get('modules',[]);bad=[m for m in modules if TOKEN in m.encode().lower()]
  if bad:
   provider['modules']=[m for m in modules if m not in bad]
   inventory.append({'path':f'import.aot_providers[{i}].modules','original_count':len(modules),'omitted_count':len(bad),'original_inventory_sha256':sha(canonical(modules)),'omitted_entry_sha256':[sha(canonical(m)) for m in bad]})
 assert expected==actual
 assert metadata['inventories']==inventory
 count=sum(x['omitted_count'] for x in inventory);assert metadata['omitted_entries']==count
 removed+=count;derived+=1
for name,row in exclusions.items():
 assert sha(before[name])==row['sha256'] and len(before[name])==row['size_bytes']
 p=PurePosixPath(name)
 assert any(part in {'native-build-cache','native-artifacts','input','source'} for part in p.parts[:-1]) or p.name.endswith(('.safetensors','.so','.o','.cubin','.pack','.ptx','.ttir','.ttgir','.llir','.source','.tar.gz','.tgz','.zst'))
ledger=json.loads(after['launch-ledger.json']);assert len(ledger['entries'])==21
for row in ledger['entries']:
 name=row['result_relative_path'];bootstrap=str(PurePosixPath(name).with_suffix('.bootstrap.json'))
 assert sha(after[name])==row['result_sha256']
 assert rows[bootstrap]['private_sha256']==row['bootstrap_sha256']
 assert row['returncode']==0 and row['cleanup_error'] is None
assert (exact,derived,removed,len(exclusions))==(227,24,144,34)
result={'status':'passed','public_master_sha256':sha(master),'private_final_sha256':sha(original_bytes),'public_file_members':len(after),'original_file_members':len(before),'byte_exact_files':exact,'inventory_only_bootstraps':derived,'omitted_inventory_entries':removed,'indexed_private_exclusions':len(exclusions),'all_21_ledger_identity_bindings_verified':True,'scientific_fields_modified':0,'audit_source_sha256':sha(Path(__file__).read_bytes())}
with (ROOT/'independent-resource-review/public-master-audit.json').open('x') as h:json.dump(result,h,indent=2);h.write('\n')
print(json.dumps(result,indent=2))
