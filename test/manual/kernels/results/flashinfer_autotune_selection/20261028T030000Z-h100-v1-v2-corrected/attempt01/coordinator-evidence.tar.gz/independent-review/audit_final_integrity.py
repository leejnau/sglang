"""Supplement raw arithmetic with independent source/cache/control identities."""

import argparse
import hashlib
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def audit(raw, plan_path):
    plan = read(plan_path)
    repo = plan_path.parents[6]
    manifest = read(raw / "manifest.json")
    assert manifest["execution_commit"] == "1e3056eac034ffdcce288b2f4257c232af379a8c"
    assert manifest["master_plan_sha256"] == sha(plan_path)
    assert manifest["master_schedule_sha256"] == sha(plan_path.with_name("schedule.json"))
    for relative, expected in plan["source_files_sha256"].items():
        assert sha(repo / relative) == expected
    for relative, expected in manifest["source_sha256"].items():
        assert sha(repo / relative) == expected
    for name, expected in manifest["batch_files_sha256"].items():
        assert sha(plan_path.with_name(name)) == expected
    reuse_sha = sha(raw / "v1/native-build-cache/reuse-manifest.json")
    assert reuse_sha == sha(raw / "v2/native-build-cache/reuse-manifest.json")
    reuse = read(raw / "v1/native-build-cache/reuse-manifest.json")
    reference_sha = sha(raw / "native-reference.bootstrap.json")
    states = []
    for phase in ("ordering", "admission", "warm", "timing"):
        for point in ("before", "after"):
            for arm in ("v1", "v2"):
                state = read(raw / f"source-{point}-{phase}-{arm}.json")
                states.append({k: v for k, v in state.items() if k != "arm"})
    assert all(row == states[0] for row in states)
    assert states[0]["reuse_manifest_sha256"] == reuse_sha
    ledger = read(raw / "launch-ledger.json")["entries"]
    numerical, controls, descriptors = 0, 0, 0
    for entry in ledger:
        path = raw / entry["result_relative_path"]
        data, boot = read(path), read(path.with_suffix(".bootstrap.json"))
        assert boot["native_reuse"]["reference_sha256"] == reference_sha
        assert boot["native_reuse"]["manifest_sha256"] == reuse_sha
        assert all(boot["binding_before"]["callable_comparison"].values())
        assert boot["native_reuse"]["before"] == boot["native_reuse"]["after_build"] == boot["native_reuse"]["after_worker"]
        assert boot["native_reuse"]["before"]["files_verified"] == len(reuse["native_files"])
        if entry["phase"] == "ordering":
            numerical += len(data["actual_profiler"]["samples"]) + len(data["graph_replays"])
            continue
        assert data["source"]["critical_sha256"] == plan["source_contract"]["runtime_sha256"]
        assert data["source"]["flashinfer_commit"] == plan["source_contract"]["flashinfer_commit"]
        for relative, expected in data["source"]["sglang_source_sha256"].items():
            assert sha(repo / relative) == expected
        assert data["startup_protocol"]["wrapper_sha256"] == sha(repo / "python/sglang/srt/model_executor/runner/flashinfer_autotune.py")
        numerical += len(data["correctness"])
        descriptors += len(data["binding_acceptance_checks"])
        for row in data["miss_scopes"]:
            assert row["restored"] and row["cache_sha256_before"] == row["cache_sha256_after"]
            assert row["winner_entries_after_removal"] == row["file_entries_after_removal"] == 0
            controls += 1
        natural = data["natural"]["tactic"]
        tier = "file" if data["phase"] == "warm" else "memory"
        for graph in data["graphs"]:
            assert graph["tactic"] == (natural if graph["id"] == "natural" else -1)
            assert graph["lookup_tier"] == (tier if graph["id"] == "natural" else "miss")
        for mode in data["measurements"].values():
            for pair in mode["pairs"]:
                for row in pair["measurements"]:
                    for field in ("lookup_before", "lookup_after"):
                        lookup = row[field]
                        assert lookup["tactic"] == (natural if row["role"] == "natural" else -1)
                        assert lookup["lookup_tier"] == (tier if row["role"] == "natural" else "miss")
                        assert lookup["cache_hit"] == (row["role"] == "natural")
    return {"status": "passed", "execution_commit": manifest["execution_commit"], "mlp_processes": 20, "total_processes": len(ledger), "total_numerical_checks_including_ordering": numerical, "restored_default_control_scopes": controls, "native_descriptor_acceptance_checks": descriptors, "native_files_per_process": len(reuse["native_files"]), "qualified_source_files_per_phase_guard": states[0]["input_files_verified"], "source_guard_records": len(states), "limits": "Exact source/artifact/cache identity and recorded control restoration; this does not turn timing uncertainty into selection optimality or a serving-performance claim."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-root", type=Path, required=True)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    result = audit(args.raw_root, args.plan)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))
