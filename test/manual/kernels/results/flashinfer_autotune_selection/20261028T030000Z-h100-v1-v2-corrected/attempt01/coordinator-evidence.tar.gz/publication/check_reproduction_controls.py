"""Ensure public reanalysis cannot silently tolerate altered scientific values."""
import copy
import importlib.util
import json
import math
from pathlib import Path

here = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("public_reanalysis_controls", here / "reproduce_public.py")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
original = {"count": 8, "metric": {"mean": 1.01, "interval": [0.99, 1.03]}, "samples": [1.0, 2.0]}
module.compare_scientific(original, copy.deepcopy(original))
passed = ["identical complete scientific object"]
for label, mutate in (
    ("one ULP is not silently accepted", lambda d: d["samples"].__setitem__(0, math.nextafter(1.0, 2.0))),
    ("changed aggregate rejected", lambda d: d["metric"].update(mean=1.001)),
    ("changed interval rejected", lambda d: d["metric"]["interval"].__setitem__(0, 0.98)),
    ("changed count rejected", lambda d: d.update(count=7)),
    ("missing observation rejected", lambda d: d["samples"].pop()),
    ("numeric type change rejected", lambda d: d.update(count=8.0)),
    ("missing field rejected", lambda d: d.pop("metric")),
):
    changed = copy.deepcopy(original)
    mutate(changed)
    try:
        module.compare_scientific(original, changed)
    except AssertionError:
        passed.append(label)
    else:
        raise AssertionError(label)

expected = {"metrics": {"v2_over_v1.eager.measured_normalized": {"exploratory_paired_block_bootstrap_95pct": [module.FROZEN_ENDPOINT, 1.01]}}}
observed = copy.deepcopy(expected)
observed["metrics"]["v2_over_v1.eager.measured_normalized"]["exploratory_paired_block_bootstrap_95pct"][0] = module.LOCAL_ENDPOINT
deviations = module.compare_scientific(expected, observed)
assert len(deviations) == 1 and tuple(deviations[0]["path"]) == module.ROUNDING_PATH
passed.append("only exact declared endpoint one ULP accepted and listed")
assert not module.compare_scientific(expected, copy.deepcopy(expected))
passed.append("exact original endpoint remains accepted without deviation")
for label, mutate in (
    ("two ULP endpoint rejected", lambda d: d["metrics"]["v2_over_v1.eager.measured_normalized"]["exploratory_paired_block_bootstrap_95pct"].__setitem__(0, math.nextafter(module.LOCAL_ENDPOINT, 2.0))),
    ("other endpoint one ULP rejected", lambda d: d["metrics"]["v2_over_v1.eager.measured_normalized"]["exploratory_paired_block_bootstrap_95pct"].__setitem__(1, math.nextafter(1.01, 2.0))),
):
    changed = copy.deepcopy(observed)
    mutate(changed)
    try:
        module.compare_scientific(expected, changed)
    except AssertionError:
        passed.append(label)
    else:
        raise AssertionError(label)
primary_expected = {"metrics": {"v2_over_v1.cuda_graph.measured_normalized": {"exploratory_paired_block_bootstrap_95pct": [module.FROZEN_ENDPOINT, 1.01]}}}
primary_observed = copy.deepcopy(primary_expected)
primary_observed["metrics"]["v2_over_v1.cuda_graph.measured_normalized"]["exploratory_paired_block_bootstrap_95pct"][0] = module.LOCAL_ENDPOINT
try:
    module.compare_scientific(primary_expected, primary_observed)
except AssertionError:
    passed.append("same ULP change in primary is rejected")
else:
    raise AssertionError("primary changed")
result = {"status": "passed", "cpu_only": True, "adapter_sha256": module.sha(here / "reproduce_public.py"), "controls_sha256": module.sha(__file__), "checks": passed, "count": len(passed)}
print(json.dumps(result, indent=2))
