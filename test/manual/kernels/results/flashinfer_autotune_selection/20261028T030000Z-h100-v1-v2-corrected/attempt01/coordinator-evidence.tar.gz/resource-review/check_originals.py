"""Read-only independent checks of original resource and preservation evidence."""
import hashlib, io, json, tarfile
from pathlib import Path, PurePosixPath
ROOT=Path('/private/tmp/fi-v1-v2-corrected-20261028')
COORD=ROOT/'coordinator'
BATCH='20261028T030000Z-h100-v1-v2-corrected'
DURABLE=Path('/Users/lnau/flashinfer-autotune-evidence')/BATCH
EXPECTED={
'ordering':'37b3c06fd5634a25b4da60bec84bf5996ad858eeaa79e21ef831d8a830407821',
'admission':'b4ebcc9567d4d6e83f82e7424f42a56da579bd1328e14785d7a89c36e2519578',
'warm':'2cc2f68e6b7171a0983fd2ca3b7ad11d1e6649b2ca0916da61776134ed50a8da',
 'timing':'b2a2a74e702d3f6fc9e28ae05c1c6b1f9d5cd2060ecaff7a82012dc968cf7cbc'}
def sha(data):return hashlib.sha256(data).hexdigest()
def load(path):return json.loads(path.read_bytes())
def members(data):
 rows={}
 with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as bundle:
  for m in bundle:
   p=PurePosixPath(m.name)
   assert not p.is_absolute() and '..' not in p.parts
   if m.isdir():continue
   assert m.isfile() and m.name not in rows
   rows[m.name]=bundle.extractfile(m).read()
   assert len(rows[m.name])==m.size
 return rows
phases={}
for phase,expected in EXPECTED.items():
 stem=f'{BATCH}-attempt01-{phase}'
 archive=COORD/(stem+'-full-raw.tgz');receipt=COORD/(stem+'-preservation.json')
 data=archive.read_bytes();record=load(receipt)
 assert sha(data)==expected==record['sha256'] and len(data)==record['size']
 assert (DURABLE/archive.name).read_bytes()==data
 assert (DURABLE/receipt.name).read_bytes()==receipt.read_bytes()
 rows=members(data);manifest_name=f'attempt01/preservation-manifest-{phase}.json'
 manifest=json.loads(rows[manifest_name]);assert manifest['phase']==phase
 assert sha(rows[manifest_name])==record['manifest_sha256']
 assert len(manifest['files'])==record['files']
 assert set(rows)=={f"attempt01/{row['path']}" for row in manifest['files']}|{manifest_name}
 for row in manifest['files']:
  value=rows['attempt01/'+row['path']]
  assert len(value)==row['size'] and sha(value)==row['sha256']
 verified=load(COORD/f'verified-{phase}.json');assert verified['status']=='passed' and verified['archive_sha256']==expected
 durable=load(COORD/f'durable-local-{phase}.json');assert durable['status']=='verified'
 for row in durable['files']:
  value=Path(row['path']).read_bytes();assert len(value)==row['size'] and sha(value)==row['sha256']
 phases[phase]={'sha256':expected,'indexed_files':record['files'],'archive_file_members':len(rows),'durable_exact':True}
raw=COORD/'raw-timing/attempt01';ledger=load(raw/'launch-ledger.json');entries=ledger['entries']
assert len(entries)==len({r['container_id'] for r in entries})==21
assert [r['phase'] for r in entries]==['ordering']+['admission']*2+['warm']*2+['timing']*16
for i,r in enumerate(entries):
 assert r['returncode']==0 and r['cleanup_error'] is None
 assert len(r['container_id'])==64
 assert r['ended_ns']>r['started_ns'] and (not i or entries[i-1]['ended_ns']<r['started_ns'])
 p=raw/r['result_relative_path'];assert sha(p.read_bytes())==r['result_sha256']
 assert sha(p.with_suffix('.bootstrap.json').read_bytes())==r['bootstrap_sha256']
 assert p.with_suffix('.container-id').read_text().strip()==r['container_id']
 assert p.with_suffix('.exit-code').read_text()=='0\n'
 if r['phase']!='ordering':
  cache=(raw/r['cache_relative_path']).read_bytes();d=load(p)
  assert sha(cache)==r['cache_sha256']==d['cache']['after_startup_sha256']==d['cache']['final_sha256']
for phase in EXPECTED:
 assert (raw/f'gpu-processes-after-{phase}.csv').read_bytes()==b''
 assert (raw/f'launcher-{phase}.exit-code').read_text()=='0\n'
release=load(COORD/'release/result.json');followup=load(COORD/'release-followup/result.json')
assert release['cleanup_confirmed'] is False
assert followup['cleanup_confirmed'] is True and followup['queue']['text']=='' and followup['queue']['returncode']==0
accounting=followup['accounting']['text'].splitlines()
assert '2888333|fi-v1-v2-corrected-268be1a08db9|CANCELLED by 150381|00:15:09|' in accounting[1]
assert all('|COMPLETED|' in row for row in accounting[2:] if row)
assert load(COORD/'image-prep-20261028T025041Z/result.json')['cleanup_confirmed'] is True
assert load(COORD/'inventory-20261028T024659Z/result.json')['cleanup_confirmed'] is True
op=ROOT/'attempt01-operational-evidence.tgz';receipt=load(ROOT/'attempt01-operational-receipt.json')
assert sha(op.read_bytes())==receipt['sha256']=='b7f5cea4d75f91360e6d65bdb07b6dedf3207d22869cc64c7e108187c0d4c2b1'
assert (DURABLE/op.name).read_bytes()==op.read_bytes()
rows=members(op.read_bytes());manifest=json.loads(rows['operational-manifest.json'])
assert len(manifest['files'])==receipt['files']==203
assert sha(rows['operational-manifest.json'])==receipt['manifest_sha256']
assert rows['release/result.json']==(COORD/'release/result.json').read_bytes()
assert rows['release-followup/result.json']==(COORD/'release-followup/result.json').read_bytes()
assert set(rows)=={r['path'] for r in manifest['files']}|{'operational-manifest.json'}
for r in manifest['files']:assert sha(rows[r['path']])==r['sha256'] and len(rows[r['path']])==r['size']
result={'status':'passed','phase_archives':phases,'unique_successful_containers':21,'all_phase_gpu_process_lists_empty':True,'allocation_cancelled_and_queue_empty':True,'initial_teardown_and_later_confirmation_both_preserved':True,'operational_archive_sha256':receipt['sha256'],'operational_files':203,'audit_source_sha256':sha(Path(__file__).read_bytes())}
output=ROOT/'independent-resource-review/original-resource-audit.json'
with output.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps(result,indent=2))
