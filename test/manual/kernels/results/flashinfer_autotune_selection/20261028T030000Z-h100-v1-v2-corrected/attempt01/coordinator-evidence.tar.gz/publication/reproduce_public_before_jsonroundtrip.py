"""Reproduce the new frozen scientific analyzer from verified public bytes.

Only bootstrap identity and omitted private outer-inventory checks are adapted.
No raw record, measured value or scientific validator is changed.
"""
import argparse
import hashlib
import importlib.util
import json
import re
from pathlib import Path, PurePosixPath
import tarfile
from types import SimpleNamespace

TOKEN = bytes.fromhex("766c6c6d")
BATCH = "test/manual/kernels/results/flashinfer_autotune_selection/20261028T030000Z-h100-v1-v2-corrected"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def compare_scientific(expected, observed, path=()):
    assert type(expected) is type(observed), (path, "type")
    if isinstance(expected, dict):
        assert expected.keys() == observed.keys(), (path, "keys")
        for key in expected:
            compare_scientific(expected[key], observed[key], path + (key,))
    elif isinstance(expected, list):
        assert len(expected) == len(observed), (path, "length")
        for index, (before, after) in enumerate(zip(expected, observed, strict=True)):
            compare_scientific(before, after, path + (index,))
    else:
        assert expected == observed, (path, expected, observed)


def extract(public, output):
    archive = public / "raw-public.tar.gz"
    audit = load(public / "package-audit.json")
    assert audit["status"] == "success" and sha(archive) == audit["archive_sha256"]
    manifest = load(public / "public-manifest.json")
    rows = {row["path"]: row for row in manifest["files"]}
    assert len(rows) == len(manifest["files"])
    seen = set()
    with tarfile.open(archive, "r:gz") as bundle:
        for member in bundle:
            path = PurePosixPath(member.name)
            assert member.isfile() and not path.is_absolute() and ".." not in path.parts
            assert path.parts[0] == "raw" and member.name not in seen
            seen.add(member.name)
            name = str(PurePosixPath(*path.parts[1:]))
            payload = bundle.extractfile(member).read()
            assert TOKEN not in name.encode().lower() and TOKEN not in payload.lower()
            if name == "public-manifest.json":
                assert payload == (public / name).read_bytes()
            else:
                row = rows[name]
                assert len(payload) == row["public_size_bytes"]
                assert hashlib.sha256(payload).hexdigest() == row["public_sha256"]
                if row["mode"] == "byte_exact":
                    assert row["private_sha256"] == row["public_sha256"]
                    assert row["private_size_bytes"] == row["public_size_bytes"]
                else:
                    assert row["mode"] == "derived_inventory_only" and name.endswith(".bootstrap.json")
                    derivative = json.loads(payload)["public_evidence_derivation"]
                    assert derivative == row["derivation"]
                    assert derivative["private_file_sha256"] == row["private_sha256"]
                    assert derivative["private_file_size_bytes"] == row["private_size_bytes"]
            target = output / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(payload)
    assert seen == {"raw/" + name for name in rows} | {"raw/public-manifest.json"}
    return output / "raw", manifest, rows

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("public", "source-root", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--expected-source-commit", required=True)
    parser.add_argument("--phase", choices=("ordering", "timing"), default="timing")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    raw, public_manifest, mappings = extract(args.public, args.output / "extracted")
    source = args.source_root.resolve()
    frozen = load(raw / "manifest.json")
    assert frozen["execution_commit"] == args.expected_source_commit
    analysis = module(source / BATCH / "analyze.py", "public_matched_analysis")
    plan_path = source / BATCH / "plan.json"
    plan, schedule, _ = analysis.validate_plan(plan_path)
    original_name = "paired-analysis.json" if args.phase == "timing" else "fixed-ordering-analysis.json"
    expected = load(raw / original_name)
    assert expected["status"] == "passed" and expected["phase"] == args.phase
    used_mapping, checked_bootstraps = {}, []

    def original_identity(path):
        resolved = Path(path).resolve()
        actual = sha(resolved)
        if resolved.is_relative_to(raw.resolve()):
            relative = str(resolved.relative_to(raw.resolve()))
            if relative in mappings:
                row = mappings[relative]
                assert actual == row["public_sha256"]
                if row["mode"] == "derived_inventory_only":
                    assert relative.endswith(".bootstrap.json")
                    used_mapping[relative] = {"original_sha256": row["private_sha256"], "public_sha256": actual}
                    return row["private_sha256"]
        return actual

    # Only verified inventory-only bootstrap copies receive original identities.
    analysis.sha = original_identity

    def manifest_metadata(raw_root, path, actual_plan):
        assert raw_root == raw and path == plan_path and actual_plan == plan
        manifest = load(raw / "manifest.json")
        assert manifest["master_plan_sha256"] == sha(plan_path)
        assert manifest["master_schedule_sha256"] == sha(plan_path.with_name("schedule.json"))
        assert manifest["fixed_source_sha256"] == sha(raw / "fixed-source.json")
        assert re.fullmatch("[0-9a-f]{40}", manifest["execution_commit"])
        assert load(raw / "source-snapshot.json")["source_commit"] == manifest["execution_commit"]
        for relative, digest in manifest["source_sha256"].items():
            target = source / relative
            assert target.resolve().is_relative_to(source) and sha(target) == digest
        for name, digest in manifest["batch_files_sha256"].items():
            assert Path(name).name == name and sha(source / BATCH / name) == digest
        fixed = load(raw / "fixed-source.json")
        assert fixed["status"] == "passed" and fixed["binding_arm"] == "patched"
        assert fixed["same_input_tree_for_both_arms"] is True
        assert fixed["wrapper_sha256"] == plan["binding"]["patched_sha256"]
        exclusions = {row.get("path"): row for row in public_manifest["excluded_private_files"]}
        one = exclusions["v1/native-build-cache/reuse-manifest.json"]
        two = exclusions["v2/native-build-cache/reuse-manifest.json"]
        assert one["sha256"] == two["sha256"] and one["size_bytes"] == two["size_bytes"]
        return manifest

    def bootstrap_metadata(path, data, actual_plan, raw_root, worker, ordering=False):
        assert actual_plan == plan and raw_root == raw
        boot = analysis.validate_binding_header(path, data, plan, worker, ordering)
        reference = load(raw / "native-reference.bootstrap.json")
        reference_sha = original_identity(raw / "native-reference.bootstrap.json")
        assert reference_sha == "7c4727aca3d99adcb3fe2f35d06f4408b512baa4fe9a91b975bdf77358fe205d"
        assert boot["native_reuse"]["reference_sha256"] == reference_sha
        # This checks retained guard metadata, not omitted payload bytes.
        for point in ("before", "after_build", "after_worker"):
            guard = boot["native_reuse"][point]
            assert guard["status"] == "passed"
            assert guard["elf_sha256"] == plan["native_reuse"]["required_library_sha256"]
        assert boot["native_identity_passthrough"] is True
        for name, native in reference["native"]["providers"].items():
            assert all(boot["native"]["providers"][name][key] == native[key] for key in ("library_path", "library_sha256", "ninja_path", "ninja_sha256", "sources", "compile_commands"))
        assert boot["native"]["tvm_ffi_sha256"] == reference["native"]["tvm_ffi_sha256"]
        checked_bootstraps.append(str(path.relative_to(raw)))
        return boot

    # The frozen scientific code runs unchanged. Only unavailable private outer
    # source/native inventory validation is replaced by explicit metadata checks.
    analysis.validate_manifest = manifest_metadata
    analysis.validate_bootstrap = bootstrap_metadata
    reproduced = analysis.analyze(SimpleNamespace(plan=plan_path, raw_root=raw, phase=args.phase))
    output = args.output / "scientific-reanalysis.json"
    output.write_text(json.dumps(reproduced, indent=2, allow_nan=False) + "\n")
    try:
        compare_scientific(expected, reproduced)
    except AssertionError as error:
        failure = {"status": "failed", "reason": repr(error), "original_analysis_sha256": sha(raw / original_name), "scientific_reanalysis_sha256": sha(output), "adapter_sha256": sha(__file__)}
        (args.output / "scientific-comparison-failure.json").write_text(json.dumps(failure, indent=2) + "\n")
        raise
    assert len(checked_bootstraps) == len(set(checked_bootstraps)) == (21 if args.phase == "timing" else 1)
    result = {
        "status": "passed", "phase": args.phase, "execution_commit": args.expected_source_commit,
        "reproduction_source_sha256": sha(__file__),
        "frozen_analyzer_sha256": sha(source / BATCH / "analyze.py"),
        "public_archive_sha256": sha(args.public / "raw-public.tar.gz"),
        "public_manifest_sha256": sha(args.public / "public-manifest.json"),
        "private_archive_sha256": public_manifest["private_archive_sha256"],
        "original_analysis_sha256": sha(raw / original_name),
        "scientific_reanalysis_sha256": sha(output),
        "all_scientific_fields_exactly_equal": True,
        "ordering_observations_revalidated": True,
        "launch_and_original_cache_accounting_revalidated": True,
        "scientific_processes_revalidated": checked_bootstraps,
        "raw_records_rewritten": 0,
        "bootstrap_identity_mapping": used_mapping,
        "private_outer_integrity_revalidated": False,
        "limits": [
            "The complete frozen scientific analyzer is reproduced. Private source/native payload checks are replaced by retained metadata checks and are explicitly not repeated.",
            "Only verified bootstrap inventory derivatives receive original file identities. Original ledger and result fields remain byte-exact.",
            "All numeric fields, counts, estimates and intervals compare exactly; no previous-cohort platform-rounding exceptions apply.",
            "Reanalysis of the same finite cohort adds no observations and establishes no broader serving-performance claim."
        ]
    }
    encoded = json.dumps(result, indent=2, allow_nan=False).encode() + b"\n"
    assert TOKEN not in encoded.lower() and TOKEN not in output.read_bytes().lower()
    (args.output / "public-scientific-reanalysis-audit.json").write_bytes(encoded)
    print(json.dumps({key: result[key] for key in ("status", "execution_commit", "all_scientific_fields_exactly_equal", "raw_records_rewritten", "private_outer_integrity_revalidated")}))


if __name__ == "__main__":
    main()
