"""Isolate an exact secondary bootstrap endpoint; never changes raw evidence."""
import argparse
import decimal
import hashlib
import json
import math
import platform
import random
import sys
from pathlib import Path

parser=argparse.ArgumentParser();parser.add_argument('--raw',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
report=json.loads(args.raw.read_text());rows={(r['trial'],r['arm']):r for r in report['results'] if r['cohort_phase']=='timing'}
logs=[rows[i,'v2']['modes']['eager']['median_log_ratio']-rows[i,'v1']['modes']['eager']['median_log_ratio'] for i in range(8)]
rng=random.Random(202610280300);draws=[]
for index in range(100000):
 ids=[rng.randrange(8) for _ in range(8)];mean=sum(logs[i] for i in ids)/8;draws.append((math.exp(mean),mean,index,ids))
draws.sort(key=lambda r:r[0]);position=99999*.025;lo,hi=math.floor(position),math.ceil(position);actual=draws[lo][0]+(draws[hi][0]-draws[lo][0])*(position-lo)
contexts=[]
with decimal.localcontext() as ctx:
 ctx.prec=100
 for rank in range(lo-2,hi+3):
  value,mean,index,ids=draws[rank];precise=decimal.Decimal(mean).exp();rounded=float(precise)
  contexts.append({'rank':rank,'draw_index':index,'block_indices':ids,'mean_log':mean,'mean_log_hex':mean.hex(),'exp':value,'exp_hex':value.hex(),'decimal100_exp':str(precise),'decimal100_rounded':rounded,'decimal100_rounded_hex':rounded.hex(),'exp_correctly_rounded':value==rounded})
expected=report['metrics']['v2_over_v1.eager.measured_normalized']['exploratory_paired_block_bootstrap_95pct'][0]
result={'python':sys.version,'platform':platform.platform(),'libc':platform.libc_ver(),'source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'raw_analysis_sha256':hashlib.sha256(args.raw.read_bytes()).hexdigest(),'metric':'v2_over_v1.eager.measured_normalized','endpoint_index':0,'block_log_deltas':logs,'bootstrap_seed':202610280300,'bootstrap_resamples':100000,'expected':expected,'observed':actual,'expected_hex':expected.hex(),'observed_hex':actual.hex(),'one_ulp':math.nextafter(expected,actual)==actual,'quantile_position':position,'adjacent_draws':contexts}
assert not args.output.exists();args.output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('adjacent_draws','block_log_deltas')}))
