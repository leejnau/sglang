"""Independent matched-arm audit from original raw JSON; no study imports."""

import argparse
import hashlib
import json
import math
import random
import statistics
from pathlib import Path

CHECKS = 0
ARMS = ("v1", "v2")
MODES = ("eager", "cuda_graph")
SHAPES = (1, 2, 4, 8, 16, 32, 64, 128, 144)
WRAPPER = "4a41c26b8dc5537707ae292c75d6069e59fae73ed881f73d083c15b5a0eb2722"


def check(value, why):
    global CHECKS
    CHECKS += 1
    if not value:
        raise ValueError(why)


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def near(a, b):
    return math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-15)


def trace(path, raw):
    trace_path = path.with_suffix(".trace.json")
    check(sha(trace_path) == raw["trace"]["sha256"], "actual raw Chrome trace hash")
    events = read(trace_path)["traceEvents"]
    signatures = {}
    for role in ("natural", "default"):
        labels = [e for e in events if e.get("cat") == "user_annotation" and e.get("name") == "retained_" + role]
        check(len(labels) == 1, "unique retained graph annotation")
        label = labels[0]
        launches = [e for e in events if e.get("cat") == "cuda_runtime" and e.get("name") == "cudaGraphLaunch" and label["ts"] <= e["ts"] < label["ts"] + label["dur"]]
        check(len(launches) == 3, "three actual retained graph launches")
        sequences, graph_ids = [], set()
        for launch in launches:
            kernels = sorted((e for e in events if e.get("cat") == "kernel" and e["args"]["correlation"] == launch["args"]["correlation"]), key=lambda e: e["ts"])
            check(len(kernels) == 2, "quantization and GEMM kernels correlate to retained graph")
            sequences.append([{"name": e["name"], **{k: e["args"][k] for k in ("device", "grid", "block", "registers per thread", "shared memory")}} for e in kernels])
            graph_ids.update(e["args"]["graph id"] for e in kernels)
        check(sequences[0] == sequences[1] == sequences[2] and len(graph_ids) == 1, "same native launch sequence for each replay")
        signatures[role] = sequences[0]
    check({g["id"]: (g["graph_object_id"], g["output_data_ptr"]) for g in raw["trace"]["graphs"]} == {g["id"]: (g["graph_object_id"], g["output"]["data_ptr"]) for g in raw["graphs"]}, "trace observes original graph and output objects")
    return signatures


def cell(path, contract):
    data, boot = read(path), read(path.with_suffix(".bootstrap.json"))
    arm, warm = data["arm"], data["phase"] == "warm"
    check(arm in ARMS and data["status"] == "success", "successful assigned worker")
    check(boot["status"] == "passed" and boot["pid"] == data["pid"] and boot["result_sha256"] == sha(path), "exact same-process result")
    witness = data["correction"]
    check(witness == boot["binding_before"] == boot["binding_after"] and witness["wrapper_sha256"] == WRAPPER, "identical corrected binding")
    check(data["shape"] == [144, 1024, 3072] and data["seed"] == 19, "frozen fixture shape and seed")
    check(data["confirmation_performed"] is False and "confirmation" not in data, "no confirmation stage")
    check(not data["forbidden_profile_attempts"] and not data["profile_protocol_errors"], "no swallowed profiler failure")
    profiles = data["startup"]["profiles"]
    count = 0 if warm else 72 if arm == "v1" else 81
    check(len(profiles) == data["startup"]["profile_attempts"] == data["final"]["profile_attempts"] == count, "exact profile count and no later profiling")
    inside = data["startup_protocol"]["inside"]
    check(inside["active_v2"] == (arm == "v2") and inside["is_tuning_mode"] and inside["on_forward_stream"] and inside["measurement_policy"] is None and not inside["managed_store"], "actual mode intervention")
    groups = {}
    if not warm:
        expected_keys = [key for i, key in enumerate(contract["profile_keys"]) if arm == "v2" or i % 9]
        check([r["key"] for r in profiles] == expected_keys, "original profile keys/order")
        for m in SHAPES:
            rows = [r for r in profiles if r["m"] == m]
            expected = [t for t in contract["candidate_order"][str(m)] if arm == "v2" or t != -1]
            check([r["tactic"] for r in rows] == expected, "exact original candidate descriptors/order")
            for row in rows:
                check(row["status"] == "finite" and math.isfinite(row["profiler_ms"]) and row["profiler_ms"] > 0, "valid actual profiling time")
                check(row["in_v2_context"] == (arm == "v2") and row["is_tuning_mode"], "actual profiling context")
                settings = row["autotuner_settings"]
                check(settings["warmup"] == 3 and settings["repeat"] == 10 and settings["stream_delay_micro_secs"] == 5000 and settings["effective_measure_policy"] is None, "unchanged timing objective")
                check(row["metadata"] == rows[0]["metadata"], "unchanged candidate operands")
            groups[m] = rows
        winner = min(groups[144], key=lambda row: row["profiler_ms"])
        check(data["natural"]["tactic"] == winner["tactic"] and data["natural"]["key"] == winner["key"], "actual first-pass minimum survives startup")
    natural = data["natural"]
    check(natural["lookup_tier"] == ("file" if warm else "memory") and natural["cache_hit"], "actual normal serving cache hit")
    selected = data["startup"]["selection"]
    check(len(selected) == 1 and selected[0]["tactic"] == natural["tactic"] and selected[0]["in_v2_context"] == (arm == "v2"), "actual startup choice consumed by bare serving")
    native_checks = data["binding_acceptance_checks"]
    check(bool(native_checks) and all(r["accepted"] is True and r["used_descriptor"] == ([] if r["tactic"] == -1 else [1]) for r in native_checks), "actual descriptor execution without silent fallback")
    cache = data["cache"]
    check(cache["after_startup_sha256"] == cache["final_sha256"] == sha(path.with_suffix(".cache.json")), "exact saved cache remains unchanged")
    check(cache["canonical_state_after_startup"] == cache["canonical_state_final"], "in-memory and loaded winners preserved")
    if warm:
        check(cache["before_sha256"] == cache["final_sha256"] and cache["memory_entries"] == 0, "fresh warm persisted-file reuse")
    else:
        check(cache["before_sha256"] is None, "fresh cold cache")
    check(all(data["final"][k] for k in ("zero_additional_profiling", "cache_unchanged", "operands_unchanged", "native_provider_restored", "on_caller_stream")), "normal final state")
    check(not any(data["final"][k] for k in ("active_v2", "is_tuning_mode", "managed_store", "tuning_contexts")) and data["final"]["measurement_policy"] is None, "bare serving after contexts exit")
    checks = data["correctness"]
    for row in checks:
        q = row["quantized_reference"]
        check(q["passed"] and math.isfinite(q["max_normalized_error"]) and 0 <= q["max_normalized_error"] <= 1, "real output numerical guard")
    check(len({g["graph_object_id"] for g in data["graphs"]}) == len({g["output"]["data_ptr"] for g in data["graphs"]}) == 2, "independent retained graph objects and outputs")
    modes = {}
    for mode, group in data["measurements"].items():
        n = 12 if mode == "eager" else 24
        check(mode in MODES and len(group["pairs"]) == n, "all timing windows retained")
        logs, times, firsts = [], {"natural": [], "default": []}, []
        field = "wall_per_call_ms" if mode == "eager" else "gpu_event_per_call_ms"
        for i, pair in enumerate(group["pairs"]):
            rows = {r["role"]: r for r in pair["measurements"]}
            check(pair["index"] == i and set(rows) == {"natural", "default"} and list(rows) == pair["order"], "complete ordered pair")
            firsts.append(pair["order"][0])
            check(rows["natural"]["iterations"] == rows["default"]["iterations"], "matched per-pair work")
            for role, row in rows.items():
                check(math.isfinite(row[field]) and row[field] > 0, "positive finite held-out timing")
                for clock in ("wall", "gpu_event"):
                    check(near(row[clock + "_batch_ms"] / row["iterations"], row[clock + "_per_call_ms"]), "raw batch/per-call arithmetic")
                check(row["profile_attempts_before"] == row["profile_attempts_after"] == count, "no measurement profiling")
                if mode == "cuda_graph":
                    check(row["iterations"] == 16 and row["prequeue_cycles"] == 10_000_000 and row["queue_query_is_exclusion_criterion"] is False, "unchanged queued replay protocol")
                times[role].append(row[field])
            logs.append(math.log(rows["natural"][field] / rows["default"][field]))
        check(firsts.count("natural") == firsts.count("default") == n // 2, "balanced within-process order")
        modes[mode] = {"log_ratio": statistics.median(logs), "absolute": {role: statistics.median(values) for role, values in times.items()}}
    check((set(modes) == set(MODES)) if data["mode"] == "timing" else not modes, "admission excluded from estimates")
    return {"trial": data["trial"], "arm": arm, "phase": data["phase"], "mode": data["mode"], "natural_tactic": natural["tactic"], "natural_key": natural["key"], "cache_sha256": cache["final_sha256"], "startup_ms": data["startup"]["startup_ms"], "groups": groups, "modes": modes, "numerical_checks": len(checks), "result_sha256": sha(path), "trace": trace(path, data), "witness": {k: v for k, v in witness.items() if k not in ("torch_stream", "ambient_ffi_stream")}}


def percentile(values, q):
    values = sorted(values)
    position = q * (len(values) - 1)
    low, high = math.floor(position), math.ceil(position)
    return values[low] + (values[high] - values[low]) * (position - low)


def audit(root, contract):
    ledger = read(root / "launch-ledger.json")["entries"]
    rows = [cell(root / r["result_relative_path"], contract) for r in ledger if r["phase"] != "ordering"]
    check(len(rows) == 20 and len({r["container_id"] for r in ledger}) == len(ledger), "twenty independent MLP processes")
    check(all(row["witness"] == rows[0]["witness"] for row in rows), "same fixed binding in both arms")
    for arm in ARMS:
        cold, warm = (next(r for r in rows if r["arm"] == arm and r["mode"] == "admission" and r["phase"] == phase) for phase in ("cold", "warm"))
        check(all(cold[k] == warm[k] for k in ("natural_tactic", "natural_key", "cache_sha256")), "actual admission winner survives fresh process")
    timing = {(r["trial"], r["arm"]): r for r in rows if r["mode"] == "timing"}
    check(set(timing) == {(i, arm) for i in range(8) for arm in ARMS}, "complete eight paired blocks")
    series = {}
    for i in range(8):
        v1, v2 = (timing[i, arm] for arm in ARMS)
        for m in SHAPES:
            old, new = v1["groups"][m], [r for r in v2["groups"][m] if r["tactic"] != -1]
            check([r["tactic"] for r in old] == [r["tactic"] for r in new], "matched explicit descriptors/order")
        for mode in MODES:
            scores = [row["modes"][mode]["log_ratio"] for row in (v1, v2)]
            for arm, score in zip(ARMS, scores):
                series.setdefault(arm + "." + mode + ".measured_natural_over_default", []).append(score)
            series.setdefault("v2_over_v1." + mode + ".measured_normalized", []).append(scores[1] - scores[0])
            for role in ("natural", "default"):
                values = [math.log(row["modes"][mode]["absolute"][role]) for row in (v1, v2)]
                for arm, value in zip(ARMS, values):
                    series.setdefault(arm + "." + mode + ".absolute_" + role + "_ms", []).append(value)
                series.setdefault("v2_over_v1." + mode + ".absolute_" + role, []).append(values[1] - values[0])
        scores = [0.0 if row["natural_tactic"] == -1 else row["modes"]["cuda_graph"]["log_ratio"] for row in (v1, v2)]
        for arm, value in zip(ARMS, scores):
            series.setdefault(arm + ".choice_identity_graph_score_secondary", []).append(value)
        series.setdefault("v2_over_v1.choice_identity_graph_score_secondary", []).append(scores[1] - scores[0])
    rng, draws = random.Random(202610280300), {key: [] for key in series}
    for _ in range(100_000):
        indices = [rng.randrange(8) for _ in range(8)]
        for key, values in series.items():
            draws[key].append(math.exp(sum(values[i] for i in indices) / 8))
    estimates = {key: {"geometric_mean": math.exp(statistics.mean(values)), "values_by_block": [math.exp(v) for v in values], "percentile95": [percentile(draws[key], q) for q in (0.025, 0.975)]} for key, values in series.items()}
    winners = {arm: [timing[i, arm]["natural_tactic"] for i in range(8)] for arm in ARMS}
    signatures = {}
    for row in rows:
        for role, tactic in (("natural", row["natural_tactic"]), ("default", -1)):
            key = json.dumps(tactic)
            variants = signatures.setdefault(key, [])
            if row["trace"][role] not in variants:
                variants.append(row["trace"][role])
    return {"checks": CHECKS, "processes": len(rows), "numerical_checks": sum(row["numerical_checks"] for row in rows), "winners": winners, "estimates": estimates, "native_signatures_by_tactic": signatures, "startup_ms": {arm: [timing[i, arm]["startup_ms"] for i in range(8)] for arm in ARMS}, "input_hashes": {r["result_relative_path"]: sha(root / r["result_relative_path"]) for r in ledger if r["phase"] != "ordering"}, "limits": "Raw measured natural/default graph ratios are primary. Identity-normalized default is secondary. No confirmation, historical/admission pooling, full-serving or universal selection claim."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-root", type=Path, required=True)
    parser.add_argument("--contract", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    try:
        report = audit(args.raw_root, read(args.contract))
        report["status"] = "passed"
    except Exception as error:
        report = {"status": "failed", "checks": CHECKS, "error": repr(error)}
    args.output.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps({key: value for key, value in report.items() if key not in ("estimates", "winners", "input_hashes")}))
    raise SystemExit(report["status"] != "passed")
