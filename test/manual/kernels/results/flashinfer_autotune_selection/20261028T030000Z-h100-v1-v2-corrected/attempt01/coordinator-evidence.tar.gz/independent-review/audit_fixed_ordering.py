"""Recompute ordering qualification from raw JSON without the study analyzer."""

import argparse
import hashlib
import json
import math
import statistics
from pathlib import Path

WRAPPERS = {
    'baseline': '5eaaa6773f5d7b5bc00de2183eef488f5b2497d7efc687ebf45f97d7f2fd3593',
    'patched': '4a41c26b8dc5537707ae292c75d6069e59fae73ed881f73d083c15b5a0eb2722',
}
NATIVE = {
    'gemm': '72690cacca4ce1d69ccaa6b9190475483d984bd58de0962d06c874c801c678d6',
    'trtllm_utils': 'e442a689064fe3af4ab46510b2d5aaf3597b072949b84f13d14e9e53352109e4',
}
count = 0


def check(value, label):
    global count
    count += 1
    if not value:
        raise ValueError(label)


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def medians(samples):
    check(len(samples) == 5, 'five samples')
    for row in samples:
        for key in ('event_ms', 'host_ms', 'residual_sync_ms'):
            check(math.isfinite(row[key]) and row[key] >= 0, 'finite nonnegative ordering sample')
    return {key: statistics.median(row[key] for row in samples) for key in ('event_ms', 'host_ms', 'residual_sync_ms')}


def audit(root):
    report = {'arms': {}, 'input_hashes': {}}
    witnesses = {}
    for arm in ('patched',):
        path = root / 'ordering' / (arm + '.json')
        data, boot = read(path), read(path.with_suffix('.bootstrap.json'))
        report['input_hashes'][str(path)] = sha(path)
        report['input_hashes'][str(path.with_suffix('.bootstrap.json'))] = sha(path.with_suffix('.bootstrap.json'))
        check(data['status'] == boot['status'] == 'passed', 'worker and bootstrap passed')
        check(data['arm'] == boot['binding_arm'] == arm, 'assigned arm')
        check(data['pid'] == boot['pid'] and boot['result_sha256'] == sha(path), 'same-process result binding')
        witness = data['attestation_before']
        check(witness == data['attestation_after'] == boot['binding_before'] == boot['binding_after'], 'unchanged imported binding')
        check(witness['wrapper_sha256'] == WRAPPERS[arm], 'exact upstream wrapper bytes')
        check(witness['wrapper_path'] == '/study/input/current/source/flashinfer/tllm_utils.py', 'canonical source path')
        check(witness['upstream_head'] == 'e6bcdebdefff9ad6dd635cb357ead72b0e7f9da6', 'upstream source identity')
        check(witness['callable_matches_source'] and witness['profiler_alias_matches'] and witness['native_identity_passthrough'], 'runtime callable identity')
        check({name: row['library_sha256'] for name, row in witness['native'].items()} == NATIVE, 'qualified native artifacts')
        check(witness['torch_version'] == '2.14.1+cu130', 'pinned Torch')
        check(bool(witness['ffi_libraries']), 'actual FFI native bindings recorded')
        for point in ('before', 'after_build', 'after_worker'):
            check(boot['native_reuse'][point]['status'] == 'passed' and boot['native_reuse'][point]['elf_sha256'] == NATIVE, 'native reuse ' + point)
        check(all(row['returncode'] == 0 and row['stdout'].endswith('ninja: no work to do.\n') for row in boot['native_reuse']['ninja_dry_runs']), 'no native rebuild')
        witnesses[arm] = witness
        refs = {}
        for row in data['reference']:
            values = medians(row['samples'])
            check(values['event_ms'] > 0 and values['event_ms'] == row['median_ms'], 'same-native reference median')
            refs[row['stream_kind']] = values['event_ms']
        check(set(refs) == {'default', 'nondefault'}, 'two reference streams')
        arm_report = {'native_reference_ms': refs, 'controlled': [], 'natural': []}
        for field, forced in (('controlled_streams', True), ('natural_streams', False)):
            check(len(data[field]) == 2 and {row['stream_kind'] for row in data[field]} == set(refs), 'two ' + field)
            for row in data[field]:
                values = medians(row['samples'])
                ref = refs[row['stream_kind']]
                check(row['forced_conflict'] == forced and row['reference_ms'] == ref, 'source of stream condition and reference')
                observed = values['event_ms'] >= ref / 2
                if forced:
                    check(row['torch_stream'] != row['ambient_ffi_stream'], 'explicitly conflicting streams')
                    check(row['restored'], 'ambient context restored')
                    check(observed == (arm == 'patched'), 'old wrapper susceptibility and corrected ordering')
                elif arm == 'patched':
                    check(observed, 'natural fixed ordering')
                arm_report['controlled' if forced else 'natural'].append({'stream_kind': row['stream_kind'], **values, 'ordering_observed': observed})
        profile = data['actual_profiler']
        check(profile['forced_conflict'] is False and len(profile['samples']) == 5, 'natural profiler observations')
        for row in profile['samples']:
            check(row['numerics'] and math.isfinite(row['profiler_ms']) and row['profiler_ms'] > 0, 'real profiler output and timer')
        summary = {key: statistics.median(row[key] for row in profile['samples']) for key in ('profiler_ms', 'host_ms', 'residual_sync_ms')}
        if arm == 'patched':
            check(summary['host_ms'] >= refs['nondefault'] / 2 and summary['residual_sync_ms'] < refs['nondefault'] / 2, 'fixed real profiler waits on its delay stream')
            replays = data['graph_replays']
            check(len(replays) == 2 and [row['input'] for row in replays] == [3.0, 9.0], 'changed graph inputs')
            for row in replays:
                check(row['event_ms'] >= refs['nondefault'] / 2, 'delay included in actual graph replay')
                check(row['output'] == row['input'] + 1 and row['numerics'] and row['restored'], 'fresh graph numerics and restoration')
        arm_report['actual_profiler'] = summary
        arm_report['graph_replays'] = data['graph_replays']
        arm_report['ffi_version'] = witness['tvm_ffi_version']
        report['arms'][arm] = arm_report
    entries = [row for row in read(root / 'launch-ledger.json')['entries'] if row['phase'] == 'ordering']
    check([row['arm'] for row in entries] == ['patched'], 'ordered prerequisite processes')
    check(len({row['container_id'] for row in entries}) == 1, 'fixed-only container identity')
    all_entries = read(root / 'launch-ledger.json')['entries']
    later = [row for row in all_entries if row['phase'] != 'ordering']
    check(all(row['started_ns'] > entries[0]['ended_ns'] for row in later), 'ordering precedes every MLP process')
    for row in entries:
        p = root / row['result_relative_path']
        check(row['returncode'] == 0 and row['result_sha256'] == sha(p) and row['bootstrap_sha256'] == sha(p.with_suffix('.bootstrap.json')), 'launch result hashes')
        check(p.with_suffix('.container-id').read_text().strip() == row['container_id'], 'actual container ID')
    for row in later:
        boot = read((root / row['result_relative_path']).with_suffix('.bootstrap.json'))
        observed = boot['binding_before']
        for key in witnesses['patched']:
            if key not in ('torch_stream', 'ambient_ffi_stream'):
                check(observed[key] == witnesses['patched'][key], 'ordering/MLP dependency identity ' + key)
    report['limits'] = 'Fixed-only ordering qualification on the recorded device. No baseline-wrapper rerun, no historical performance pooling, and no ranking-quality inference from this prerequisite.'
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--raw-root', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        result = audit(args.raw_root)
        result.update(status='passed', checks=count)
    except Exception as error:
        result = {'status': 'failed', 'checks': count, 'error': repr(error)}
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps(result))
    raise SystemExit(0 if result['status'] == 'passed' else 1)
