#!/usr/bin/env bash
set -euo pipefail
study=/tmp/fi-mlp-confirmation-2865829
source_dir="$study/source"
batch=test/manual/kernels/results/flashinfer_autotune_selection/20261027T020000Z-h100-mlp-confirmation
raw="$study/results/mlp-confirmation/attempt01"
mkdir "$study/coordinator"
python3 "$source_dir/$batch/analyzer.py" \
  --plan "$source_dir/$batch/plan.json" \
  --schedule "$source_dir/$batch/schedule.json" \
  --historical-contract "$source_dir/$batch/historical-contract.json" \
  --raw-root "$raw" \
  --worker "$source_dir/test/manual/kernels/bench_flashinfer_mlp_confirmation.py" \
  --output "$study/coordinator/admission-analysis.json" --admission
python3 "$source_dir/$batch/outer_audit.py" \
  --execution-commit 3cae7f706d2aa2bfc2268f13597a3d1706432410 \
  --raw-root "$raw" --source-root "$source_dir" \
  --prior-bootstrap "$raw/native-reference.bootstrap.json" \
  --allocation-evidence /home/lnau/flashinfer-autotune-study/20261027T020000Z-h100-mlp-confirmation-allocation-state.txt \
  --phase admission --output "$study/coordinator/admission-outer-audit.json"
cp "$study/coordinator/admission-analysis.json" "$raw/admission-analysis.json"
cp "$study/coordinator/admission-outer-audit.json" "$raw/admission-outer-audit.json"
sha256sum "$raw/admission-analysis.json" "$raw/admission-outer-audit.json"
