#!/usr/bin/env python3
"""Pack two explicit sparse snapshots without walking commit history."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

CAPTURE = "fb57a74b14b03ec5a35cfc4b43828e46e11261e3"
DEFAULT_SOURCE = Path("/private/tmp/sglang-autotune-selection-study")
PREFIXES = ("python/", "test/manual/kernels/")
FILES = (".gitignore", "pyproject.toml")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source_commit")
    parser.add_argument("--repo", type=Path, default=DEFAULT_SOURCE)
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("snapshot.pack"))
    args = parser.parse_args()
    env = dict(os.environ, GIT_NO_LAZY_FETCH="1", GIT_TERMINAL_PROMPT="0")
    def git(*arguments):
        return subprocess.run(["git", "-C", str(args.repo), *arguments], env=env,
                              check=True, capture_output=True).stdout
    current = git("rev-parse", "--verify", args.source_commit + "^{commit}").decode().strip()
    commits = list(dict.fromkeys((current, CAPTURE)))
    objects, snapshots = set(), []
    for commit in commits:
        git("cat-file", "-e", commit + "^{commit}")
        objects.add(commit)
        objects.add(git("rev-parse", commit + "^{tree}").decode().strip())
        tree_count = blob_count = 0
        for entry in git("ls-tree", "-r", "-t", "-z", "--full-tree", commit).split(b"\0"):
            if not entry:
                continue
            header, name = entry.split(b"\t", 1)
            _mode, kind, oid = header.decode().split()
            path = name.decode("utf-8", "surrogateescape")
            if kind == "tree":
                objects.add(oid)
                tree_count += 1
            elif kind == "blob" and (path in FILES or path.startswith(PREFIXES)):
                objects.add(oid)
                blob_count += 1
        snapshots.append({"commit": commit, "trees": tree_count + 1, "selected_blobs": blob_count})
    ordered = sorted(objects)
    check = subprocess.run(["git", "-C", str(args.repo), "cat-file", "--batch-check"],
                           input=("\n".join(ordered) + "\n").encode(), env=env,
                           check=True, capture_output=True).stdout.decode().splitlines()
    if len(check) != len(ordered) or any(line.endswith(" missing") for line in check):
        raise RuntimeError("snapshot needs missing objects; hydrate the source repository explicitly before retrying")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("xb") as output:
        subprocess.run(["git", "-C", str(args.repo), "pack-objects", "--stdout"],
                       input=("\n".join(ordered) + "\n").encode(), stdout=output,
                       env=env, check=True)
    result = {"schema_version": 1, "source_commit": current, "capture_commit": CAPTURE,
              "snapshots": snapshots, "explicit_objects": len(objects),
              "paths": [*PREFIXES, *FILES], "history_walk": False,
              "lazy_fetch": False, "pack": str(args.output), "size_bytes": args.output.stat().st_size,
              "sha256": hashlib.sha256(args.output.read_bytes()).hexdigest(),
              "created_unix": time.time()}
    manifest = args.output.with_suffix(args.output.suffix + ".json")
    with manifest.open("x") as output:
        json.dump(result, output, indent=2)
        output.write("\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
