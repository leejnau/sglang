"""Verify and extract an immutable coordinator archive without changing its bytes."""
import argparse
import hashlib
import json
import tarfile
from pathlib import Path, PurePosixPath

p = argparse.ArgumentParser()
p.add_argument('--archive', type=Path, required=True)
p.add_argument('--record', type=Path, required=True)
p.add_argument('--destination', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
record = json.loads(a.record.read_text())
assert not a.destination.exists() and not a.output.exists()
assert a.archive.stat().st_size == record['size'] and sha(a.archive) == record['sha256']
with tarfile.open(a.archive) as archive:
    for item in archive.getmembers():
        path = PurePosixPath(item.name)
        assert not path.is_absolute() and '..' not in path.parts
        assert item.isfile() or item.isdir()
    a.destination.mkdir()
    archive.extractall(a.destination)
raw = a.destination / 'attempt01'
manifest_path = raw / ('preservation-manifest-' + record['phase'] + '.json')
manifest = json.loads(manifest_path.read_text())
assert manifest['phase'] == record['phase']
rows = manifest['files']
assert len({r['path'] for r in rows}) == len(rows)
for row in rows:
    target = raw / row['path']
    assert target.stat().st_size == row['size'] and sha(target) == row['sha256'], row['path']
actual = {str(f.relative_to(raw)) for f in raw.rglob('*') if f.is_file()}
assert actual == {r['path'] for r in rows} | {manifest_path.name}
result = dict(status='passed', archive=str(a.archive), archive_sha256=sha(a.archive),
              record_sha256=sha(a.record), raw_root=str(raw), rows_verified=len(rows),
              preservation_manifest_sha256=sha(manifest_path))
a.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
