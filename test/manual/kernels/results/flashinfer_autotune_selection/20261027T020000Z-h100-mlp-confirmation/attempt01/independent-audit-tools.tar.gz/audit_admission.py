"""Independent admission integrity check; no timing-effect estimate is made."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location("independent_math", HERE / "interpret_results.py")
math = importlib.util.module_from_spec(spec)
spec.loader.exec_module(math)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-root", type=Path, required=True)
    parser.add_argument("--expected-source-commit", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists()
    raw = args.raw_root
    manifest = math.read(raw / "manifest.json")
    assert manifest["execution_commit"] == args.expected_source_commit
    path = raw / "admission-auto_synthetic.json"
    row = math.read(path)
    bootstrap = math.read(path.with_suffix(".bootstrap.json"))
    assert row["status"] == "success" and row["mode"] == "admission"
    assert bootstrap["status"] == "passed" and bootstrap["result_sha256"] == math.sha(path)
    assert row["worker_sha256"] == bootstrap["worker_sha256"] == manifest["source_sha256"][
        "test/manual/kernels/bench_flashinfer_mlp_confirmation.py"]
    assert row["fixture"]["shape"] == [144, 1024, 3072]
    assert row["mlp_adapter"]["initializer_recipe"] == "original_synthetic_no_clone_copy"
    initializers = row["startup"]["initializer_calls"]
    assert len(initializers) == 9
    assert all(not x["cloned"] and not x["copied"] and x["returned_same_object"]
               and x["generated_sha256"] == x["returned_sha256"] for x in initializers)
    profiles = row["startup"]["profiles"]
    assert len(profiles) == 81 and all(x["error"] is None and x["elapsed_ms"] > 0 for x in profiles)
    finalist = math.finalist(profiles)
    assert finalist["tactic"] == row["finalist"]["tactic"]
    natural = min(profiles[72:], key=lambda x: x["elapsed_ms"])
    assert natural["tactic"] == row["natural"]["tactic"] == row["startup_choices"][0]["tactic"]
    confirmation = row["confirmation"]
    logs, score = math.median_logs(confirmation["rounds"], "role", "elapsed_ms")
    assert len(logs) == 12 and sum(x["order"][0] == "winner" for x in confirmation["rounds"]) == 6
    role = "winner" if score < 0 else "default"
    payload = {"explicit_tactic": finalist["tactic"], "default_tactic": -1,
               "pair_orders": [x["order"] for x in confirmation["rounds"]],
               "log_ratios": logs, "median_log_ratio": score,
               "decision_role": role,
               "decision_tactic": finalist["tactic"] if role == "winner" else -1,
               "decided_ns": confirmation["decided_ns"]}
    decision = hashlib.sha256(math.encoded(payload)).hexdigest()
    assert payload == confirmation["decision_payload"]
    assert decision == confirmation["decision_sha256"] == confirmation["initial_decision_sha256"] == row["final"]["decision_sha256"]
    assert all(g["confirmation_decision_sha256"] == decision and
               g["capture_started_ns"] > confirmation["decided_ns"] for g in row["graphs"])
    assert not row["rounds"]  # Admission never contributes graph timing data.
    assert len(row["diagnostic_profile_attempts"]) == 24
    assert row["total_actual_profiler_calls"] == 105 and not row["forbidden_profile_attempts"]
    assert row["natural"]["cache_sha256"] == row["startup"]["cache_sha256"] == row["final"]["cache_sha256"]
    assert row["natural"]["cache_state_sha256"] == row["startup"]["cache_state_sha256"] == row["final"]["cache_state_sha256"]
    checks = row["correctness"] + row["profile_correctness"]
    assert checks and all(x["passed"] for x in checks)
    assert row["post_timing_acceptance"]["used_descriptor"] == 1
    assert row["synthetic_acceptance"][0]["used_descriptor"] == 1
    traces = {r: math.trace_graph(path.with_suffix(".trace.json"), r) for r in ("winner", "default")}
    for name, value in (("gemm", math.GEMM_SHA), ("trtllm_utils", math.TIMING_SHA)):
        assert bootstrap["native"]["providers"][name]["library_sha256"] == value
    report = {"status": "passed", "immutable": True,
              "scope": "One admission process, independent identity/decision/cache/output evidence; excluded from timing estimates.",
              "execution_commit": args.expected_source_commit,
              "raw_sha256": math.sha(path), "source_sha256": math.sha(__file__),
              "math_source_sha256": math.sha(HERE / "interpret_results.py"),
              "numerical_checks": len(checks), "startup_profiles": 81,
              "confirmation_profiler_calls": 24, "decision_sha256": decision,
              "original_cache_unchanged": True, "traces": traces}
    text = json.dumps(report, indent=2, allow_nan=False) + "\n"
    assert bytes.fromhex("766c6c6d") not in text.encode().lower()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(text)
    print(json.dumps({"status": "passed", "output": str(args.output), "numerical_checks": len(checks)}))


if __name__ == "__main__":
    main()
