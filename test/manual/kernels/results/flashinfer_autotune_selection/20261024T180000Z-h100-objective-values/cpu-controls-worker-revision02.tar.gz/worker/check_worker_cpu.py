"""Focused CPU controls for the new worker; no CUDA or performance inference."""
from __future__ import annotations
import contextlib
import copy
import hashlib
import importlib.util
import json
import math
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path('/private/tmp/sglang-autotune-selection-study')
WORKER = ROOT/'test/manual/kernels/bench_flashinfer_objective_values.py'
spec = importlib.util.spec_from_file_location('objective_values_worker', WORKER)
w = importlib.util.module_from_spec(spec); spec.loader.exec_module(w)
checks = []
def check(value, label):
    if not value: raise AssertionError(label)
    checks.append(label)
def rejects(function, label):
    try: function()
    except (RuntimeError, ValueError, KeyError): checks.append(label)
    else: raise AssertionError(label)

batch = ROOT/'test/manual/kernels/results/flashinfer_autotune_selection/20261024T180000Z-h100-objective-values'
schedule = json.loads((batch/'schedule.json').read_text())
for entry in schedule['entries']:
    row, orders = w.select_schedule(schedule,entry['block'],entry['cell'],entry['capture_order'])
    check(row==entry and len(orders)==24 and sum(x[0]=='winner' for x in orders)==12,'actual frozen schedule '+str(entry['launch_index']))
rejects(lambda:w.select_schedule(schedule,0,'invalid','winner-first'),'unknown cell rejected')
bad=copy.deepcopy(schedule); bad['round_schedules'][0]['orders'][0]=['winner','winner']
rejects(lambda:w.select_schedule(bad,0,schedule['entries'][0]['cell'],schedule['entries'][0]['capture_order']),'duplicate graph schedule rejected')
check(w.tactic_json(-1)==-1 and w.tactic_json(tuple(range(8)))==list(range(8)),'tactic serialization preserves default and descriptor')
rejects(lambda:w.tactic_json((0,)*7),'malformed descriptor rejected')

# Load exact official CPU-capable tuner/initializer code, with the already
# disclosed GPU-only import leaves from the admission proof loader.
adapter=Path('/private/tmp/fi-next-steps-20261024/fixture-adapter')
sys.path.insert(0,str(adapter))
loader=(adapter/'check_adapter.py').read_text().split('contract = json.loads(',1)[0]
ns={'__file__':str(adapter/'check_adapter.py'),'__name__':'worker_cpu_current_loader'}
exec(compile(loader,str(adapter/'check_adapter.py'),'exec'),ns)
torch,api,harness=ns['torch'],ns['api'],ns['harness']
from flashinfer.autotuner.initializers import autotuner_initializer_rand_scaled
def tensor_hash(tensor):
    return hashlib.sha256(bytes(tensor.detach().contiguous().view(torch.uint8).reshape(-1).tolist())).hexdigest()
q=torch.ones((1,144,1024),dtype=torch.float8_e4m3fn)
runs=[]
for values in ('synthetic','captured'):
    torch.manual_seed(19); before=tensor_hash(torch.get_rng_state()); records=[]
    init=w.make_initializer(autotuner_initializer_rand_scaled,q,values,records,tensor_hash)
    outputs=[init((1,m,1024),q.dtype,q.device) for m in w.PROFILE_MS]
    runs.append((records,[tensor_hash(x) for x in outputs],before,tensor_hash(torch.get_rng_state())))
    check([x['shape'][1] for x in records]==list(w.PROFILE_MS),'nine exact actual initializer calls '+values)
    check(sum(x['cloned'] and x['copied'] for x in records)==1,'one matched clone/copy '+values)
check(runs[0][2:]==runs[1][2:],'original RNG before/after identical')
check([r['generated_sha256'] for r in runs[0][0]]==[r['generated_sha256'] for r in runs[1][0]],'default original draws identical all nine profiles')
check(runs[0][1][:-1]==runs[1][1][:-1] and runs[0][1][-1]!=runs[1][1][-1]==tensor_hash(q),'only exact M144 returned activation differs')
records=[]; init=w.make_initializer(autotuner_initializer_rand_scaled,q,'synthetic',records)
init(tuple(q.shape),q.dtype,q.device)
check(not any('sha256' in key for row in records for key in row),'timing initializer records no bytes or synthetic references')

with tempfile.TemporaryDirectory() as directory:
    cache=Path(directory)/'cache.json'; cache.write_text('{}')
    tuner=api.AutoTuner()
    e=w.Experiment.__new__(w.Experiment); e.tuner=tuner; e.args=SimpleNamespace(cache=cache)
    e.result={'miss_scopes':[]}
    with harness.use_isolated_tuner(tuner),harness.autotune_v2(mode='replay',persistent_cache=False,measurement_policy=harness.MeasurementPolicy(execution_mode='cuda_graph')):
        tuner._winner_cache()['graph-key']=(-1,None); tuner.profiling_cache['legacy-key']=(-1,None)
        tuner._file_configs['file-key']=('Runner',-1)
        original=copy.deepcopy(tuner._winner_partitions)
        with e.miss_scope():
            check(not tuner._winner_cache() and not tuner._file_configs,'actual graph-policy effective maps removed')
            tuner._logged_cache_miss_oor.add(('x',()))
        check(tuner._winner_partitions==original and tuner._file_configs=={'file-key':('Runner',-1)},'actual graph partition and file contents restored')
        check(not tuner._logged_cache_miss_oor and e.result['miss_scopes'][-1]['restored'],'ancillary miss log restored')
        rejects(lambda:(_ for _ in ()).throw(RuntimeError('deliberate')),'deliberate exception check')
        try:
            with e.miss_scope(): raise RuntimeError('deliberate')
        except RuntimeError: pass
        check(tuner._winner_partitions==original and e.result['miss_scopes'][-1]['restored'],'cache restoration also survives exception')

class FakeOut:
    def __init__(self,log):self.log=log
    def fill_(self,value):self.log.append('poison')
    def data_ptr(self):return 123
class FakeGraph:
    def __init__(self,log):self.log=log
    def replay(self):self.log.append('replay')
class FakeEvent:
    def __init__(self,log,name,complete,error,elapsed):self.log,self.name,self.complete,self.error,self.elapsed=log,name,complete,error,elapsed
    def record(self):self.log.append(self.name+'.record')
    def synchronize(self):self.log.append(self.name+'.sync')
    def query(self):
        self.log.append(self.name+'.query')
        if self.error:raise RuntimeError('query error')
        return self.complete
    def elapsed_time(self,other):self.log.append('elapsed');return self.elapsed
def sample(complete,error=False,elapsed=.1):
    log=[]; events=[]
    def event(**_):
        value=FakeEvent(log,'first' if not events else 'last',complete,error,elapsed);events.append(value);return value
    e=w.Experiment.__new__(w.Experiment)
    e.torch=SimpleNamespace(cuda=SimpleNamespace(Event=event,_sleep=lambda cycles:log.append('sleep')))
    e.graphs={'winner':{'graph':FakeGraph(log),'output':FakeOut(log)}}
    e.result={};e.profile_attempts=81;e.assert_bare=lambda:None;e.warm=lambda *a:{'actual_ms':20,'calls':5120}
    e.check=lambda *a:(log.append('check') or 'checked')
    if error or not (elapsed>0 and math.isfinite(elapsed)):
        rejects(lambda:e.sample('winner',0),'sampler invalid/query error preserved '+repr((error,elapsed)))
        check(e.result['pending_sample'] is not None,'failed sample remains visible')
        return
    row=e.sample('winner',0)
    check(log[log.index('first.query')-1]=='last.record','start query immediately after end event '+str(complete))
    check(log.count('replay')==16 and log.index('poison')<log.index('first.record')<log.index('sleep'),'exact16 replays with drained output poison '+str(complete))
    check(log[-1]=='check' and row['gpu_event_per_replay_ms']==elapsed/16,'timed own output checked before later calls '+str(complete))
    check(row['start_event_complete_after_enqueue'] is complete and row['profile_attempts_before']==row['profile_attempts_after']==81,'both query outcomes retained without profile '+str(complete))
sample(False);sample(True);sample(False,True);sample(False,elapsed=0)

# The profiler guard increments before denying, and an invalid returned time is
# retained even if the actual choose_one caller would catch the raised error.
def profiler_case(elapsed,allow=True):
    e=w.Experiment.__new__(w.Experiment);e.profile_attempts=0;e.allow_profiling=allow;e.stage='test'
    e.args=SimpleNamespace(mode='timing');e.policy=None
    e.result={'startup':{'profiles':[]},'forbidden_profile_attempts':[],'protocol_errors':[],'objective':'auto'}
    if not allow:
        rejects(lambda:e.profile(None,[], -1,None),'outside-startup profile rejected before tensors')
        check(e.profile_attempts==1 and e.result['forbidden_profile_attempts']==['test'],'monotonic forbidden attempt retained')
        return
    settings={'warmup':3,'repeat':10,'stream_delay_micro_secs':5000,'cuda_graph_delay_micro_secs':100,'use_global_timer':False,'measurement_policy':None}
    e.settings=lambda config:settings;e.metadata=lambda value:{}
    e.tuner=SimpleNamespace(_get_cache_key=lambda *a:SimpleNamespace(file_key='real-key'),_in_v2_context=True)
    e.model_runner=SimpleNamespace(forward_stream='forward');e.torch=SimpleNamespace(cuda=SimpleNamespace(current_stream=lambda:'forward'))
    e.original_profile=lambda *a,**kw:elapsed
    config=SimpleNamespace(use_cuda_graph=False,use_cold_l2_cache=False,use_cuda_graph_individual_timing=False,cuda_graph_profile_replays=1,profiling_repeat=None)
    runner=type('CublasFp8GemmRunner',(),{'get_cache_key_extras':lambda self,inputs:()})()
    inputs=[SimpleNamespace(shape=(1,144,1024))]
    if elapsed>0 and math.isfinite(elapsed):check(e.profile(runner,inputs,-1,config)==elapsed,'positive actual profiling return preserved')
    else:
        rejects(lambda:e.profile(runner,inputs,-1,config),'invalid profiling time rejected '+repr(elapsed))
        row=e.result['startup']['profiles'][0]
        check(row['raw_elapsed_repr']==repr(elapsed) and row['error'] and e.result['protocol_errors'],'invalid profiling evidence survives swallowed candidate error '+repr(elapsed))
profiler_case(1.0);profiler_case(0.0);profiler_case(-1.0);profiler_case(float('nan'));profiler_case(float('inf'));profiler_case(1,False)

e=w.Experiment.__new__(w.Experiment)
e.graphs={'winner':{'output':SimpleNamespace(data_ptr=lambda:1),'inputs':[None]*4+[SimpleNamespace(data_ptr=lambda:1)]}}
rejects(lambda:e.check(SimpleNamespace(data_ptr=lambda:2),'wrong-owner','winner'),'wrong retained output rejected before numerical execution')
e.graphs['winner']['inputs'][4]=SimpleNamespace(data_ptr=lambda:3)
rejects(lambda:e.check(SimpleNamespace(data_ptr=lambda:1),'aliased-owner','winner'),'saved native output mismatch rejected before numerical execution')

class Operand:
    def __init__(self,pointer):self.pointer=pointer
    def data_ptr(self):return self.pointer
    def fill_(self,value):return self
    def copy_(self,value):return self
    def squeeze(self,axis):return self
for tactic,used in ((tuple(range(8)),1),(tuple(range(8)),0),(-1,None)):
    e=w.Experiment.__new__(w.Experiment);e.result={};native_calls=[]
    e.torch=SimpleNamespace(cuda=SimpleNamespace(synchronize=lambda:None))
    e.input=Operand(8);e.saved_input=Operand(9);e.metadata=lambda t:{'data_ptr':t.data_ptr()}
    e.gb=SimpleNamespace(_cublaslt_algo_arg=lambda t:t)
    e.native=SimpleNamespace(bmm_fp8=lambda *a:native_calls.append('default'),
        bmm_fp8_run_with_descriptor=lambda *a:(native_calls.append('descriptor') or used))
    e.check=lambda output,label,*a:label
    operands=[Operand(i) for i in range(6)]
    saved={'id':'winner','inputs':operands,'tactic':tactic,'graph':SimpleNamespace(replay=lambda:None),'output':operands[4]}
    if used==0:
        rejects(lambda:e.accept_actual(saved,'control'),'native rejected descriptor is fatal')
        check(e.result['native_acceptance_attempts'][0]['used_descriptor']==0,'native fallback retained in failed evidence')
    else:
        result=e.accept_actual(saved,'control')
        check(result['pointers_unchanged'] and result['original_graph_replayed'],'exact native operands and original graph validated '+repr(tactic))
        check(native_calls==(['default'] if tactic==-1 else ['descriptor']),'true native route without proxy '+repr(tactic))

original=object(); modified=object();gb=SimpleNamespace(_FP8_GEMM_SM100_TUNING_CONFIG=original)
e=w.Experiment.__new__(w.Experiment);e.setup=lambda:None;e.gb=gb;e.original_config=original;e.config=modified
e.tuner=SimpleNamespace(_profile_single_kernel=lambda:None);e.profile=lambda:None
def startup_failure():
    check(gb._FP8_GEMM_SM100_TUNING_CONFIG is modified,'scoped config installed before actual startup')
    raise RuntimeError('deliberate startup failure')
e.startup=startup_failure
rejects(e.run,'startup failure propagates')
check(gb._FP8_GEMM_SM100_TUNING_CONFIG is original,'scoped module config restored on startup failure')

source=WORKER.read_bytes().lower(); prohibited=bytes([118,108,108,109])
check(prohibited not in source,'new worker passes prohibited-name byte scan')
report={'status':'success','controls':len(checks),'checks':checks,'worker_sha256':w.sha(WORKER),
        'scope':'Actual initializer and current cache APIs execute on CPU with disclosed existing import leaves; event/graph sampler uses deterministic fake CUDA objects. No CUDA numerical or performance qualification.',
        'source_sha256':w.sha(__file__)}
Path(__file__).with_name('cpu-controls.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'success','controls':len(checks),'worker_sha256':w.sha(WORKER)}))
