"""Execute the actual coordinator bootstrap with CPU-only provider doubles."""
from __future__ import annotations
import contextlib
import hashlib
import importlib.util
import io
import json
import sys
import tempfile
from pathlib import Path
from types import ModuleType,SimpleNamespace
from unittest.mock import patch

SOURCE=Path('/private/tmp/sglang-autotune-selection-study/test/manual/kernels/results/flashinfer_autotune_selection/20261024T180000Z-h100-objective-values/run_current.py')
HELPER='b8d0f6bbc85eaca0e3ef1419ab99a97d5340c96b3da382cba81d7896768287ba'
MANIFEST='9a4c51562d7410d785cc544c004bc4f92486f40311cb5c7a7328c2c1213160d5'
checks=[]
def check(value,label):
    if not value:raise AssertionError(label)
    checks.append(label)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

with tempfile.TemporaryDirectory() as directory:
    root=Path(directory)
    for kind in ('success','source-failure','identity-failure','duplicate-binding','worker-failure','missing-result','overwrite','output-mismatch'):
        folder=root/kind;folder.mkdir();output=folder/'result.json';worker=folder/'worker.py';manifest=folder/'manifest.json';manifest.write_text('{}')
        raw=object();control=ModuleType('control_native');control.raw=raw
        gemm=ModuleType('flashinfer.gemm.gemm_base')
        fakefi=ModuleType('flashinfer');fakefi.__path__=[]
        fakegemm=ModuleType('flashinfer.gemm');fakegemm.__path__=[];fakegemm.gemm_base=gemm
        provider=ModuleType('container_preflight');provider.__file__=str(folder/'helper.py')
        provider.digest=lambda p: HELPER if str(p)==provider.__file__ else MANIFEST if Path(p)==manifest else sha(p)
        provider.prepare_data_links=lambda source:{'actual_cuda':False}
        def source_gate(*args):
            if kind=='source-failure':raise RuntimeError('deliberate source failure')
            return {'source_commit':'controlled'}
        provider.check_source=source_gate;provider.import_current=lambda source:{'controlled':True}
        def build(source,*,native_module_callback):
            bound=native_module_callback('gemm',None,raw)
            if kind=='duplicate-binding':native_module_callback('gemm',None,raw)
            native_module_callback('trtllm_utils',None,object())
            gemm.gen_gemm_module=lambda:SimpleNamespace(build_and_load=lambda:object() if kind=='identity-failure' else bound)
            return {'controlled':True}
        provider.explicit_native_build=build
        if kind=='missing-result':worker.write_text('raise SystemExit(0)\n')
        else:
            worker.write_text("import json,sys\nfrom pathlib import Path\nimport objective_values_bootstrap as bootstrap\nimport control_native\nassert bootstrap.native_gemm is control_native.raw\nout=Path(sys.argv[sys.argv.index('--output')+1])\nout.write_text(json.dumps({'status':'error' if "+repr(kind=='worker-failure')+" else 'success'}))\nraise SystemExit("+repr(1 if kind=='worker-failure' else 0)+")\n")
        mods={'container_preflight':provider,'flashinfer':fakefi,'flashinfer.gemm':fakegemm,'flashinfer.gemm.gemm_base':gemm,'control_native':control}
        tail_output=folder/'different.json' if kind=='output-mismatch' else output
        argv=['run_current.py','--source',str(folder),'--manifest',str(manifest),'--target',str(worker),'--output',str(output),'--','--output',str(tail_output)]
        if kind=='overwrite':output.write_text('keep-original')
        with patch.dict(sys.modules,mods),patch.object(sys,'argv',argv),contextlib.redirect_stdout(io.StringIO()):
            spec=importlib.util.spec_from_file_location('actual_bootstrap_control',SOURCE);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
            if kind in ('overwrite','output-mismatch'):
                try:module.main()
                except (FileExistsError,ValueError):pass
                else:raise AssertionError('missing early bootstrap guard')
                if kind=='overwrite':check(output.read_text()=='keep-original','existing result bytes never overwritten')
                check(not output.with_suffix('.bootstrap.json').exists(),'invalid/overwrite args fail before misleading bootstrap evidence '+kind)
                continue
            code=module.main();record=json.loads(output.with_suffix('.bootstrap.json').read_text())
            check(code==(0 if kind=='success' else 1),'actual bootstrap exitcode '+kind)
            check(record['status']==('passed' if kind=='success' else 'failed'),'actual bootstrap status '+kind)
            if kind=='success':
                check(record['native_identity_passthrough'] is True and record['result_sha256']==sha(output),'original raw provider handoff and exact final result binding')
                check(record['pid']>0 and record['worker_sha256']==sha(worker),'same-process worker source evidence')
            elif kind in ('source-failure','identity-failure','duplicate-binding'):
                check('error' in record and 'traceback' in record and not output.exists(),'bootstrap failure preserved without fabricated worker result '+kind)
            elif kind=='worker-failure':check(record['result_sha256']==sha(output),'failed worker original result preserved and bound')
            elif kind=='missing-result':check('without a result' in record['error'],'missing worker result is not a successful bootstrap')
report={'status':'success','controls':len(checks),'checks':checks,'source_sha256':sha(__file__),'bootstrap_sha256':sha(SOURCE),
        'scope':'Actual run_current.main/runpy/argument/output lifecycle executes with explicitly CPU-only provider/native/import doubles. No current-source import, native compilation or CUDA qualification is claimed.'}
Path(__file__).with_name('bootstrap-controls.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'success','controls':len(checks),'bootstrap_sha256':sha(SOURCE)}))
