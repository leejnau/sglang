"""Red/green CPU regression for recursively canonical live-cache digests."""
from __future__ import annotations
import ast
import hashlib
import json
import os
import subprocess
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORKER=Path('/private/tmp/sglang-autotune-selection-study/test/manual/kernels/bench_flashinfer_objective_values.py')
PYTHON=Path('/private/tmp/sglang-policy-lifecycle-venv/bin/python')
checks=[]
def check(value,label):
    if not value:raise AssertionError(label)
    checks.append(label)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def methods(path):
    return {node.name:node for node in ast.walk(ast.parse(path.read_text())) if isinstance(node,ast.FunctionDef)}
old,new=methods(HERE/'frozen_worker.py'),methods(WORKER)
def names(node):
    return next(ast.literal_eval(row.value) for row in node.body if isinstance(row,ast.Assign)
                and any(isinstance(target,ast.Name) and target.id=='names' for target in row.targets))
check(names(old['cache_state_sha'])==names(new['cache_state_sha']),'exact cache state field list unchanged')
for name in ('make_initializer','profile','policy_scope','startup_policy','capture','choose_recorder','miss_scope','time_graphs','sample','warm','operation','accept_actual','trace'):
    check(ast.dump(old[name],include_attributes=False)==ast.dump(new[name],include_attributes=False),'unchanged execution contract '+name)
variants={}
for variant,path in (('red',HERE/'frozen_worker.py'),('green',WORKER)):
    output=HERE/('regression-'+variant)
    if output.exists():raise FileExistsError('refusing to overwrite regression evidence')
    env=dict(os.environ,FI_PROOF_WORKER=str(path),FI_PROOF_OUTPUT=str(output),PYTHONHASHSEED='4')
    result=subprocess.run([str(PYTHON),str(HERE/'prove_populated_cache.py')],env=env,capture_output=True,text=True)
    (HERE/(variant+'-regression.log')).write_text(result.stdout+result.stderr)
    check(result.returncode==0,'actual populated current tuner CPU run '+variant)
    variants[variant]=json.loads((output/'proof-4.json').read_text())
    data=variants[variant]
    check(data['profile_count']==81 and all(row['restored'] for row in data['miss_scopes']),'all81 profile rows and both actual map restorations '+variant)
    check(all(not row['semantic_changed'] for row in data['phases']),'no semantic cache mutation through both scopes '+variant)
check(all(row['sha256']!=variants['red']['before_sha256'] and row['repr_changed']==['_excluded_file_keys'] for row in variants['red']['phases']),'frozen digest falsely changes after both scopes solely nested set repr')
check(all(row['sha256']==variants['green']['before_sha256'] for row in variants['green']['phases']),'corrected digest stable across both restored scopes')
check(not variants['red']['order_invariance_control']['hash_unchanged'],'frozen digest detects a purely order-only equivalent rebuild')
check(variants['green']['order_invariance_control']['hash_unchanged'],'corrected digest invariant to nested map/set order rebuild')
for row in variants['green']['real_mutation_controls']:check(row['detected'],'real mutation remains detected '+row['kind'])
for row in variants['green']['diagnostic_controls']:check(row['passed'],'final guard evidence '+row['kind'])
raw=Path('/private/tmp/fi-objective-values-20261024/coordinator/admission-failure.json');actual=json.loads(raw.read_text())
check(actual['status']=='error' and actual['error']=='RuntimeError: live selection/cache state changed after startup','actual GPU stopped at live-cache guard')
check(actual['startup']['profile_attempts']==81 and not actual['rounds'],'actual GPU timing cohort never started')
check(all(row['restored'] and row['cache_sha256_before']==row['cache_sha256_after'] for row in actual['miss_scopes']),'actual GPU restoration booleans and incidental files agree')
check(actual['startup']['cache_state_sha256']==actual['pre_capture_cache_state_sha256'],'actual GPU baseline agreed immediately before graph capture')
report={'status':'success','controls':len(checks),'checks':checks,'worker_sha256':sha(WORKER),
 'frozen_worker_sha256':sha(HERE/'frozen_worker.py'),'proof_source_sha256':sha(HERE/'prove_populated_cache.py'),'controls_source_sha256':sha(__file__),
 'actual_failure_sha256':sha(raw),'variant_reports':{variant:{'path':str(HERE/('regression-'+variant)/'proof-4.json'),'sha256':sha(HERE/('regression-'+variant)/'proof-4.json')} for variant in variants},
 'diagnosis':'A concrete false-positive digest mechanism is reproduced with exact populated current tuner/cache paths and actual admission tactic/time rows. Nested unordered set repr can change after semantically correct restoration. Recursive canonicalization preserves equal state while detecting real changes.',
 'gpu_cause_limit':'The original GPU failure did not retain per-field post-guard state, so its exact changed bytes cannot be reconstructed. Matching guard/restoration evidence and CPU reproduction strongly support this measurement-guard diagnosis; this is not proof of a production cache or native-tactic defect.',
 'scope':'No GPU experiments; native runners and profiler are controlled CPU stand-ins. Timing, initializer, policy, cache field list and restoration methods are unchanged.'}
Path(__file__).with_name('regression-controls.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'success','controls':len(checks),'worker_sha256':sha(WORKER)}))
