"""Reproduce the admission cache guard with exact current CPU tuner paths."""
from __future__ import annotations
import ast
import copy
import hashlib
import importlib.util
import json
import os
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
PROOF=Path('/private/tmp/fi-next-steps-20261024/activation-values-design/prove_profile_invariance.py')
WORKER=Path(os.environ.get('FI_PROOF_WORKER','/private/tmp/sglang-autotune-selection-study/test/manual/kernels/bench_flashinfer_objective_values.py'))
RAW=Path('/private/tmp/fi-objective-values-20261024/coordinator/admission-failure.json')
ns={'__file__':str(PROOF),'__name__':'exact_cpu_profile_loader'}
prefix=PROOF.read_text().split("control=run('synthetic_matched_copy')",1)[0]
exec(compile(prefix,str(PROOF),'exec'),ns)
api,harness,torch,original,inputs=map(ns.get,('api','harness','torch','original','inputs'))
spec=importlib.util.spec_from_file_location('frozen_objective_worker',WORKER)
w=importlib.util.module_from_spec(spec);spec.loader.exec_module(w)
raw=json.loads(RAW.read_text());times={m:{} for m in w.PROFILE_MS}
for row in raw['startup']['profiles']:
    times[row['m']][tuple(row['tactic']) if isinstance(row['tactic'],list) else row['tactic']]=row['elapsed_ms']
class CublasFp8GemmRunner(api.TunableRunner):
    def get_cache_key_extras(self,values):return (values[0].dtype,values[1].dtype,values[4].dtype)
    def get_valid_tactics(self,values,profile):return [t for t in times[values[0].shape[-2]] if t!=-1]
    def forward(self,values,tactic=-1,**kwargs):values[4].fill_(1);return values[4]
runner=CublasFp8GemmRunner();pool=[runner]
tuner=api.AutoTuner()
tuner._profile_single_kernel=lambda r,values,tactic,config,**kwargs:times[values[0].shape[-2]][tactic]
config=ns['make_config']('captured_m144',[])
e=w.Experiment.__new__(w.Experiment);e.tuner=tuner;e.result={'miss_scopes':[]}
names=next(ast.literal_eval(node.value) for node in ast.walk(ast.parse(WORKER.read_text()))
           if isinstance(node,ast.FunctionDef) and node.name=='cache_state_sha'
           for node in node.body if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='names' for t in node.targets))
policy=harness.MeasurementPolicy(execution_mode='cuda_graph')
with tempfile.TemporaryDirectory() as folder,patch.object(torch.cuda,'is_current_stream_capturing',lambda:False),harness.use_isolated_tuner(tuner):
    e.args=SimpleNamespace(cache=Path(folder)/'cache.json')
    with harness.autotune_v2(mode='tune',persistent_cache=False,measurement_policy=policy):
        chosen,tactic=tuner.choose_one('fp8_gemm',pool,config,inputs)
    tuner.save_configs(str(e.args.cache))
    before_sha=e.cache_state_sha();before={name:copy.deepcopy(getattr(tuner,name)) for name in names}
    before_repr={name:repr(getattr(tuner,name)) for name in names}
    phases=[]
    for phase in ('default','admission_explicit'):
        with harness.autotune_v2(mode='replay',persistent_cache=False,measurement_policy=policy):
            with e.miss_scope():
                if phase=='admission_explicit':
                    key=tuner._get_cache_key('fp8_gemm',runner,tuple(tuple(t.shape) for t in inputs),config,runner.get_cache_key_extras(inputs))
                    explicit=next(t for t in times[144] if t!=-1)
                    tuner._cache_profile_result(key,None,config,explicit)
                tuner.choose_one('fp8_gemm',pool,config,inputs)
        phases.append({'phase':phase,'sha256':e.cache_state_sha(),
            'semantic_changed':[name for name in names if getattr(tuner,name)!=before[name]],
            'repr_changed':[name for name in names if repr(getattr(tuner,name))!=before_repr[name]]})
    def reordered(value):
        if isinstance(value,dict):return {copy.deepcopy(key):reordered(item) for key,item in reversed(list(value.items()))}
        if isinstance(value,(set,frozenset)):return type(value)(reversed(sorted(value,key=repr)))
        if isinstance(value,list):return [reordered(item) for item in value]
        if isinstance(value,tuple):return tuple(reordered(item) for item in value)
        return copy.deepcopy(value)
    for name in names:setattr(tuner,name,reordered(getattr(tuner,name)))
    order_control={'semantic_changed':[name for name in names if getattr(tuner,name)!=before[name]],
                   'sha256':e.cache_state_sha(),'hash_unchanged':e.cache_state_sha()==before_sha}
    assert not order_control['semantic_changed']
    mutations=[]
    with harness.autotune_v2(mode='replay',persistent_cache=False,measurement_policy=policy):
        bank=tuner._winner_cache();key=next(iter(bank));old=bank[key]
        bank[key]=((123,)*8,old[1])
        mutations.append({'kind':'winner_tactic','detected':e.cache_state_sha()!=before_sha,
                          'field_detected':getattr(e,'cache_state_field_sha256',{}).get('_winner_partitions')})
        bank[key]=old
        del bank[key]
        mutations.append({'kind':'winner_removed','detected':e.cache_state_sha()!=before_sha})
        bank[key]=old
        identity=tuner._winner_cache_identity();tuner._excluded_file_keys[identity].add('deliberate_new_key')
        mutations.append({'kind':'exclusion_added','detected':e.cache_state_sha()!=before_sha})
        tuner._excluded_file_keys[identity].remove('deliberate_new_key')
    assert all(row['detected'] for row in mutations)
    diagnostic_controls=[]
    if hasattr(e,'cache_state_field_sha256'):
        e.memory_sha=e.cache_state_sha();e.memory_fields=dict(e.cache_state_field_sha256)
        e.args=SimpleNamespace(cache=e.args.cache);e.cache_sha=w.sha(e.args.cache)
        e.assert_bare=lambda:None;e.scope_state=lambda:{}
        e.read_hashes={'controlled':'unchanged'};e.operand_hashes=lambda:dict(e.read_hashes)
        e.startup_attempts=e.profile_attempts=81;e.graphs={}
        e.result.update(forbidden_profile_attempts=[],protocol_errors=[])
        e.final_checks('positive_diagnostic')
        diagnostic_controls.append({'kind':'unchanged_positive','passed':e.result['cache_state_guard_checks'][-1]['changed_fields']==[]})
        tuner._dirty_seq+=1
        try:e.final_checks('negative_diagnostic')
        except RuntimeError:
            diagnostic_controls.append({'kind':'real_mutation_guard','passed':True})
        else:raise AssertionError('real mutation escaped final guard')
        diagnostic_controls.append({'kind':'diagnostic_before_raise','passed':e.result['cache_state_guard_checks'][-1]['changed_fields']==['_dirty_seq']})
        tuner._dirty_seq-=1
        assert all(row['passed'] for row in diagnostic_controls)
    record={'status':'success','python_hash_seed':os.environ.get('PYTHONHASHSEED'),'profile_count':sum(len(t) for t in times.values()),
        'actual_gpu_record_sha256':w.sha(RAW),'worker_sha256':w.sha(WORKER),'before_sha256':before_sha,
        'phases':phases,'miss_scopes':e.result['miss_scopes'],'order_invariance_control':order_control,'real_mutation_controls':mutations,
        'diagnostic_controls':diagnostic_controls,
        'state_details':{name:{'before_repr':before_repr[name],'after_repr':repr(getattr(tuner,name))} for name in names if repr(getattr(tuner,name))!=before_repr[name]},
        'limits':'Exact current choose_one/cache/retirement/save/context paths run on CPU. GPU-only import leaves use the disclosed proof loader; native runners and profiler are controlled stand-ins with actual saved tactic/time rows. No GPU or serving result.'}
    output=Path(os.environ.get('FI_PROOF_OUTPUT',str(HERE)));output.mkdir(parents=True,exist_ok=True)
    destination=output/('proof-'+str(os.environ.get('PYTHONHASHSEED','random'))+'.json')
    destination.write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({'status':record['status'],'profile_count':record['profile_count'],'phases':phases,'path':str(destination)}))
