from pathlib import Path
import importlib.util
import json
import math
import sys

path=Path('/private/tmp/sglang-autotune-selection-study/test/manual/kernels/results/flashinfer_autotune_selection/20261024T180000Z-h100-objective-values/analyze.py')
spec=importlib.util.spec_from_file_location('objective_values_analyzer',path)
a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
checks=[]
def check(name,condition):
 assert condition,name
 checks.append(name)
def rejects(name,call):
 try:call()
 except (ValueError,KeyError,TypeError):checks.append(name)
 else:raise AssertionError(name)
plan=a.load(path.with_name('plan.json'));schedule=a.load(path.with_name('schedule.json'))
a.validate_plan(plan,schedule,path.with_name('schedule.json'));checks.append('actual_plan_schedule_full_balance')
check('zero_of_eight_onesided_exact',math.isclose(a.exact_binomial_interval(0,8)['one_sided_upper'],1-.05**(1/8),abs_tol=1e-14))
check('all_of_eight_bound',a.exact_binomial_interval(8,8)['one_sided_upper']==1)
check('clopper_pearson_symmetry',math.isclose(a.exact_binomial_interval(2,8)['two_sided_clopper_pearson'][0],1-a.exact_binomial_interval(6,8)['two_sided_clopper_pearson'][1],abs_tol=1e-14))
check('linear_quantile',a.quantile([0,10,20,30],.125)==3.75)
check('factor_orientation',all(math.isclose(x,y,abs_tol=1e-14) for x,y in zip(a.block_contrasts(dict(zip(a.CELLS,[1,2,3,6]))).values(),[math.log(2),math.log(3),0])))
workers=[]
for b in range(8):
 for cell,value in zip(a.CELLS,[1,2,3,6]):
  workers.append({'block':b,'cell':cell,'event_ratio':value,'wall_ratio':value,'selected_default':cell=='auto_synthetic'})
s=a.summarize_statistics(workers,resamples=2000)
for factor,expected in [('objective',2),('values',3),('interaction',1)]:
 row=s['factor_estimates'][factor]
 check(factor+'_closed_form_estimator',math.isclose(row['ratio_of_ratios'],expected,rel_tol=1e-14))
 check(factor+'_constant_block_bootstrap',all(math.isclose(v,expected,rel_tol=1e-14) for v in row['bootstrap_interval']['bounds']))
check('primary_family_level',s['factor_estimates']['objective']['bootstrap_interval']['confidence']==.975)
check('interaction_secondary_level',s['factor_estimates']['interaction']['bootstrap_interval']['confidence']==.95)
workers=[]
for b in range(8):
 for cell in a.CELLS:
  ratio=math.exp(.4) if b==0 and cell.startswith('graph_') else 1
  workers.append({'block':b,'cell':cell,'event_ratio':ratio,'wall_ratio':1,'selected_default':True})
s=a.summarize_statistics(workers,resamples=2000)
check('rare_bad_block_is_not_replaced_by_median',math.isclose(s['factor_estimates']['objective']['ratio_of_ratios'],math.exp(.05),rel_tol=1e-14))
check('all32_worker_outcomes_retained',sum(len(row['worker_outcomes']) for row in s['cells'].values())==32)
check('bad_selection_counts',s['cells']['graph_synthetic']['material_regressions_ratio_gt_1_10']['count']==1)
check('first_block_no_inference','bootstrap_interval' not in a.summarize_statistics(workers[:4])['factor_estimates']['objective'])
rejects('incomplete_block_reject',lambda:a.summarize_statistics(workers[:-1]))
rejects('duplicate_worker_reject',lambda:a.summarize_statistics(workers+[workers[0]]))
rejects('zero_ratio_reject',lambda:a.block_contrasts(dict(zip(a.CELLS,[1,0,1,1]))))
rejects('nan_ratio_reject',lambda:a.block_contrasts(dict(zip(a.CELLS,[1,float('nan'),1,1]))))
rejects('inf_ratio_reject',lambda:a.block_contrasts(dict(zip(a.CELLS,[1,float('inf'),1,1]))))
output={'status':'passed','checks':len(checks),'controls':checks,'scope':'CPU schedule/statistical-estimator controls; worker/raw metadata gates pending.'}
Path('/private/tmp/fi-objective-values-20261024/analysis/statistics-controls.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output))
