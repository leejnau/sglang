from pathlib import Path
import collections
import hashlib
import itertools
import json
import random

repo = Path('/private/tmp/sglang-autotune-selection-study')
batch = repo / 'test/manual/kernels/results/flashinfer_autotune_selection/20261024T180000Z-h100-objective-values'
proposal_path = Path('/private/tmp/fi-next-steps-20261024/next-study-design/proposal.json')
proposal = json.loads(proposal_path.read_text())
assert hashlib.sha256(proposal_path.read_bytes()).hexdigest() == '347b905b8b421f3f6d1160d3b40f3b7aa4348fbaf4fc0602bf5608f42932a45b'
cells = ['auto_synthetic', 'graph_synthetic', 'auto_captured', 'graph_captured']
sequences = ['ABDC', 'BCAD', 'CDBA', 'DACB']
letters = dict(zip('ABCD', cells))
order_seed = 202610241801
capture_seed = 202610241802
indices = []
order_rng = random.Random(order_seed)
for repeat in range(2):
    sequence_indices = list(range(4))
    order_rng.shuffle(sequence_indices)
    indices.extend(sequence_indices)
orders = [[letters[c] for c in sequences[index]] for index in indices]
rng = random.Random(capture_seed)
patterns = list(itertools.combinations(range(4), 2))
for search_attempt in range(1, 1_000_001):
    bits = [[int(i in chosen) for i in range(4)] for chosen in [rng.choice(patterns) for _ in range(8)]]
    if any(sum(bits[b][c] for b in range(8)) != 4 for c in range(4)):
        continue
    if any(sum(bits[b][c] for b in range(0, 8, 2)) != 2 for c in range(4)):
        continue
    if any(sum(bits[b][c] for b in range(4)) != 2 for c in range(4)):
        continue
    if any(sum(bits[b][cells.index(orders[b][pos])] for b in range(8)) != 4 for pos in range(4)):
        continue
    break
else:
    raise AssertionError('balanced capture schedule search failed')
workers = []
rounds = []
for block, order in enumerate(orders):
    pairs = [['winner', 'default']] * 12 + [['default', 'winner']] * 12
    random.Random(180100 + block).shuffle(pairs)
    rounds.append({'block': block, 'seed': 180100 + block, 'orders': pairs})
    for position, cell in enumerate(order):
        objective, values = cell.split('_')
        workers.append({'block': block, 'williams_sequence': sequences[indices[block]], 'launch_position': position,
                        'launch_index': block * 4 + position, 'cell': cell, 'objective': objective, 'values': values,
                        'capture_order': 'winner-first' if bits[block][cells.index(cell)] else 'default-first',
                        'replay_order_seed': 180100 + block,
                        'raw_name': f'block{block}-{cell}-timing.json',
                        'trace_name': f'block{block}-{cell}-timing.trace.json',
                        'bootstrap_name': f'block{block}-{cell}-timing.bootstrap.json'})
schedule = {'schema_version': 1, 'cells': cells, 'independent_blocks': 8, 'workers': 32,
            'launch_randomization': {'design': 'Four-sequence first-order-balanced Williams design, two complete repeats; shuffle the four sequence labels separately within each repeat using one seeded generator.',
                                     'sequences': sequences, 'seed': order_seed, 'sequence_indices': indices},
            'capture_randomization': {'seed': capture_seed, 'search_attempt': search_attempt,
                                     'algorithm': 'Independent seeded draws of two winner-first cells in each block; first schedule with4/8 winner-first per cell,2/4 per cell in each Williams repeat,2/4 per cell on even blocks and4/8 per launch position.',
                                     'winner_first_bits_in_cell_order': bits},
            'entries': workers, 'round_schedules': rounds}
(batch/'schedule.json').write_text(json.dumps(schedule, indent=2)+'\n')
plan = {'schema_version': 1, 'batch_id': batch.name,
        'scope': 'Fixed current-source mechanism pilot. No production policy, persistence, model performance or rare-failure safety claim.',
        'proposal_sha256': hashlib.sha256(proposal_path.read_bytes()).hexdigest(),
        'schedule_sha256': hashlib.sha256((batch/'schedule.json').read_bytes()).hexdigest(),
        'source_contract': proposal['source_contract'],
        'qualified_source': {'candidate_manifest_sha256': '9a4c51562d7410d785cc544c004bc4f92486f40311cb5c7a7328c2c1213160d5',
                             'container_preflight_sha256': 'b8d0f6bbc85eaca0e3ef1419ab99a97d5340c96b3da382cba81d7896768287ba',
                             'fp8_port_patch_sha256': 'e5c0a130690cd9fe9f1204b11368433430345f066ee8dc3bd376cf49c7ef4d64',
                             'callback_patch_sha256': '706ca4d91f3e6ef8c1643977beef72fa39af121e691f9380a175633787fe94ef',
                             'qualification_execution_commit': '12447b7d6219d54d1296401c0b8cfeeff1568931',
                             'version_limit': 'Official fallback package0.0.0+unknown/unknown; exact source manifests and native artifacts establish identity.'},
        'environment': {'image': 'lmsysorg/sglang@sha256:c1f4d9fc6fcf50c2269adbc757ce7b1778883af04155edb888fa9eea3b6648c0',
                        'gpu': 'NVIDIA H100 NVL', 'uuid': '240958a2-e8e1-3bac-b767-365c9e0b97bd', 'driver': '580.159.04',
                        'power_limit_watts': 310, 'torch': '2.14.1+cu130', 'exclusive': True, 'image_id': 'sha256:2e152727f0a5ce999172ec48203b2b292d41b3cb370976827718870557899caa'},
        'protocol': {'worker': 'test/manual/kernels/bench_flashinfer_objective_values.py', 'independent_blocks': 8,
                     'timing_workers': 32, 'cells': {c: dict(zip(('objective','values'),c.split('_'))) for c in cells},
                     'seed': 19, 'actual_profile_ms': [1,2,4,8,16,32,64,128,144], 'runtime_cache_m':256,
                     'profiles_per_worker':9, 'expected_tactics_per_profile':9, 'expected_measurements_per_worker':81,
                     'rounds':24, 'replays_per_sample':16, 'prequeue_cycles':10_000_000,
                     'initial_warmup_ms':500, 'rewarm_ms':20, 'capture_graphs':['winner','default'],
                     'startup_history':False, 'inline_gpu_fingerprints':False, 'cache_persistence':False,
                     'graph_profile_replays':1, 'profiler_warmup':3, 'profiler_repeat':10, 'cold_l2':False,
                     'objective_auto':None, 'objective_graph':{'execution_mode':'cuda_graph'},
                     'graph_timing':None, 'global_timer':False,
                     'timing_oracle': 'Same retained full-layer graphs; GPU events exclude the queued sleep. Queued wall time is diagnostic only.',
                     'all_query_outcomes_retained':True, 'no_adaptive_depth':True,
                     'first_block_gate': 'Integrity/comparability only; then all remaining28 workers, independent of observed winners or signs.',
                     'candidate_order_scope': 'Original ordered candidate pool at each fixed actual profile M must match across cells/processes. Different M endpoints may have different descriptor lists.'},
        'analysis': {'primary_unit':'One complete four-cell fresh-process block.',
                     'worker_estimator':'Median of24 within-round winner/default GPU-event ratios.',
                     'objective_log_contrast':'0.5 * ((log graph_synthetic - log auto_synthetic) + (log graph_captured - log auto_captured))',
                     'values_log_contrast':'0.5 * ((log auto_captured - log auto_synthetic) + (log graph_captured - log graph_synthetic))',
                     'primary_estimator':'Exponentiate the arithmetic mean of8 complete-block log contrasts.',
                     'primary_factor_family':['objective','values'],
                     'bootstrap': {'unit':'whole four-cell block', 'resamples':200_000, 'seed':202610241803,
                                   'sampling':'Python random.Random(seed).randrange(8),8 draws per replicate; same resampled block indices for both primary factors and secondary interaction.',
                                   'interval_level':0.975, 'tail_probabilities':[0.0125,0.9875],
                                   'quantile':'Linear interpolation at sorted index (B-1)*p (Hyndman-Fan type7).',
                                   'interpretation':'Bonferroni-adjusted nominal95% two-factor estimation family; exploratory percentile intervals with only8 blocks, no formal equivalence or superiority conclusion.'},
                     'secondary':['All four cell worker distributions and full block contrasts; interaction; profiler margins by bucket; selection/kernel/native identities; order strata; paired queued wall diagnostics.'],
                     'material_regression':{'threshold':1.10,'comparison':'>','scope':'Research classifier, not a production replacement margin or safety policy.'},
                     'frequency_uncertainty': {'per_cell_n':8,'two_sided':'Exact95% Clopper-Pearson binomial intervals.',
                                               'one_sided_failure_upper':'Exact95% upper bound;0/8 gives1-0.05**(1/8), approximately31.2%.',
                                               'limit':'Fixed-input process repetitions may be nonstationary/dependent; binomial bounds are conditional and not safety certification.'},
                     'no_pooling':'No historical pooling or within-worker pseudo-replication; all outcomes, failed selections and traces retained.',
                     'small_effect_limit':'Calibration showed recipe sensitivity around1.3–1.5% and unresolved sub-percent capture effects. Same-default small ratios do not demonstrate a speedup.'},
        'values_limits':[proposal['fixed_controls']['honest_values_limit'],proposal['fixed_controls']['matched_control_limit']],
        'admission': proposal['fixed_controls']['separate_values_admission'],
        'stopping':{'integrity_failure':'Stop and preserve all outcomes; no retry or silent substitution.',
                    'performance_sign':'Never a stop/acceptance criterion.', 'complete_blocks_required':8,
                    'no_automatic_expansion':True},
        'limits': ['Research source with unmerged FP8 runtime/callback patches, not stock FlashInfer.',
                   'Selected explicit native acceptance after timing proves viability on the retained problem, not observation of native return during the earlier capture. Capture lookup/submitted-tactic provenance and same-original-graph trace are separate required evidence.',
                   'No scoped-cache prototype, persistence claim, production policy change, distributed adoption or full-model performance inference.',
                   'All-default or neutral results show only no demonstrated benefit in this one fixed current-source case.']}
(batch/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'batch':str(batch),'capture_search_attempt':search_attempt,'schedule_sha256':plan['schedule_sha256'],'plan_sha256':hashlib.sha256((batch/'plan.json').read_bytes()).hexdigest(),'workers':len(workers)}))
