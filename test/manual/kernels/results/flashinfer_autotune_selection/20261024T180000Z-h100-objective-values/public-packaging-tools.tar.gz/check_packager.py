"""CPU fault controls for lossless public-evidence packaging."""
from __future__ import annotations
import copy
import gzip
import importlib.util
import json
import tarfile
import tempfile
from pathlib import Path

SOURCE=Path(__file__).with_name('package_results.py')
spec=importlib.util.spec_from_file_location('public_packager',SOURCE);p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
checks=[]
def check(value,label):
    if not value:raise AssertionError(label)
    checks.append(label)
def rejects(function,label):
    try:function()
    except RuntimeError:checks.append(label)
    else:raise AssertionError(label)
def archive(raw,path):
    with tarfile.open(path,'w:gz') as handle:handle.add(raw,arcname=raw.name)

historical=Path('/private/tmp/fi-next-steps-20261024/current-source-coordinator/raw/attempt02/retained-auto.bootstrap.json')
original=historical.read_bytes();derived,evidence=p.derive_bootstrap(original)
before=json.loads(original);after=json.loads(derived)
check(evidence['omitted_entries']==6,'actual historical schema has six offending AOT inventory labels')
check(after['native']==before['native'] and after['source']==before['source'] and after['result_sha256']==before['result_sha256'],'actual schema native/source/result evidence preserved exactly')
check(after['import']['source_modules']==before['import']['source_modules'],'actual source-module inventory unchanged when safe')
check(not p.forbidden(derived) and evidence['private_file_sha256']==p.digest(original),'actual historical inventory derivative is safe and binds original bytes')

with tempfile.TemporaryDirectory() as directory:
    base=Path(directory);raw=base/'attempt01';raw.mkdir()
    (raw/'worker.json').write_bytes(b'{"status":"success","rounds":[{"elapsed_ms":0.1}]}\n')
    (raw/'failed.json').write_bytes(b'{"status":"error","error":"preserve original failure"}\n')
    (raw/'worker.trace.json').write_bytes(b'{"traceEvents":[{"name":"actual_kernel"}]}\n')
    (raw/'other.trace.json.gz').write_bytes(gzip.compress(b'{"traceEvents":[]}',mtime=0))
    boot={'status':'passed','source':{'critical_sha256':'unchanged'},'native':{'library_sha256':'a'*64,'compile_commands':['c++ original.cpp']},
          'import':{'source_modules':{'safe':{'path':'safe.py'},p.TOKEN.decode():{'path':'private.py'}},
                    'aot_providers':[{'id':'provider','version':'1','modules':['safe_kernel',p.TOKEN.upper().decode()]}]}}
    (raw/'worker.bootstrap.json').write_text(json.dumps(boot,indent=1)+'\n')
    (raw/'fixture').mkdir();(raw/'fixture/fixture.safetensors').write_bytes(b'private tensor')
    (raw/'native-build-cache').mkdir();(raw/'native-build-cache/module.so').write_bytes(b'private binary')
    (raw/'native-build-cache/build.ninja').write_bytes(b'rule build\n  command = c++ original.cpp\n')
    private=base/'private.tgz';archive(raw,private)
    output=base/'public';audit=p.package(raw,private,output,p.file_sha(private))
    check(audit['status']=='success' and audit['derived_bootstrap_files']==1 and audit['omitted_inventory_entries']==2,'complete positive package and scan')
    for name in ('worker.json','failed.json','worker.trace.json','other.trace.json.gz','native-build-cache/build.ninja'):
        check((output/'raw'/name).read_bytes()==(raw/name).read_bytes(),'byte-exact public evidence '+name)
    public_boot=json.loads((output/'raw/worker.bootstrap.json').read_text())
    check(public_boot['native']==boot['native'] and public_boot['source']==boot['source'],'all source/native compile evidence unchanged')
    check(public_boot['import']['source_modules']=={'safe':{'path':'safe.py'}} and public_boot['import']['aot_providers'][0]['modules']==['safe_kernel'],'only offending source/AOT entries omitted')
    check(not (output/'raw/fixture/fixture.safetensors').exists() and not (output/'raw/native-build-cache/module.so').exists(),'private tensor/binary excluded with hashes')
    manifest=json.loads((output/'public-manifest.json').read_text())
    check(manifest['private_members_verified']==8 and len(manifest['excluded_private_files'])==2,'entire private archive membership bound and exclusions disclosed')
    second=base/'public-copy';p.package(raw,private,second,p.file_sha(private))
    check(p.file_sha(output/'raw-public.tar.gz')==p.file_sha(second/'raw-public.tar.gz'),'public compressed artifact deterministic')
    before_hash=p.file_sha(output/'raw-public.tar.gz')
    rejects(lambda:p.package(raw,private,output),'existing public output rejected')
    check(p.file_sha(output/'raw-public.tar.gz')==before_hash,'overwrite rejection retains original archive bytes')
    rejects(lambda:p.package(raw,private,base/'wrong-sha','0'*64),'wrong private archive SHA rejected')
    (raw/'worker.json').write_bytes(b'changed')
    rejects(lambda:p.package(raw,private,base/'wrong-tree'),'private archive/extracted mismatch rejected')
    (raw/'worker.json').write_bytes(b'unsafe '+p.TOKEN)
    bad=base/'bad-private.tgz';archive(raw,bad)
    rejects(lambda:p.package(raw,bad,base/'unsafe-worker'),'prohibited content in worker evidence is fatal, never rewritten')
    check(not (base/'unsafe-worker').exists(),'failed package leaves no completed public output')
    (raw/'worker.json').write_bytes(b'safe')
    (raw/'other.trace.json.gz').write_bytes(gzip.compress(p.TOKEN,mtime=0));archive(raw,bad)
    rejects(lambda:p.package(raw,bad,base/'unsafe-compressed-trace'),'compressed trace contents independently scanned')
    outside=copy.deepcopy(boot);outside['native']['unsupported']=p.TOKEN.decode()
    rejects(lambda:p.derive_bootstrap(json.dumps(outside).encode()),'prohibited native field is never silently sanitized')
    (output/'raw/worker.json').write_bytes(b'tampered')
    rejects(lambda:p.verify_public(output),'staged evidence/archive tampering detected')

check(not p.forbidden(SOURCE.read_bytes()) and not p.forbidden(Path(__file__).read_bytes()),'packaging helpers pass prohibited-byte scan')
report={'status':'success','controls':len(checks),'checks':checks,'packager_sha256':p.file_sha(SOURCE),'controls_source_sha256':p.file_sha(__file__),
        'scope':'Synthetic temporary private archives exercise packaging, complete member/hash verification, explicit inventory-only omissions, compressed trace scanning and failure preservation. Prior qualification data is inspected in memory for schema only, never republished.'}
Path(__file__).with_name('packaging-controls.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'success','controls':len(checks),'packager_sha256':p.file_sha(SOURCE)}))
