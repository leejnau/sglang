from pathlib import Path
import ast,difflib,gzip,hashlib,io,json,subprocess,tarfile
repo=Path('/private/tmp/sglang-autotune-selection-study')
relative=Path('test/manual/kernels/results/flashinfer_autotune_selection/20261024T180000Z-h100-objective-values')
batch=repo/relative;base=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
originals={}
for name in ('cpu-validation.json','analysis-controls.tar.gz','analysis-controls-index.json'):
 blob=subprocess.run(['git','-C',str(repo),'show','900c3f9656e468f8c942b828fa699bc8bd28f3a7:'+str(relative/name)],capture_output=True,check=True).stdout
 assert hashlib.sha256(blob).hexdigest()==sha(batch/name)
 originals[name]=sha(batch/name)
assert sha(batch/'plan.json')=='d13c06b45e57dbf2a4f864a161970749934337d2508d0b757467d02f4c98eb7d'
assert sha(batch/'schedule.json')=='cca9dd435bd9c47192d4193153f94c801acb265ecc75bee86c4542482824da0d'
assert sha(repo/'test/manual/kernels/bench_flashinfer_objective_values.py')=='979e28aeb3248b27cb27df21b98cf274442c0e6b92c4df3444c48f7214ce90ba'
controls=json.loads((base/'applied-controls.json').read_text());actual_controls=json.loads((base/'compile-metadata-controls.json').read_text());gate=json.loads((base/'actual-admission-gate03-applied.json').read_text())
assert controls['status']=='passed' and controls['checks']==63
assert actual_controls['status']=='passed' and actual_controls['checks']==11
assert gate['status']=='passed' and gate['validated_workers']==4 and gate['mode']=='admission'
assert ast.dump(ast.parse((batch/'analyze.py').read_text()),include_attributes=False)==ast.dump(ast.parse((base/'analyze_candidate.py').read_text()),include_attributes=False)
patch=''
for name in ('analyze.py','analyzer_controls.py'):
 old=(base/(name+'.baseline')).read_text();new=(batch/name).read_text()
 patch+=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='a/'+str(relative/name),tofile='b/'+str(relative/name)))
(base/'revision03.patch').write_text(patch)
reanalysis=batch/'attempt02/reanalyzed';reanalysis.mkdir(parents=True,exist_ok=True)
(reanalysis/'admission-analysis.json').write_bytes((base/'actual-admission-gate03-applied.json').read_bytes())
status={'schema_version':1,'status':'offline_corrected_checker_passed_four_admissions','original_attempt02_status':'failed original frozen analyzer compilation metadata guard; preserved without relabeling','execution_commit':'900c3f9656e468f8c942b828fa699bc8bd28f3a7','private_raw_archive_sha256':'09c4e8981d84bf84fbdd7a51c28df9292eb5fb2f67583370d1a4bd467e00e43a','corrected_analyzer_sha256':sha(batch/'analyze.py'),'analysis_sha256':sha(reanalysis/'admission-analysis.json'),'producer_source_verification':'Forty source blobs reconstructed from exact execution commit and verified against original raw manifest; real Git source checks executed without CPU adaptation.','admission_workers':4,'startup_profile_rows':324,'recorded_numerical_checks':108,'timing_workers':0,'factor_estimates':None,'limit':'The offline correction validates the four instrumented admissions; it does not turn them into timing trials or change the original attempt02 outcome.'}
(reanalysis/'status.json').write_text(json.dumps(status,indent=2)+'\n')
report={'schema_version':1,'status':'passed','revision':3,'scope':'Analyzer correction only; no worker, source/provider, factor, schedule, sample or statistics change.','reason':'Previous analyzer incorrectly required CUDA architecture flags on four genuine host C++ translation units.','source_sha256':{name:sha(batch/name) for name in ('analyze.py','analyzer_controls.py','plan.json','schedule.json')},'worker_sha256':sha(repo/'test/manual/kernels/bench_flashinfer_objective_values.py'),'full_analyzer_CPU_controls':controls,'actual_prior_native_compile_metadata_controls':actual_controls,'actual_four_admission_reanalysis':status,'minimal_patch_sha256':sha(base/'revision03.patch'),'original_CPU_artifacts_unchanged':originals,'formatting_only_after_reviewed_scratch_candidate':True,'hooks':'All applicable repository pre-commit hooks passed after formatting.','limits':['CPU doubles retain disclosed historical Git lookup adaptation; the actual four-admission reanalysis uses exact committed producer source blobs and real source checks.','All failed original gates and scratch invocation errors remain preserved. No timing workers or factor estimates exist.','A distinct frozen revision is required before new GPU work.']}
(batch/'revision03-cpu-validation.json').write_text(json.dumps(report,indent=2)+'\n')
items=[('src/analyze.py',batch/'analyze.py'),('src/analyzer_controls.py',batch/'analyzer_controls.py'),('baseline/analyze.py',base/'analyze.py.baseline'),('baseline/analyzer_controls.py',base/'analyzer_controls.py.baseline'),('revision03.patch',base/'revision03.patch'),('controls/full-controls.json',base/'applied-controls.json'),('controls/actual-compile-metadata-controls.json',base/'compile-metadata-controls.json'),('controls/check_compile_metadata.py',base/'check_compile_metadata.py'),('scratch/analyze_candidate.py',base/'analyze_candidate.py'),('scratch/analyzer_controls_candidate.py',base/'analyzer_controls_candidate.py'),('scratch/prepare_candidate.py',base/'prepare_candidate.py'),('scratch/prepare_controls_candidate.py',base/'prepare_controls_candidate.py'),('scratch/run_candidate_controls.py',base/'run_candidate_controls.py'),('scratch/candidate-full-controls.json',base/'candidate-full-controls.json'),('scratch/offline-readiness.json',base/'offline-readiness.json'),('scratch/gate01-invocation.stderr.log',base/'actual-admission-gate01.stderr.log'),('scratch/gate02-candidate-analysis.json',base/'actual-admission-gate02.json'),('actual/admission-analysis.json',reanalysis/'admission-analysis.json'),('actual/status.json',reanalysis/'status.json'),('package_revision03.py',Path(__file__))]
index=[];archive=batch/'revision03-analysis-controls.tar.gz'
with archive.open('wb') as target,gzip.GzipFile(filename='',mode='wb',fileobj=target,mtime=0) as compressed,tarfile.open(fileobj=compressed,mode='w') as tar:
 for name,path in items:
  data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data));index.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(batch/'revision03-analysis-controls-index.json').write_text(json.dumps({'schema_version':1,'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive)},'members':index},indent=2)+'\n')
print(json.dumps({'analyzer_sha256':sha(batch/'analyze.py'),'controls_sha256':sha(batch/'analyzer_controls.py'),'CPU_validation_sha256':sha(batch/'revision03-cpu-validation.json'),'archive_sha256':sha(archive),'index_sha256':sha(batch/'revision03-analysis-controls-index.json'),'actual_gate_sha256':sha(reanalysis/'admission-analysis.json'),'status_sha256':sha(reanalysis/'status.json'),'patch_sha256':sha(base/'revision03.patch'),'archive_members':len(items)},indent=2))
