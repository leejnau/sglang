from pathlib import Path
import copy,hashlib,importlib.util,json,sys
base=Path(__file__).parent
spec=importlib.util.spec_from_file_location('candidate_analyzer',base/'analyze_candidate.py');a=importlib.util.module_from_spec(spec);sys.modules[spec.name]=a;spec.loader.exec_module(a)
raw=Path('/private/tmp/fi-next-steps-20261024/current-source-coordinator/raw/attempt02/retained-auto.bootstrap.json')
evidence=json.loads(raw.read_text());checks=[]
a.normalize_provider_identity(evidence);checks.append('actual_qualified_4CUDA_4host_commands_accepted')
def reject(name,mutate):
 x=copy.deepcopy(evidence);mutate(x)
 try:a.normalize_provider_identity(x)
 except (ValueError,KeyError,IndexError):checks.append(name)
 else:raise AssertionError(name)
cu=lambda x:x['native']['providers']['gemm']['compile_commands'][0]
host=lambda x:x['native']['providers']['trtllm_utils']['compile_commands'][1]
reject('CUDA_missing_architecture',lambda x:cu(x).update(command=cu(x)['command'].replace('-gencode=arch=compute_90a,code=sm_90a','')))
reject('CUDA_wrong_architecture',lambda x:cu(x).update(command=cu(x)['command'].replace('compute_90a,code=sm_90a','compute_100a,code=sm_100a')))
reject('CUDA_wrong_compiler',lambda x:cu(x).update(command=cu(x)['command'].replace('/usr/local/cuda/bin/nvcc','c++',1)))
reject('host_wrong_compiler',lambda x:host(x).update(command=host(x)['command'].replace('c++','nvcc',1)))
reject('host_CUDA_architecture_argument',lambda x:host(x).update(command=host(x)['command']+' -gencode=arch=compute_90a,code=sm_90a'))
reject('unqualified_source_path',lambda x:host(x).update(file='/opt/other/source.cpp'))
reject('command_recorded_source_mismatch',lambda x:host(x).update(command=host(x)['command'].replace(host(x)['file'],'/study/input/current/source/csrc/wrong.cpp',1)))
reject('duplicate_translation_unit',lambda x:x['native']['providers']['trtllm_utils']['compile_commands'].__setitem__(2,copy.deepcopy(host(x))))
reject('wrong_actual_FP8_source',lambda x:x['native']['providers']['gemm']['sources'].update({'/study/input/current/source/flashinfer/data/csrc/bmm_fp8.cu':'bad'}))
reject('AOT_provider_instead_of_current_JIT',lambda x:x['native']['providers']['gemm'].update(library_path='/opt/site-packages/gemm.so'))
result={'status':'passed','checks':len(checks),'controls':checks,'metadata_source_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'candidate_sha256':hashlib.sha256((base/'analyze_candidate.py').read_bytes()).hexdigest(),'scope':'Offline metadata-validator controls using preserved actual prior native build metadata. No GPU action or new native build.'}
(base/'compile-metadata-controls.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
