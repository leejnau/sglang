from pathlib import Path
import importlib.util,json,sys,types,hashlib
base=Path(__file__).parent
repo=Path('/private/tmp/sglang-autotune-selection-study')
original=repo/'test/manual/kernels/results/flashinfer_autotune_selection/20261024T180000Z-h100-objective-values/analyzer_controls.py'
spec=importlib.util.spec_from_file_location('scratch_candidate_analyzer',base/'analyze_candidate.py');a=importlib.util.module_from_spec(spec);sys.modules[spec.name]=a;spec.loader.exec_module(a)
source=(base/'analyzer_controls_candidate.py').read_text();m=types.ModuleType('scratch_candidate_controls');m.__file__=str(original)
exec(compile(source,str(original),'exec'),m.__dict__)
result=m.run(a)
result['candidate_analyzer_sha256']=hashlib.sha256((base/'analyze_candidate.py').read_bytes()).hexdigest()
result['candidate_controls_sha256']=hashlib.sha256(source.encode()).hexdigest()
result['controlled_path_resolution']='Candidate CPU controls use the original controls __file__ location solely to find current source/fixture files; historical Git lookup remains the existing disclosed CPU adaptation.'
(base/'candidate-full-controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'checks':result['checks'],'source_sha256':result['candidate_analyzer_sha256']}))
