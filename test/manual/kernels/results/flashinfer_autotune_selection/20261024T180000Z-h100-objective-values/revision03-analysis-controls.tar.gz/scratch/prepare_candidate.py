from pathlib import Path
import difflib,hashlib,json
root=Path('/private/tmp/sglang-autotune-selection-study')
source=root/'test/manual/kernels/results/flashinfer_autotune_selection/20261024T180000Z-h100-objective-values/analyze.py'
base=Path(__file__).parent
text=source.read_text()
old='''        require(
            all(
                "-gencode=arch=compute_90a,code=sm_90a" in row["command"]
                and "/study/input/current/source/" in row["command"]
                for row in commands
            ),
            "current-source H100 native compilation",
        )
'''
new='''        import shlex

        compiled_sources = []
        for row in commands:
            path = Path(row["file"])
            require(
                str(path).startswith("/study/input/current/source/csrc/"),
                "actual current-source translation-unit path",
            )
            relative = str(path).split("/csrc/", 1)[1]
            require(relative in sources, "compiled source belongs to qualified provider")
            compiled_sources.append(relative)
            argv = shlex.split(row["command"])
            require(
                argv.count("-c") == 1 and argv[argv.index("-c") + 1] == str(path),
                "compile command names its recorded translation unit",
            )
            compiler = Path(argv[0]).name
            if path.suffix == ".cu":
                require(
                    compiler == "nvcc"
                    and "-gencode=arch=compute_90a,code=sm_90a" in argv,
                    "current-source H100 CUDA compilation",
                )
            elif path.suffix == ".cpp":
                require(
                    compiler in {"c++", "g++", "clang++"}
                    and not any(arg.startswith(("-gencode", "--generate-code")) for arg in argv),
                    "current-source host C++ compilation",
                )
            else:
                raise ValueError("unexpected native translation-unit type")
        require(
            len(set(compiled_sources)) == len(sources)
            and set(compiled_sources) == set(sources),
            "complete one-to-one native translation-unit compilation",
        )
'''
assert text.count(old)==1
candidate=text.replace(old,new)
(base/'analyze_candidate.py').write_text(candidate)
patch=''.join(difflib.unified_diff(text.splitlines(keepends=True),candidate.splitlines(keepends=True),fromfile='a/analyze.py',tofile='b/analyze.py'))
(base/'candidate.patch').write_text(patch)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(base/'candidate-manifest.json').write_text(json.dumps({'scope':'Scratch-only analyzer correction; repository source unchanged.','base_analyzer_sha256':sha(source),'candidate_analyzer_sha256':sha(base/'analyze_candidate.py'),'patch_sha256':sha(base/'candidate.patch'),'change':'Classify actual CUDA versus host C++ translation units; retain complete source/command coverage, source identity and cross-worker provider equality.'},indent=2)+'\n')
print((base/'candidate-manifest.json').read_text())
