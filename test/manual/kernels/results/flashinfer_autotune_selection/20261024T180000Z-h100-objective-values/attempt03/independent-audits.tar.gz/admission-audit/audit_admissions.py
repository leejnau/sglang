"""Independent actual-data audit of the four disposable admission workers."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import re
import struct
from pathlib import Path

CELLS=('auto_synthetic','graph_synthetic','auto_captured','graph_captured')
MS=(1,2,4,8,16,32,64,128,144)
checks=[]
def check(value,label):
    if not value:raise AssertionError(label)
    checks.append(label)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'))
def signature(event):
    fields=('device','grid','block','registers per thread','shared memory')
    return {'name':event['name'],**{key:event['args'].get(key) for key in fields}}
def trace_audit(path,rows):
    events=json.loads(path.read_text())['traceEvents'];result={};all_ids=[]
    for name in ('winner','default'):
        markers=[row for row in events if row.get('cat')=='user_annotation' and row.get('name')=='retained_'+name and row.get('ph')=='X']
        check(len(markers)==1,'one original CPU marker '+path.name+name)
        marker=markers[0];lo,hi=marker['ts'],marker['ts']+marker['dur']
        launches=sorted([row for row in events if row.get('cat')=='cuda_runtime' and 'cudaGraphLaunch' in row.get('name','') and lo<=row['ts']<=hi],key=lambda row:row['ts'])
        check(len(launches)==3 and len({row['args']['correlation'] for row in launches})==3,'three retained launches/correlations '+path.name+name)
        cycles=[];ids=set()
        for launch in launches:
            kernels=sorted([row for row in events if row.get('cat')=='kernel' and row.get('args',{}).get('correlation')==launch['args']['correlation']],key=lambda row:row['ts'])
            check(len(kernels)>=2 and any('_static_quant_fp8' in row['name'] for row in kernels) and any('_static_quant_fp8' not in row['name'] for row in kernels),'actual quantizer and GEMM '+path.name+name)
            check(all(lo<=row['ts'] and row['ts']+row['dur']<=hi+1 for row in kernels),'all graph kernels finish inside synchronized marker '+path.name+name)
            ids.update(row['args']['graph id'] for row in kernels);cycles.append([signature(row) for row in kernels])
        check(cycles[0]==cycles[1]==cycles[2] and len(ids)==1 and next(iter(ids))>0,'same ordered launches for original graph '+path.name+name)
        row=rows[name]
        check(row['graph_launch_events']==3 and row['kernel_events']==len(cycles[0])*3,'recorded trace counts match actual events '+path.name+name)
        result[name]={'graph_id':next(iter(ids)),'ordered_launch_signature':cycles[0]};all_ids.extend(ids)
    check(len(set(all_ids))==2,'two distinct retained CUDA graph identities '+path.name)
    return result

def fixture_read_hashes(root):
    manifest=json.loads((root/'fixture/manifest.json').read_text());data=(root/'fixture/fixture.safetensors').read_bytes()
    length=struct.unpack_from('<Q',data)[0];header=json.loads(data[8:8+length]);payload=data[8+length:]
    blobs={key:payload[meta['data_offsets'][0]:meta['data_offsets'][1]] for key,meta in header.items() if key!='__metadata__'}
    for key,blob in blobs.items():check(hashlib.sha256(blob).hexdigest()==manifest['tensors'][key]['sha256'],'actual immutable fixture bytes '+key)
    weight=hashlib.sha256()
    for k in range(1024):weight.update(blobs['weight_fp8_rowmajor'][k::1024])
    return manifest,[manifest['quantization']['independent_input_fp8_sha256'],weight.hexdigest(),hashlib.sha256(blobs['input_scale']).hexdigest(),hashlib.sha256(blobs['weight_scale']).hexdigest()]

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--raw-root',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    check(not args.output.exists(),'refuse audit report overwrite')
    manifest,read_hashes=fixture_read_hashes(args.raw_root)
    records={};providers=[];containers=[];summaries={}
    for cell in CELLS:
        path=args.raw_root/('admission-'+cell+'.json');data=json.loads(path.read_text());records[cell]=data
        prefix=cell+': '
        check(data['status']=='success' and data['mode']=='admission' and not data['rounds'] and data['block']==0,prefix+'disposable successful admission, zero timing rounds')
        check((args.raw_root/('admission-'+cell+'.exit-code')).read_text().strip()=='0',prefix+'container completed successfully')
        container=(args.raw_root/('admission-'+cell+'.container-id')).read_text().strip();check(re.fullmatch('[a-f0-9]{64}',container) is not None,prefix+'actual container identifier');containers.append(container)
        bootstrap=json.loads(path.with_suffix('.bootstrap.json').read_text())
        check(bootstrap['status']=='passed' and bootstrap['pid']==data['pid'] and bootstrap['result_sha256']==sha(path) and bootstrap['worker_sha256']==data['worker_sha256'],prefix+'same-process exact bootstrap/worker source/result binding')
        check(bootstrap['native_identity_passthrough'] and data['source']['native_identity_passthrough'],prefix+'unproxied original native provider')
        provider_identity={}
        for name,provider in bootstrap['native']['providers'].items():
            check(provider['linkage']['returncode']==0 and 'not found' not in provider['linkage']['stdout'],prefix+'native dependencies resolved '+name)
            check(len(provider['sources'])==(3 if name=='gemm' else 5),prefix+'actual full translation units '+name)
            for command in provider['compile_commands']:
                matching=[source for source in provider['sources'] if source.replace('/flashinfer/data/csrc/','/csrc/')==command['file']]
                check(len(matching)==1 and command['file'].startswith('/study/input/current/source/'),prefix+'compile command belongs to exact pinned source through official data symlink '+Path(command['file']).name)
                if command['file'].endswith('.cu'):
                    check('-gencode=arch=compute_90a,code=sm_90a' in command['command'],prefix+'CUDA translation unit targets H100 '+Path(command['file']).name)
                else:check(command['file'].endswith('.cpp'),prefix+'host translation unit is C++ '+Path(command['file']).name)
            provider_identity[name]={key:provider[key] for key in ('library_sha256','ninja_sha256','sources','exports_checked')}
        providers.append(provider_identity)
        profiles=data['startup']['profiles'];initializers=data['startup']['initializer_calls']
        check(data['startup']['profile_attempts']==81==len(profiles) and not data['forbidden_profile_attempts'] and not data['protocol_errors'],prefix+'all81 original profiling measurements and no hidden errors')
        check([row['shape'][1] for row in initializers]==list(MS) and sum(row['targeted'] for row in initializers)==1 and sum(row['cloned'] and row['copied'] for row in initializers)==1,prefix+'exact nine initializer endpoints and matched M144 intervention')
        check(all(row['fingerprinted'] and row['error'] is None and math.isfinite(row['elapsed_ms']) and row['elapsed_ms']>0 for row in profiles),prefix+'positive finite actual timings with explicit admission hashes')
        by_m={m:[row for row in profiles if row['m']==m] for m in MS}
        check([row['m'] for m in MS for row in by_m[m]]==[row['m'] for row in profiles],prefix+'original endpoint profiling sequence')
        for m,group in by_m.items():
            check(len(group)==9 and group[0]['tactic']==-1 and sum(row['tactic']==-1 for row in group)==1,prefix+'default races eight descriptors M'+str(m))
            check(all(row['fingerprints']==group[0]['fingerprints'] for row in group),prefix+'all candidates use same read bytes M'+str(m))
            check(group[0]['fingerprints'][0]==initializers[MS.index(m)]['returned_sha256'],prefix+'initializer returned actual profiled bytes M'+str(m))
            for row in group:
                settings=row['settings'];config=settings['config']
                expected_policy={'execution_mode':'cuda_graph','cold_l2':None,'_timer':'auto','graph_timing':None} if cell.startswith('graph_') else None
                check(settings['measurement_policy']==expected_policy and settings['effective_policy_timer']==('events' if cell.startswith('graph_') else None),prefix+'exact unspecified/graph policy without timer override M'+str(m))
                check((settings['warmup'],settings['repeat'],settings['stream_delay_micro_secs'],settings['cuda_graph_delay_micro_secs'],settings['use_global_timer'])==(3,10,5000,100,False),prefix+'unchanged actual timer contract M'+str(m))
                check(config['use_cuda_graph']==cell.startswith('graph_') and config['use_cold_l2_cache'] is False and config['use_cuda_graph_individual_timing'] is False and config['cuda_graph_profile_replays']==1 and config['effective_profiling_repeat']==10,prefix+'actual requested objective and hot-amortized flags M'+str(m))
        runtime=by_m[144];selected=data['natural']['tactic'];check(min(runtime,key=lambda row:row['elapsed_ms'])['tactic']==selected,prefix+'natural winner is first measured runtime minimum')
        check(data['natural']['lookup_tier']=='memory' and data['natural']['cache_hit'],prefix+'natural winner is actual memory hit')
        start=data['startup'];check(start['cache_state_sha256']==data['pre_capture_cache_state_sha256']==data['pre_trace_checks']['cache_state_sha256']==data['final']['cache_state_sha256'],prefix+'canonical in-process state invariant through all controls')
        check(all(not row['changed_fields'] and row['expected_field_sha256']==row['actual_field_sha256'] and row['expected_sha256']==row['actual_sha256'] for row in data['cache_state_guard_checks']),prefix+'per-field preservation diagnostics agree')
        check(data['final']['profile_attempts']==81 and not data['final']['active_v2'] and not data['final']['is_tuning_mode'] and data['final']['tuning_contexts']==0 and not data['final']['managed_store'] and data['final']['on_caller_stream'],prefix+'no final profiling/policy/store/stream leak')
        check(all(row['restored'] and row['winner_entries_after_removal']==row['file_entries_after_removal']==0 and row['cache_sha256_before']==row['cache_sha256_after'] for row in data['miss_scopes']),prefix+'real effective-cache removals restore exact maps/files')
        checks_by_name={row['check']:row for row in data['correctness']};check(len(checks_by_name)==len(data['correctness']),prefix+'unique numerical guard identities')
        graphs={row['id']:row for row in data['graphs']};check(set(graphs)=={'winner','default','admission_explicit'} and len({row['output']['data_ptr'] for row in graphs.values()})==3,prefix+'three independent graph-owned allocations including explicit control')
        for name,graph in graphs.items():
            check(graph['read_operand_hashes']==read_hashes and graph['inputs'][4]['data_ptr']==graph['output']['data_ptr'],prefix+'exact retained fixture/native output binding '+name)
            check(graph['selection']['cache_hit']==(name!='default') and graph['lookup_tier']==('miss' if name=='default' else 'memory'),prefix+'actual public hit/miss capture '+name)
            for label in ('poisoned','changed_input','restored_input'):
                row=checks_by_name[name+'_'+label];check(row['passed'] and row['output_data_ptr']==graph['output']['data_ptr'] and row['graph_id']==name,prefix+'actual own graph numerical check '+name+label)
                if label=='changed_input':check(row['exact_zero_required'] and row['max_abs_error']==0,prefix+'changed input produces exact zero '+name)
        for row in data['correctness']:
            check(row['passed'] and math.isfinite(row['max_abs_error']) and (row['max_abs_error']==0 if row['exact_zero_required'] else row['max_abs_error']>=0),prefix+'finite passed numerical record')
            if row['graph_id'] is not None:check(row['output_data_ptr']==graphs[row['graph_id']]['output']['data_ptr'],prefix+'no wrong-graph substitute output')
        acceptance=data['post_timing_acceptance'];check(acceptance['graph_id']=='winner' and acceptance['graph_object_id']==graphs['winner']['graph_object_id'] and acceptance['captured_inputs']==graphs['winner']['inputs'],prefix+'selected native acceptance exact retained operands')
        if selected==-1:check(acceptance['route']=='native_default' and acceptance['descriptor_acceptance']=='not_applicable_default_route' and acceptance['used_descriptor'] is None,prefix+'true default native route without descriptor claim')
        else:check(acceptance['route']=='native_descriptor' and acceptance['used_descriptor']==1,prefix+'selected actual descriptor used without fallback')
        control=data['known_explicit_control'];check(control['accepted'] and control['actual_acceptance']['used_descriptor']==1 and control['actual_acceptance']['pointers_unchanged'] and control['actual_acceptance']['original_graph_replayed'],prefix+'known explicit descriptor accepted and original controlled graph correct')
        trace=data['trace'];trace_path=args.raw_root/Path(trace['path']).name;check(sha(trace_path)==trace['sha256'],prefix+'actual raw replay trace SHA')
        check(data['pre_trace_checks']['ended_ns']<trace['started_ns']<trace['ended_ns']<data['final']['ended_ns'],prefix+'trace strictly after controls before final checks')
        traced={row['graph_id']:row for row in trace['graphs']}
        for name,row in traced.items():check(row['graph_object_id']==graphs[name]['graph_object_id'] and row['output_data_ptr']==graphs[name]['output']['data_ptr'],prefix+'trace replays same retained object '+name)
        signatures=trace_audit(trace_path,traced)
        summaries[cell]={'selected_tactic':selected,'known_explicit_tactic':control['tactic'],'profile_measurements':len(profiles),'numerical_guards':len(data['correctness']),
            'cache_guard_stages':[row['stage'] for row in data['cache_state_guard_checks']],'trace':signatures,'worker_sha256':data['worker_sha256'],'raw_sha256':sha(path)}
    check(len(set(containers))==4,'four fresh distinct admission containers')
    check(all(identity==providers[0] for identity in providers),'actual ELF/Ninja/source/export identities equal across four cells')
    baseline=records['auto_synthetic']
    for cell,data in records.items():
        check(data['startup']['rng_before']==baseline['startup']['rng_before'] and data['startup']['rng_after']==baseline['startup']['rng_after'],'identical original RNG sequence across cells '+cell)
        for a,b in zip(baseline['startup']['initializer_calls'],data['startup']['initializer_calls'],strict=True):
            check(a['shape']==b['shape'] and a['generated_sha256']==b['generated_sha256'],'same default draw/layout before intervention '+cell)
            if a['targeted'] and cell.endswith('captured'):check(b['returned_sha256']==read_hashes[0] and b['returned_sha256']!=a['returned_sha256'],'only exact M144 activation replaced '+cell)
            else:check(a['returned_sha256']==b['returned_sha256'],'other initialized activation bytes unchanged '+cell)
        for a,b in zip(baseline['startup']['profiles'],data['startup']['profiles'],strict=True):
            check(a['m']==b['m'] and a['tactic']==b['tactic'] and a['key']==b['key'],'same endpoint candidate order/cache key '+cell)
            check(a['fingerprints'][1:]==b['fingerprints'][1:],'same static weight/scales across all profiles '+cell)
            if a['m']==144 and cell.endswith('captured'):check(b['fingerprints'][0]==read_hashes[0],'actual captured quantized activation at runtime profile '+cell)
            else:check(a['fingerprints'][0]==b['fingerprints'][0],'all nonintervened profile activations unchanged '+cell)
    report={'status':'success','checks':len(checks),'check_labels':checks,'source_sha256':sha(__file__),'summaries':summaries,'provider_identities':providers[0],
        'scope':'Four instrumented disposable admission processes only. No performance cohort/timing inference. Native acceptance is the actual returned flag on retained operands after setup, not a direct flag observation during earlier capture. The replay trace is of the original retained graph objects.',
        'raw_root':str(args.raw_root)}
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':'success','checks':len(checks),'output':str(args.output)}))

if __name__=='__main__':main()
