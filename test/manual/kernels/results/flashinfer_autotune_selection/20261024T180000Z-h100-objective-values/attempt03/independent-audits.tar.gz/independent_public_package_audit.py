"""Independently compare public evidence with its exact private archive."""

import copy
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

BASE = Path('/private/tmp/fi-objective-values-20261024')
RAW = BASE / 'coordinator/raw/20261024T180000Z-h100-objective-values/attempt03'
PRIVATE = BASE / 'coordinator/20261024T180000Z-h100-objective-values-attempt03-full-raw.tgz'
PUBLIC = BASE / 'public-packaging/objective-values-attempt03'
OUTPUT = BASE / 'independent-public-package-audit.json'
TOKEN = bytes([118, 108, 108, 109])
checks = 0


def check(condition, label):
    global checks
    if not condition:
        raise AssertionError(label)
    checks += 1


def digest(data):
    return hashlib.sha256(data).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def payloads(archive, prefix):
    records = {}
    with tarfile.open(archive, 'r:gz') as bundle:
        for member in bundle:
            path = PurePosixPath(member.name)
            check(not path.is_absolute() and '..' not in path.parts and path.parts[0] == prefix,
                  'safe archive path')
            if member.isdir():
                continue
            check(member.isfile(), 'regular archive file')
            name = str(PurePosixPath(*path.parts[1:]))
            check(name not in records, 'no duplicate archive files')
            data = bundle.extractfile(member).read()
            check(len(data) == member.size, 'archive file size')
            records[name] = data
    return records


def main():
    check(not OUTPUT.exists(), 'immutable new audit destination')
    private_bytes = PRIVATE.read_bytes()
    public_bytes = (PUBLIC / 'raw-public.tar.gz').read_bytes()
    check(digest(private_bytes) == 'e972e9fa9abc02f841867b6e2921e11825c926ff3a337d5efc210ce54c0d7ddb',
          'expected complete private archive')
    check(digest(public_bytes) == '55af84c2272e7f6b0a98fa10ced3ccd0b1f9b068f058c01840f3087a65aa6706',
          'expected complete public archive')
    check(len(public_bytes) == 3069698, 'public master size')
    original = payloads(PRIVATE, 'attempt03')
    published = payloads(PUBLIC / 'raw-public.tar.gz', 'raw')
    check(set(original) == {str(p.relative_to(RAW)) for p in RAW.rglob('*') if p.is_file()},
          'private archive matches extracted member set')
    for name, data in original.items():
        check((RAW / name).read_bytes() == data, 'private archive/extracted exact bytes')
    preservation = json.loads(original['preservation-manifest.json'])
    check(len(preservation['files']) == 272, 'private preservation inventory size')
    check({r['path'] for r in preservation['files']} == set(original) - {'preservation-manifest.json'},
          'private preservation inventory complete except self')
    for row in preservation['files']:
        data = original[row['path']]
        check(len(data) == row['size_bytes'] and digest(data) == row['sha256'],
              'private preservation hash/size')

    manifest_bytes = (PUBLIC / 'public-manifest.json').read_bytes()
    check(published['public-manifest.json'] == manifest_bytes, 'embedded public manifest exact')
    manifest = json.loads(manifest_bytes)
    rows = {r['path']: r for r in manifest['files']}
    excluded = {r['path']: r for r in manifest['excluded_private_files']}
    check(len(rows) == len(manifest['files']), 'unique declared public members')
    check(len(excluded) == len(manifest['excluded_private_files']), 'unique private exclusions')
    check(set(rows).isdisjoint(excluded), 'public and excluded sets disjoint')
    check(set(rows) | set(excluded) == set(original), 'complete private/public accounting')
    check(set(published) == set(rows) | {'public-manifest.json'}, 'public archive member accounting')
    check(manifest['private_members_verified'] == len(original) == 273,
          '273 original files includes preservation manifest')
    check(manifest['private_archive_sha256'] == digest(private_bytes), 'private archive identity in manifest')
    check(manifest['private_archive_size_bytes'] == len(private_bytes), 'private archive size in manifest')
    check(manifest['packager_sha256'] == digest((BASE / 'public-packaging/package_results.py').read_bytes()),
          'actual packager source identity')
    modes = {'byte_exact': 0, 'derived_inventory_only': 0}
    omitted = 0
    for name, row in rows.items():
        before, after = original[name], published[name]
        check(digest(before) == row['private_sha256'] and len(before) == row['private_size_bytes'],
              'declared private original hash/size')
        check(digest(after) == row['public_sha256'] and len(after) == row['public_size_bytes'],
              'declared published hash/size')
        check((PUBLIC / 'raw' / name).read_bytes() == after, 'published archive/staging exact bytes')
        check(row['mode'] in modes, 'known publication mode')
        modes[row['mode']] += 1
        if row['mode'] == 'byte_exact':
            check(before == after, 'unmodified public evidence')
            continue
        check(name.endswith('.bootstrap.json'), 'derivation limited to bootstrap inventory')
        old, new = json.loads(before), json.loads(after)
        expected = copy.deepcopy(old)
        metadata = new.get('public_evidence_derivation')
        check(metadata == row['derivation'], 'public derivation metadata matches manifest')
        check(metadata['private_file_sha256'] == digest(before) and
              metadata['private_file_size_bytes'] == len(before), 'derivation binds original bytes')
        inventories = []
        source_modules = old['import']['source_modules']
        source_dropped = {k: v for k, v in source_modules.items() if TOKEN in canonical({k: v}).lower()}
        if source_dropped:
            expected['import']['source_modules'] = {k: v for k, v in source_modules.items() if k not in source_dropped}
            inventories.append({
                'path': 'import.source_modules', 'original_count': len(source_modules),
                'omitted_count': len(source_dropped),
                'original_inventory_sha256': digest(canonical(source_modules)),
                'omitted_entry_sha256': [digest(canonical({k: v})) for k, v in sorted(source_dropped.items())],
            })
        for index, provider in enumerate(old['import']['aot_providers']):
            modules = provider['modules']
            dropped = [item for item in modules if TOKEN in item.encode().lower()]
            if dropped:
                expected['import']['aot_providers'][index]['modules'] = [x for x in modules if x not in dropped]
                inventories.append({
                    'path': 'import.aot_providers[' + str(index) + '].modules',
                    'original_count': len(modules), 'omitted_count': len(dropped),
                    'original_inventory_sha256': digest(canonical(modules)),
                    'omitted_entry_sha256': [digest(canonical(x)) for x in dropped],
                })
        check(metadata['inventories'] == inventories, 'exact allowed inventory omissions and hashes')
        removed = sum(item['omitted_count'] for item in inventories)
        check(removed == metadata['omitted_entries'] == 6, 'six prohibited provider labels per bootstrap')
        expected['public_evidence_derivation'] = metadata
        check(expected == new, 'no other semantic bootstrap changes')
        check(json.dumps(expected, indent=2, allow_nan=False).encode() + b'\n' == after,
              'exact derived serialization reproduced independently')
        omitted += removed
    for name, row in excluded.items():
        data = original[name]
        check(row['type'] == 'file' and row['size_bytes'] == len(data) and row['sha256'] == digest(data),
              'excluded private bytes fully identified')
        check(name.endswith('.safetensors') or name.startswith(('native-artifacts/', 'native-build-cache/')),
              'exclusions limited to private fixture/native/build files')
        check(name not in published, 'excluded private payload absent')
    for name, data in published.items():
        check(TOKEN not in name.encode().lower() and TOKEN not in data.lower(),
              'public decompressed prohibited-token scan')
        check(not name.endswith(('.safetensors', '.so', '.o', '.cubin', '.ptx', '.ttir', '.ttgir', '.llir', '.source')),
              'no private tensor/native/build source payload')
    check(modes == {'byte_exact': 208, 'derived_inventory_only': 36}, 'expected exact/derived counts')
    check(omitted == 216 and len(excluded) == 29, 'expected omissions/private exclusions')
    result = {
        'status': 'passed', 'checks': checks, 'errors': [],
        'audit_source_sha256': digest(Path(__file__).read_bytes()),
        'public_archive': {'sha256': digest(public_bytes), 'size_bytes': len(public_bytes),
                           'members': len(published), 'exact_originals': modes['byte_exact'],
                           'derived_bootstraps': modes['derived_inventory_only'], 'omitted_inventory_labels': omitted,
                           'manifest_sha256': digest(manifest_bytes)},
        'private_archive': {'sha256': digest(private_bytes), 'size_bytes': len(private_bytes),
                            'files_including_preservation_manifest': len(original),
                            'preservation_inventory_rows_excluding_self': len(preservation['files']),
                            'private_exclusions': len(excluded)},
        'derivation_scope': 'Only six offending provider module labels per bootstrap were removed, with original inventory and omitted-entry hashes. Every other original bootstrap field is preserved; worker results, errors, timings and traces are exact original bytes.',
        'scan': 'All public decompressed names and payloads checked; no prohibited token, private tensor/native binary or build-source payload.',
        'limitations': ['Package integrity and disclosure audit only; no numerical/performance reanalysis or experiment execution.',
                        'Repository archive splitting is not yet audited here; joined part bytes must match the recorded public master SHA.'],
    }
    OUTPUT.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
