"""Independent raw-sample and whole-block statistics audit; no GPU execution."""
from __future__ import annotations
import argparse
import hashlib
import importlib.util
import json
import math
import random
import statistics
from pathlib import Path

CELLS=('auto_synthetic','graph_synthetic','auto_captured','graph_captured')
WEIGHTS={'objective':(-.5,.5,-.5,.5),'values':(-.5,-.5,.5,.5),'interaction':(1.,-1.,-1.,1.)}
CHECKS=[]
def check(value,label):
    if not value:raise AssertionError(label)
    CHECKS.append(label)
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def close(a,b):return math.isclose(a,b,rel_tol=2e-12,abs_tol=2e-14)
def positive(value):return type(value) in (int,float) and math.isfinite(value) and value>0
def describe(values):
    return {'n':len(values),'median':statistics.median(values),'minimum':min(values),'maximum':max(values),'values':values}
def paired_samples(rounds,orders):
    check(len(rounds)==len(orders)==24,'all24 paired rounds retained')
    ratios=[];walls=[];counts={'start_complete_inconclusive':0,'start_pending_after_enqueue':0}
    by_order={'winner_first':[],'default_first':[]}
    for index,(group,order) in enumerate(zip(rounds,orders,strict=True)):
        check(group['index']==index and group['order']==order,'exact scheduled paired round '+str(index))
        measurements=group['measurements'];check([row['graph_id'] for row in measurements]==order and len(measurements)==2,'each scheduled graph once in round '+str(index))
        rows={row['graph_id']:row for row in measurements}
        for row in measurements:
            check(row['replays']==16 and row['prequeue_cycles']==10_000_000,'fixed16 replay10m recipe')
            check(row['start_query_error'] is None and type(row['start_event_complete_after_enqueue']) is bool,'actual query outcome retained without filtering')
            label='start_complete_inconclusive' if row['start_event_complete_after_enqueue'] else 'start_pending_after_enqueue'
            check(row['queue_evidence']==label,'query classification does not claim completion is invalid')
            counts[label]+=1
            check(positive(row['gpu_event_batch_ms']) and close(row['gpu_event_per_replay_ms'],row['gpu_event_batch_ms']/16),'actual positive event span normalized by16')
            check(positive(row['wall_including_prequeue_ms']) and row['wall_diagnostic_only'] is True,'queued wall kept diagnostic')
        ratio=rows['winner']['gpu_event_batch_ms']/rows['default']['gpu_event_batch_ms']
        ratios.append(ratio);walls.append(rows['winner']['wall_including_prequeue_ms']/rows['default']['wall_including_prequeue_ms'])
        by_order[order[0]+'_first'].append(ratio)
    check(sum(counts.values())==48,'all48 sample/query outcomes contribute to worker estimand')
    check(all(len(values)==12 for values in by_order.values()),'12 paired rounds per first-graph stratum')
    return {'event_ratio':statistics.median(ratios),'wall_ratio':statistics.median(walls),
        'round_event_ratios':ratios,'round_wall_ratios':walls,'query_counts':counts,
        'order_strata':{name:describe(values) for name,values in by_order.items()}}

def quantile(sorted_values,probability):
    index=(len(sorted_values)-1)*probability;lo=int(index);fraction=index-lo
    return sorted_values[lo]+fraction*(sorted_values[min(lo+1,len(sorted_values)-1)]-sorted_values[lo])

def binomial_bounds(k,n):
    def tail(p,upper):
        indices=range(k,n+1) if upper else range(k+1)
        return math.fsum(math.comb(n,j)*p**j*(1-p)**(n-j) for j in indices)
    def invert(target,upper):
        low,high=0.,1.
        for _ in range(110):
            mid=(low+high)/2;value=tail(mid,upper)
            if (value<target) if upper else (value>target):low=mid
            else:high=mid
        return (low+high)/2
    return {'count':k,'n':n,'fraction':k/n,'two_sided95':[0. if k==0 else invert(.025,True),1. if k==n else invert(.025,False)],
            'one_sided95_upper':1. if k==n else invert(.05,False)}

def cohort_statistics(workers,resamples=200_000,seed=202610241803):
    units={block:{row['cell']:row for row in workers if row['block']==block} for block in sorted({row['block'] for row in workers})}
    check(len(workers)==len(units)*4 and all(set(rows)==set(CELLS) for rows in units.values()),'statistics use complete four-cell process blocks')
    logs=[]
    for block,rows in units.items():
        y=[math.log(rows[cell]['event_ratio']) for cell in CELLS]
        logs.append({'block':block,**{name:math.fsum(weight*value for weight,value in zip(weights,y,strict=True)) for name,weights in WEIGHTS.items()}})
    factors={name:{'ratio_of_ratios':math.exp(math.fsum(row[name] for row in logs)/len(logs)),
        'block_log_contrasts':[row[name] for row in logs],'block_ratio_contrasts':[math.exp(row[name]) for row in logs]} for name in WEIGHTS}
    if len(units)==8:
        samples={name:[] for name in WEIGHTS};rng=random.Random(seed)
        for _ in range(resamples):
            draw=[rng.randrange(8) for _ in range(8)]
            for name in WEIGHTS:samples[name].append(math.fsum(logs[index][name] for index in draw)/8)
        for name in WEIGHTS:
            ordered=sorted(samples[name]);probabilities=(.025,.975) if name=='interaction' else (.0125,.9875)
            factors[name]['bootstrap_interval']={'confidence':.95 if name=='interaction' else .975,
                'bounds':[math.exp(quantile(ordered,p)) for p in probabilities],
                'resamples':resamples,'seed':seed,'unit':'whole four-cell process block','interpolate_on':'log scale before exponentiation'}
    return {'independent_blocks':len(units),'workers':len(workers),'block_log_contrasts':logs,'factors':factors,
        'cells':{cell:{'event_ratio':describe([units[b][cell]['event_ratio'] for b in units]),
            'wall_diagnostic_ratio':describe([units[b][cell]['wall_ratio'] for b in units]),
            'explicit_selection':binomial_bounds(sum(not units[b][cell]['selected_default'] for b in units),len(units)),
            'material_regression_gt1_10':binomial_bounds(sum(units[b][cell]['event_ratio']>1.10 for b in units),len(units))} for cell in CELLS}}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--raw-root',type=Path,required=True);parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--schedule',type=Path,required=True)
    parser.add_argument('--official',type=Path);parser.add_argument('--blocks',type=int,choices=(1,8),default=8);parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args();check(not args.output.exists(),'refuse independent report overwrite')
    plan=json.loads(args.plan.read_text());schedule=json.loads(args.schedule.read_text())
    check(plan['schedule_sha256']==sha(args.schedule),'actual schedule bound by frozen plan')
    bootstrap=plan['analysis']['bootstrap'];check(bootstrap['resamples']==200_000 and bootstrap['seed']==202610241803 and bootstrap['tail_probabilities']==[.0125,.9875],'frozen bootstrap family/unit/algorithm')
    helper=Path(__file__).parents[1]/'admission-audit/audit_admissions.py';spec=importlib.util.spec_from_file_location('independent_admission_helpers',helper)
    independent=importlib.util.module_from_spec(spec);spec.loader.exec_module(independent);independent.check=check
    fixture,read_hashes=independent.fixture_read_hashes(args.raw_root)
    workers=[];cids=[];identities=[];read_layouts={}
    entries=[row for row in schedule['entries'] if row['block']<args.blocks]
    check(len(entries)==args.blocks*4,'complete fixed schedule cohort requested')
    for assignment in entries:
        path=args.raw_root/assignment['raw_name'];data=json.loads(path.read_text());label=f"block{assignment['block']} {assignment['cell']}: "
        check(data['status']=='success' and data['mode']=='timing' and data['block']==assignment['block'] and data['cell']==assignment['cell'],label+'original successful scheduled timing worker')
        check(data['plan_sha256']==sha(args.plan) and data['schedule_sha256']==sha(args.schedule) and data['assignment']==assignment,label+'exact frozen source plan/schedule assignment')
        check(data['capture_order']==assignment['capture_order'] and data['all_samples_retained'] and not data['queue_query_is_exclusion_criterion'],label+'fixed capture order and no outcome exclusions')
        check((args.raw_root/path.with_suffix('.exit-code').name).read_text().strip()=='0',label+'original container exit0')
        cid=(args.raw_root/path.with_suffix('.container-id').name).read_text().strip();check(len(cid)==64,label+'actual fresh container id');cids.append(cid)
        boot=json.loads(path.with_suffix('.bootstrap.json').read_text());check(boot['status']=='passed' and boot['result_sha256']==sha(path) and boot['pid']==data['pid'] and boot['worker_sha256']==data['worker_sha256'] and boot['native_identity_passthrough'],label+'native bootstrap identity and exact result binding')
        identity={name:{key:row[key] for key in ('library_sha256','ninja_sha256','sources','exports_checked')} for name,row in boot['native']['providers'].items()};identities.append(identity)
        check(data['source']['critical_sha256']==plan['source_contract']['runtime_sha256'] and data['fixture']['tensor_file_sha256']==plan['source_contract']['fixture']['sha256'],label+'qualified source and immutable actual fixture')
        start=data['startup'];profiles=start['profiles'];initializers=start['initializer_calls']
        check(start['profile_attempts']==81==len(profiles) and not data['forbidden_profile_attempts'] and not data['protocol_errors'],label+'no omitted or poststartup profiling')
        check([row['shape'][1] for row in initializers]==list(independent.MS) and sum(row['cloned'] and row['copied'] for row in initializers)==1,label+'same nine profile and matched copy recipe')
        check(all(not row['fingerprinted'] and 'fingerprints' not in row for row in profiles) and all(not any('sha256' in key for key in row) for row in initializers),label+'cohort carries no inline synthetic-byte hashes')
        check(data['profiling_byte_attestation']=='metadata_only_no_synthetic_byte_attestation' and not data['synthetic_input_references_retained'],label+'no synthetic byte attestation or retained references claimed')
        by_m={m:[row for row in profiles if row['m']==m] for m in independent.MS}
        for m,group in by_m.items():
            check(len(group)==9 and group[0]['tactic']==-1 and sum(row['tactic']==-1 for row in group)==1,label+'default and eight descriptor candidates M'+str(m))
            for row in group:
                check(row['error'] is None and positive(row['elapsed_ms']),label+'positive actual profiler result')
                settings=row['settings'];config=settings['config'];graph=assignment['objective']=='graph'
                check((settings['warmup'],settings['repeat'],settings['stream_delay_micro_secs'],settings['cuda_graph_delay_micro_secs'],settings['use_global_timer'])==(3,10,5000,100,False) and config['use_cuda_graph']==graph and not config['use_cold_l2_cache'] and not config['use_cuda_graph_individual_timing'] and config['cuda_graph_profile_replays']==1,label+'unchanged actual measurement contract')
            key=m;domain={'key':group[0]['key'],'candidates':[row['tactic'] for row in group]}
            if key in read_layouts:check(domain==read_layouts[key],label+'same endpoint candidate pool/key across repeated cells')
            else:read_layouts[key]=domain
        selected=data['natural']['tactic'];runtime=by_m[144]
        check(selected==min(runtime,key=lambda row:row['elapsed_ms'])['tactic'] and data['natural']['cache_hit'] and data['natural']['lookup_tier']=='memory',label+'real minimum winner consumed from memory')
        graphs={row['id']:row for row in data['graphs']};check(set(graphs)=={'winner','default'} and len({row['output']['data_ptr'] for row in graphs.values()})==2,label+'two independent original graph outputs')
        numerical={row['check']:row for row in data['correctness']};check(len(numerical)==len(data['correctness'])==65,label+'65 unique original numerical guard records')
        for name,graph in graphs.items():
            check(graph['read_operand_hashes']==read_hashes and graph['inputs'][4]['data_ptr']==graph['output']['data_ptr'],label+'exact captured actual fixture/native operands '+name)
            check(graph['selection']['cache_hit']==(name=='winner') and graph['lookup_tier']==('memory' if name=='winner' else 'miss'),label+'natural hit and actual default miss '+name)
            for kind in ('poisoned','changed_input','restored_input'):
                record=numerical[name+'_'+kind];check(record['graph_id']==name and record['output_data_ptr']==graph['output']['data_ptr'] and record['passed'],label+'owned changed/restored/poisoned numerical output')
                if kind=='changed_input':check(record['max_abs_error']==0 and record['exact_zero_required'],label+'exact zero changed input')
        for row in numerical.values():
            check(row['passed'] and math.isfinite(row['max_abs_error']),label+'finite numerical result')
            if row['graph_id'] is not None:check(row['output_data_ptr']==graphs[row['graph_id']]['output']['data_ptr'],label+'numerical record belongs to actual graph output')
        orders=schedule['round_schedules'][assignment['block']]['orders'];paired=paired_samples(data['rounds'],orders)
        check(close(paired['event_ratio'],data['selected_over_default_graph_event_median']),label+'reported median recomputed from all24 actual paired samples')
        ended=[]
        for group in data['rounds']:
            for row in group['measurements']:
                graph=graphs[row['graph_id']];check(row['graph_object_id']==graph['graph_object_id'] and row['output_data_ptr']==graph['output']['data_ptr'],label+'timed original object/output binding')
                check(row['profile_attempts_before']==row['profile_attempts_after']==81 and row['rewarm']['actual_ms']>=20 and row['rewarm']['calls']>=5120,label+'no profiling and fixed rewarm outside sample')
                check(row['wall_started_ns']<=row['enqueue_started_ns']<row['enqueue_ended_ns']<=row['ended_ns'] and row['enqueue_span_includes_start_query'],label+'query/enqueue/wall chronology')
                check(close(row['enqueue_cpu_ms'],(row['enqueue_ended_ns']-row['enqueue_started_ns'])/1e6) and close(row['wall_including_prequeue_ms'],(row['ended_ns']-row['wall_started_ns'])/1e6),label+'actual diagnostic timestamp normalization')
                record=numerical[row['correctness_check']];check(record['graph_id']==row['graph_id'] and record['output_data_ptr']==row['output_data_ptr'],label+'timed allocation checked immediately by exact guard')
                ended.append(row['ended_ns'])
        acceptance=data['post_timing_acceptance'];check(max(ended)<acceptance['started_ns']<acceptance['ended_ns'] and acceptance['captured_inputs']==graphs['winner']['inputs'] and acceptance['graph_object_id']==graphs['winner']['graph_object_id'],label+'exact selected native acceptance after all primary timings')
        if selected==-1:check(acceptance['route']=='native_default' and acceptance['used_descriptor'] is None and acceptance['descriptor_acceptance']=='not_applicable_default_route',label+'default has no invented descriptor acceptance')
        else:check(acceptance['used_descriptor']==1 and acceptance['descriptor_acceptance']=='accepted',label+'actual selected descriptor accepted without fallback')
        check(acceptance['pointers_unchanged'] and acceptance['original_graph_replayed'],label+'native acceptance preserves/rechecks original graph')
        check(start['cache_state_sha256']==data['pre_capture_cache_state_sha256']==data['pre_trace_checks']['cache_state_sha256']==data['final']['cache_state_sha256'],label+'canonical cache state invariant')
        check(all(not row['changed_fields'] and row['expected_field_sha256']==row['actual_field_sha256'] for row in data['cache_state_guard_checks']) and all(row['restored'] for row in data['miss_scopes']),label+'per-field and miss restoration evidence')
        check(data['final']['profile_attempts']==81 and data['final']['cache_unchanged'] and data['final']['operands_unchanged'] and not data['final']['active_v2'] and not data['final']['is_tuning_mode'] and not data['final']['managed_store'] and data['final']['on_caller_stream'],label+'raw replay and final lifecycle state')
        trace=data['trace'];trace_path=args.raw_root/Path(trace['path']).name;check(sha(trace_path)==trace['sha256'] and data['pre_trace_checks']['ended_ns']<trace['started_ns']<trace['ended_ns']<data['final']['ended_ns'],label+'original posttiming raw trace chronology/hash')
        traces={row['graph_id']:row for row in trace['graphs']}
        for name,row in traces.items():check(row['graph_object_id']==graphs[name]['graph_object_id'] and row['output_data_ptr']==graphs[name]['output']['data_ptr'],label+'trace original graph/output identity')
        traced=independent.trace_audit(trace_path,traces)
        workers.append({'block':assignment['block'],'cell':assignment['cell'],'capture_order':assignment['capture_order'],
            'selected_default':selected==-1,'selected_tactic':selected,**paired,
            'kernel_signatures_equal':traced['winner']['ordered_launch_signature']==traced['default']['ordered_launch_signature'],
            'profile_best_explicit_over_default':min(row['elapsed_ms'] for row in runtime if row['tactic']!=-1)/next(row['elapsed_ms'] for row in runtime if row['tactic']==-1),
            'raw_sha256':sha(path),'worker_sha256':data['worker_sha256']})
    check(len(set(cids))==len(cids),'all independent cohort containers distinct')
    check(all(row==identities[0] for row in identities),'same actual provider ELF/Ninja/sources across entire cohort')
    stats=cohort_statistics(workers);comparisons=[]
    if args.official:
        official=json.loads(args.official.read_text());official_stats=official.get('statistics',official)
        for name,result in stats['factors'].items():
            actual=official_stats['factor_estimates'][name]
            check(close(result['ratio_of_ratios'],actual['ratio_of_ratios']),'official factor point matches independent arithmetic '+name)
            if 'bootstrap_interval' in result:check(all(close(a,b) for a,b in zip(result['bootstrap_interval']['bounds'],actual['bootstrap_interval']['bounds'],strict=True)),'official fixed whole-block interval matches independent seeded resampling '+name)
            comparisons.append(name)
    report={'status':'success','final_immutable':True,'checks':len(CHECKS),'check_labels':CHECKS,'audit_source_sha256':sha(__file__),
        'independent_helper_sha256':sha(helper),'plan_sha256':sha(args.plan),'schedule_sha256':sha(args.schedule),
        'workers':workers,'statistics':stats,'official_comparisons':comparisons,'query_counts':{name:sum(row['query_counts'][name] for row in workers) for name in ('start_complete_inconclusive','start_pending_after_enqueue')},
        'limits':['Eight complete four-cell process blocks are independent units;24paired rounds are repeated observations within workers.','Same-default small effects remain unresolved by prior timing calibration; no serving performance claim.','Native acceptance after timing proves exact retained-problem viability, not direct observation during earlier capture.','Main profiling activations are not byte-hashed; separate admission/source/RNG/metadata establish the intended recipe, not synthetic-byte attestation.']}
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':'success','checks':len(CHECKS),'workers':len(workers),'output':str(args.output)}))

if __name__=='__main__':main()
