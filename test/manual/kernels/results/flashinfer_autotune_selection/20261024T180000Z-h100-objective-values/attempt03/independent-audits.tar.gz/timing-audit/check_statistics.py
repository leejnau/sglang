"""Focused independent estimand/sample-inclusion controls, without GPU data."""
from __future__ import annotations
import copy
import hashlib
import importlib.util
import json
import math
import random
from collections import Counter
from pathlib import Path

SOURCE=Path(__file__).with_name('audit_cohort.py')
spec=importlib.util.spec_from_file_location('independent_timing_audit',SOURCE);a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
checks=[]
def check(value,label):
    if not value:raise AssertionError(label)
    checks.append(label)
def rejects(function,label):
    try:function()
    except AssertionError:checks.append(label)
    else:raise AssertionError(label)

orders=[['winner','default'],['default','winner']]*12
def rounds(winners,defaults):
    output=[]
    for i,order in enumerate(orders):
        values={'winner':winners[i],'default':defaults[i]}
        rows=[{'graph_id':name,'replays':16,'prequeue_cycles':10_000_000,
               'start_query_error':None,'start_event_complete_after_enqueue':bool(i%2),
               'queue_evidence':'start_complete_inconclusive' if i%2 else 'start_pending_after_enqueue',
               'gpu_event_batch_ms':values[name],'gpu_event_per_replay_ms':values[name]/16,
               'wall_including_prequeue_ms':1.,'wall_diagnostic_only':True} for name in order]
        output.append({'index':i,'order':order,'measurements':rows})
    return output
raw=rounds([1.,10.,10.]*8,[1.,2.,100.]*8);result=a.paired_samples(raw,orders)
check(result['event_ratio']==1. and result['event_ratio']!=10./2.,'median of paired ratios rather than ratio of marginal medians')
check(result['query_counts']=={'start_complete_inconclusive':24,'start_pending_after_enqueue':24},'completed and pending query outcomes both retained')
bad=copy.deepcopy(raw);bad[0]['measurements'][0]['start_query_error']='deliberate'
rejects(lambda:a.paired_samples(bad,orders),'query error cannot silently disappear')
bad=copy.deepcopy(raw);bad[0]['measurements'].pop()
rejects(lambda:a.paired_samples(bad,orders),'missing paired observation cannot disappear')
bad=copy.deepcopy(raw);bad[0]['measurements'][0]['gpu_event_batch_ms']=0
rejects(lambda:a.paired_samples(bad,orders),'nonpositive sample cannot appear fast')
bad=copy.deepcopy(raw);bad[0]['order']=list(reversed(bad[0]['order']))
rejects(lambda:a.paired_samples(bad,orders),'off-schedule order cannot be accepted')
check(a.quantile([0.,4.],.25)==1.,'specified linear percentile interpolation')
check(math.exp(a.quantile([math.log(1.),math.log(4.)],.5))==2.,'log-scale interpolation followed by exponentiation')

workers=[]
known=(1.,2.,3.,6.)
for block in range(8):
    for cell,value in zip(a.CELLS,known,strict=True):workers.append({'block':block,'cell':cell,'event_ratio':value,'wall_ratio':1.,'selected_default':True})
summary=a.cohort_statistics(workers)
check(a.close(summary['factors']['objective']['ratio_of_ratios'],2.),'known objective multiplicative contrast')
check(a.close(summary['factors']['values']['ratio_of_ratios'],3.),'known activation-values multiplicative contrast')
check(a.close(summary['factors']['interaction']['ratio_of_ratios'],1.),'known absence of interaction')
for name,expected in (('objective',2.),('values',3.),('interaction',1.)):
    row=summary['factors'][name]
    check(all(a.close(value,expected) for value in row['bootstrap_interval']['bounds']),'constant whole-block bootstrap is degenerate at known estimand '+name)
check(summary['factors']['objective']['bootstrap_interval']['confidence']==.975 and summary['factors']['interaction']['bootstrap_interval']['confidence']==.95,'primary adjusted and secondary intervals separately labeled')
check(summary['independent_blocks']==8 and summary['workers']==32,'eight complete process blocks are inferential units')
partial=a.cohort_statistics(workers[:4])
check('bootstrap_interval' not in partial['factors']['objective'],'no inferential interval at first-block integrity checkpoint')
rejects(lambda:a.cohort_statistics(workers[:-1]),'incomplete whole block cannot enter inference')
for k,n,expected in ((0,8,1-.05**(1/8)),(8,8,1.)):
    check(a.close(a.binomial_bounds(k,n)['one_sided95_upper'],expected),'exact binomial one-sided upper '+str(k))
check(a.close(a.binomial_bounds(0,8)['two_sided95'][1],1-.025**(1/8)),'exact zero-event equal-tail upper')
check(a.close(a.binomial_bounds(8,8)['two_sided95'][0],.025**(1/8)),'exact all-event equal-tail lower')

# A second independent reference uses only the integer sum of eight sampled
# block numbers, avoiding the audit's floating contrast/resample implementation.
varying=[]
for block in range(8):
    y=(1.,2.**block,3.**(7-block),2.**block*3.**(7-block))
    for cell,value in zip(a.CELLS,y,strict=True):varying.append({'block':block,'cell':cell,'event_ratio':value,'wall_ratio':1.,'selected_default':True})
vary=a.cohort_statistics(varying)
rng=random.Random(202610241803);frequencies=Counter(sum(rng.randrange(8) for _ in range(8)) for _ in range(200_000))
def integer_quantile(counts,probability):
    def order(index):
        accumulated=0
        for value,count in sorted(counts.items()):
            accumulated+=count
            if index<accumulated:return value
        raise AssertionError('integer reference count')
    position=199_999*probability;lo=int(position);f=position-lo
    return order(lo)+f*(order(min(lo+1,199_999))-order(lo))
for name,base,counts in (('objective',2.,frequencies),('values',3.,Counter({56-key:value for key,value in frequencies.items()}))):
    expected=[math.exp(math.log(base)*integer_quantile(counts,p)/8) for p in (.0125,.9875)]
    check(all(a.close(x,y) for x,y in zip(vary['factors'][name]['bootstrap_interval']['bounds'],expected,strict=True)),'nonconstant exact fixed-RNG integer-reference interval '+name)
check(a.close(vary['factors']['objective']['ratio_of_ratios'],2.**3.5) and a.close(vary['factors']['values']['ratio_of_ratios'],3.**3.5),'nonconstant whole-block geometric factor means')

source=SOURCE.read_bytes();token=bytes([118,108,108,109]);check(token not in source.lower(),'new independent audit contains no prohibited token')
report={'status':'success','controls':len(checks),'checks':checks,'audit_source_sha256':hashlib.sha256(source).hexdigest(),
        'controls_source_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'scope':'Pure CPU synthetic observations test the prespecified paired estimand, full outcome inclusion, complete-block inference,200000 seeded whole-block resamples and exact binomial bounds. No official analyzer import and no GPU/performance inference.'}
Path(__file__).with_name('statistics-controls.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'success','controls':len(checks),'audit_source_sha256':report['audit_source_sha256']}))
