"""Verify repository segments and bounded result-disclosure claims."""

import hashlib
import io
import json
from pathlib import Path
import statistics
import tarfile

BASE = Path('/private/tmp/fi-objective-values-20261024')
BATCH = Path('/private/tmp/sglang-autotune-selection-study/test/manual/kernels/results/flashinfer_autotune_selection/20261024T180000Z-h100-objective-values')
ATTEMPT = BATCH / 'attempt03'
RAW = BASE / 'coordinator/raw/20261024T180000Z-h100-objective-values/attempt03'
MASTER = BASE / 'public-packaging/objective-values-attempt03/raw-public.tar.gz'
OUTPUT = BASE / 'independent-parts-claims-audit.json'
TOKEN = bytes([118, 108, 108, 109])
checks = 0


def require(value, label):
    global checks
    if not value:
        raise AssertionError(label)
    checks += 1


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    require(not OUTPUT.exists(), 'new independent audit destination')
    parts_bytes = (ATTEMPT / 'raw-public-parts.json').read_bytes()
    parts = json.loads(parts_bytes)
    require([r['path'] for r in parts['parts']] ==
            ['raw-public.tar.gz.part001', 'raw-public.tar.gz.part002', 'raw-public.tar.gz.part003'],
            'exactly three ordered byte segments')
    buffers = []
    for row in parts['parts']:
        data = (ATTEMPT / row['path']).read_bytes()
        require(len(data) == row['size_bytes'] and sha(data) == row['sha256'], 'part hash and size')
        require(len(data) <= 1024 * 1024, 'each part at most one MiB')
        buffers.append(data)
    joined = b''.join(buffers)
    require(joined == MASTER.read_bytes(), 'joined segments byte-identical to independently audited master')
    require(len(joined) == parts['master_size_bytes'] == 3069698, 'joined master size')
    require(sha(joined) == parts['master_sha256'] ==
            '55af84c2272e7f6b0a98fa10ced3ccd0b1f9b068f058c01840f3087a65aa6706',
            'joined master identity')
    manifest_bytes = (ATTEMPT / 'public-manifest.json').read_bytes()
    manifest = json.loads(manifest_bytes)
    expected = {row['path']: row for row in manifest['files']}
    expected['public-manifest.json'] = {'public_sha256': sha(manifest_bytes),
                                      'public_size_bytes': len(manifest_bytes)}
    names = set()
    with tarfile.open(fileobj=io.BytesIO(joined), mode='r:gz') as archive:
        for member in archive:
            require(member.isfile() and member.name.startswith('raw/') and '..' not in Path(member.name).parts,
                    'safe regular joined-archive member')
            name = member.name[4:]
            require(name in expected and name not in names, 'unique expected joined-archive member')
            data = archive.extractfile(member).read()
            row = expected[name]
            require(sha(data) == row['public_sha256'] and len(data) == row['public_size_bytes'],
                    'joined-archive member identity')
            require(TOKEN not in name.encode().lower() and TOKEN not in data.lower(),
                    'joined decompressed prohibited-token scan')
            names.add(name)
    require(names == set(expected) and len(names) == 245, 'all declared public members')

    result_bytes = (ATTEMPT / 'result.json').read_bytes()
    result = json.loads(result_bytes)
    readme_bytes = (BATCH / 'README.md').read_bytes()
    readme = readme_bytes.decode()
    timing = [json.loads(p.read_text()) for p in sorted(RAW.glob('block*-timing.json'))]
    admission = [json.loads((RAW / ('admission-' + cell + '.json')).read_text())
                 for cell in sorted(result['cells'])]
    require(len(timing) == result['timing_workers'] == 32, 'timing-worker summary count')
    require(len(admission) == result['admission_workers'] == 4, 'admission-worker summary count')
    for workers, prefix in [(timing, 'timing'), (admission, 'admission')]:
        require(sum(len(w['startup']['profiles']) for w in workers) == result[prefix + '_profile_measurements'],
                'profile summary count')
        require(sum(len(w['correctness']) for w in workers) == result[prefix + '_numerical_checks'],
                'numerical-check summary count')
    require(sum(len(w['rounds']) for w in timing) == result['paired_rounds'] == 768, 'paired-round summary')
    require(sum(len(row['measurements']) for w in timing for row in w['rounds']) ==
            result['retained_samples'] == 1536, 'retained-sample summary')
    counts = {}
    for cell in result['cells']:
        subset = [w for w in timing if w['cell'] == cell]
        require(len(subset) == 8, 'eight independent workers per cell')
        default = sum(w['natural']['tactic'] == -1 for w in subset)
        explicit = len(subset) - default
        bad = sum(w['selected_over_default_graph_event_median'] > 1.1 for w in subset)
        require(default == result['cells'][cell]['default_selections']['count'] and
                explicit == result['cells'][cell]['explicit_selections']['count'] and
                bad == result['cells'][cell]['material_regressions_ratio_gt_1_10']['count'],
                'per-cell selection/regression table matches actual workers')
        counts[cell] = {'default': default, 'explicit': explicit, 'ratio_gt_1_10': bad}
    counter = json.loads((RAW / result['counterexample']['raw_name']).read_text())
    ratios = []
    for row in counter['rounds']:
        by_graph = {m['graph_id']: m['gpu_event_per_replay_ms'] for m in row['measurements']}
        ratios.append(by_graph['winner'] / by_graph['default'])
    ratio = statistics.median(ratios)
    require(ratio == result['counterexample']['graph_ratio'], 'counterexample median reproduced')
    require(counter['post_timing_acceptance']['used_descriptor'] ==
            result['counterexample']['native_used_descriptor'] == 1, 'counterexample explicit native acceptance')
    require(len(counter['correctness']) == result['counterexample']['numerical_checks_passed'] == 65 and
            all(row['passed'] for row in counter['correctness']), 'counterexample owned numerical controls')
    require(result['official_analysis_sha256'] == sha((RAW / 'analysis.json').read_bytes()),
            'official-analysis identity')
    for key in ['objective', 'values']:
        bounds = result['factor_estimates'][key]['bootstrap_interval']['bounds']
        require(bounds[0] < 1 < bounds[1], 'both factor intervals include one')
    for phrase in ['not a direct serving latency ratio', 'Both include 1',
                   'do not establish', 'not a selection benefit',
                   'cannot establish rare-regression safety', 'not', 'v1/v2 comparison',
                   'derived bootstrap inventories', 'six disallowed provider']:
        require(phrase in readme, 'required bounded README disclosure')
    require(result['public_archive_sha256'] == sha(joined) and
            result['private_archive_sha256'] == manifest['private_archive_sha256'],
            'result archive identities')
    for data in [parts_bytes, manifest_bytes, result_bytes, readme_bytes]:
        require(TOKEN not in data.lower(), 'repository report content scan')
    output = {
        'status': 'passed', 'checks': checks, 'errors': [],
        'audit_source_sha256': sha(Path(__file__).read_bytes()),
        'parts': {'count': len(buffers), 'sizes_bytes': [len(x) for x in buffers],
                  'metadata_sha256': sha(parts_bytes), 'joined_sha256': sha(joined),
                  'joined_size_bytes': len(joined), 'decompressed_members_checked': len(names),
                  'identical_to_previously_audited_master': True},
        'claims_review': {'readme_sha256': sha(readme_bytes), 'result_sha256': sha(result_bytes),
                          'cells_verified_against_raw': counts, 'counterexample_ratio': ratio,
                          'timing_workers': len(timing), 'admission_workers': len(admission),
                          'block_bootstrap_not_recomputed': True,
                          'scope_assessment': 'README/result correctly distinguish selected/default graph ratios from serving performance, disclose patched source, all admission attempts, controlled copy-history limits, rare-event uncertainty and exact versus derived packaging. No blocker found.'},
        'limits': ['Packaging and bounded claim cross-check only; does not repeat the full independent statistical/numerical audit.',
                   'Scheduler release is reported from coordinator evidence; this audit performs no remote resource query.'],
    }
    OUTPUT.write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps(output, indent=2))


if __name__ == '__main__':
    main()
