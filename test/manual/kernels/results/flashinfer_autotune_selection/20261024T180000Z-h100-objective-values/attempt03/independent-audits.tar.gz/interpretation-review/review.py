#!/usr/bin/env python3
"""Independent raw-data interpretation audit; no study analyzer imports."""
import argparse
import collections
import hashlib
import json
import math
import pathlib
import random
import statistics
import sys

CELLS = ('auto_synthetic', 'graph_synthetic', 'auto_captured', 'graph_captured')
CHECKS = 0


def require(condition, description):
    global CHECKS
    CHECKS += 1
    if not condition:
        raise AssertionError(description)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def describe(values):
    return dict(n=len(values), median=statistics.median(values), mean=statistics.mean(values),
                range=[min(values), max(values)], values=values)


def close(a, b, description):
    require(math.isclose(a, b, rel_tol=1e-13, abs_tol=1e-15), description)


def quantile(sorted_values, p):
    index = (len(sorted_values) - 1) * p
    lo = math.floor(index)
    hi = math.ceil(index)
    return sorted_values[lo] + (index - lo) * (sorted_values[hi] - sorted_values[lo])


def signature(event):
    args = event['args']
    return {key: (event['name'] if key == 'name' else args[key]) for key in
            ('name', 'grid', 'block', 'device', 'registers per thread', 'shared memory')}


def trace_observation(raw_path, worker):
    path = raw_path.with_name(raw_path.stem.replace('-timing', '-timing.trace') + '.json')
    require(digest(path) == worker['trace']['sha256'], 'actual trace digest')
    events = json.loads(path.read_text())['traceEvents']
    all_kernels = [e for e in events if e.get('cat') == 'kernel']
    all_launches = [e for e in events if e.get('cat') == 'cuda_runtime' and e['name'] == 'cudaGraphLaunch']
    require(len(all_kernels) == 12 and len(all_launches) == 6, 'actual trace counts')
    observations = {}
    for graph in ('winner', 'default'):
        scopes = [e for e in events if e.get('cat') == 'user_annotation' and e['name'] == 'retained_' + graph]
        require(len(scopes) == 1, 'one retained CPU scope per graph')
        scope = scopes[0]
        launches = [e for e in all_launches if e['pid'] == scope['pid'] and e['tid'] == scope['tid']
                    and scope['ts'] <= e['ts'] and e['ts'] + e['dur'] <= scope['ts'] + scope['dur']]
        require(len(launches) == 3, 'three launches in original graph scope')
        graph_ids = set()
        sequences = []
        for launch in launches:
            kernels = sorted((e for e in all_kernels
                              if e['args']['correlation'] == launch['args']['correlation']), key=lambda e: e['ts'])
            require(len(kernels) == 2, 'one quantizer and GEMM per launch')
            graph_ids.update(e['args']['graph id'] for e in kernels)
            sequences.append([signature(e) for e in kernels])
        require(len(graph_ids) == 1, 'one actual CUDA graph identity per retained graph')
        require(all(x == sequences[0] for x in sequences), 'stable ordered launch signature')
        summary = next(x for x in worker['trace']['graphs'] if x['graph_id'] == graph)
        require(sequences[0] == summary['signatures'], 'actual trace matches recorded signatures')
        live = next(x for x in worker['graphs'] if x['id'] == graph)
        require(summary['graph_object_id'] == live['graph_object_id'], 'retained original graph object')
        require(summary['output_data_ptr'] == live['output']['data_ptr'], 'retained original output owner')
        observations[graph] = {'cuda_graph_id': next(iter(graph_ids)), 'signatures': sequences[0]}
    require(observations['winner']['cuda_graph_id'] != observations['default']['cuda_graph_id'], 'two actual graph identities')
    return observations


def inspect_worker(path, official):
    worker = json.loads(path.read_text())
    require(worker['status'] == 'success' and worker['mode'] == 'timing', 'timing worker success')
    require(len(worker['startup']['profiles']) == 81 and len(worker['rounds']) == 24, 'fixed profile and round counts')
    require(len(worker['correctness']) == 65 and all(x['passed'] for x in worker['correctness']), 'all numerical guards')
    require(len({x['check'] for x in worker['correctness']}) == 65, 'unique numerical check labels')
    require(sum(x['exact_zero_required'] for x in worker['correctness']) == 2, 'both changed-input zero guards')
    require(worker['final']['profile_attempts'] == 81 and not worker['forbidden_profile_attempts'], 'no later profiling')
    require(worker['final']['cache_unchanged'] and worker['final']['operands_unchanged'], 'cache/operand final guards')
    require(not worker['final']['active_v2'] and not worker['final']['is_tuning_mode'] and worker['final']['tuning_contexts'] == 0,
            'no leaked policy or tuning context')
    ratios, walls = [], []
    event_values = {'winner': [], 'default': []}
    strata = {'winner_first': [], 'default_first': []}
    pending = complete = 0
    for row in worker['rounds']:
        by_graph = {x['graph_id']: x for x in row['measurements']}
        require(set(by_graph) == {'winner', 'default'}, 'paired graph measurements')
        for graph, x in by_graph.items():
            require(x['replays'] == 16 and x['prequeue_cycles'] == 10000000, 'fixed replay/prequeue contract')
            require(x['profile_attempts_before'] == 81 and x['profile_attempts_after'] == 81, 'inactive replay sample')
            require(x['start_query_error'] is None, 'query succeeds')
            require(x['gpu_event_batch_ms'] > 0, 'positive measured duration')
            close(x['gpu_event_per_replay_ms'], x['gpu_event_batch_ms'] / 16, 'duration normalization')
            event_values[graph].append(x['gpu_event_batch_ms'] / 16)
            pending += x['start_event_complete_after_enqueue'] is False
            complete += x['start_event_complete_after_enqueue'] is True
        event_ratio = by_graph['winner']['gpu_event_batch_ms'] / by_graph['default']['gpu_event_batch_ms']
        wall_ratio = by_graph['winner']['wall_including_prequeue_ms'] / by_graph['default']['wall_including_prequeue_ms']
        ratios.append(event_ratio)
        walls.append(wall_ratio)
        strata['winner_first' if row['order'][0] == 'winner' else 'default_first'].append(event_ratio)
    require(all(len(x) == 12 for x in strata.values()), 'balanced replay order')
    result = dict(block=worker['block'], cell=worker['cell'], capture_order=worker['capture_order'],
                  event_ratio=statistics.median(ratios), wall_ratio=statistics.median(walls),
                  event_values={k: describe(v) for k,v in event_values.items()},
                  replay_order_strata={k: describe(v) for k,v in strata.items()},
                  pending_queries=pending, complete_queries=complete)
    close(result['event_ratio'], official['event_ratio'], 'official worker event estimate')
    close(result['wall_ratio'], official['wall_ratio'], 'official worker wall estimate')
    close(result['event_ratio'], worker['selected_over_default_graph_event_median'], 'producer worker event estimate')
    for graph in event_values:
        close(statistics.median(event_values[graph]), official['event_per_replay_ms'][graph]['median'], 'official absolute event median')
    for key in strata:
        close(statistics.median(strata[key]), official['order_strata_event_ratios'][key]['median'], 'official replay-order stratum')
    profiles = [x for x in worker['startup']['profiles'] if x['m'] == 144]
    require(len(profiles) == 9, 'actual M144 candidate rows')
    minimum = min(profiles, key=lambda x: x['elapsed_ms'])
    default = next(x for x in profiles if x['tactic'] == -1)
    explicit = min((x for x in profiles if x['tactic'] != -1), key=lambda x: x['elapsed_ms'])
    winner = next(x for x in worker['graphs'] if x['id'] == 'winner')
    require(winner['tactic'] == minimum['tactic'], 'selected actual first-minimum candidate')
    result.update(selected_tactic=winner['tactic'], selected_default=winner['tactic'] == -1,
                  m144_profile_default_ms=default['elapsed_ms'], m144_best_explicit_ms=explicit['elapsed_ms'],
                  m144_best_explicit_over_default=explicit['elapsed_ms'] / default['elapsed_ms'],
                  native_acceptance=worker['post_timing_acceptance'])
    require(result['native_acceptance']['pointers_unchanged'] and result['native_acceptance']['original_graph_replayed'], 'posttiming original-operand viability')
    if not result['selected_default']:
        require(result['native_acceptance']['used_descriptor'] == 1, 'explicit native acceptance')
    result['trace'] = trace_observation(path, worker)
    result['same_paired_kernel_signature'] = result['trace']['winner']['signatures'] == result['trace']['default']['signatures']
    result['raw_sha256'] = digest(path)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('raw', type=pathlib.Path)
    args = parser.parse_args()
    raw = args.raw
    official = json.loads((raw / 'analysis.json').read_text())
    require(official['status'] == 'passed' and official['validated_workers'] == 32, 'official fixed-cohort completion')
    official_by_key = {(x['block'], x['cell']): x for x in official['workers']}
    workers = [inspect_worker(raw / f'block{block}-{cell}-timing.json', official_by_key[(block,cell)])
               for block in range(8) for cell in CELLS]
    by_key = {(x['block'], x['cell']): x for x in workers}
    effects = {'objective': [], 'values': [], 'interaction': []}
    for block in range(8):
        a, b, c, d = [math.log(by_key[(block, cell)]['event_ratio']) for cell in CELLS]
        effects['objective'].append(((b-a)+(d-c))/2)
        effects['values'].append(((c-a)+(d-b))/2)
        effects['interaction'].append((d-c)-(b-a))
    bootstrap = {key: [] for key in effects}
    rng = random.Random(202610241803)
    for _ in range(200000):
        indices = [rng.randrange(8) for _ in range(8)]
        for key, values in effects.items():
            bootstrap[key].append(math.exp(sum(values[i] for i in indices)/8))
    factors = {}
    for key, values in effects.items():
        draws = sorted(bootstrap[key])
        tails = (0.025, 0.975) if key == 'interaction' else (0.0125, 0.9875)
        interval = [quantile(draws, p) for p in tails]
        estimate = math.exp(statistics.mean(values))
        target = official['statistics']['factor_estimates'][key]
        close(estimate, target['ratio_of_ratios'], 'official factor estimate')
        for actual, expected in zip(interval, target['bootstrap_interval']['bounds']):
            close(actual, expected, 'official frozen bootstrap interval')
        require(all(math.isclose(x,y,rel_tol=1e-13,abs_tol=1e-15) for x,y in zip(values,target['block_log_contrasts']['values'])), 'official per-block contrasts')
        factors[key] = dict(ratio_of_ratios=estimate, exploratory_interval=interval, block_log_contrasts=values,
                            descriptive_only_without_block0=math.exp(statistics.mean(values[1:])),
                            without_block0_limit='Sensitivity only; block0 is retained in the prespecified primary result.')
    cells = {}
    for cell in CELLS:
        rows = [x for x in workers if x['cell'] == cell]
        require(sum(x['capture_order'] == 'winner-first' for x in rows) == 4, 'balanced capture order by cell')
        cells[cell] = dict(event_ratios=describe([x['event_ratio'] for x in rows]),
                           explicit_selections=sum(not x['selected_default'] for x in rows),
                           material_regressions_gt_1_10=sum(x['event_ratio'] > 1.10 for x in rows),
                           capture_order_strata={order:describe([x['event_ratio'] for x in rows if x['capture_order'] == order])
                                                 for order in ('winner-first','default-first')})
        close(cells[cell]['event_ratios']['median'], official['statistics']['cells'][cell]['event_winner_over_default']['median'], 'official cell median')
    defaults = [x for x in workers if x['selected_default']]
    explicit = [x for x in workers if not x['selected_default']]
    require(len(defaults) == 31 and len(explicit) == 1, '31 default selections and one explicit selection')
    require(all(x['same_paired_kernel_signature'] for x in defaults), 'all default/default pairs have identical observed launch signatures')
    require(not explicit[0]['same_paired_kernel_signature'], 'explicit winner has different observed kernel signature')
    first_over_second = [(x['event_ratio'] if x['capture_order'] == 'winner-first' else 1/x['event_ratio']) for x in defaults]
    report = dict(schema_version=1, status='passed', scope='Independent raw numerical and interpretation audit; no GPU execution, analyzer import or source mutation.',
                  execution_commit=official['execution_commit'],
                  inputs=dict(raw_path=str(raw), official_analysis_sha256=digest(raw/'analysis.json'),
                              script_sha256=digest(pathlib.Path(__file__))),
                  independent_units=8, worker_count=32, profiles=32*81, paired_rounds=32*24,
                  replay_samples=32*48, numerical_checks=32*65, numerical_zero_input_checks=64,
                  actual_trace_launches=192, actual_trace_kernel_events=384,
                  pending_start_queries=sum(x['pending_queries'] for x in workers),
                  complete_start_queries=sum(x['complete_queries'] for x in workers),
                  factors=factors, cells=cells, workers=workers,
                  default_pairs=dict(count=31, same_observed_launch_signatures=31,
                                     capture_first_over_second=describe(first_over_second),
                                     first_capture_slower_count=sum(x>1 for x in first_over_second),
                                     limit='Capture-order association is descriptive; allocation, physical history and other mechanisms are not isolated.'),
                  inference=dict(established=[
                      'The fixed current-source research cohort completed with numerical, ownership, cache, posttiming acceptance and same-original-graph trace checks.',
                      'One auto/synthetic process selected an accepted explicit descriptor with a small profiling advantage and a materially slower retained serving graph.',
                      'Both primary factor intervals contain one; percent-level same-default capture-order effects remain visible.'
                  ], not_established=[
                      'No superiority, equivalence, safety, prevention of bad selection or production policy improvement is established.',
                      'Posttiming used_descriptor=1 establishes descriptor viability on retained operands; it does not directly record the earlier capture return.',
                      'Timing processes did not hash synthetic profiling bytes inline. Separate admission attestation does not make their physical histories identical.',
                      'The patched pinned source, fixed layer shape, input seed and hardware do not establish release behavior or model-level benefit.',
                      'Single aggregate tactic measurements do not identify the cause or uncertainty of the 0.63 percent profiling margin.'
                  ]),
                  recommendation=dict(sglang_policy_change='no_go',
                      next_contribution='Narrow upstream output-refresh correctness fix and its focused validation controls, kept separate from policy or persistence changes.',
                      next_bounded_work='Prepare a deterministic source/harness regression case around the saved accepted-descriptor versus default mismatch and an owner-facing explanation of the objective contract; no automatic cohort expansion.',
                      later_experiment_gate='Only run a separately frozen comparison if it tests a stated measurement mechanism or a deployment objective. Do not derive a margin threshold or safety claim from this one failure.'))
    report['checks_passed'] = CHECKS
    json.dump(report, sys.stdout, indent=2, sort_keys=True, allow_nan=False)
    print()


if __name__ == '__main__':
    main()
