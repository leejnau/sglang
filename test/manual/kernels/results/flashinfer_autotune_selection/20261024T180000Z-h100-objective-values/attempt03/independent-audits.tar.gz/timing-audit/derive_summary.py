"""Derive immutable summaries/counterexamples from independently audited raw."""
from __future__ import annotations
import argparse
import hashlib
import json
import statistics
from pathlib import Path

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(value,label):
    if not value:raise AssertionError(label)
def kernel_sequence(trace,name):
    events=trace['traceEvents']
    marker=next(row for row in events if row.get('cat')=='user_annotation' and row.get('name')=='retained_'+name)
    calls=sorted([row for row in events if row.get('cat')=='cuda_runtime' and 'cudaGraphLaunch' in row.get('name','') and marker['ts']<=row['ts']<=marker['ts']+marker['dur']],key=lambda row:row['ts'])
    require(len(calls)==3,'three original retained graph launches')
    sequences=[]
    for call in calls:
        kernels=sorted([row for row in events if row.get('cat')=='kernel' and row.get('args',{}).get('correlation')==call['args']['correlation']],key=lambda row:row['ts'])
        sequences.append([{'name':row['name'],**{key:row['args'].get(key) for key in ('device','grid','block','registers per thread','shared memory')}} for row in kernels])
    require(sequences[0]==sequences[1]==sequences[2],'ordered kernel sequence repeated')
    return sequences[0]

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--raw-root',type=Path,required=True);parser.add_argument('--audit',type=Path,required=True);parser.add_argument('--admission-audit',type=Path,required=True);parser.add_argument('--output-dir',type=Path,required=True);args=parser.parse_args()
    require(not args.output_dir.exists(),'refusing summary overwrite');args.output_dir.mkdir(parents=True)
    audit=json.loads(args.audit.read_text());admission=json.loads(args.admission_audit.read_text());require(audit['status']==admission['status']=='success','both independent audits passed')
    require(audit['statistics']['independent_blocks']==8 and len(audit['workers'])==32,'complete fixed cohort')
    admissions={cell:json.loads((args.raw_root/('admission-'+cell+'.json')).read_text()) for cell in audit['statistics']['cells']}
    records={};extra_checks=0
    for row in audit['workers']:
        name=f"block{row['block']}-{row['cell']}-timing.json";path=args.raw_root/name;data=json.loads(path.read_text());require(sha(path)==row['raw_sha256'],'actual raw result still matches independent audit')
        ref=admissions[row['cell']]
        require(data['startup']['rng_before']==ref['startup']['rng_before'] and data['startup']['rng_after']==ref['startup']['rng_after'],'actual cohort RNG states match separate byte-attested admission')
        require(data['startup']['candidate_order']==ref['startup']['candidate_order'],'actual endpoint candidate order matches admission')
        fields=('shape','dtype','device','targeted','cloned','copied')
        require([{key:item[key] for key in fields} for item in data['startup']['initializer_calls']]==[{key:item[key] for key in fields} for item in ref['startup']['initializer_calls']],'actual initializer recipe/layout matches admission')
        require(all(a['key']==b['key'] and a['settings']==b['settings'] for a,b in zip(data['startup']['profiles'],ref['startup']['profiles'],strict=True)),'actual profiling keys/settings match byte-attested admission')
        bootstrap=json.loads(path.with_suffix('.bootstrap.json').read_text())
        identity={name:{key:value[key] for key in ('library_sha256','ninja_sha256','sources','exports_checked')} for name,value in bootstrap['native']['providers'].items()}
        require(identity==admission['provider_identities'],'actual native providers match separate admission')
        records[(row['block'],row['cell'])]=data;extra_checks+=6
    exceptions=[]
    for worker in audit['workers']:
        if worker['event_ratio']<=1.10:continue
        data=records[(worker['block'],worker['cell'])];runtime=[row for row in data['startup']['profiles'] if row['m']==144];chosen=data['natural']['tactic'];selected=next(row for row in runtime if row['tactic']==chosen);default=next(row for row in runtime if row['tactic']==-1)
        profiles=sorted(runtime,key=lambda row:row['elapsed_ms']);graphs={row['id']:row for row in data['graphs']}
        trace_path=args.raw_root/Path(data['trace']['path']).name;trace=json.loads(trace_path.read_text())
        signatures={name:kernel_sequence(trace,name) for name in ('winner','default')}
        latencies={name:[row['gpu_event_per_replay_ms']*1000 for group in data['rounds'] for row in group['measurements'] if row['graph_id']==name] for name in ('winner','default')}
        raw_hex=None if chosen==-1 else b''.join(word.to_bytes(8,'little') for word in chosen).hex()
        exceptions.append({'block':worker['block'],'cell':worker['cell'],'raw_name':f"block{worker['block']}-{worker['cell']}-timing.json",'raw_sha256':worker['raw_sha256'],
            'selected_descriptor_words':chosen,'selected_descriptor_raw64_hex':raw_hex,'selected_descriptor_raw64_sha256':None if raw_hex is None else hashlib.sha256(bytes.fromhex(raw_hex)).hexdigest(),
            'runtime_profile_actual_m':144,'runtime_cache_m':256,'runtime_profile_order_index':next(i for i,row in enumerate(runtime) if row['tactic']==chosen),'global_measurement_index':selected['index'],
            'profile_selected_us':selected['elapsed_ms']*1000,'profile_default_us':default['elapsed_ms']*1000,
            'profile_selected_over_default':selected['elapsed_ms']/default['elapsed_ms'],'apparent_profile_advantage_fraction':1-selected['elapsed_ms']/default['elapsed_ms'],
            'runner_up_tactic':profiles[1]['tactic'],'selected_profile_settings':selected['settings'],
            'runtime_candidates_in_original_order':[{'order':i,'tactic':row['tactic'],'profile_us':row['elapsed_ms']*1000} for i,row in enumerate(runtime)],
            'retained_graph_event_ratio':worker['event_ratio'],'all24_pair_ratios':worker['round_event_ratios'],'pair_ratio_range':[min(worker['round_event_ratios']),max(worker['round_event_ratios'])],
            'rounds_above_one':sum(value>1 for value in worker['round_event_ratios']),'rounds_above1_10':sum(value>1.10 for value in worker['round_event_ratios']),
            'order_strata':worker['order_strata'],'per_graph_gpu_event_us':{name:{'median':statistics.median(values),'minimum':min(values),'maximum':max(values)} for name,values in latencies.items()},
            'capture_order':worker['capture_order'],'captured_read_operand_hashes':{name:row['read_operand_hashes'] for name,row in graphs.items()},
            'native_acceptance':data['post_timing_acceptance'],'actual_original_graph_launch_signatures':signatures,
            'same_quantizer_signature':signatures['winner'][0]==signatures['default'][0],'different_gemm_signatures':signatures['winner'][1:]!=signatures['default'][1:],
            'numerical_guards':len(data['correctness']),'all_numerics_passed':all(row['passed'] for row in data['correctness']),
            'zero_input_checks_exact':all(row['max_abs_error']==0 for row in data['correctness'] if row['exact_zero_required']),
            'max_quantized_reference_abs_error':max(row['max_abs_error'] for row in data['correctness']),
            'cache_state_unchanged':data['startup']['cache_state_sha256']==data['final']['cache_state_sha256'],'all_query_outcomes':worker['query_counts'],
            'trace_sha256':sha(trace_path),
            'interpretation':'Accepted, numerically correct explicit tactic won this synthetic-input eager/hot startup profile by a small measured margin, then its original full-layer graph was slower under the fixed independent replay oracle. This is a retained counterexample, not a serving-throughput or general algorithm-speed claim.'})
    counterexample={'status':'success','final_immutable':True,'material_threshold':1.10,'counterexamples':exceptions,'audit_sha256':sha(args.audit),'derivation_source_sha256':sha(__file__)}
    (args.output_dir/'counterexamples.json').write_text(json.dumps(counterexample,indent=2)+'\n')
    first=next(iter(records.values()));stats=audit['statistics']
    summary={'status':'success','final_immutable':True,'execution_commit':(args.raw_root/'sglang-commit-before.txt').read_text().strip(),
        'private_archive_sha256':'e972e9fa9abc02f841867b6e2921e11825c926ff3a337d5efc210ce54c0d7ddb',
        'source':first['source'],'fixture':{key:first['fixture'][key] for key in ('manifest_sha256','tensor_file_sha256','shape','quantized_input_sha256')},'environment':first['environment'],
        'protocol':{'blocks':8,'cells_per_block':4,'fresh_timing_processes':32,'input_seed':19,'paired_rounds_per_worker':24,'replays_per_sample':16,'prequeue_cycles':10_000_000,'prespecified_complete_cohort_retained':True},
        'validation':{'independent_timing_checks':audit['checks'],'independent_admission_checks':admission['checks'],'additional_cohort_admission_binding_checks':extra_checks,
            'positive_finite_cohort_profile_measurements':sum(len(data['startup']['profiles']) for data in records.values()),'cohort_numerical_guards':sum(len(data['correctness']) for data in records.values()),
            'timed_samples':1536,'query_counts':audit['query_counts'],'no_query_outcome_exclusion':True,'official_point_and_fixed_bootstrap_agree':audit['official_comparisons']},
        'primary_factor_results':{name:stats['factors'][name] for name in ('objective','values')},'secondary_interaction':stats['factors']['interaction'],
        'cell_results':stats['cells'],'observed_default_selections':sum(row['selected_default'] for row in audit['workers']),'observed_explicit_selections':sum(not row['selected_default'] for row in audit['workers']),
        'material_counterexample_count':len(exceptions),'material_counterexamples_file_sha256':sha(args.output_dir/'counterexamples.json'),
        'interpretation':'Both prespecified adjusted factor intervals include1. This pilot does not resolve a general objective or values benefit. One accepted explicit selection shows a stable large graph-replay regression despite correct output; keeping that rare outcome visible matters more than the near-neutral cell medians. The other three cells show0/8 observed material regressions each, which does not establish safety.',
        'next_decision':'Retain the verified counterexample as a focused measurement/selection diagnostic. Do not change production policy or claim a graph-policy fix from0/8. Any further GPU comparison should be separately specified; no automatic expansion or additional experiment follows this report.',
        'limits':['A single captured layer/geometry, fixed input seed and H100 source/image configuration; no full-model or serving-throughput measurement.','Research source is current27c62 plus the qualified FP8-only descriptor port and callback patch, not an unmodified release.','Main startup records metadata without synthetic input byte hashes. Separate admissions and actual RNG/source/key/settings comparisons bind the intended recipe, not a direct per-worker synthetic-byte attestation.','Synthetic/captured arms match clone/copy operations but differ in source content/address and possible physical history.','Small same-default normalized effects remain unresolved by prior recipe/capture calibration.','Eight complete blocks are inferential units.24 rounds are within-worker repetitions; cells and historical batches cannot be pooled for a per-cell rare-failure safety claim.','Native descriptor acceptance was checked on exact retained operands after timing; capture-time lookup and original trace are separate evidence.','Queued wall spans include a deliberate delay and are diagnostic only.'],
        'provenance':{'timing_audit_sha256':sha(args.audit),'admission_audit_sha256':sha(args.admission_audit),'derivation_source_sha256':sha(__file__),'plan_sha256':audit['plan_sha256'],'schedule_sha256':audit['schedule_sha256']}}
    (args.output_dir/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    token=bytes([118,108,108,109]);require(all(token not in path.read_bytes().lower() for path in args.output_dir.glob('*.json')),'safe publication byte scan')
    print(json.dumps({'status':'success','additional_cohort_admission_checks':extra_checks,'counterexamples':len(exceptions),'outputs':{path.name:sha(path) for path in args.output_dir.glob('*.json')}},indent=2))

if __name__=='__main__':main()
