"""Reproduce the frozen analyzer on public bytes and verify exact differences."""

import argparse
import copy
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("public", "source-root", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--source-commit", required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    archive = args.public / "raw-public.tar.gz"
    package = json.loads((args.public / "package-audit.json").read_bytes())
    assert sha(archive) == package["archive_sha256"]
    extracted = args.output / "extracted"
    extracted.mkdir()
    seen = set()
    with tarfile.open(archive, "r:gz") as bundle:
        for member in bundle:
            name = PurePosixPath(member.name)
            assert member.isfile() and not name.is_absolute() and ".." not in name.parts
            assert name.parts[0] == "raw" and member.name not in seen
            seen.add(member.name)
            payload = bundle.extractfile(member).read()
            assert bytes.fromhex("766c6c6d") not in payload.lower()
            target = extracted / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(payload)
    raw = extracted / "raw"
    manifest = json.loads((raw / "public-manifest.json").read_bytes())
    assert (raw / "public-manifest.json").read_bytes() == (args.public / "public-manifest.json").read_bytes()
    original = json.loads((raw / "cold-analysis.json").read_bytes())
    rerun_path = args.output / "public-analyzer-rerun.json"
    command = [
        sys.executable,
        str(args.source_root / "test/manual/kernels/results/flashinfer_autotune_selection/20261027T174000Z-h100-scoped-skips/analyze.py"),
        "--raw-root", str(raw), "--source-root", str(args.source_root),
        "--expected-source-commit", args.source_commit,
        "--output", str(rerun_path),
    ]
    completed = subprocess.run(command, text=True, capture_output=True)
    (args.output / "analyzer.log").write_text(completed.stdout + completed.stderr)
    assert completed.returncode == 0, completed.stdout + completed.stderr
    rerun = json.loads(rerun_path.read_bytes())
    normalized = copy.deepcopy(rerun)
    mapping = next(row for row in manifest["files"] if row["path"] == "cold.bootstrap.json")
    assert original["bootstrap_sha256"] == mapping["private_sha256"]
    assert rerun["bootstrap_sha256"] == mapping["public_sha256"] == sha(raw / "cold.bootstrap.json")
    changes = []
    if original["bootstrap_sha256"] != rerun["bootstrap_sha256"]:
        assert mapping["mode"] == "derived_inventory_only"
        changes.append(dict(path="bootstrap_sha256", original=original["bootstrap_sha256"], derived=rerun["bootstrap_sha256"]))
        normalized["bootstrap_sha256"] = original["bootstrap_sha256"]
    assert normalized == original
    result = dict(
        status="passed", source_commit=args.source_commit,
        scope="Exact frozen analyzer reproduction; indexed bootstrap file-hash substitution only",
        public_archive_sha256=sha(archive),
        public_manifest_sha256=sha(raw / "public-manifest.json"),
        original_analysis_sha256=sha(raw / "cold-analysis.json"),
        public_rerun_analysis_sha256=sha(rerun_path),
        reproduction_source_sha256=sha(Path(__file__)),
        analyzer_command=command, analyzer_returncode=completed.returncode,
        differences=changes, all_other_fields_equal=True,
        qualification_complete=rerun["qualification_complete"], findings=rerun["findings"],
        limits="No scientific field, original raw record or frozen protocol changed; native/build payloads remain in the preserved private archive.",
    )
    encoded = json.dumps(result, indent=2, sort_keys=True).encode() + b"\n"
    assert bytes.fromhex("766c6c6d") not in encoded.lower()
    (args.output / "public-analyzer-reproduction-audit.json").write_bytes(encoded)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
