"""Curate preserved scoped-cache evidence without editing original records.

The unchanged audited packager may omit only unrelated import-inventory labels
from bootstrap copies. Scientific files, caches, logs and errors stay byte-exact;
unexpected prohibited content fails closed and needs a reviewed mapping.
"""

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path

BASE_SHA = "7324863cb8598251d977dfdb71102621562ee828deb0ab50fdc1ad1cd97bd33c"
SCANNER_SHA = "c96c507702ab345cc4ac7bad36aef857788acda9982b54d3dae2faa01ab028a0"


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for data in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(data)
    return value.hexdigest()


def load(name, filename, expected):
    path = Path(__file__).with_name(filename)
    if digest(path) != expected:
        raise ValueError("Publication dependency differs: " + filename)
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def preservation(raw, phases):
    counts = {}
    for phase in phases:
        for suffix in ("log", "exit-code"):
            if not (raw / f"{phase}.{suffix}").is_file():
                raise ValueError("Missing declared phase evidence")
        record = json.loads((raw / f"preservation-manifest-{phase}.json").read_bytes())
        if record["phase"] != phase:
            raise ValueError("Preservation phase differs")
        seen = set()
        for row in record["files"]:
            path = Path(row["path"])
            if path.is_absolute() or ".." in path.parts or str(path) in seen:
                raise ValueError("Unsafe or repeated preservation path")
            seen.add(str(path))
            original = raw / path
            if original.stat().st_size != row["size"] or digest(original) != row["sha256"]:
                raise ValueError("Original preservation bytes differ: " + str(path))
        counts[phase] = len(seen)
    return counts


def prepare(raw, archive, output, expected_sha, phases):
    base = load("scoped_packager", "package_base.py", BASE_SHA)
    scanner = load("scoped_scanner", "assemble_public.py", SCANNER_SHA)
    base.PRIVATE_DIRS |= {"model", "checkpoint", "model-cache"}
    base.PRIVATE_SUFFIXES += (".bin", ".pt", ".ptx", ".ttir", ".ttgir", ".llir", ".source")
    original_exclusion = base.exclusion

    def exclusion(relative):
        if relative.name == "model-stream-plan.json":
            return "Private checkpoint transfer plan; original SHA remains bound by public provenance and preservation records."
        return original_exclusion(relative)

    base.exclusion = exclusion
    if digest(archive) != expected_sha:
        raise ValueError("Private archive differs from its preservation receipt")
    counts = preservation(raw, phases)
    packaged = base.package(raw, archive, output, expected_sha)
    scanner.scan("raw-public.tar.gz", (output / "raw-public.tar.gz").read_bytes())
    manifest = json.loads((output / "public-manifest.json").read_bytes())
    rows = {row["path"]: row for row in manifest["files"]}
    critical = []
    for original in sorted(raw.rglob("*")):
        if not original.is_file() or base.exclusion(original.relative_to(raw)):
            continue
        relative = str(original.relative_to(raw))
        if relative.endswith(".bootstrap.json"):
            continue
        if rows[relative]["mode"] != "byte_exact" or (output / "raw" / relative).read_bytes() != original.read_bytes():
            raise ValueError("Scientific or diagnostic evidence changed: " + relative)
        critical.append(relative)
    report = {
        "status": "passed",
        "phases": list(phases),
        "preservation_rows": counts,
        "private_archive_sha256": expected_sha,
        "public_archive_sha256": packaged["archive_sha256"],
        "public_manifest_sha256": packaged["manifest_sha256"],
        "critical_byte_exact_files": critical,
        "base_packager_sha256": BASE_SHA,
        "recursive_scanner_sha256": SCANNER_SHA,
        "wrapper_sha256": digest(Path(__file__)),
        "limits": [
            "Publication integrity only; no scientific findings or phase outcomes are selected or altered.",
            "Derived bootstrap copies have different file hashes. Original file hashes remain authoritative in the public mapping and preserved private archive.",
            "Native ELF/build caches, checkpoint/source payloads and private transfer plans stay private; their identities remain in bootstrap/provenance records.",
            "Unexpected prohibited bytes in scientific records or logs stop publication. No blind token or path replacement is performed.",
        ],
    }
    encoded = json.dumps(report, indent=2, sort_keys=True).encode() + b"\n"
    base.scanned_payload("publication-audit.json", encoded)
    (output / "publication-audit.json").write_bytes(encoded)
    if digest(archive) != expected_sha:
        raise ValueError("Private archive changed during curation")
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("raw-root", "private-archive", "output"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--expected-private-sha", required=True)
    parser.add_argument("--phases", nargs="+", choices=("preflight", "cold", "warm"), required=True)
    args = parser.parse_args()
    result = prepare(args.raw_root.resolve(), args.private_archive.resolve(), args.output.resolve(), args.expected_private_sha, args.phases)
    print(json.dumps({k: v for k, v in result.items() if k != "critical_byte_exact_files"}, indent=2))


if __name__ == "__main__":
    main()
