"""Independent saved-artifact checks; no imports from experiment code."""
import argparse
import hashlib
import json
import math
import subprocess
from pathlib import Path


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def review(raw, source, commit):
    checks = []
    def check(condition, label):
        if not condition:
            raise AssertionError(label)
        checks.append(label)
    def read(relative):
        return json.loads((raw / relative).read_text())
    def git_sha(relative):
        data = subprocess.check_output(['git', 'show', commit + ':' + relative], cwd=source)
        return hashlib.sha256(data).hexdigest()
    batch = 'test/manual/kernels/results/flashinfer_autotune_selection/20261027T174000Z-h100-scoped-skips/'
    plan = json.loads(subprocess.check_output(['git','show',commit+':'+batch+'plan.json'],cwd=source))
    w = read('cold.json')
    p = read('provenance.json')
    check(p['execution_commit'] == commit, 'frozen execution commit')
    check(p['plan_sha256'] == git_sha(batch+'plan.json'), 'frozen protocol digest')
    check(w['provenance'] == p and w['provenance_sha256'] == digest(raw/'provenance.json'), 'worker binds original provenance bytes')
    deps = {'worker_sha256':'audit_flashinfer_scoped_skip.py','parent_worker_sha256':'audit_flashinfer_replay_coverage.py','scoped_worker_sha256':'audit_flashinfer_scoped_cache.py','adapter_sha256':'audit_flashinfer_scoped_handoff.py'}
    for field, name in deps.items():
        path='test/manual/kernels/'+name
        check(w[field] == p['harness_source_sha256'][path] == git_sha(path), 'actual worker dependency: '+name)
    check(w['adapter_sha256'] == hashlib.sha256(subprocess.check_output(['git','show','02b783334418af5cddc711611e4b6a8b9b48905f:test/manual/kernels/audit_flashinfer_scoped_handoff.py'],cwd=source)).hexdigest(), 'CPU-qualified adapter unchanged')
    for path, expected in p['harness_source_sha256'].items():
        check(git_sha(path) == expected, 'source archive binds '+path)
    check({name: row['sha256'] for name,row in w['sources'].items()} == p['source_sha256'], 'actual imported source set matches provenance')
    for name,row in w['sources'].items():
        if name.startswith('sglang.'):
            check(row['sha256']==git_sha('python/'+name.replace('.','/')+'.py'), 'imported production source '+name)
        else:
            relative=name.removeprefix('flashinfer.').replace('.','/')+'.py'
            check(row['sha256']==plan['environment']['flashinfer_source_sha256'][relative], 'qualified dependency '+name)
    check(w['status']=='completed' and w['study']=='actual_model_scoped_skip_handoff' and w['phase']=='cold', 'completed intended worker')
    check(w['model_id']==plan['model']['repository'] and w['model_revision']==plan['model']['revision'], 'pinned model identity')
    check(w['environment']['gpu']=='NVIDIA H100 NVL' and w['environment']['capability']==[9,0] and w['environment']['torch']==plan['environment']['torch'], 'qualified hardware/framework')
    check(w['started_ns'] < w['finished_ns'], 'worker chronology')
    check(w['server_args']['flashinfer_autotune_skip_ops']==['fp8_gemm'] and w['server_args']['tp_size']==1, 'configured FP8 skip and TP1')
    check(w['server_args']['cuda_graph_config']=={'decode':{'backend':'full','bs':[1],'max_bs':1},'prefill':{'backend':'disabled'}}, 'one full decode graph')
    check(w['profile_calls']==[] and w['protocol_calls']==[] and w['graph_replays']==3, 'zero profiling/custom protocols, three retained replays')
    life=w['scoped_lifecycle']; ref=life['legacy_reference_state']; cache=life['legacy_reference_cache']
    check(life['configured_skips']==life['resolved_skips']==['fp8_gemm'], 'configured and resolved skips agree')
    check(life['region_root']==p['persistent_cache_roots']['managed'], 'graph identity root comes from protocol')
    check(ref['winner_identity'] is None and ref['skip_ops']==[] and not ref['is_tuning'] and not ref['in_v2_context'] and not ref['ambient_store'] and not ref['managed_store'], 'legacy ownership before graph region')
    identity=life['tune']['state_inside']['winner_identity']
    check(identity[0]==life['region_root'] and life['region_policy']=={'measure_execution_mode':'cuda_graph'}, 'explicit graph identity/policy')
    for name, state, tuning in [('prepare',life['tune']['state_inside'],True),('replay',life['replay_state_inside'],False)]:
        check(state['winner_identity']==identity and state['is_tuning'] is tuning and state['strict_replay'] is (not tuning), name+' identity/mode')
        check(state['in_v2_context'] and state['cache_scope']=='context' and state['isolate_legacy'] and state['managed_store'] and not state['ambient_store'], name+' context ownership')
        check(state['skip_ops']==['fp8_gemm'] and state['policy_fields']=={'measure_execution_mode':'cuda_graph'}, name+' effective skip/policy')
    prep=life['tune']
    check(prep['profile_count_before']==prep['profile_count_after']==0 and prep['files_before']==prep['files_after']=={}, 'preparation neither profiles nor publishes')
    check(prep['state_inside']==prep['state_after_forward'], 'preparation preserves scope controls')
    check(len(prep['selections'])==128, '128 actual prepared selections')
    for i,row in enumerate(prep['selections']):
        check(row['op']=='fp8_gemm' and row['skip_active'] is True and row['selected_tactic']=='-1' and row['runner_is_first'] is True and row['capturing'] is False and row['state']==prep['state_inside'], 'prepared default under skip '+str(i))
    def report(value,status,count,owner,label):
        expected={'hits':0,'misses':0,'skipped':0,'dropped_records':0}
        expected[{'miss':'misses','skipped':'skipped'}[status]]=count
        check(all(type(value[k]) is int and value[k]==n for k,n in expected.items()), label+' counters')
        check(len(value['records'])==count and value['max_records']>=count,label+' complete records')
        for i,row in enumerate(value['records']):
            check(row['op']=='fp8_gemm' and row['selected_tactic']=='-1' and row['status']==status and row['source']==('skip_ops' if status=='skipped' else 'fallback') and row['runner']=='CublasFp8GemmRunner' and row['cache_identity']==owner,label+' selection '+str(i))
    stages=life['strict']['records']
    check([r['capturing'] for r in stages]==[False,False,True], 'actual two warmups and capture distinguished')
    for i,row in enumerate(stages):
        report(row['coverage'],'skipped',128,identity,'capture stage '+str(i))
        check(row['state_before']==row['state_after']==life['replay_state_inside'] and row['profile_count_before']==row['profile_count_after']==0,'capture controls and zero profiling '+str(i))
    report(life['strict']['coverage'],'skipped',384,identity,'aggregate capture')
    check(life['strict']['coverage']['records']==[item for row in stages for item in row['coverage']['records']], 'aggregate equals invocation records')
    for name in ['legacy_before','legacy_after']:
        report(life[name],'miss',128,None,name)
    neutral=256
    rows=w['numerical_reports']
    check([r['arm'] for r in rows]==['eager','graph']*3,'three numerical arm pairs')
    for i,row in enumerate(rows):
        graph=row['arm']=='graph'; count=0 if graph else 128
        report(row['coverage'],'miss',count,None,'numerical diagnostic '+str(i)); neutral+=count
        check(row['profile_delta']==0 and row['replay_delta']==int(graph),'numerical route '+str(i))
        check(row['state_before']==row['state_after']==ref and row['cache_before']==row['cache_after']==cache,'numerical ambient/cache restoration '+str(i))
    check(neutral==640,'640 genuine neutral default misses')
    check(life['complete'] is True and life['legacy_restored'] is True and len(life['reset_calls'])==3,'adapter completion and three extra resets')
    check(life['strict']['state_after']==life['legacy_exit_state']==ref and life['legacy_exit_cache']==cache,'actual legacy ownership restored')
    check(life['strict']['files_after']==w['managed_after_numerics']=={},'no managed publications')
    check(w['startup']['profile_count']==0 and w['startup']['eligible_linear_layers']==len(w['startup']['eligible_linears'])==128,'actual full-model FP8 coverage')
    check(w['startup']['cache']==w['inventory_after_numerics']=={'loaded':{},'memory':[]},'no in-memory or loaded winners')
    check(w['startup']['files']==w['cache_after_numerics'] and w['startup']['state']==w['final_state'],'serving preserves cache files and controls')
    check(w['cache_before_startup']=={},'cold legacy root empty')
    for path,snapshot in w['startup']['files'].items():
        actual=raw/'tuner-cache/cold'/path
        check(digest(actual)==snapshot['sha256'] and json.loads(actual.read_text())==snapshot['contents'],'actual legacy bytes '+path)
        check(set(snapshot['contents'])=={'_metadata','_generation'},'legacy metadata only '+path)
    check(not list((raw/'managed-cache/cold').rglob('*')),'actual saved managed directory empty or absent')
    calls=w['selection_calls']; startup=[r for r in calls if r['stage']=='startup' and r['state']['is_tuning']]
    check(startup and all(r['skip_active'] and r['state']['skip_ops']==['fp8_gemm'] for r in startup),'real startup honors skip without fixing its count')
    check(all(r['op']=='fp8_gemm' and r['selected_tactic']=='-1' and r['runner_is_first'] for r in calls),'all raw selections use first runner/default')
    check(sum(r['capturing'] is True for r in calls)==128,'128 raw calls actually inside CUDA capture')
    for stage,count in [('scoped_tune',128),('scoped_warmup',256),('scoped_capture',128)]:
        observed=[r for r in calls if r['stage']==stage]
        check(len(observed)==count and all(r['skip_active'] and r['state']['winner_identity']==identity for r in observed),'raw graph-stage selection binding '+stage)
    numbers=w['numerics']; cases=numbers['checks']
    check([r['case'] for r in cases]==['original','changed','restored'],'required numerical cases')
    tokens=[r['decode_token'] for r in cases]
    check(tokens[0]==tokens[2] and tokens[0]!=tokens[1],'actual changed/restored token challenge')
    prompts=[r['prompt_input_ids'] for r in cases]
    check(prompts[0] and prompts[0]==prompts[1]==prompts[2],'same genuine prefixes')
    for i,row in enumerate(cases):
        check(row['allclose'] is True and row['argmax_equal'] is True and row['atol']==0.05 and row['rtol']==0.01 and math.isfinite(row['max_abs_error']) and row['max_abs_error']>=0,'frozen numerical comparison '+str(i))
        eager,graph=row['arms']['eager'],row['arms']['graph']
        check(eager['output_shape']==graph['output_shape'] and all(type(n)is int and n>0 for n in eager['output_shape']),'real same-shaped logits '+str(i))
        check(eager['prefix_seq_lens']==graph['prefix_seq_lens']==[len(row['prompt_input_ids'])],'matching KV prefixes '+str(i))
        for arm,replays in [('eager',0),('graph',1)]:
            a=row['arms'][arm]
            check(a['finite'] and a['profile_delta']==0 and a['replay_delta']==replays and a['decode_token']==row['decode_token'] and a['prompt_input_ids']==row['prompt_input_ids'],'actual finite numerical route '+str(i)+' '+arm)
            check(a['graph_output_owner_unchanged'] and a['original_graph_unchanged'] and len(a['output_sha256'])==64,'cloned output and retained graph owner '+str(i)+' '+arm)
            check(a['poisoned_graph_output'] is (arm=='graph'),'poison freshness challenge '+str(i)+' '+arm)
        check(graph['graph_input_ids']==[row['decode_token']],'graph consumed actual token '+str(i))
        if row['max_abs_error']==0:
            check(eager['output_sha256']==graph['output_sha256'],'zero error agrees with independent output hashes '+str(i))
    check(numbers['changed_output'] is True and numbers['restored_output_allclose'] is True,'changed/restored result controls')
    check(cases[0]['arms']['graph']['output_sha256']!=cases[1]['arms']['graph']['output_sha256'],'changed graph output hashes differ')
    model=read('model-manifest.json')
    check(digest(raw/'model-manifest.json')==p['model_manifest_sha256']==plan['model']['manifest_sha256'],'original model manifest bytes')
    check(model==p['model'] and model['status']=='passed' and len(model['files'])==9,'verified real nine-file checkpoint')
    native=read('native-build-cache/reuse-manifest.json')
    check(native['status']=='passed' and digest(raw/'native-build-cache/reuse-manifest.json')==p['native_reuse_sha256'],'qualified native manifest bytes')
    check(digest(raw/'native-build-cache/model-stream-plan.json')==p['model_stream_plan_sha256']==plan['model']['stream_plan_sha256'],'fixed checkpoint streaming plan')
    reference=read('native-reference.bootstrap.json')
    check(digest(raw/'native-reference.bootstrap.json')==p['native_reference_sha256']=='7c4727aca3d99adcb3fe2f35d06f4408b512baa4fe9a91b975bdf77358fe205d','exact prior qualified native reference')
    expected_native={'gemm':plan['environment']['native_sha256']['gemm'],'trtllm_utils':plan['environment']['native_sha256']['delay']}
    for path,sha in native['native_files'].items():
        check(digest(raw/'native-build-cache/qualified-providers'/path)==sha,'actual preserved native file '+path)
    for phase in ['preflight','cold']:
        check((raw/(phase+'.exit-code')).read_text().strip()=='0' and (raw/('launcher-'+phase+'.exit-code')).read_text().strip()=='0',phase+' process and launcher exits')
        boot=read(phase+'.bootstrap.json'); result=read(phase+'.json'); snapshot=read('runtime-snapshot-'+phase+'.json')
        check(boot['status']=='passed' and boot['result_sha256']==digest(raw/(phase+'.json')),phase+' bootstrap binds actual result')
        check(boot['native_identity_passthrough'] is True,phase+' native identifiers preserved')
        check(boot['native_reuse']['manifest_sha256']==p['native_reuse_sha256'] and boot['native_reuse']['reference_sha256']==p['native_reference_sha256'],phase+' native provenance bindings')
        for name,provider in boot['native']['providers'].items():
            old=reference['native']['providers'][name]
            for field in ['library_path','library_sha256','ninja_path','ninja_sha256','sources','compile_commands']:
                check(provider[field]==old[field],phase+' actual provider '+name+' '+field)
        for boundary in ['before','after_build','after_worker']:
            b=boot['native_reuse'][boundary]
            check(b['status']=='passed' and b['elf_sha256']==expected_native,phase+' unchanged native ELF '+boundary)
        check(len(boot['native_reuse']['ninja_dry_runs'])==2 and all(r['returncode']==0 and r['stdout'].endswith('ninja: no work to do.\n') for r in boot['native_reuse']['ninja_dry_runs']),phase+' no native rebuild')
        check(snapshot['status']=='passed' and snapshot['native_files']==native['native_files'],phase+' runtime native snapshot')
        check(snapshot['model_files']=={r['path']:r['sha256'] for r in model['files']},phase+' model files rehashed on node')
        for label in ['before','after']:
            check(not(raw/('gpu-processes-'+label+'-'+phase+'.csv')).read_text().strip(),phase+' GPU processes empty '+label)
        check(not(raw/('sglang-status-after-'+phase+'.txt')).read_text().strip(),phase+' server process absent after execution')
    check(p['image_id']=='sha256:2e152727f0a5ce999172ec48203b2b292d41b3cb370976827718870557899caa' and p['image']==plan['environment']['image'],'qualified image bytes')
    check(p['gpu']['name']=='NVIDIA H100 NVL' and p['gpu']['driver_version']=='580.159.04' and p['gpu']['uuid'].startswith('GPU-'),'actual admitted GPU provenance')
    return {'status':'passed','check_count':len(checks),'checks':checks,'findings':[], 'source_commit':commit,'result_sha256':digest(raw/'cold.json'),'graph_skips':384,'prepared_skips':128,'neutral_decode_misses':640,'profile_calls':0,'retained_replays':3,'numerical_max_abs_errors':[r['max_abs_error'] for r in cases], 'method':'Independent stdlib inspection of original saved JSONs, source blobs, persisted cache bytes and preserved native binaries; no worker/analyzer imports and no rerun.', 'limits':'Output arrays and model weights are not in this archive: numerical assertions are source-bound recorded observations plus independent hashes, and checkpoint bytes were rehashed on the node. No native-kernel trace, cache-reuse or performance claim.'}

if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--raw-root',type=Path,required=True)
    p.add_argument('--source-root',type=Path,required=True)
    p.add_argument('--commit',required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    try:
        result=review(a.raw_root,a.source_root,a.commit)
    except Exception as error:
        result={'status':'failed','findings':[{'type':type(error).__name__,'message':str(error)}]}
    a.output.parent.mkdir(parents=True,exist_ok=True)
    a.output.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'checks':result.get('check_count'),'findings':result.get('findings'),'sha256':digest(a.output)}))
    raise SystemExit(result['status']!='passed')
