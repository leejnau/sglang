"""Independent stdlib audit of one frozen scoped-cache CPU proof run."""
import argparse
import ast
import hashlib
import json
import math
import subprocess
from pathlib import Path

COMMIT = "af0b27cabe97e334c3201e8ba55aa3b4da01662e"
WORKER_SHA = "e3aaff0ac276c4333b7f2254ee46a64c1cdbaaa65ba98965eda3ccaffabb49e5"
BASE_SHA = "62eeaadb792d6b9bc506afcfe41968495f36adff27ee24ee13fb81cebce05859"
PLAN_SHA = "7cfd8a13a21ec61b6a4df6be53d9bba379aadd36410b50cb807118b2e38d4b48"
STAGES = {
    "seed": (29, 6), "warm": (50, 0), "process_default": (30, 6),
    "memory": (31, 3), "overlap": (38, 0), "controls": (37, 0),
    "bundled": (20, 0), "invalidation": (27, 6),
}

def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    return sha_bytes(path.read_bytes())

def canonical(data):
    return json.dumps(data, sort_keys=True, separators=(",", ":")).encode()

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ("root", "repo", "source", "plan", "output"):
        parser.add_argument("--" + arg, type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    checks, errors = 0, []
    def check(name, condition):
        nonlocal checks
        checks += 1
        if not condition:
            errors.append(name)

    worker = args.repo / "test/manual/kernels/flashinfer_autotune_scoped_cache.py"
    base = args.repo / "test/manual/kernels/flashinfer_autotune_policy_lifecycle.py"
    check("worker SHA", sha(worker) == WORKER_SHA)
    check("inherited loader SHA", sha(base) == BASE_SHA)
    check("plan SHA", sha(args.plan) == PLAN_SHA)
    for path in (worker, base, args.plan):
        rel = path.relative_to(args.repo).as_posix()
        frozen = subprocess.check_output(["git", "show", COMMIT + ":" + rel], cwd=args.repo)
        check("committed bytes " + rel, frozen == path.read_bytes())
    plan = json.loads(args.plan.read_text())
    check("exact upstream base", plan["flashinfer_release_commit"] == "8dc1163fbfbec7098a2418276fd04bc1fa1aeaa5")
    for path, digest in plan["flashinfer_source_sha256"].items():
        check("complete module " + path, sha(args.source / path) == digest)
    check("no native overlay", plan["native_gemm_overlay_applied"] is False)
    check("no native execution", plan["native_code_executed"] is False)

    result_path = args.root / "result.json"
    result = json.loads(result_path.read_text())
    check("result success", result["status"] == "success")
    check("reported worker SHA", result["worker_sha256"] == WORKER_SHA)
    check("reported base SHA", result["base_worker_sha256"] == BASE_SHA)
    check("reported plan SHA", result["manifest_sha256"] == PLAN_SHA)
    reports = result["reports"]
    check("eight ordered stages", [r["stage"] for r in reports] == list(STAGES))
    check("eight declared fresh processes", result["fresh_processes"] == 8)
    pids = [r["pid"] for r in reports]
    check("eight distinct positive PIDs", len(set(pids)) == 8 and all(type(p) is int and p > 0 for p in pids))
    stage_summary, all_profiles, all_checks = {}, [], []
    for row in reports:
        name = row["stage"]
        stage = json.loads((args.root / (name + ".json")).read_text())
        check("retained report " + name, stage == row)
        check("stage success " + name, row["status"] == "success")
        check("stage assertion count " + name, len(row["checks"]) == STAGES[name][0])
        check("stage profile count " + name, len(row["profiles"]) == STAGES[name][1])
        for i, item in enumerate(row["checks"]):
            check("stage assertion " + name + "/" + str(i), item["passed"] is True)
        all_checks.extend(row["checks"])
        all_profiles.extend(row["profiles"])
        for i, profile in enumerate(row["profiles"]):
            label = name + "/profile/" + str(i)
            check(label + " candidate", type(profile["tactic"]) is int and profile["tactic"] in (-1, 0, 1))
            check(label + " finite positive", isinstance(profile["time_fixture"], (int, float)) and math.isfinite(profile["time_fixture"]) and profile["time_fixture"] > 0)
            wanted = 1 if profile["use_cuda_graph"] else 0
            expected = 1.0 if profile["tactic"] == wanted else 4.0 if profile["tactic"] == -1 else 2.0
            check(label + " controlled objective", profile["time_fixture"] == expected)
            check(label + " hot L2", profile["use_cold_l2_cache"] is False)
            identity = ast.literal_eval(profile["identity"])
            check(label + " matching partition", identity is not None if profile["use_cuda_graph"] else identity is None)
        for start in range(0, len(row["profiles"]), 3):
            triple = row["profiles"][start:start + 3]
            check(name + " complete triple " + str(start), {p["tactic"] for p in triple} == {-1, 0, 1})
            check(name + " consistent objective " + str(start), len({p["use_cuda_graph"] for p in triple}) == 1)
            best = min(triple, key=lambda p: p["time_fixture"])
            check(name + " correct minimum " + str(start), best["tactic"] == (1 if triple[0]["use_cuda_graph"] else 0))
        stage_summary[name] = {"pid": row["pid"], "assertions": len(row["checks"]), "controlled_profiles": len(row["profiles"])}
    check("262 assertions", len(all_checks) == result["assertions_passed"] == 262)
    check("21 controlled profiles", len(all_profiles) == 21)
    check("15 graph profiles", sum(p["use_cuda_graph"] for p in all_profiles) == 15)
    overlap_names = [item["name"] for item in reports[4]["checks"]]
    for label in (
        "scoped thread sees old ambient without changing it",
        "scoped target survives another thread attachment",
        "other thread can replace ambient", "reader thread exits",
        "reader thread passes", "thread-local context cleaned",
    ):
        check("normal/error overlap " + label, overlap_names.count(label) == 2)
    control_names = [item["name"] for item in reports[5]["checks"]]
    for label in (
        "nested v2 rejected", "scoped reload fails before mutating caches",
        "unsafe shortlist tuning rejected", "single-winner rank delegates safely",
        "shortlist guard preserves legacy winner bank",
        "outer tuning counter behavior unchanged",
    ):
        check("explicit outcome " + label, control_names.count(label) == 1)

    legacy_path = args.root / "legacy.json"
    legacy = json.loads(legacy_path.read_text())
    generation = legacy.pop("_generation")
    check("v1 content generation", generation == sha_bytes(canonical(legacy)))
    check("v1 metadata", legacy["_metadata"] == plan["cpu_metadata_fixture"])
    legacy_entries = {k: v for k, v in legacy.items() if k.startswith("(")}
    check("one v1 winner", len(legacy_entries) == 1)
    file_key, value = next(iter(legacy_entries.items()))
    check("v1 winner0", value[:2] == ["PolicyRunner", 0])
    check("v1 provenance", value[2] == ["cuda_graph_profile_replays", None, "l2_cache_policy", "hot"])
    check("v1 operation key", ast.literal_eval(file_key) == ("manual::policy_lifecycle", "PolicyRunner", ((2, 3),), ()))
    expected_legacy = {"_metadata": plan["cpu_metadata_fixture"], file_key: value, "_generation": generation}
    check("v1 exact serializer bytes", legacy_path.read_bytes() == json.dumps(expected_legacy, indent=2).encode())

    managed = []
    for root_name in ("graph-store", "process-store", "invalidation-store"):
        manifests = list((args.root / root_name).glob("v2/*/manifest.json"))
        entries = list((args.root / root_name).glob("v2/*/entries/*.json"))
        check(root_name + " one manifest", len(manifests) == 1)
        check(root_name + " one entry", len(entries) == 1)
        manifest = json.loads(manifests[0].read_text())
        expected_manifest = dict(plan["cpu_metadata_fixture"], measure_execution_mode="cuda_graph", cache_schema="v2")
        check(root_name + " full identity", manifest == expected_manifest)
        check(root_name + " environment hash", manifests[0].parent.name == sha_bytes(canonical(manifest))[:16])
        entry = json.loads(entries[0].read_text())
        check(root_name + " winner1", entry["runner"] == "PolicyRunner" and entry["tactic"] == 1)
        check(root_name + " shared operation key", entry["key"] == file_key)
        check(root_name + " entry filename", entries[0].stem == sha_bytes(file_key.encode())[:24])
        check(root_name + " graph provenance", entry["profiling_policy"] == ["cuda_graph_profile_replays", 1, "l2_cache_policy", "hot"])
        def decode(obj):
            if isinstance(obj, dict) and set(obj) == {"__tuple__"}:
                return tuple(decode(x) for x in obj["__tuple__"])
            return obj
        check(root_name + " structural key", decode(entry["key_fields"]) == ast.literal_eval(file_key))
        managed.append({"root": root_name, "manifest_sha256": sha(manifests[0]), "entry_sha256": sha(entries[0]), "tactic": entry["tactic"]})
    for name in ("absent-store", "memory-context-must-not-create", "bundled-miss", "new-ambient-store"):
        check("no write to " + name, not (args.root / name).exists())
    check("three persistent entries total", len(list(args.root.glob("*-store/v2/*/entries/*.json"))) == 3)
    check("no atomic temp leaks", not list(args.root.rglob("*.tmp")))
    artifacts = {str(p.relative_to(args.root)): sha(p) for p in sorted(args.root.rglob("*")) if p.is_file()}
    audit = {
        "status": "success" if not errors else "failure", "immutable_final": True,
        "source_commit": COMMIT, "worker_sha256": WORKER_SHA,
        "base_worker_sha256": BASE_SHA, "plan_sha256": PLAN_SHA,
        "audit_source_sha256": sha(Path(__file__)), "result_sha256": sha(result_path),
        "independent_assertions": checks, "errors": errors,
        "proof_assertions": 262, "fresh_processes": 8, "controlled_profiles": 21,
        "zero_profile_stages": [name for name, counts in STAGES.items() if counts[1] == 0],
        "stages": stage_summary, "legacy_file_sha256": sha(legacy_path),
        "legacy_generation": generation, "managed_entries": managed,
        "raw_artifact_sha256": artifacts,
        "limits": [
            "Synthetic CPU runner and controlled profile times; no CUDA, native-kernel or serving-performance evidence.",
            "Rechecks retained records and serialized bytes; does not rederive unavailable intermediate live tensors.",
            "Overlap qualifies replay attachment only; concurrent tuning and serving remain unqualified.",
            "Uses scoped managed graph persistence beside v1 JSON; does not add graph-policy export to v1 JSON.",
        ],
    }
    args.output.write_text(json.dumps(audit, indent=2) + "\n")
    args.output.chmod(0o444)
    print(json.dumps({key: audit[key] for key in ("status", "independent_assertions", "errors", "result_sha256")}))
    if errors:
        raise SystemExit(1)

if __name__ == "__main__":
    main()
