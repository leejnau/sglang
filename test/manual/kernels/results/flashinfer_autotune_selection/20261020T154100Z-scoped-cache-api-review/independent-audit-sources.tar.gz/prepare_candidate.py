"""Build a review-only scoped-cache proposal from a pinned upstream snapshot."""

import difflib
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path('/private/tmp/fi-policy-api-review-20261020')
COMMIT = '8dc1163fbfbec7098a2418276fd04bc1fa1aeaa5'
BASE = ROOT / 'root' / COMMIT
CANDIDATE = ROOT / 'candidate'
assert not CANDIDATE.exists()
shutil.copytree(BASE, CANDIDATE)


def replace(name, old, new):
    path = CANDIDATE / name
    text = path.read_text()
    assert text.count(old) == 1, (name, old)
    path.write_text(text.replace(old, new))


cache = 'flashinfer/autotune_cache.py'
tuner = 'flashinfer/autotuner/autotuner.py'
replace(cache, 'def _resolve_managed_store(tuner, cache_root, manifest: Dict[str, str]):', 'def _resolve_managed_store(\n    tuner, cache_root, manifest: Dict[str, str], *, attach_ambient: bool = True\n):')
replace(cache, '        if store is not tuner._managed_cache:', '        if attach_ambient and store is not tuner._managed_cache:')
replace(cache, '    *,\n    tuning_buckets: Optional[Tuple[int, ...]] = None,', '    *,\n    cache_scope: str = "process",\n    tuning_buckets: Optional[Tuple[int, ...]] = None,')
replace(cache, '    enable_tuning = mode == "tune"', '    if cache_scope not in ("process", "context"):\n        raise ValueError("cache_scope must be \'process\' or \'context\'")\n    enable_tuning = mode == "tune"')
replace(cache, '            store = _resolve_managed_store(tuner, cache_root, manifest)', '            store = _resolve_managed_store(\n                tuner, cache_root, manifest, attach_ambient=cache_scope == "process"\n            )')
replace(cache, '        local.measure = measurement_policy\n', '        local.measure = measurement_policy\n        local.cache_scope = cache_scope\n')
replace(cache, '            local.measure = None\n', '            local.measure = None\n            local.cache_scope = "process"\n')
replace(cache, '        tuning_buckets: Forwarded to :func:`flashinfer.autotune`.', '''        cache_scope: ``"process"`` (default) preserves ambient attachment and
            legacy lookup precedence. ``"context"`` targets its managed store
            only inside this scope, without ever changing the process ambient.
            An identified context excludes legacy-loaded and bundled configs;
            a replay miss uses the default tactic. Store objects and memos remain cached.
            With persistence disabled, an explicit policy uses its memory bank;
            no store is consulted. No policy (or an empty policy) preserves
            legacy memory/file lookup. Nested v2 scopes remain unsupported.
        tuning_buckets: Forwarded to :func:`flashinfer.autotune`.''')
replace(cache, '    the process ambient (last-wins).\n\n    A persistent', '    the process ambient (last-wins) when ``attach_ambient`` is True.\n\n    Context-scoped callers resolve and hydrate without mutating the ambient.\n    A persistent')
replace(cache, '''    A persistent autotune_v2 context always attaches its store as the ambient
    the moment it opens, so bare, context-free serving after the context
    exits resolves to it.  autotune_v2 does not nest, so there is no scoped
    variant to preserve an outer ambient for; sequential contexts are simply
    last-wins.  The store object (and its memos) is reused across identity
    switches via the registry.''', '''    Process-scoped contexts attach on entry for bare serving after exit;
    sequential process attachments are last-wins. Context-scoped resolution
    never changes that pointer, including while another thread attaches.
    Store objects and memos remain registered across identity switches.''')
replace(cache, '''    **Attach semantics**: ``persistent_cache=True`` attaches the managed
    store for the remainder of the process''', '''    **Attach semantics**: by default, ``persistent_cache=True`` attaches the
    managed store for the remainder of the process''')
replace(cache, '            # A persistent context always attaches its store as the process\n            # ambient (last-wins), so bare serving after it exits resolves\n            # to it.', '            # Process scope attaches as ambient; context scope only resolves\n            # and hydrates. It must never attach then restore global state.')
replace(tuner, '    measure: Any = None\n', '    measure: Any = None\n    cache_scope: str = "process"\n')
replace(tuner, '    def _winner_cache(self) -> dict:', '''    @property
    def _isolate_legacy_configs(self) -> bool:
        """Opt-in identified scopes own their winner sources exclusively."""
        local = self._v2_local
        return (
            local.active
            and local.cache_scope == "context"
            and self._winner_cache_identity() is not None
        )

    def _winner_cache(self) -> dict:''')
replace(tuner, '            if self._file_configs:\n', '            if self._file_configs and not self._isolate_legacy_configs:\n')
replace(tuner, '                and not self.is_tuning_mode\n', '                and not self.is_tuning_mode\n                and not self._isolate_legacy_configs\n')
replace(tuner, '                    op_has_file = any(\n', '                    op_has_file = not self._isolate_legacy_configs and any(\n')
replace(tuner, '''            self._file_configs.pop(key.file_key, None)
            self._file_config_policies.pop(key.file_key, None)''', '''            if not self._isolate_legacy_configs:
                self._file_configs.pop(key.file_key, None)
                self._file_config_policies.pop(key.file_key, None)''')
replace(tuner, '''        with self._lock:
            if self._override_tuning_buckets is not None or self._override_round_up:
                tuning_config = self._apply_tuning_overrides(tuning_config)

            input_shapes = tuple(self._get_input_sizes(inputs))
            profiles = self._generate_optimization_profiles(tuning_config, inputs)''', '''        if self._isolate_legacy_configs:
            raise RuntimeError(
                "rank_tactics(k>1) is not supported with a context-scoped cache identity"
            )

        with self._lock:
            if self._override_tuning_buckets is not None or self._override_round_up:
                tuning_config = self._apply_tuning_overrides(tuning_config)

            input_shapes = tuple(self._get_input_sizes(inputs))
            profiles = self._generate_optimization_profiles(tuning_config, inputs)''')
replace(cache, '''    tuner = AutoTuner.get()
    with tuner._lock:
        tuner.profiling_cache.clear()''', '''    tuner = AutoTuner.get()
    if tuner._v2_local.active and tuner._v2_local.cache_scope == "context":
        raise RuntimeError("reload inside a context-scoped cache is not supported")
    with tuner._lock:
        tuner.profiling_cache.clear()''')
replace(cache, '            legacy memory/file lookup. Nested v2 scopes remain unsupported.', '''            legacy memory/file lookup. Nested v2 scopes remain unsupported.
            Identified tuning scopes reject ``rank_tactics(k>1)``; reload inside
            a context scope is unsupported. Concurrent tuning/serving and
            distributed scoped-store coordination require separate qualification.''')
doc = 'docs/design_docs/autotuner_v2.md'
replace(doc, '''**Per-bucket or per-region measurement policy.** Explicit non-goal. Prefill (large M) and decode
(small M) land in disjoint shape buckets, so each bucket is served in one consistent mode; a
single ambient policy matching the mode-sensitive path is sufficient.''', '''**Mixed execution policies.** Actual framework execution and capture coverage determine the
policy; eager and graph buckets are not necessarily disjoint. An optional
`autotune_v2(..., cache_scope="context")` selects a managed identity for a bounded region
without changing the ambient store. The framework must tune covered profiles before capture
and use the same identity for capture-time lookup; full graph replay performs no Python lookup.
Eager tails stay outside that scope. Identified scopes do not inherit untagged legacy or bundled
configs. `cache_scope="process"` retains existing attachment and lookup behavior by default.
This does not change the process-global tuning-mode counter: concurrent tuning and serving
are not qualified by scoped attachment. Nested v2 contexts remain unsupported. Identified
scoped tuning rejects `rank_tactics(k>1)` until its winner writes honor the selected identity.
`autotune_v2_reload()` inside a context scope is unsupported; outside it still targets the
ambient store. Distributed scoped-store use and mutation/reload need separate qualification.''')
doc_path = CANDIDATE / doc
doc_text = doc_path.read_text()
start = doc_text.index("**Attach semantics.**")
end = doc_text.index("\n### 2.2 Store layout", start)
old_attach = doc_text[start:end]
new_attach = """**Attach semantics.** The default `cache_scope="process"` keeps process-lifetime
attachment: the last process attachment is used by bare inference after warmup.
`cache_scope="context"` instead resolves and hydrates the selected managed identity
without ever changing that process pointer. The framework must select the same
identity while tuning and during capture-time forward warmups and capture. Full
captured replay repeats no Python lookup. Eager tails remain outside the graph scope.
Scoped identities exclude legacy-loaded and bundled configs, leaving legacy serving
state intact. Store objects and their memos remain registered across scope exits.
Nested v2 contexts are still unsupported; nesting ordinary `autotune()` is unchanged.
Concurrent tuning/serving, distributed scoped-store use and scoped reload remain
outside this initial qualification.
"""
doc_path.write_text(doc_text[:start] + new_attach + doc_text[end:])
documentation_proposal = {
    'path': doc,
    'base_sha256': hashlib.sha256((BASE / doc).read_bytes()).hexdigest(),
    'candidate_sha256': hashlib.sha256(doc_path.read_bytes()).hexdigest(),
    'attach_section': {'start_anchor': '**Attach semantics.**', 'end_anchor': '\n### 2.2 Store layout', 'previous_section_sha256': hashlib.sha256(old_attach.encode()).hexdigest(), 'replacement': new_attach},
    'mixed_execution_section': {'start_anchor': '**Per-bucket or per-region measurement policy.**', 'end_anchor': '\n\n## 6. Limitations and future work', 'replacement': '**Mixed execution policies.**' + doc_path.read_text().split('**Mixed execution policies.**',1)[1].split('\n\n## 6. Limitations and future work',1)[0]},
    'retention': 'Full upstream documentation remains private; the public artifact carries sanitized replacement text and source hashes only.',
}
(ROOT / 'documentation-proposal.json').write_text(json.dumps(documentation_proposal, indent=2) + '\n')
files = [cache, tuner, doc]
patch = ''.join(''.join(difflib.unified_diff((BASE / name).read_text().splitlines(keepends=True), (CANDIDATE / name).read_text().splitlines(keepends=True), fromfile='a/' + name, tofile='b/' + name)) for name in [cache, tuner])
assert bytes([118, 108, 108, 109]) not in patch.encode().lower()
(ROOT / 'scoped-cache-proposal.patch').write_text(patch)
manifest = {
    'upstream_base_commit': COMMIT,
    'status': 'research-only proposal; no maintainer agreement or production adoption',
    'patch_sha256': hashlib.sha256(patch.encode()).hexdigest(),
    'files': [{'path': name, 'base_sha256': hashlib.sha256((BASE / name).read_bytes()).hexdigest(), 'candidate_sha256': hashlib.sha256((CANDIDATE / name).read_bytes()).hexdigest()} for name in files],
    'contract': 'Optional context cache ownership; default process behavior unchanged; context resolution never mutates ambient; identified scopes exclude legacy and bundled file sources.',
    'scope_change': 'Graph winners use a scoped v2 managed-store peer while eager/default retains v1 JSON. This relaxes the earlier proposed requirement to persist graph-policy winners in v1 JSON; no SGLang production change is authorized by this prototype.',
    'limits': ['Concurrent tuning/serving remains unqualified because existing tuning counters are process-global.', 'No nested v2 contexts.', 'No CUDA capture, native numerical or performance validation.', 'Current main is unreleased and does not include the separately qualified descriptor overlay.'],
}
(ROOT / 'candidate-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
plan = json.loads((ROOT / 'root/current-main-proof-plan.json').read_text())
plan['flashinfer_release'] = 'unreleased-main-scoped-cache-proposal'
plan['flashinfer_source_sha256'] = {name: hashlib.sha256((CANDIDATE / name).read_bytes()).hexdigest() for name in plan['flashinfer_source_sha256']}
(ROOT / 'candidate-proof-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
print(json.dumps({'candidate': str(CANDIDATE), 'patch_sha256': manifest['patch_sha256'], 'diff_lines': len(patch.splitlines())}))
