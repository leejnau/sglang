"""Verify that partial API fixes cannot pass the scoped-cache qualification."""

import hashlib
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/private/tmp/fi-policy-api-review-20261020')
REPO = Path('/private/tmp/sglang-autotune-selection-study')
PYTHON = '/private/tmp/sglang-policy-lifecycle-venv/bin/python'
WORKER = REPO / 'test/manual/kernels/flashinfer_autotune_scoped_cache.py'
plans = json.loads((REPO / 'test/manual/kernels/results/flashinfer_autotune_selection/20261020T154100Z-scoped-cache-api-review/candidate-proof-plan.json').read_text())
cases = [
    ('ambient-mutation', 'flashinfer/autotune_cache.py', '        if attach_ambient and store is not tuner._managed_cache:', '        if store is not tuner._managed_cache:', 'seed', 'cold graph scope never attaches ambient'),
    ('legacy-file-precedence', 'flashinfer/autotuner/autotuner.py', '            if self._file_configs and not self._isolate_legacy_configs:', '            if self._file_configs:', 'warm', 'actual choose_one tactic'),
    ('bundled-precedence', 'flashinfer/autotuner/autotuner.py', '                and not self.is_tuning_mode\n                and not self._isolate_legacy_configs\n', '                and not self.is_tuning_mode\n', 'bundled', 'actual choose_one tactic'),
]
reports = []
for name, file, before, after, failing_stage, message in cases:
    folder = ROOT / 'final/faults' / name
    folder.mkdir(parents=True)
    candidate = folder / 'source'
    shutil.copytree(ROOT / 'candidate', candidate)
    path = candidate / file
    text = path.read_text()
    assert text.count(before) == 1
    path.write_text(text.replace(before, after))
    plan = dict(plans)
    plan['flashinfer_source_sha256'] = {p: hashlib.sha256((candidate / p).read_bytes()).hexdigest() for p in plans['flashinfer_source_sha256']}
    manifest = folder / 'plan.json'
    manifest.write_text(json.dumps(plan, indent=2) + '\n')
    command = [PYTHON, str(WORKER), '--flashinfer-source', str(candidate), '--manifest', str(manifest), '--output-dir', str(folder / 'raw')]
    p = subprocess.run(command, cwd=REPO, capture_output=True, text=True)
    (folder / 'controller.log').write_text(p.stdout + p.stderr)
    raw = folder / 'raw' / (failing_stage + '.log')
    assert p.returncode != 0 and raw.exists(), (name, p.returncode)
    assert message in raw.read_text(), (name, raw.read_text())
    reports.append({'name': name, 'expected_failure': True, 'returncode': p.returncode, 'failing_stage': failing_stage, 'expected_error_substring': message, 'worker_sha256': hashlib.sha256(WORKER.read_bytes()).hexdigest(), 'manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(), 'changed_file': file, 'changed_file_sha256': hashlib.sha256(path.read_bytes()).hexdigest()})
(ROOT / 'final/fault-controls.json').write_text(json.dumps({'status': 'success', 'independent_partial_fix_negative_controls': reports}, indent=2) + '\n')
print(json.dumps({'status': 'success', 'partial_fix_negative_controls': len(reports)}))
