"""Retain sanitized API proposal evidence without copying upstream documents."""

import gzip
import hashlib
import json
import shutil
import subprocess
import tarfile
from pathlib import Path

ROOT = Path('/private/tmp/fi-policy-api-review-20261020')
REPO = Path('/private/tmp/sglang-autotune-selection-study')
BATCH = REPO / 'test/manual/kernels/results/flashinfer_autotune_selection/20261020T154100Z-scoped-cache-api-review'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def rec(p):
    return {'sha256': sha(p), 'size_bytes': p.stat().st_size}


def read(p):
    return json.loads(p.read_text())


def write(name, data):
    (BATCH / name).write_text(json.dumps(data, indent=2) + '\n')


def archive(name, files):
    rows = []
    with tarfile.open(BATCH / name, 'w:gz') as out:
        for p, member in files:
            assert p.is_file() and not p.is_symlink()
            assert bytes([118, 108, 108, 109]) not in p.read_bytes().lower(), p
            out.add(p, arcname=member, recursive=False)
            rows.append({'path': member, **rec(p)})
    with tarfile.open(BATCH / name) as data:
        for r in rows:
            value = data.extractfile(r['path']).read()
            assert hashlib.sha256(value).hexdigest() == r['sha256']
            assert len(value) == r['size_bytes']
    return {'path': name, **rec(BATCH / name), 'members': rows}


runs = {name: ROOT / 'final' / name / 'result.json' for name in ('scoped-candidate', 'legacy-candidate', 'legacy-upstream')}
runs['independent-scoped'] = ROOT / 'independent-final/result.json'
expected = {'scoped-candidate': 262, 'legacy-candidate': 191, 'legacy-upstream': 191, 'independent-scoped': 262}
for name, p in runs.items():
    assert read(p)['status'] == 'success' and read(p)['assertions_passed'] == expected[name]
shutil.copyfile(runs['scoped-candidate'], BATCH / 'results.json')
reports = [Path('/private/tmp/fi-scoped-cache-final-independent-audit.json'), Path('/private/tmp/fi-scoped-cache-independent-readiness.json')]
for p in reports:
    assert read(p)['status'] in ('success', 'passed')
sources = [Path('/private/tmp/fi-scoped-cache-independent-audit.py'), Path('/private/tmp/fi-scoped-cache-readiness-audit.py'), ROOT / 'prepare_candidate.py', ROOT / 'final_fault_controls.py', Path(__file__)]
source_index = archive('independent-audit-sources.tar.gz', [(p, p.name) for p in sources])
files = []
for prefix, base in [('formal', ROOT / 'final'), ('independent', ROOT / 'independent-final'), ('preflight', ROOT / 'prototype-preflight')]:
    for p in sorted(base.rglob('*')):
        if p.is_file() and 'source' not in p.relative_to(base).parts:
            files.append((p, prefix + '/' + str(p.relative_to(base))))
for name in ('patch-validation.json', 'source-pre-commit.log', 'final-source-pre-commit.log', 'driver-help.txt'):
    files.append((ROOT / name, name))
commands = {
    'execution_commit': 'af0b27cabe97e334c3201e8ba55aa3b4da01662e',
    'python': '/private/tmp/sglang-policy-lifecycle-venv/bin/python',
    'working_directory': str(REPO),
    'scoped_worker': 'test/manual/kernels/flashinfer_autotune_scoped_cache.py',
    'legacy_worker': 'test/manual/kernels/flashinfer_autotune_policy_lifecycle.py',
    'candidate_source': str(ROOT / 'candidate'),
    'upstream_source': str(ROOT / 'root/8dc1163fbfbec7098a2418276fd04bc1fa1aeaa5'),
    'formal_commands': [
        {'worker': 'scoped_worker', 'source': 'candidate_source', 'manifest': str(BATCH / 'candidate-proof-plan.json'), 'output_dir': str(ROOT / 'final/scoped-candidate'), 'exit_code': 0},
        {'worker': 'legacy_worker', 'source': 'candidate_source', 'manifest': str(BATCH / 'candidate-proof-plan.json'), 'output_dir': str(ROOT / 'final/legacy-candidate'), 'exit_code': 0},
        {'worker': 'legacy_worker', 'source': 'upstream_source', 'manifest': str(BATCH / 'upstream-proof-plan.json'), 'output_dir': str(ROOT / 'final/legacy-upstream'), 'exit_code': 0},
    ],
    'arguments': '--flashinfer-source <source> --manifest <manifest> --output-dir <output_dir>',
    'controlled_boundaries': 'Existing frozen CPU loader, finite profile table and metadata fixture. Managed-entry-point metadata export is bound to the same fixture; bundled-config probe uses a controlled hit response.',
    'clarification': 'Inherited plan wording about unchanged methods means the harness does not monkeypatch choose_one/search/persistence. Candidate source changes are explicit in the pinned proposed patch.',
    'preparation': 'Initial scoped choose_one controls passed203. Review found shortlist/invalidation write paths; guards were added before source freeze and262-check validation. Raw unified-diff whitespace was preserved compressed after a hook rewrote the plain work copy; no source candidate changed from that hook.',
    'scope': 'No SGLang production source change, GPU allocation, CI, upstream message or PR.',
}
(ROOT / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
files.append((ROOT / 'commands.json', 'commands.json'))
raw_index = archive('attempt01-raw.tar.gz', files)
write('raw-member-index.json', raw_index)
write('summary.json', {
    'status': 'success',
    'execution_commit': commands['execution_commit'],
    'upstream_base': '8dc1163fbfbec7098a2418276fd04bc1fa1aeaa5',
    'latest_stable': 'v0.7.2',
    'current_main_gaps_reproduced': True,
    'proofs': {name: {'checks': expected[name], 'fresh_processes': read(p)['fresh_processes'], **rec(p)} for name, p in runs.items()},
    'partial_fix_negative_controls': read(ROOT / 'final/fault-controls.json'),
    'proposal': {
        'keyword': 'cache_scope="context"',
        'default': 'Existing cache_scope="process" behavior is unchanged.',
        'context': 'Select own managed identity without changing ambient; exclude legacy-loaded and bundled sources only for identified context scopes.',
        'memory': 'PersistentFalse explicit policy uses its memory bank, no disk; empty/no policy retains legacy lookup.',
        'coexistence': 'Keep eager/default v1 persistence and add scoped managed graph persistence as a peer.',
        'scope_change': 'Graph winners no longer need a v1 JSON bridge; this is a proposed research direction, not an approved production migration.',
        'upstream_code_diff': {'files': 2, 'added_lines_including_docs_comments': 58, 'removed_lines': 20},
        'unsupported': ['Identified rank_tactics k>1 during tuning', 'Reload inside scoped context', 'Nested v2 contexts'],
    },
    'limits': read(runs['scoped-candidate'])['limits'] + ['True distributed coordination and mutation/reload of scoped stores remain unqualified.', 'Scope isolation does not constrain arbitrary global v1 load/save calls.'],
    'readiness': 'Concrete CPU-qualified upstream proposal ready for API discussion; no SGLang policy PR or performance claim.',
})
write('validation.json', {
    'status': 'success',
    'execution_commit': commands['execution_commit'],
    'run_records': {name: rec(p) for name, p in runs.items()},
    'independent_audits': [{'report': read(p), **rec(p)} for p in reports],
    'exact_audit_and_preparation_sources': source_index,
    'patch_validation': read(ROOT / 'patch-validation.json'),
    'patch_archive': rec(BATCH / 'scoped-cache-proposal.patch.gz'),
    'uncompressed_patch_sha256': hashlib.sha256(gzip.decompress((BATCH / 'scoped-cache-proposal.patch.gz').read_bytes())).hexdigest(),
    'raw_archive': rec(BATCH / 'attempt01-raw.tar.gz'),
    'raw_byte_comparison_passed': True,
    'commands': commands,
    'controlled_boundary_clarification': commands['clarification'],
    'production_or_cuda_claim': False,
})
print(json.dumps({'raw_members': len(raw_index['members']), 'raw_archive': rec(BATCH / 'attempt01-raw.tar.gz'), 'audit_sources': len(sources)}))
