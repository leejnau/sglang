#!/usr/bin/env python3
"""Read-only source and completed-result audit; no proof rerun."""
import ast
import gzip
import hashlib
import json
import re
import subprocess
from pathlib import Path

S = Path('/private/tmp/sglang-autotune-selection-study')
R = Path('/private/tmp/fi-policy-api-review-20261020')
B = 'test/manual/kernels/results/flashinfer_autotune_selection/20261020T154100Z-scoped-cache-api-review'
C = 'af0b27cabe97e334c3201e8ba55aa3b4da01662e'
U = '8dc1163fbfbec7098a2418276fd04bc1fa1aeaa5'
OUT = Path('/private/tmp/fi-scoped-cache-independent-readiness.json')
N = 0


def check(value, label):
    global N
    if not value:
        raise AssertionError(label)
    N += 1


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(p):
    return json.loads(p.read_text())


def frozen(path):
    return subprocess.check_output(['git', 'show', C + ':' + path], cwd=S)


def artifact(name):
    content = frozen(B + '/' + name)
    check(content == (S / B / name).read_bytes(), 'frozen artifact bytes: ' + name)
    return content


manifest = json.loads(artifact('candidate-manifest.json'))
candidate_plan = json.loads(artifact('candidate-proof-plan.json'))
upstream_plan = json.loads(artifact('upstream-proof-plan.json'))
archive = artifact('scoped-cache-proposal.patch.gz')
patch = gzip.decompress(archive)
check(digest(archive) == manifest['patch_archive']['sha256'], 'compressed patch hash')
check(digest(patch) == manifest['patch_sha256'] == manifest['patch_archive']['uncompressed_sha256'], 'exact patch bytes')
check(manifest['upstream_base_commit'] == U, 'pinned upstream source')
base = R / 'root' / U
candidate = R / 'candidate'

# Independently apply the unified diff to memory, validating every old line.
lines = patch.decode().splitlines(keepends=True)
i = 0
applied = {}
while i < len(lines):
    check(lines[i].startswith('--- a/'), 'old patch path')
    name = lines[i][6:].strip()
    i += 1
    check(lines[i].strip() == '+++ b/' + name, 'new patch path')
    i += 1
    old = (base / name).read_text().splitlines(keepends=True)
    new, position = [], 0
    while i < len(lines) and not lines[i].startswith('--- a/'):
        match = re.match(r'@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@', lines[i])
        check(match is not None, 'hunk header')
        start = int(match.group(1)) - 1
        check(start >= position, 'ordered nonoverlapping hunks')
        new.extend(old[position:start])
        position = start
        i += 1
        while i < len(lines) and not lines[i].startswith(('@@ ', '--- a/')):
            line = lines[i]
            check(line[0] in ' +- ', 'unified diff line type')
            if line[0] in ' -':
                check(old[position] == line[1:], 'exact original context/removal')
                position += 1
            if line[0] in ' +':
                new.append(line[1:])
            i += 1
    new.extend(old[position:])
    applied[name] = ''.join(new).encode()
    check(applied[name] == (candidate / name).read_bytes(), 'independent patch application: ' + name)
    ast.parse(applied[name].decode())
check(set(applied) == {'flashinfer/autotune_cache.py', 'flashinfer/autotuner/autotuner.py'}, 'two Python source changes only')
for row in manifest['files']:
    check(sha(base / row['path']) == row['base_sha256'], 'base source hash: ' + row['path'])
    check(sha(candidate / row['path']) == row['candidate_sha256'], 'candidate source hash: ' + row['path'])
doc = json.loads(artifact('documentation-proposal.json'))
text = (base / doc['path']).read_text()
for section in ('attach_section', 'mixed_execution_section'):
    spec = doc[section]
    begin, end = text.index(spec['start_anchor']), text.index(spec['end_anchor'], text.index(spec['start_anchor']))
    if 'previous_section_sha256' in spec:
        check(digest(text[begin:end].encode()) == spec['previous_section_sha256'], 'original documentation section')
    text = text[:begin] + spec['replacement'] + text[end:]
check(digest(text.encode()) == doc['candidate_sha256'], 'documentation replacement reconstruction')
for plan, root in ((candidate_plan, candidate), (upstream_plan, base)):
    check(plan['flashinfer_release_commit'] == U and plan['native_code_executed'] is False, 'source plan scope')
    for name, value in plan['flashinfer_source_sha256'].items():
        check(sha(root / name) == value, 'complete module source: ' + name)

driver = 'test/manual/kernels/flashinfer_autotune_scoped_cache.py'
helper = 'test/manual/kernels/flashinfer_autotune_policy_lifecycle.py'
driver_sha, helper_sha = digest(frozen(driver)), digest(frozen(helper))
check(sha(S / driver) == driver_sha and sha(S / helper) == helper_sha, 'frozen driver/helper bytes')
expected = {
    'scoped-candidate': {'seed': 29, 'warm': 50, 'process_default': 30, 'memory': 31, 'overlap': 38, 'controls': 37, 'bundled': 20, 'invalidation': 27},
    'legacy-candidate': {'seed': 44, 'plain_reload': 30, 'bridge_reload': 48, 'file_order': 21, 'controls': 48},
    'legacy-upstream': {'seed': 44, 'plain_reload': 30, 'bridge_reload': 48, 'file_order': 21, 'controls': 48}
}
summaries, pids = [], []
for cohort, stages in expected.items():
    root = R / 'final' / cohort
    result = read(root / 'result.json')
    scoped = cohort == 'scoped-candidate'
    plan_name = 'upstream-proof-plan.json' if cohort == 'legacy-upstream' else 'candidate-proof-plan.json'
    plan = upstream_plan if cohort == 'legacy-upstream' else candidate_plan
    check(result['status'] == 'success', cohort + ': result status')
    check(result['manifest_sha256'] == digest(frozen(B + '/' + plan_name)), cohort + ': frozen manifest')
    check(result['worker_sha256'] == (driver_sha if scoped else helper_sha), cohort + ': worker source binding')
    if scoped:
        check(result['base_worker_sha256'] == helper_sha, cohort + ': helper source binding')
    else:
        check(result['sglang_execution_commit'] == C, cohort + ': recorded execution commit')
    reports = result['reports']
    check([x['stage'] for x in reports] == list(stages), cohort + ': stage order')
    check(result['fresh_processes'] == len(reports) == len(stages), cohort + ': process count')
    check(result['assertions_passed'] == sum(stages.values()) == sum(len(x['checks']) for x in reports), cohort + ': assertion accounting')
    for report in reports:
        stage = report['stage']
        check(report == read(root / (stage + '.json')), cohort + '/' + stage + ': actual stage report')
        check(report['status'] == 'success' and len(report['checks']) == stages[stage], cohort + '/' + stage + ': assertions')
        pids.append(report['pid'])
        for assertion in report['checks']:
            check(assertion['passed'] is True, cohort + '/' + stage + ': ' + assertion['name'])
        if not scoped:
            check(report['torch'] == '2.14.1' and report['cuda_available'] is False, cohort + '/' + stage + ': recorded CPU environment')
            check(report['source_sha256'] == plan['flashinfer_source_sha256'], cohort + '/' + stage + ': actual source guard')
    summaries.append({'cohort': cohort, 'result_sha256': sha(root / 'result.json'), 'processes': len(reports), 'assertions': result['assertions_passed'], 'controlled_profile_counts': {x['stage']: len(x['profiles']) for x in reports}})
check(len(set(pids)) == len(pids) == 18, 'all eighteen process IDs distinct')
faults = read(R / 'final/fault-controls.json')
check(faults['status'] == 'success' and len(faults['independent_partial_fix_negative_controls']) == 3, 'partial fix negative controls')
for fault in faults['independent_partial_fix_negative_controls']:
    check(fault['expected_failure'] is True and fault['returncode'] != 0 and fault['worker_sha256'] == driver_sha, 'frozen worker detects partial fix: ' + fault['name'])
entries = list((R / 'final/scoped-candidate/graph-store').glob('v2/*/entries/*.json'))
check(len(entries) == 1 and read(entries[0])['tactic'] == 1, 'actual managed graph publication')
legacy = read(R / 'final/scoped-candidate/legacy.json')
check([v[1] for k, v in legacy.items() if k.startswith('(')] == [0], 'actual v1 eager winner preserved')
check(not OUT.exists(), 'unique report path')
report = {
    'status': 'success', 'audit_checks_passed': N,
    'frozen_sglang_commit': C, 'upstream_base_commit': U,
    'auditor_sha256': sha(Path(__file__)), 'driver_sha256': driver_sha, 'helper_sha256': helper_sha,
    'candidate_patch_sha256': digest(patch), 'candidate_manifest_sha256': digest(frozen(B + '/candidate-manifest.json')),
    'independent_patch_application_bytes_equal_candidate': True,
    'documentation_reconstruction_hash_matches': True,
    'cohorts': summaries, 'total_fresh_processes': len(pids), 'total_proof_assertions': 644,
    'negative_controls_report_sha256': sha(R / 'final/fault-controls.json'),
    'readiness': 'Bounded CPU proposal and legacy compatibility evidence is reviewable; no production routing, upstream approval, CUDA capture, distributed coordination, concurrent tuning/serving or performance qualification.',
    'scope_change': manifest['scope_change'],
    'claim_clarifications': [
        'Proposed graph winners use a v2 managed-store peer; the retained v1 JSON path is the eager/default peer.',
        'Candidate-plan language about no method changes describes harness replacement boundaries; the hash-checked source patch deliberately changes lookup logic.',
        'The invalidation helper control is not a distributed execution test; overlap controls exercise replay-only attachment.',
        'Legacy cohorts record Torch2.14.1 and CUDA unavailable. Scoped driver uses the same frozen helper guard rather than repeating those fields in stage reports.',
        'Fault-control report is checked as retained evidence; no fault variant or proof was re-executed by this audit.'
    ]
}
OUT.write_text(json.dumps(report, indent=2) + '\n')
OUT.chmod(0o444)
print(json.dumps({'status': 'success', 'checks': N, 'report': str(OUT), 'report_sha256': sha(OUT), 'script_sha256': sha(Path(__file__))}))
